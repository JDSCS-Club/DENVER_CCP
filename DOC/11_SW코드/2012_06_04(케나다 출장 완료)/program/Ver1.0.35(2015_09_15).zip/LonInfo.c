
#include "def.h"
#include "Variable.h"
#include "LonInfo.h"


extern VARIABLE_H m_Variable;
//******************************************************************************************
//	LONWORK �о ó�� �� ����
//******************************************************************************************
void LonWorkLoop()
{
	int i;
	int nTxPos = 0;
	UCHAR btTxBuf[128];
	UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;
	char szBuf[512];
	char szBuf2[64];
	
	if(m_Variable.m_nCDT_FaultDataStFlag == 1)
	{
		m_Variable.m_nCDT_FaultDataStFlag = 0;

		m_Variable.m_LIC_CNCS_Tx_Flag = TRUE;
		m_Variable.m_nTxDbg1msTimer = 0;

		nTxPos = 0;
		btTxBuf[nTxPos++] = STX;  // STX
		btTxBuf[nTxPos++] = 0x01; // Command Code
		btTxBuf[nTxPos++] = 0x00; // 0x00���� ����
		btTxBuf[nTxPos++] = 0x06; // ����
		btTxBuf[nTxPos++] = m_Variable.m_nLnWkTxFlag; // �����̼�(Recently):0x01, ����â(Historycal):0x02
		btTxBuf[nTxPos++] = 0x00; // 
		btTxBuf[nTxPos++] = WORD_H(DWORD_H(m_Variable.m_nDateTime2SecondCnt)); // �ð�(HH)
		btTxBuf[nTxPos++] = WORD_L(DWORD_H(m_Variable.m_nDateTime2SecondCnt)); // �ð�(HL)
		btTxBuf[nTxPos++] = WORD_H(DWORD_L(m_Variable.m_nDateTime2SecondCnt)); // �ð�(LH)
		btTxBuf[nTxPos++] = WORD_L(DWORD_L(m_Variable.m_nDateTime2SecondCnt)); // �ð�(LL)
		btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
		btTxBuf[nTxPos++] = ETX; // ETX
		LonWorkTx(btTxBuf,nTxPos);

		MyPrintf("MDS Falut Request : ",nTxPos);
		//for(i=0;i<nTxPos;i++) MyPrintf("%02X ",WORD_L(btTxBuf[i]));
		//MyPrintf("\r\n");
	}

	// NVSRAM�� ����� ������ RS232�� �����Ͽ� ������Ѵ�.
	if(m_Variable.m_bLnWkDbgTxFlag)
	{
		m_Variable.m_bLnWkDbgTxFlag = FALSE;
		m_Variable.m_nDbgTxPos = 0;
		m_Variable.m_nTxDbg1msTimer = 0;
	}
	
	if(m_Variable.m_nDbgTxPos < m_Variable.m_nNvsramPos) //m_nDbgTxPos = 0xFFFFFFFF �� �׻� ū ���� ������ �ִٰ� �����϶�� ���ɿ� ���� 0���� Ŭ���� �ȴ�.
	{
		if(m_Variable.m_nTxDbg1msTimer > 200)
		{
			m_Variable.m_nTxDbg1msTimer = 0;
			szBuf[0] = 0;
			for(i=0;i<(MIN(128,(UINT)(m_Variable.m_nNvsramPos-m_Variable.m_nDbgTxPos)));i++) {sprintf(szBuf2,"%02X ",pNvsram[m_Variable.m_nDbgTxPos+i]); strcat(szBuf,szBuf2);}
			strcat(szBuf,"\r\n");
			user_DebugPrint(szBuf);
			m_Variable.m_nDbgTxPos += 128;
		}
	}
	else
	if(m_Variable.m_nDbgTxPos == 0xFFFFFFFF)
	{
		if(nTxPos)
		{
			szBuf[0] = 0;
			sprintf(szBuf2,"[TX:%02d] ",nTxPos); strcat(szBuf,szBuf2);
			for(i=0;i<nTxPos;i++) {sprintf(szBuf2,"%02X ",WORD_L(btTxBuf[i])); strcat(szBuf,szBuf2);}
			strcat(szBuf,"\r\n");
			user_DebugPrint(szBuf);			
		}
	}
}
//******************************************************************************************
//	LonWorkRead
//******************************************************************************************
void LonWorkRead()
{
	int i;
	int nTmp;
	PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;
	UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;
	PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó���� ���� ���Ƿ� �������.
	UCHAR nKind;
	static UCHAR nOldKind = 0;
	UCHAR nRxLen;
	static int nRecRxPos = 0;
	UCHAR btRxBuf[256];
	static UCHAR btFtpOneRecRxBuf[1024];
	int nTxPos = 0;
	UCHAR btTxBuf[128];
	char szBuf[512];
	char szBuf2[64];
	
	nKind = WORD_L(pLnWkDp->btKind); 

	switch(nKind)
	{
	// FTP1~6 ��������
	case 1: case 2: case 3: case 4: case 5: case 6:
		nRxLen = 0;
		
		// ����
		if(nKind == 1)
		{
			nRecRxPos = 0;
			nRxLen = LonWorkRx(nKind,btRxBuf);
			if(nRxLen>6 && nRecRxPos<768)
			{
				memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);
				nTmp = (nRxLen-7);
				nRecRxPos += nTmp;
				
				szBuf[0] = 0;
				sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szBuf,szBuf2);
				if(nTmp < 128)
				{
					for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				else
				{
					for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
					strcat(szBuf,"..");
					for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				strcat(szBuf,"\r\n");
				user_DebugPrint(szBuf);
			}
		}
		else
		// �߰� ���ڵ� ����
		if(nKind >= 2 && nKind <= 5)
		{
			nRxLen = LonWorkRx(nKind,btRxBuf);
			if(nRxLen>6 && nRecRxPos<768)
			{
				memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);
				nTmp = (nRxLen-7);
				nRecRxPos += nTmp;

				szBuf[0] = 0;
				sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szBuf,szBuf2);
				if(nTmp < 128)
				{
					for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				else
				{
					for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
					strcat(szBuf,"..");
					for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				strcat(szBuf,"\r\n");
				user_DebugPrint(szBuf);
			}
		}
		else
		// ��
		if(nKind == 6)
		{
			nRxLen = LonWorkRx(nKind,btRxBuf);
			if(nRxLen>6 && nRecRxPos<768)
			{
				memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);
				nTmp = (nRxLen-7);
				nRecRxPos += nTmp;

				szBuf[0] = 0;
				sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szBuf,szBuf2);
				if(nTmp < 128)
				{
					for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				else
				{
					for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
					strcat(szBuf,"..");
					for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				strcat(szBuf,"\r\n");
				user_DebugPrint(szBuf);
			}
		}

		// ���̰� 0~127���� �´ٸ� �����͸� �����Ѵ�.
		if((nRxLen>6 && nRxLen<134))
		{
			if(NVSRAM_WAYSIDEONBUF_SIZE > m_Variable.m_nNvsramPos)
			{
				user_DebugPrint("***FTP File receive... ^^;;***\r\n");
				memcpy(&pNvsram[m_Variable.m_nNvsramPos],btFtpOneRecRxBuf,nRecRxPos);
				m_Variable.m_nNvsramPos += nRecRxPos;
			}
			else
			{
				MyPrintf("***FTP data buffer full..\r\n");
			}
				
			m_Variable.m_bLnWkFtpEndFlag = TRUE;
		}
		else
		if(nKind == 6)
		{
			if(NVSRAM_WAYSIDEONBUF_SIZE > m_Variable.m_nNvsramPos)
			{
				user_DebugPrint("***FTP File receive End ^..^ ***\r\n");
				memcpy(&pNvsram[m_Variable.m_nNvsramPos],btFtpOneRecRxBuf,nRecRxPos);
				m_Variable.m_nNvsramPos += nRecRxPos;
			}
			else
			{
				MyPrintf("***FTP data buffer full..\r\n");
			}
		}
							
		nOldKind = nKind;
		
		break;
			
	// �Ϲ� ��������(����)
	case 7:
		nRxLen = LonWorkRx(7,btRxBuf);

		if(m_Variable.m_nDbgTxPos == 0xFFFFFFFF)
		{
			szBuf[0] = 0;
			sprintf(szBuf2,"[RX:%02d] ",nRxLen); strcat(szBuf,szBuf2);
			for(i=0;i<nRxLen;i++) {sprintf(szBuf2,"%02X ",btRxBuf[i]); strcat(szBuf,szBuf2);}
			strcat(szBuf,"\r\n");
			user_DebugPrint(szBuf);
		}
		
		if(nRxLen)
		{
			nTxPos = 0;

			switch(btRxBuf[1])
			{
			// WAYSIDE ON ACK ����
			case 0x02: 

				m_Variable.m_nLnWkWaySideOnRxOk = 1;

				MyPrintf("WAYSIDE ON Flage On. \r\n");

				break;
				
			// FTP���� ��
			case 0x06: 
				if(m_Variable.m_nLnWkWaySideOnRxOk)
				{
					m_Variable.m_nLnWkWaySideOnRxOk--; 
					m_Variable.m_bLnWkFtpEndFlag = TRUE; 

					MyPrintf("FTP Sending END. \r\n");
				}
				break;
				
			// �ð���û, MPU�� DPRAM�� �����͸� ���� ���� ���ͷ�Ʈ�� �������������� LIC_LON���� �������� ����
			case 0x08:
				nTxPos = 0;

				if(m_Variable.m_LIC_CNCS_TimSetFlag && m_Variable.m_nCncsRxCheck1msTimer)
				{

					btTxBuf[nTxPos++] = STX; // STX
					btTxBuf[nTxPos++] = 0x09; // Command Code
					btTxBuf[nTxPos++] = 0x00; // 0x00���� ����
					btTxBuf[nTxPos++] = 0x06; // ����
					
					// Y.J ����
					btTxBuf[nTxPos++] = m_Variable.m_tmUtcTime.year;							// �� BCD
					btTxBuf[nTxPos++] = m_Variable.m_tmUtcTime.month;							// ��
					btTxBuf[nTxPos++] = m_Variable.m_tmUtcTime.day;								// ��
					btTxBuf[nTxPos++] = m_Variable.m_tmUtcTime.hour;							// ��
					btTxBuf[nTxPos++] = m_Variable.m_tmUtcTime.minute; 							// ��
					btTxBuf[nTxPos++] = m_Variable.m_tmUtcTime.second; 							// ��
					
					btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
					btTxBuf[nTxPos++] = ETX; // ETX
					LonWorkTx(btTxBuf,nTxPos);


					MyPrintf("TIME Sending : ");

				}
				break;
				
			// ���µ����� ��û, MPU�� DPRAM�� �����͸� ���� ���� ���ͷ�Ʈ�� �������������� LIC_LON���� �������� ����
			case 0x0A:
				m_Variable.m_nCarCnt = btRxBuf[4];
				if(m_Variable.m_nCarCnt < 1 && m_Variable.m_nCarCnt > 2) m_Variable.m_nCarCnt = 1;
				nTxPos = 0;

				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x0B; // Command Code
				btTxBuf[nTxPos++] = 0x00; // 0x00���� ����
				btTxBuf[nTxPos++] = 0x05; // ����
				btTxBuf[nTxPos++] = BitSwap(m_Variable.m_btSenseCommStBuf[0]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_Variable.m_btSenseCommStBuf[1]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_Variable.m_btSenseCommStBuf[2]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_Variable.m_btSenseCommStBuf[3]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_Variable.m_btSenseCommStBuf[4]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_Variable.m_btSenseCommStBuf[5]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_Variable.m_btSenseCommStBuf[6]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_Variable.m_btSenseCommStBuf[7]); // ���� ������
				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX
				LonWorkTx(btTxBuf,nTxPos);		
				
				memcpy(m_Variable.m_btSenseCommStBuf,m_Variable.m_btCommSt,8);

				MyPrintf("Unit State Data Sending : ");

				break;
				
			//������û
			case 0x0C:
				nTxPos = 0;
				memset(btTxBuf,0x00,sizeof(btTxBuf));

				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x0D; // Command Code

				// 2 : Firmware
				// 0 : Not used�� ����ϰ� ������ ��¥�� ��������ʴ´�.
				// 6 : ��������(LIC -> CDT) ����

				nTmp = MAX(1,WORD_L(btRxBuf[4]));
				nTmp = MIN((VER_BDD_MAX_CNT)+1,WORD_L(btRxBuf[4]));
				nTmp--;

				btTxBuf[nTxPos++] = m_Variable.LIC_VerList[nTmp][0] == NULL ? 6 : 2; // 2:����&����Ʈ, 6:����
				
				btTxBuf[nTxPos++] = 31; // �����ͱ���
				
				btTxBuf[nTxPos++] = btRxBuf[4]; // Index ��ȣ
				btTxBuf[nTxPos++] = m_Variable.LIC_VerList[nTmp][0] == NULL ? 6 : 4; // Type

				memcpy(&btTxBuf[nTxPos],&m_Variable.LIC_VerList[nTmp][0],strlen((char*)&m_Variable.LIC_VerList[nTmp][0]));
				nTxPos = nTxPos+9;

				btTxBuf[nTxPos+0] = ConvHex2Asc((m_Variable.m_btExVersionTbl[WORD_L(nTmp)]>>12)&0x0F); // Production Version
				btTxBuf[nTxPos+1] = '.'; // Production Version
				btTxBuf[nTxPos+2] = ConvHex2Asc((m_Variable.m_btExVersionTbl[WORD_L(nTmp)]>>8)&0x0F); // Production Version
				btTxBuf[nTxPos+3] = '.'; // Production Version
				btTxBuf[nTxPos+4] = ConvHex2Asc((m_Variable.m_btExVersionTbl[WORD_L(nTmp)]>>4)&0x0F); // Production Version
				btTxBuf[nTxPos+5] = ConvHex2Asc((m_Variable.m_btExVersionTbl[WORD_L(nTmp)]&0x0F)); // Production Version
				btTxBuf[nTxPos+6] = '';
				nTxPos = nTxPos+9;

				btTxBuf[nTxPos+0] = ConvHex2Asc((m_Variable.m_btExVersion_DAYTbl[WORD_L(nTmp)]>>28)&0xF);// '2': // Year
				btTxBuf[nTxPos+1] = ConvHex2Asc((m_Variable.m_btExVersion_DAYTbl[WORD_L(nTmp)]>>24)&0xF);// '0': // Year
				btTxBuf[nTxPos+2] = ConvHex2Asc((m_Variable.m_btExVersion_DAYTbl[WORD_L(nTmp)]>>20)&0xF);// '1': // Year
				btTxBuf[nTxPos+3] = ConvHex2Asc((m_Variable.m_btExVersion_DAYTbl[WORD_L(nTmp)]>>16)&0xF);// '2': // Year
				btTxBuf[nTxPos+4] = '-';
				btTxBuf[nTxPos+5] = ConvHex2Asc((m_Variable.m_btExVersion_DAYTbl[WORD_L(nTmp)]>>12)&0xF);// '0': // Month
				btTxBuf[nTxPos+6] = ConvHex2Asc((m_Variable.m_btExVersion_DAYTbl[WORD_L(nTmp)]>>8)&0xF);// '1': // Month
				btTxBuf[nTxPos+7] = '-';
				btTxBuf[nTxPos+8] = ConvHex2Asc((m_Variable.m_btExVersion_DAYTbl[WORD_L(nTmp)]>>4)&0xF);// '0': // Day
				btTxBuf[nTxPos+9] = ConvHex2Asc((m_Variable.m_btExVersion_DAYTbl[WORD_L(nTmp)])&0xF);// '1' : // Day
				btTxBuf[nTxPos+10] = '';
				nTxPos = nTxPos+11;

				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX

				if(WORD_L(btRxBuf[4]) != 2)
				{
					LonWorkTx(btTxBuf,nTxPos);
				}

				MyPrintf("Unit Ver Sending : ");

				break;

			//�������(Single or married A)
			case 0x0E:
				m_Variable.m_btCttSignalA.BYTE = btRxBuf[4];

				m_Variable.m_bCiFaultFlag = (btRxBuf[4]&0x10) ? TRUE : FALSE; 

				MyPrintf("Atcive_CAB - Traction - Sp - All_Door_Close - Ci_CutOff = 0x[%02X] \r\n",btRxBuf[4]);

				break;
				
			// �������� ���� ��û
			case 0x10:
				nTxPos = 0;
				memset(btTxBuf,0x00,sizeof(btTxBuf));

				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x11; // Command Code
				btTxBuf[nTxPos++] = 0x00; // Message Code
				btTxBuf[nTxPos++] = 0x02; // ����
				btTxBuf[nTxPos++] = WORD_H(m_Variable.m_TrainCofVal); // ������
				btTxBuf[nTxPos++] = WORD_L(m_Variable.m_TrainCofVal); // ������
				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX
				LonWorkTx(btTxBuf,nTxPos);

				MyPrintf("Door State[X] : ",m_Variable.m_TrainCofVal);

				break;
				
			// CI ��ġ ��û
			case 0x12:
				nTxPos = 0;
				memset(btTxBuf,0x00,sizeof(btTxBuf));

				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x13; // Command Code
				btTxBuf[nTxPos++] = 0x00; // Message Code
				btTxBuf[nTxPos++] = 0x01; // ����
				if(m_Variable.m_nCarPos >= 1 && m_Variable.m_nCarPos <= 8)
				{
					btTxBuf[nTxPos++] = 0x00; // ������
					btTxBuf[nTxPos++] = MASKBIT(1,m_Variable.m_nCarPos-1); // ������
				}
				else
				{
					btTxBuf[nTxPos++] = 0x80; // ������
					btTxBuf[nTxPos++] = 0x00; // ������
				}
				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX
				LonWorkTx(btTxBuf,nTxPos);

				MyPrintf("C/I Position[X] : ",MASKBIT(1,m_Variable.m_nCarPos-1));

				break;
			
			// ������ȣ ��û
			case 0x14:
				nTxPos = 0;
				memset(btTxBuf,0x00,sizeof(btTxBuf));

				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x15; // Command Code
				btTxBuf[nTxPos++] = 0x00; // Message Code
				btTxBuf[nTxPos++] = 0x02; // ����
				btTxBuf[nTxPos++] = WORD_H(BCD_BIN(m_Variable.m_nCarNo));
				btTxBuf[nTxPos++] = WORD_L(BCD_BIN(m_Variable.m_nCarNo));
				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX
				LonWorkTx(btTxBuf,nTxPos);

				MyPrintf("Train NUM Sending[%X] : ",m_Variable.m_nCarNo);

				break;

			// CI���峭 ���� ��ġ ��û
			case 0x16:
				nTxPos = 0;
				memset(btTxBuf,0x00,sizeof(btTxBuf));

				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x17; // Command Code
				btTxBuf[nTxPos++] = 0x00; // Message Code
				btTxBuf[nTxPos++] = 0x02; // ����
				//if(m_Variable.m_btCiFaultVal != 0x8000 && m_Variable.m_btTestOtherCiFault != 0x8000) //
				if(m_Variable.m_btCiFaultVal != 0x8000 ) //
				{
					btTxBuf[nTxPos++] = 0x00;
					switch(m_Variable.m_TrainCofVal)
					{
						/*
					// 2��
					case 0: btTxBuf[nTxPos++] = 0xFC | m_Variable.m_btCiFaultVal | m_Variable.m_btTestOtherCiFault; break; // ������
					// 4��
					case 1: btTxBuf[nTxPos++] = 0xF0 | m_Variable.m_btCiFaultVal | m_Variable.m_btTestOtherCiFault; break; // ������
					// 6��
					case 2: btTxBuf[nTxPos++] = 0xC0 | m_Variable.m_btCiFaultVal | m_Variable.m_btTestOtherCiFault; break; // ������
					// 8��
					case 3: btTxBuf[nTxPos++] = 0x00 | m_Variable.m_btCiFaultVal | m_Variable.m_btTestOtherCiFault; break; // ������
					default:
							btTxBuf[nTxPos++] = 0x00 | m_Variable.m_btCiFaultVal | m_Variable.m_btTestOtherCiFault; break; // ������
						*/
						// 2��
					case 0: btTxBuf[nTxPos++] = 0xFC | m_Variable.m_btCiFaultVal ; break; // ������
						// 4��
					case 1: btTxBuf[nTxPos++] = 0xF0 | m_Variable.m_btCiFaultVal ; break; // ������
						// 6��
					case 2: btTxBuf[nTxPos++] = 0xC0 | m_Variable.m_btCiFaultVal ; break; // ������
						// 8��
					case 3: btTxBuf[nTxPos++] = 0x00 | m_Variable.m_btCiFaultVal ; break; // ������
					default:
						btTxBuf[nTxPos++] = 0x00 | m_Variable.m_btCiFaultVal ; break; // ������
					}
					//btTxBuf[nTxPos++] = m_btCiFaultVal | m_btTestOtherCiFault;
				}
				else
				{
					btTxBuf[nTxPos++] = 0x80;
					btTxBuf[nTxPos++] = 0x00;
				}
				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX
				LonWorkTx(btTxBuf,nTxPos);

				MyPrintf("Other C/I Fault Condition[%X] : ",m_Variable.m_btCiFaultVal);

				break;
			}

			if(nTxPos)
			{
				if(m_Variable.m_nDbgTxPos == 0xFFFFFFFF)
				{
					szBuf[0] = 0;
					sprintf(szBuf2,"[TX:%02d] ",nTxPos); strcat(szBuf,szBuf2);
					for(i=0;i<nTxPos;i++) {sprintf(szBuf2,"%02X ",WORD_L(btTxBuf[i])); strcat(szBuf,szBuf2);}
					strcat(szBuf,"\r\n");
					user_DebugPrint(szBuf);
				}			
			}
		}
		break;
	}
}
//******************************************************************************************
//	LonWorkRx
//******************************************************************************************
UCHAR LonWorkRx(int nRxPos, UCHAR *pRxBuf)
{
	int i;
	UCHAR nRxLen;
	UCHAR *pBuf;
	PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;

	if(nRxPos >= 1 && nRxPos <= 6)
	{
		nRxLen = MIN(sizeof(LNWKFTPIT)-1,WORD_L(pLnWkDp->lfBuf[nRxPos-1].btLen)+6);
		if(nRxLen > 6)
		{
			pBuf = &pLnWkDp->lfBuf[nRxPos-1].btStx;
			for(i=0;i<nRxLen;i++) pRxBuf[i] = WORD_L(pBuf[i]);

			//MyPrintf("[Len:%d,Pos:%d->",nRxLen,nRxPos);
			//for(i=0;i<nRxLen;i++) MyPrintf("%02X ",pRxBuf[i]);
			//MyPrintf("]\r\n");

			if(pRxBuf[0] == STX && pRxBuf[nRxLen-1] == ETX)
			{
				return nRxLen;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}
	else
		if(nRxPos == 7)
		{
			nRxLen = MIN(sizeof(LNWKGERIT),WORD_L(pLnWkDp->lgRxBuf.btLen)+6);
			if(nRxLen > 5)
			{
				pBuf = &pLnWkDp->lfBuf[nRxPos-1].btStx;
				for(i=0;i<nRxLen;i++) pRxBuf[i] = WORD_L(pBuf[i]);

				//MyPrintf("[Len:%d,Pos:%d->",nRxLen,nRxPos);
				//for(i=0;i<nRxLen;i++) MyPrintf("%02X ",pRxBuf[i]);
				//MyPrintf("]\r\n");

				if(pRxBuf[0] == STX && pRxBuf[nRxLen-1] == ETX && !Make1ByteBcc(&pRxBuf[1],nRxLen-2))
				{
					return nRxLen;
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;
		}

		return 0;
}
//******************************************************************************************
//	LonWorkTx
//******************************************************************************************
void LonWorkTx(UCHAR *pTxBuf,UCHAR nLen)
{
	int i;
	char szBuf[512];
	char szBuf2[64];

	UCHAR *pBuf;
	PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;

	pBuf = &pLnWkDp->lgTxBuf.btStx;

	memcpy(pBuf,pTxBuf,(int)nLen);
	LNWK_TXINTREQ();
}

//******************************************************************************************
//	1ms Loop
//******************************************************************************************
void LonInfo_1msLoop()
{
	int i;
	int nTxPos = 0;
	UCHAR btTxBuf[32];
	static UINT nDelayCnt = 0;

	if(m_Variable.m_nCarKindToLonCnt < 6 && !(nDelayCnt%2000))
	{
		m_Variable.m_nCarKindToLonCnt++;

		MyPrintf("Train NUM Sending[%X] : ",m_Variable.m_nCarNo);

		nTxPos = 0;
		btTxBuf[nTxPos++] = STX; // STX
		btTxBuf[nTxPos++] = 0xF0; // Command Code
		btTxBuf[nTxPos++] = 0x00; // Message Code
		btTxBuf[nTxPos++] = 0x02; // ����
		btTxBuf[nTxPos++] = WORD_H(m_Variable.m_nCarNo); // ������ȣ ����
		btTxBuf[nTxPos++] = WORD_L(m_Variable.m_nCarNo); // ������ȣ ����
		btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
		btTxBuf[nTxPos++] = ETX; // ETX
		LonWorkTx(btTxBuf,nTxPos);

		MyPrintf("[TX:%02d] ",nTxPos);
		for(i=0;i<nTxPos;i++) MyPrintf("%02X ",WORD_L(btTxBuf[i]));
		MyPrintf("\r\n");
	}

	nDelayCnt++;
}
