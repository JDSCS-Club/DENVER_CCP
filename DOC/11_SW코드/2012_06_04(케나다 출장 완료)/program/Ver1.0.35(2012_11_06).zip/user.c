#include "string.h"
#include "main.h"
#include "def.h"
#include "xr16l784.h"
#include "user.h"
#include "ds1647.h"

UINT m_nUserDebug1msTimer = 0;

UINT m_nTest1msTimer = 0;

UINT m_nUart1RxOneByteGapDelayTime = 0;
UINT m_nUart2RxOneByteGapDelayTime = 0;
UINT m_nUart3RxOneByteGapDelayTime = 0;

DATE_TIME_TYPE m_tmCurTime;
DATE_TIME_TYPE m_tmUtcTime;

RACK_DI mRackDi;

UCHAR m_btCommSt[8]; //LIC�� MDS�� ������  �� ��ġ ���� ���� ���� ������ �ִ� �κ�.
UCHAR m_btOldCommSt[8]; // ���� ������ �������� �����Ѵ�.
UCHAR m_btSenseCommStBuf[8]; // ���°����� 1�� �����Ǿ��� ��� ���� ���¸� �о� ���������� ���°��� ���������� �����ϴ� ����

int m_LIC_CNCS_Tx_Flag = 0; //���� ��� ���̶�� �÷���/ LIC<-> CNCS���۽� ����Ѵ�.
int m_LIC_CNCS_TX_DelyTime = 0;
int m_nLnWkTxFlag = 0; //���� ��� ���� �÷���.
int m_nFaultCnt = 0; //���� ���� ī����
int nRecving_Posi = 0; //�������̸鼭 ���� ����� ���� �ϸ� CNCS�� ����Ÿ ���� �Ѵ�.
int m_nCDT_FaultDataStFlag = 0;//���� ����� ���� Flag

//int m_TrainCofVal = 0x8000; // ������ �߷� ����(0:2,1:4,2:6,3:8), 0x8000�� �ʱ�ȯ ���� ���� ���� ��Ÿ��
//int m_nCarPos = 0x8000; // ���� ���� ��ġ(1~8ȣ�� �ش���), 0x8000�� �ʱ�ȯ ���� ���� ���� ��Ÿ��
//int m_btCiFaultVal = 0x8000; // C/I������ �߻��ϸ� ���峭 ȣ���� �ش� ��Ʈ�� SET�Ѵ�.(BIT7~0, 8~1ȣ���� �ǹ���), 0x8000�� �ʱ�ȯ ���� ���� ���� ��Ÿ��
//USHORT m_nCarNo = 0x8000; //  ������ȣ, 0x8000�� �ʱ�ȯ ���� ���� ���� ��Ÿ��
int m_TrainCofVal = 0x0000; // ������ �߷� ����(0:2,1:4,2:6,3:8), 0x8000�� �ʱ�ȯ ���� ���� ���� ��Ÿ��
int m_nCarPos = 0x0001; // ���� ���� ��ġ(1~8ȣ�� �ش���), 0x8000�� �ʱ�ȯ ���� ���� ���� ��Ÿ��
int m_btCiFaultVal = 0x8000; // C/I������ �߻��ϸ� ���峭 ȣ���� �ش� ��Ʈ�� SET�Ѵ�.(BIT7~0, 8~1ȣ���� �ǹ���), 0x8000�� �ʱ�ȯ ���� ���� ���� ��Ÿ��

USHORT m_nCarNo = 0000; //  ������ȣ, 0x8000�� �ʱ�ȯ ���� ���� ���� ��Ÿ��
char m_chCarKind = 'A'; // ������ȣ ��ȯ�� �ݵ�� ���� ������ ��ȯ�� ��
int m_nCarKindToLonCnt = 0; // ó���� 5ȸ ���� LON�� ������ȣ�� �����Ѵ�.
char m_chCarKindNum = 0; //

BOOL m_bLnWkDbgTxFlag = 0; //���� ��� Ȯ�� ��ű� �÷���. 
UCHAR m_nLnWkWaySideOnRxOk = 0; //���� ���� �Ϸ� �÷���. 
UCHAR m_nCarCnt = 0; // ���� ����
UINT m_nNvsramPos = 0;
BOOL m_bLnWkFtpEndFlag = FALSE;
UINT m_nDateTime2SecondCnt = 0; // �����丮�� ���۽� ���ϴ� �ð�(2000�� 1�� 1�� 0�� 0�� 0�ʺ��� �� ����, CNCS�� ���� �����͸� ���Ź޾� Wayside On�� �����Ѵ�.)

UINT m_nTxDbg1msTimer = 0;
UINT m_nDbgTxPos = 0xFFFFFFFF; 

UINT m_nSingleOrMarriedCarUpdate1msTimer = 0;

USHORT m_btExVersionTbl[VER_BDD_MAX_CNT+4];
USHORT m_btExVersion_DAYTbl[VER_BDD_MAX_CNT+4];
BOOL m_bExVersionEnableTbl[VER_BDD_MAX_CNT+4];

UCHAR m_btCttSignalA = 0x00; // ����Ʈ ��ȣ Married car�϶� A or Single car
UCHAR m_btCttSignalB = 0x00; // ����Ʈ ��ȣ Married car�϶� B

int m_LIC_CNCS_TimSetFlag = 0; //CNCS�� ����� �̷������ 
int m_LIC_GIA_TimSetFlag = 0; //GIA�� ����� �̷������ 					// Y.J (2011.03.02 ����.)

UINT m_nCncsRxCheck1msTimer = 0; // CNCS�� ������ ���� ���θ� �Ǵ��ϱ� ���� Ÿ�̸�
UINT m_nGiaRxCheck1msTimer = 0; // Gia�� ������ ���� ���θ� �Ǵ��ϱ� ���� Ÿ�̸�

UCHAR m_btTestOtherCiFault = 0x8000; //0x8000 CI ���� ��ü�� �ʱ� ������ ����.
BOOL m_bCiFaultFlag = FALSE;


//2011_03_03 ���� 
UCHAR LIC_VerList[VER_BDD_MAX_CNT][9] = 
	{
	"CCP"    ,
	"CRA-LICL",
	"CRA-VTX",
	"CRA-VOIP",
	"CRA-PAC",
	"CRA-LICM",
	"FDI1",
	"SDI1",
	"SDI2",
	"SDI3", 
	"SDI4",
	"PII1",
	"PII2",
	"VRX1",
	"VRX2",
	"VRX3",
	"VRX4",
	"VRX5",
	"CRA-MAIN",
	"CRA-LAUN",
	"CRA-UP",
	"CRA-PP",
	"CRA-SP",
	"CRA-FTP",
	"CRA-CDT",
	NULL
	};

//2011_05_13 �߰�.
T_FAULT_INFO m_tFaultInfo[eCDT_MAXIMUM];

//******************************************************************************************
//	�ʱ�ȭ
//******************************************************************************************
void user_Init()
{
	int i;
	int wCarNo = 0;
	UCHAR LL,LH,HL,HH;
	char szBuf[128];
	UCHAR *pDpram = (UCHAR *)DPRAM_BASE;

	PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó���� ���� ���Ƿ� �������.
	
	// �ʱ�ȭ�ϱ�
	//timeGet(&m_tmCurTime);
	memset(m_btCommSt,0x00,sizeof(m_btCommSt)); //���� ����Ÿ ���� ���� 
	memset(m_btOldCommSt,0x00,sizeof(m_btOldCommSt)); //���� ����Ÿ ���� ���� 
	memset(m_btSenseCommStBuf,0x00,sizeof(m_btSenseCommStBuf)); //���� ����Ÿ ���� ���� 
	
	memset(m_btExVersionTbl,0x0000,sizeof(m_btExVersionTbl));
	memset(m_btExVersion_DAYTbl,0x0000,sizeof(m_btExVersion_DAYTbl));


	for(i=0;i<VER_BDD_MAX_CNT;i++)
	{
		if(WORD_L(pLicVerDp->VerCnt) == TRUE)
		{
			if(
				!IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chVer[0])) || !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chVer[1])) ||
				!IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chVer[2])) || !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chVer[3])) ||

				!IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[0])) || !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[1])) ||
				!IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[2])) || !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[3])) ||
				!IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[4])) || !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[5]))
			)
			{
				memset(pLicVerDp->cvbBuf[i].chVer,'0',4);
				memset(pLicVerDp->cvbBuf[i].chBuildDate,'0',6);
			}
			else
			{
				LH = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[0])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[1])));
				LL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[2])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[3])));
				m_btExVersionTbl[i] = MAKE_WORD(LH,LL);
				HH = 0x20;
				HL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[0])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[1])));
				LH = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[2])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[3])));
				LL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[4])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[5])));
				
				m_btExVersion_DAYTbl[i] = MAKE_DWORD(HH,HL,LH,LL);
			}
		}
		else //�ѹ��� ���� ���� �Է��� �������� ��� 0 ���� �ʱ�ȭ �Ѵ�.
		{
			pLicVerDp->VerCnt = TRUE;
			memset(pLicVerDp->cvbBuf[i].chVer,'0',4);
			memset(pLicVerDp->cvbBuf[i].chBuildDate,'0',6);
		}
	}

	//if(MAKE_WORD(pLicVerDp->CarNum[0],pLicVerDp->CarNum[1]) != 0xFFFF)
	//{
	//	m_nCarNo = MAKE_WORD(pLicVerDp->CarNum[0],pLicVerDp->CarNum[1]);
	//}
	
	// LIC-MPU����� ���� & ���嵥��Ʈ
	m_btExVersionTbl[5] = MAKE_WORD(
								MAKE_BYTE(ConvHex2Asc(GetFirmwareVersion(1)/1000%10),ConvHex2Asc(GetFirmwareVersion(1)/100%10)),
								MAKE_BYTE(ConvHex2Asc(GetFirmwareVersion(1)/10%10),ConvHex2Asc(GetFirmwareVersion(1)%10))
								);

	m_btExVersion_DAYTbl[5] = MAKE_DWORD(
								0x20,
								MAKE_BYTE(ConvHex2Asc(GetFirmwareVersion(2)/100000%10),ConvHex2Asc(GetFirmwareVersion(2)/10000%10)),
								MAKE_BYTE(ConvHex2Asc(GetFirmwareVersion(2)/1000%10),ConvHex2Asc(GetFirmwareVersion(2)/100%10)),
								MAKE_BYTE(ConvHex2Asc(GetFirmwareVersion(2)/10%10),ConvHex2Asc(GetFirmwareVersion(2)%10))
								);

	i = GetFirmwareVersion(1);
	sprintf(szBuf,"Lonwork Monitor Program, Version:%d.%d%d%d\r\n",i/1000%10,i/100%10,i/10%10,i%10);
	user_DebugPrint(szBuf);


	if(DI_ADDRESS_A)
	{
		m_chCarKindNum = LIC_DEV_NO;
		m_chCarKind = 'A';
        m_nCarNo = 4001;
	}
	else if(DI_ADDRESS_B)
	{
		m_chCarKindNum = LIC_BAKDEV_NO;
		m_chCarKind = 'B';
        m_nCarNo = 4002;
	}
}

//******************************************************************************************
//	Loop
//******************************************************************************************
void user_Loop()
{
	int i;

	user_LonWorkLoop();
	
	//user_Lic2LicLoop();
		
	user_DebugLoop();
	
	user_WithCncsRs232Loop();
	
	user_WithPacRs485Loop();
	
	if(m_nSingleOrMarriedCarUpdate1msTimer > 500)
	{
		m_nSingleOrMarriedCarUpdate1msTimer = 0;
		if(user_IsSingleOrMarried()) SINGLE_OR_MARRIED_CAR = user_IsSingleOrMarried();
	}
}

//******************************************************************************************
//	LIC�� ������ ó��(ROTEM ��û���� �����)
//******************************************************************************************

void user_Lic2LicLoop()
{
	int nTxPos;
	UCHAR btBuf[128];
	UCHAR btTxBuf[128];
	int nRxLen;
	static int nRxPos = 0;
	static UCHAR nOldUart3RxOneByteGapDelayTime = 0;
	static UCHAR btRx3chBuf[256];
	
	m_bCiFaultFlag = m_btCttSignalA & 0x10 ? TRUE : FALSE;
		
	if(m_nCarPos >= 1 && m_nCarPos <= 8) m_btCiFaultVal = MASKBIT(m_bCiFaultFlag,m_nCarPos-1);
	
	// �����ϱ�
	if(m_nTest1msTimer > 100) // 100ms ���Ŀ��� ���������� A -> B �� ���� �Ѵ�.
	{
		m_nTest1msTimer = 0;
		
		if(m_chCarKind == 'A')
		{
			nTxPos = 0;
			btTxBuf[nTxPos++] = 0x02;
			btTxBuf[nTxPos++] = m_btCiFaultVal;
			btTxBuf[nTxPos++] = m_btCiFaultVal;
			btTxBuf[nTxPos++] = 0x03;
			
			xr16l784_RtsDelayStartSend(XR16L784_3CHL,(UCHAR *)btTxBuf,nTxPos,1);
		}
	}
	
	// ���� �ޱ�
	nRxLen = user_PacRx(btBuf,128);
	if(nRxLen)
	{
		if(!m_nUart3RxOneByteGapDelayTime) nRxPos = 0;
		nOldUart3RxOneByteGapDelayTime = m_nUart3RxOneByteGapDelayTime = 10;
		
		if(nRxPos + nRxLen < 250)
		{
			memcpy(&btRx3chBuf[nRxPos],btBuf,nRxLen);
			nRxPos += nRxLen;
		}
	}
	
	if(nOldUart3RxOneByteGapDelayTime && !m_nUart3RxOneByteGapDelayTime)
	{
		if(nRxPos >= 4)
		{
			if(btRx3chBuf[0] == 0x02 && btRx3chBuf[3] == 0x03 && btRx3chBuf[1] == btRx3chBuf[2])
			{
				m_btTestOtherCiFault = btRx3chBuf[1];

				nTxPos = 0;
				btTxBuf[nTxPos++] = 0x02;
				btTxBuf[nTxPos++] = m_btCiFaultVal;
				btTxBuf[nTxPos++] = m_btCiFaultVal;
				btTxBuf[nTxPos++] = 0x03;
				
				xr16l784_RtsDelayStartSend(XR16L784_3CHL,(UCHAR *)btTxBuf,nTxPos,10);
			}
		}
		
		nOldUart3RxOneByteGapDelayTime = m_nUart3RxOneByteGapDelayTime;
	}
}

//******************************************************************************************
//	����� ���� ����
//******************************************************************************************
void user_DebugLoop()
{
	int i,j;
	int sIndex = 0;
	char szBuf1[256];
	char szBuf2[256];
	UCHAR btBuf[256];
	UCHAR sTemp[10];
	int nRxLen;
	static int nRxPos = 0;
	static UCHAR nOldUart1RxOneByteGapDelayTime = 0;
	static UCHAR btRxBuf[256];
	DATE_TIME_TYPE tmBuf;
	PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;
	PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó���� ���� ���Ƿ� �������.
	PCOMMSTATUS_LIC pCommStatus_Lic;  //��ġ Status 
	UCHAR HH,HL,LH,LL;
	
	// ����
	nRxLen = user_DebugRx(btBuf,128);
	if(nRxLen)
	{
		if(!m_nUart1RxOneByteGapDelayTime) nRxPos = 0;
		nOldUart1RxOneByteGapDelayTime = m_nUart1RxOneByteGapDelayTime = 10;
		
		if(nRxPos + nRxLen < 250)
		{
			memcpy(&btRxBuf[nRxPos],btBuf,nRxLen);
			nRxPos += nRxLen;
		}
	}
	
	if(nOldUart1RxOneByteGapDelayTime && !m_nUart1RxOneByteGapDelayTime)
	{
		strncpy(szBuf1,(char *)btRxBuf,MIN(32,nRxPos));
		szBuf1[32] = NULL;
		//for(i=0;i<strlen(szBuf1);i++) if(!IS_ASCALPHABET(szBuf1[i]) && !IS_ASCSPEC(szBuf1[i])) {szBuf1[i] = NULL; break;}
			
		if(btRxBuf[0] == '\r' || btRxBuf[0] == '\n')
		{
			MyPrintf((char *)"->\r\n");
		}
		else
		if(!strncmp(szBuf1,"Time",4))
		{
			if(IS_ASCNUMBER(btRxBuf[5]) && IS_ASCNUMBER(btRxBuf[6]) && 
				IS_ASCNUMBER(btRxBuf[7]) && IS_ASCNUMBER(btRxBuf[8]) &&
				IS_ASCNUMBER(btRxBuf[9]) && IS_ASCNUMBER(btRxBuf[10]) &&
				IS_ASCNUMBER(btRxBuf[11]) && IS_ASCNUMBER(btRxBuf[12]) &&
				IS_ASCNUMBER(btRxBuf[13]) && IS_ASCNUMBER(btRxBuf[14]) &&
				IS_ASCNUMBER(btRxBuf[15]) && IS_ASCNUMBER(btRxBuf[16]))
			{
				tmBuf.second = MAKE_BYTE(ConvAsc2Hex(btRxBuf[15]),ConvAsc2Hex(btRxBuf[16]));
				tmBuf.minute = MAKE_BYTE(ConvAsc2Hex(btRxBuf[13]),ConvAsc2Hex(btRxBuf[14]));
				tmBuf.hour = MAKE_BYTE(ConvAsc2Hex(btRxBuf[11]),ConvAsc2Hex(btRxBuf[12]));
				tmBuf.day = MAKE_BYTE(ConvAsc2Hex(btRxBuf[9]),ConvAsc2Hex(btRxBuf[10]));
				tmBuf.month = MAKE_BYTE(ConvAsc2Hex(btRxBuf[7]),ConvAsc2Hex(btRxBuf[8]));
				tmBuf.year = MAKE_BYTE(ConvAsc2Hex(btRxBuf[5]),ConvAsc2Hex(btRxBuf[6]));
				tmBuf.weekday = 0;

				m_tmCurTime.second = HEXA2BIN(tmBuf.second);
				m_tmCurTime.minute = HEXA2BIN(tmBuf.minute);
				m_tmCurTime.hour = HEXA2BIN(tmBuf.hour);
				m_tmCurTime.day = HEXA2BIN(tmBuf.day);
				m_tmCurTime.month = HEXA2BIN(tmBuf.month);
				m_tmCurTime.year = HEXA2BIN(tmBuf.year);

				memset(&m_tmUtcTime, 0x00, sizeof(DATE_TIME_TYPE));
				
				if(m_LIC_CNCS_TimSetFlag = GetLocalTimeToUTC(&m_tmCurTime, -7, &m_tmUtcTime))
				{
					m_tmUtcTime.year	= ConvDec2Hex(m_tmUtcTime.year	);
					m_tmUtcTime.month	= ConvDec2Hex(m_tmUtcTime.month );
					m_tmUtcTime.day		= ConvDec2Hex(m_tmUtcTime.day	);
					m_tmUtcTime.hour	= ConvDec2Hex(m_tmUtcTime.hour	);
					m_tmUtcTime.minute	= ConvDec2Hex(m_tmUtcTime.minute);
					m_tmUtcTime.second	= ConvDec2Hex(m_tmUtcTime.second);
				
					m_nCncsRxCheck1msTimer = 100000;
				}
				
				m_tmUtcTime.year	= ConvDec2Hex(m_tmUtcTime.year	);
				m_tmUtcTime.month	= ConvDec2Hex(m_tmUtcTime.month );
				m_tmUtcTime.day		= ConvDec2Hex(m_tmUtcTime.day	);
				m_tmUtcTime.hour	= ConvDec2Hex(m_tmUtcTime.hour	);
				m_tmUtcTime.minute	= ConvDec2Hex(m_tmUtcTime.minute);
				m_tmUtcTime.second	= ConvDec2Hex(m_tmUtcTime.second);				

				sprintf(btBuf,"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%02X[minute],%02X[second] \r\n",

					BIN2HEXA(m_tmUtcTime.year),
					BIN2HEXA(m_tmUtcTime.month),
					BIN2HEXA(m_tmUtcTime.day),
					BIN2HEXA(m_tmUtcTime.hour),
					BIN2HEXA(m_tmUtcTime.minute),
					BIN2HEXA(m_tmUtcTime.second));

				user_DebugPrint((char *)btBuf);
			}		
			else
			{
				user_DebugPrint("Not Date&time format \r\n");
			}
		}
		else
		if(!strncmp(szBuf1,"t",1))
		{
			sprintf(btBuf,"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%02X[minute],%02X[second] \r\n",
				BIN2HEXA(m_tmUtcTime.year),
				BIN2HEXA(m_tmUtcTime.month),
				BIN2HEXA(m_tmUtcTime.day),
				BIN2HEXA(m_tmUtcTime.hour),
				BIN2HEXA(m_tmUtcTime.minute),
				BIN2HEXA(m_tmUtcTime.second));
			user_DebugPrint((char *)btBuf);
		}
		else
		if(!strncmp(szBuf1,"Version",7))
		{
			i = GetFirmwareVersion(1);
			
			memcpy(sTemp,&pLnWkDp->btVerH,2);
			j = MAKE_WORD(sTemp[0],sTemp[1]);
			
			sprintf(btBuf,"LIC-MPU Version:%d.%d%d%d,Build Date:20%06d, LIC-LON Version:%d.%d%d%d,Build Date:%08X\r\n",
				i/1000%10,
				i/100%10,
				i/10%10,
				i%10,
				GetFirmwareVersion(2),
				BYTE_H(WORD_H(j)),
				BYTE_L(WORD_H(j)),
				BYTE_H(WORD_L(j)),
				BYTE_L(WORD_L(j)),
				MAKE_DWORD(pLnWkDp->btBuildDateHH,pLnWkDp->btBuildDateHL,pLnWkDp->btBuildDateLH,pLnWkDp->btBuildDateLL));

			user_DebugPrint((char *)btBuf);

			memset(btBuf,0x00,256);

			//2011_03_03 ���� 
			for(i=0;i<VER_BDD_MAX_CNT;i++) //CNCS�� ���� ���� ���� ���� ǥ�� �ϴ� �κ� �߰� 
			{
				if(LIC_VerList[i][0] == NULL) break;
				memset(btBuf,0x00,256);
				strncpy((char *)btBuf,(char *)&LIC_VerList[i][0],strlen((char*)&LIC_VerList[i][0]));
				sprintf(&btBuf[strlen((char*)&btBuf)],":");
				strncpy((char *)&btBuf[strlen((char*)&btBuf)],(char *)&pLicVerDp->cvbBuf[i].chVer[0],4);
				sprintf(&btBuf[strlen((char*)&btBuf)],":");
				strncpy((char *)&btBuf[strlen((char*)&btBuf)],(char *)&pLicVerDp->cvbBuf[i].chBuildDate[0],6);
				sprintf(&btBuf[strlen((char*)&btBuf)],"\r\n");
				
				user_DebugPrint((char *)btBuf);
			}
			
			MyPrintf("\r\n\r\n");
		}
		else
		if(!strncmp(szBuf1,"Recent",6))
		{
			m_nLnWkTxFlag = 1;
			user_DebugPrint("Recent fault read start send \r\n");
		}
		else
		if(!strncmp(szBuf1,"Historical",10))
		{
			m_nLnWkTxFlag = 2;
			gm_SysTimeToRtc(&tmBuf,m_nDateTime2SecondCnt);
			sprintf(btBuf,"Historical read start send, Historical start time : %08XH, Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%02X[minute],%02X[second] \r\n",
				m_nDateTime2SecondCnt,
				tmBuf.year,
				tmBuf.month,
				tmBuf.day,
				tmBuf.hour,
				tmBuf.minute,
				tmBuf.second);
			user_DebugPrint((char *)btBuf);
		}
		else
		if(!strncmp(szBuf1,"Rxinfo",6))
		{
			if(!m_nNvsramPos)
			{
				sprintf(btBuf,"Total byte : %d, Packet count : %d, window count : %d, remaind packet : %d, m_nLnWkWaySideOnRxOk : %d, m_bLnWkFtpEndFlag : %d, Historical start time : %08XH \r\n",
					0,0,0,0,
					m_nLnWkWaySideOnRxOk,
					m_bLnWkFtpEndFlag,
					m_nDateTime2SecondCnt);
			}
			else
			{
				sprintf(btBuf,"Total byte : %d, Packet count : %d, window count : %d, remaind packet : %d, m_nLnWkWaySideOnRxOk : %d, m_bLnWkFtpEndFlag : %d, Historical start time : %08XH \r\n",
					m_nNvsramPos,
					((m_nNvsramPos-1)/128)+1,
					((m_nNvsramPos-1)/128/6)+1,
					m_nNvsramPos%128,
					m_nLnWkWaySideOnRxOk,
					m_bLnWkFtpEndFlag,
					m_nDateTime2SecondCnt);
			}
			user_DebugPrint((char *)btBuf);
		}
		else
		if(!strncmp(szBuf1,"LnWayClr",8))
		{
			m_nLnWkWaySideOnRxOk = 0;
			user_DebugPrint("'m_nLnWkWaySideOnRxOk' Clear OK \r\n");
		}
		else
		if(!strncmp(szBuf1,"LnFtpClr",8))
		{
			m_bLnWkFtpEndFlag = FALSE;
			user_DebugPrint("'m_bLnWkFtpEndFlag' Clear OK \r\n");
		}
		else
		if(!strncmp(szBuf1,"HisStTm",7))
		{
			if(IS_ASCHEX(btRxBuf[8]) && IS_ASCHEX(btRxBuf[9]) && 
				IS_ASCHEX(btRxBuf[10]) && IS_ASCHEX(btRxBuf[11]) &&
				IS_ASCHEX(btRxBuf[12]) && IS_ASCHEX(btRxBuf[13]) &&
				IS_ASCHEX(btRxBuf[14]) && IS_ASCHEX(btRxBuf[15]))
			{
				m_nDateTime2SecondCnt = MAKE_DWORD(
					MAKE_BYTE(ConvAsc2Hex(btRxBuf[8]),ConvAsc2Hex(btRxBuf[9])),
					MAKE_BYTE(ConvAsc2Hex(btRxBuf[10]),ConvAsc2Hex(btRxBuf[11])),
					MAKE_BYTE(ConvAsc2Hex(btRxBuf[12]),ConvAsc2Hex(btRxBuf[13])),
					MAKE_BYTE(ConvAsc2Hex(btRxBuf[14]),ConvAsc2Hex(btRxBuf[15])));

				
				gm_SysTimeToRtc(&tmBuf,m_nDateTime2SecondCnt);
				sprintf(btBuf,"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%02X[minute],%02X[second], Setting OK \r\n",
					tmBuf.year,
					tmBuf.month,
					tmBuf.day,
					tmBuf.hour,
					tmBuf.minute,
					tmBuf.second
					);
				user_DebugPrint((char *)btBuf);
			}		
			else
			{
				user_DebugPrint("No format \r\n");
			}
		}
		else
		if(!strncmp(szBuf1,"CarNoSet",8))
		{
			if(IS_ASCNUMBER(btRxBuf[9]) && IS_ASCNUMBER(btRxBuf[10]) && IS_ASCNUMBER(btRxBuf[11]) && IS_ASCNUMBER(btRxBuf[12]))
			{
				m_nCarNo = ConvAsc2Dec(btRxBuf[9])*1000 + ConvAsc2Dec(btRxBuf[10])*100 + ConvAsc2Dec(btRxBuf[11])*10 + ConvAsc2Dec(btRxBuf[12]);
				m_chCarKind = m_nCarNo&0x01 ? 'A' : 'B';
				MyPrintf("Car Number = %d,%c Car \r\n",m_nCarNo,m_chCarKind);
			}
			else
			{
				MyPrintf("Invalid syntax\r\n");
			}	
			
			user_CarNoForCarKindToLon();	
		}
		else
		if(!strncmp(szBuf1,"WaySideON",9))
		{
			m_nCDT_FaultDataStFlag = 1;
			nRecving_Posi = 0;
			
			gm_SysTimeToRtc(&tmBuf,m_nDateTime2SecondCnt);
			sprintf(btBuf,"m_nCDT_FaultDataStFlag  = %d,%s, Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%02X[minute],%02X[second]\r\n",m_nCDT_FaultDataStFlag,m_nLnWkTxFlag == 2 ? "Historical" : "Recently",
					tmBuf.year,
					tmBuf.month,
					tmBuf.day,
					tmBuf.hour,
					tmBuf.minute,
					tmBuf.second
				);
			user_DebugPrint((char *)btBuf);
		}
		else
		if(!strncmp(szBuf1,"CommStSet",9))
		{
			if( IS_ASCHEX(btRxBuf[10]) &&IS_ASCHEX(btRxBuf[11]) && 
				IS_ASCHEX(btRxBuf[12]) &&IS_ASCHEX(btRxBuf[13]) &&
				IS_ASCHEX(btRxBuf[14]) &&IS_ASCHEX(btRxBuf[15]) && 
				IS_ASCHEX(btRxBuf[16]) &&IS_ASCHEX(btRxBuf[17]))
			{

				FunConvAscHex((char *)&btRxBuf[10],sTemp,8);

				memset(m_btCommSt,0x00,sizeof(m_btCommSt));
				pCommStatus_Lic = (COMMSTATUS_LIC *)m_btCommSt;

				pCommStatus_Lic->BYTE_1.BYTE = sTemp[0];
				pCommStatus_Lic->BYTE_2.BYTE = sTemp[1];
				pCommStatus_Lic->BYTE_3.BYTE = sTemp[2];
				pCommStatus_Lic->BYTE_4.BYTE = sTemp[3];

				MyPrintf("CommStSet =  %02X-%02X-%02X-%02X \r\n",
				m_btCommSt[0],
				m_btCommSt[1],
				m_btCommSt[2],
				m_btCommSt[3]);
				
				for(i=0;i<8;i++)
				{
					if(!(m_btOldCommSt[i]&0x01) && (m_btCommSt[i]&0x01)) m_btSenseCommStBuf[i] |= 0x01;
					if(!(m_btOldCommSt[i]&0x02) && (m_btCommSt[i]&0x02)) m_btSenseCommStBuf[i] |= 0x02;
					if(!(m_btOldCommSt[i]&0x04) && (m_btCommSt[i]&0x04)) m_btSenseCommStBuf[i] |= 0x04;
					if(!(m_btOldCommSt[i]&0x08) && (m_btCommSt[i]&0x08)) m_btSenseCommStBuf[i] |= 0x08;
					if(!(m_btOldCommSt[i]&0x10) && (m_btCommSt[i]&0x10)) m_btSenseCommStBuf[i] |= 0x10;
					if(!(m_btOldCommSt[i]&0x20) && (m_btCommSt[i]&0x20)) m_btSenseCommStBuf[i] |= 0x20;
					if(!(m_btOldCommSt[i]&0x40) && (m_btCommSt[i]&0x40)) m_btSenseCommStBuf[i] |= 0x40;
					if(!(m_btOldCommSt[i]&0x80) && (m_btCommSt[i]&0x80)) m_btSenseCommStBuf[i] |= 0x80;
				}
				
				memcpy(m_btOldCommSt,m_btCommSt,8);
			}
			else
			{
				MyPrintf("Invalid syntax\r\n");
			}
		}
		else
		if(!strncmp(szBuf1,"TrainConf",9))
		{
			if(IS_ASCNUMBER(btRxBuf[10]))
			{
				m_TrainCofVal = MIN(3,ConvAsc2Hex(btRxBuf[10]));
				MyPrintf("TrainConf value = %02X \r\n",m_TrainCofVal);
			}
			else
			{
				MyPrintf("Invalid syntax\r\n");
			}
		}
		else
		if(!strncmp(szBuf1,"CarPosSet",9))
		{
			if(IS_ASCNUMBER(btRxBuf[10]))
			{
				if(ConvAsc2Dec(btRxBuf[10]) >= 1 && ConvAsc2Dec(btRxBuf[10]) <= 8)
				{
					m_nCarPos = ConvAsc2Dec(btRxBuf[10]);
					MyPrintf("CarPosVal = %02X \r\n",m_nCarPos);
				}
				else
				{
					MyPrintf("Invalid syntax [%d]\r\n",ConvAsc2Dec(btRxBuf[10]));
				}
			}
			else
			{
				MyPrintf("Invalid syntax\r\n");
			}
		}
		else
		if(!strncmp(szBuf1,"CiFaultSet",10))
		{
			if( IS_ASCNUMBER(btRxBuf[11]) && IS_ASCNUMBER(btRxBuf[12]))
			{
				m_btCiFaultVal = MAKE_WORD(ConvAsc2Hex(btRxBuf[11]),ConvAsc2Hex(btRxBuf[12]));
				MyPrintf("CiFault Val = %02X \r\n",m_btCiFaultVal);
			}
			else
			{
				MyPrintf("Invalid syntax\r\n");
			}
		}
		else
		if(!strncmp(szBuf1,"VerSet",6))
		{

			if( IS_ASCNUMBER(btRxBuf[7]) && IS_ASCNUMBER(btRxBuf[8]) && 

				IS_ASCNUMBER(btRxBuf[10]) && IS_ASCNUMBER(btRxBuf[11]) &&
				IS_ASCNUMBER(btRxBuf[12]) && IS_ASCNUMBER(btRxBuf[13]) &&

				IS_ASCNUMBER(btRxBuf[15]) && IS_ASCNUMBER(btRxBuf[16]) &&
				IS_ASCNUMBER(btRxBuf[17]) && IS_ASCNUMBER(btRxBuf[18]) && 
				IS_ASCNUMBER(btRxBuf[19]) && IS_ASCNUMBER(btRxBuf[20])
				)
			{
				sIndex = ConvAsc2Dec(btRxBuf[7])*10 + ConvAsc2Dec(btRxBuf[8]);
				sIndex = MIN(VER_BDD_MAX_CNT,sIndex);

				pLicVerDp->cvbBuf[sIndex].chVer[0] = btRxBuf[10];
				pLicVerDp->cvbBuf[sIndex].chVer[1] = btRxBuf[11];
				pLicVerDp->cvbBuf[sIndex].chVer[2] = btRxBuf[12];
				pLicVerDp->cvbBuf[sIndex].chVer[3] = btRxBuf[13];

				pLicVerDp->cvbBuf[sIndex].chBuildDate[0]=btRxBuf[15];
				pLicVerDp->cvbBuf[sIndex].chBuildDate[1]=btRxBuf[16];
				pLicVerDp->cvbBuf[sIndex].chBuildDate[2]=btRxBuf[17];
				pLicVerDp->cvbBuf[sIndex].chBuildDate[3]=btRxBuf[18];
				pLicVerDp->cvbBuf[sIndex].chBuildDate[4]=btRxBuf[19];
				pLicVerDp->cvbBuf[sIndex].chBuildDate[5]=btRxBuf[20];

				LH = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chVer[0])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chVer[1])));
				LL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chVer[2])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chVer[3])));
				m_btExVersionTbl[sIndex] = MAKE_WORD(LH,LL);
				HH = 0x20;
				HL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate[0])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate[1])));
				LH = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate[2])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate[3])));
				LL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate[4])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate[5])));
				m_btExVersion_DAYTbl[sIndex] = MAKE_DWORD(HH,HL,LH,LL);
				
				memset(btBuf,0x00,256);
				memcpy(btBuf,&LIC_VerList[sIndex][0],strlen((char*)&LIC_VerList[sIndex][0]));
				sprintf(&btBuf[strlen((char*)&btBuf)],":");
				memcpy(&btBuf[strlen((char*)&btBuf)],&pLicVerDp->cvbBuf[sIndex].chVer[0],4);
				sprintf(&btBuf[strlen((char*)&btBuf)],":");
				memcpy(&btBuf[strlen((char*)&btBuf)],&pLicVerDp->cvbBuf[sIndex].chBuildDate[0],6);
				sprintf(&btBuf[strlen((char*)&btBuf)],"\r\n");
				
				user_DebugPrint((char *)btBuf);

			}
			else
			{
				user_DebugPrint("Syntax error\r\n");
			}

		}
		else		
		if(!strncmp(szBuf1,"?",1))
		{
			MyPrintf("[ENTER]      : Move next line after out '->' \r\n");
			MyPrintf("'?'          : Help \r\n");
			MyPrintf("'Time'       : Date&time setting , 'Time=YYMMDDHHMNSS', 'EX)Time=120102030405' \r\n");
			MyPrintf("'t'          : Date&time read \r\n");
			MyPrintf("'Version     : Version \r\n");
			MyPrintf("'Recent'     : Recently faults start \r\n");
			MyPrintf("'Historical' : Historical data start \r\n");
			MyPrintf("'Rxinfo'     : Recieve info \r\n");
			MyPrintf("'LnWayClr'   : 'm_nLnWkWaySideOnRxOk' variable clear \r\n");
			MyPrintf("'LnFtpClr'   : 'm_bLnWkFtpEndFlag' variable clear \r\n");
			MyPrintf("'HisStTm'    : Historical data start time set(2000/1/1 0:0:0 ~ total second), HisStTm=XXXXXXXX, 'EX)HisStTm=0000000F' \r\n");
			MyPrintf("'CarNoSet'   : Car number set. CarNoSet=XXXX, EX)CarNoSet=4001 -> [%d[0x%X],%c CAR]\r\n",m_nCarNo,m_nCarNo,m_chCarKind);
			MyPrintf("'TrainConf'  : Train Configuration. TrainConf=X(X : 0~3[2,4,6,8Car]) => [%d]\r\n",m_TrainCofVal);
			MyPrintf("'CarPosSet'  : Car index position. CarPosSet=X(X:1~8) 'EX)CarPosSet=1' => [%d]\r\n",m_nCarPos);
			MyPrintf("'CiFaultSet' : Other C/I Fault. CiFaultSet=XX 'EX)CiFaultSet=00' => [0x%02X]\r\n",m_btCiFaultVal);
			MyPrintf("'WaySideON'  : WaySide_ON \r\n");
			MyPrintf("'CommStSet'  : Comm Status. CommStSet=XXXXXXXX  'EX) CommStSet=FF7F1F53' => [0x%02X,0x%02X,0x%02X,0x%02X]\r\n",WORD_L(m_btCommSt[0]),WORD_L(m_btCommSt[1]),WORD_L(m_btCommSt[2]),WORD_L(m_btCommSt[3]));
			MyPrintf("'VerSet'     : Each unit version set. VerSet=XX(incdex):XXXX(Ver):XXXXXX(BuildDate) \r\n");
			MyPrintf("\r\n");
		}
		else
		{
			user_DebugPrint("Syntax error\r\n");
		}

		nOldUart1RxOneByteGapDelayTime = m_nUart1RxOneByteGapDelayTime;
	}
}

//******************************************************************************************
//	Single car ����, Married Car���� ����
//
//	Return
//	- 1 : Single
//	- 2 : Married
//	- 0 : �ش���� ���� �����������
//******************************************************************************************
int user_IsSingleOrMarried()
{
	return 1;
}

//******************************************************************************************
//	Single car ����, Married Car������ ���� TRUE�Ǵ� FALSE�Ѵ�.
//******************************************************************************************
void user_SetVersionEnableTbl(int nVal)
{
	int nPos;
	
	switch(nVal)
	{
	// �̱�ī�� ���
	case 1:
		nPos = 0;
		m_bExVersionEnableTbl[nPos++] = TRUE;	//TRIC, A/F       
		m_bExVersionEnableTbl[nPos++] = TRUE;	//TRIC, B                                 
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CCP, F/A end                            
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CCP, B                                  
		m_bExVersionEnableTbl[nPos++] = TRUE;	//LIC-LON                                 
		m_bExVersionEnableTbl[nPos++] = TRUE;	//LIC-MPU                                 
		m_bExVersionEnableTbl[nPos++] = TRUE;	//GIA                                     
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VTX                                     
		m_bExVersionEnableTbl[nPos++] = TRUE;	//PAC, F/A                                
		m_bExVersionEnableTbl[nPos++] = TRUE;	//PAC, F/A                                
		m_bExVersionEnableTbl[nPos++] = TRUE;	//FDI, F /A                               
		m_bExVersionEnableTbl[nPos++] = TRUE;	//FDI, B                                  
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 1                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 2                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 3                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 4                                   
		m_bExVersionEnableTbl[nPos++] = FALSE;	//SDI 5                                   
		m_bExVersionEnableTbl[nPos++] = FALSE;	//SDI 6                                   
		m_bExVersionEnableTbl[nPos++] = FALSE;	//SDI 7                                   
		m_bExVersionEnableTbl[nPos++] = FALSE;	//SDI 8                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//PII 1                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//PII 2                                   
		m_bExVersionEnableTbl[nPos++] = FALSE;	//PII 3                                   
		m_bExVersionEnableTbl[nPos++] = FALSE;	//PII 4                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 1                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 2                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 3                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 4                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 5                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 6                                   
		m_bExVersionEnableTbl[nPos++] = FALSE;	//VRX 7                                   
		m_bExVersionEnableTbl[nPos++] = FALSE;	//VRX 8                                   
		m_bExVersionEnableTbl[nPos++] = FALSE;	//VRX 9                                   
		m_bExVersionEnableTbl[nPos++] = FALSE;	//VRX 10                                  
		m_bExVersionEnableTbl[nPos++] = FALSE;	//VRX 11                                  
		m_bExVersionEnableTbl[nPos++] = FALSE;	//VRX 12                                  
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-MAIN                                 
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-LAUN                                 
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-UP                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-PPLAY                                
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-SPLAY                                
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-FTPDATA                              
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-CDTDATA                              
		break;
			
	// �޸��� ī�� ���
	case 2:
		nPos = 0;
		m_bExVersionEnableTbl[nPos++] = TRUE;	//TRIC, A/F       
		m_bExVersionEnableTbl[nPos++] = TRUE;	//TRIC, B                                 
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CCP, F/A end                            
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CCP, B                                  
		m_bExVersionEnableTbl[nPos++] = TRUE;	//LIC-LON                                 
		m_bExVersionEnableTbl[nPos++] = TRUE;	//LIC-MPU                                 
		m_bExVersionEnableTbl[nPos++] = TRUE;	//GIA                                     
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VTX                                     
		m_bExVersionEnableTbl[nPos++] = TRUE;	//PAC, F/A                                
		m_bExVersionEnableTbl[nPos++] = TRUE;	//PAC, F/A                                
		m_bExVersionEnableTbl[nPos++] = TRUE;	//FDI, F /A                               
		m_bExVersionEnableTbl[nPos++] = TRUE;	//FDI, B                                  
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 1                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 2                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 3                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 4                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 5                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 6                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 7                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//SDI 8                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//PII 1                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//PII 2                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//PII 3                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//PII 4                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 1                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 2                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 3                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 4                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 5                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 6                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 7                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 8                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 9                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 10                                  
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 11                                  
		m_bExVersionEnableTbl[nPos++] = TRUE;	//VRX 12                                  
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-MAIN                                 
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-LAUN                                 
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-UP                                   
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-PPLAY                                
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-SPLAY                                
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-FTPDATA                              
		m_bExVersionEnableTbl[nPos++] = TRUE;	//CN-CDTDATA         
		break;
	}
}

//******************************************************************************************
//	UART ��� �ۼ��� �Լ�
//******************************************************************************************
int user_DebugRx(UCHAR *pBuf,int nRxBuffLen)
{
	return xr16l784_GetRxBuffer1Ch(pBuf,nRxBuffLen);
}

void user_DebugPrint(char *pTxBuf)
{
	xr16l784_Send(XR16L784_1CHL,(UCHAR *)pTxBuf,strlen(pTxBuf));
}

int user_CncsRx(UCHAR *pBuf,int nRxBuffLen)
{
	return xr16l784_GetRxBuffer2Ch(pBuf,nRxBuffLen);
}

void user_CncsTx(UCHAR *pTxBuf,int nTxLen)
{
	xr16l784_RtsDelayStartSend(XR16L784_2CHL,(UCHAR *)pTxBuf,nTxLen,10);
	//xr16l784_Send(XR16L784_2CHL,(UCHAR *)pTxBuf,nTxLen);
}

int user_PacRx(UCHAR *pBuf,int nRxBuffLen)
{
	return xr16l784_GetRxBuffer3Ch(pBuf,nRxBuffLen);
}

void user_PacTx(UCHAR *pTxBuf,int nTxLen)
{
	xr16l784_RtsDelayStartSend(XR16L784_3CHL,(UCHAR *)pTxBuf,nTxLen,10);
}

//******************************************************************************************
//	LONWORK �о ó�� �� ����
//******************************************************************************************
void user_LonWorkLoop()
{
	int i;
	int nTxPos = 0;
	UCHAR btTxBuf[128];
	UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;
	char szBuf[512];
	char szBuf2[64];
	
	if(m_nCDT_FaultDataStFlag == 1)
	{
		m_nCDT_FaultDataStFlag = 0;

		m_LIC_CNCS_Tx_Flag = TRUE;
		m_nTxDbg1msTimer = 0;

		nTxPos = 0;
		btTxBuf[nTxPos++] = STX;  // STX
		btTxBuf[nTxPos++] = 0x01; // Command Code
		btTxBuf[nTxPos++] = 0x00; // 0x00���� ����
		btTxBuf[nTxPos++] = 0x06; // ����
		btTxBuf[nTxPos++] = m_nLnWkTxFlag; // �����̼�(Recently):0x01, ����â(Historycal):0x02
		btTxBuf[nTxPos++] = 0x00; // 
		btTxBuf[nTxPos++] = WORD_H(DWORD_H(m_nDateTime2SecondCnt)); // �ð�(HH)
		btTxBuf[nTxPos++] = WORD_L(DWORD_H(m_nDateTime2SecondCnt)); // �ð�(HL)
		btTxBuf[nTxPos++] = WORD_H(DWORD_L(m_nDateTime2SecondCnt)); // �ð�(LH)
		btTxBuf[nTxPos++] = WORD_L(DWORD_L(m_nDateTime2SecondCnt)); // �ð�(LL)
		btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
		btTxBuf[nTxPos++] = ETX; // ETX
		user_LonWorkTx(btTxBuf,nTxPos);

		MyPrintf("[TX:%02d] ",nTxPos);
		for(i=0;i<nTxPos;i++) MyPrintf("%02X ",WORD_L(btTxBuf[i]));
		MyPrintf("\r\n");
	}

	// NVSRAM�� ����� ������ RS232�� �����Ͽ� ������Ѵ�.
	if(m_bLnWkDbgTxFlag)
	{
		m_bLnWkDbgTxFlag = FALSE;
		m_nDbgTxPos = 0;
		m_nTxDbg1msTimer = 0;
	}
	
	if(m_nDbgTxPos < m_nNvsramPos) //m_nDbgTxPos = 0xFFFFFFFF �� �׻� ū ���� ������ �ִٰ� �����϶�� ���ɿ� ���� 0���� Ŭ���� �ȴ�.
	{
		if(m_nTxDbg1msTimer > 200)
		{
			m_nTxDbg1msTimer = 0;
			szBuf[0] = 0;
			for(i=0;i<(MIN(128,(UINT)(m_nNvsramPos-m_nDbgTxPos)));i++) {sprintf(szBuf2,"%02X ",pNvsram[m_nDbgTxPos+i]); strcat(szBuf,szBuf2);}
			strcat(szBuf,"\r\n");
			user_DebugPrint(szBuf);
			m_nDbgTxPos += 128;
		}
	}
	else
	if(m_nDbgTxPos == 0xFFFFFFFF)
	{
		if(nTxPos)
		{
			szBuf[0] = 0;
			sprintf(szBuf2,"[TX:%02d] ",nTxPos); strcat(szBuf,szBuf2);
			for(i=0;i<nTxPos;i++) {sprintf(szBuf2,"%02X ",WORD_L(btTxBuf[i])); strcat(szBuf,szBuf2);}
			strcat(szBuf,"\r\n");
			user_DebugPrint(szBuf);			
		}
	}
}

void user_LonWorkRead()
{
	int i;
	int nTmp;
	PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;
	UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;
	PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó���� ���� ���Ƿ� �������.
	UCHAR nKind;
	static UCHAR nOldKind = 0;
	UCHAR nRxLen;
	static int nRecRxPos = 0;
	UCHAR btRxBuf[256];
	static UCHAR btFtpOneRecRxBuf[1024];
	int nTxPos = 0;
	UCHAR btTxBuf[128];
	char szBuf[512];
	char szBuf2[64];
	
	nKind = WORD_L(pLnWkDp->btKind); 

	switch(nKind)
	{
	// FTP1~6 ��������
	case 1: case 2: case 3: case 4: case 5: case 6:
		nRxLen = 0;
		
		// ����
		if(nKind == 1)
		{
			nRecRxPos = 0;
			nRxLen = user_LonWorkRx(nKind,btRxBuf);
			if(nRxLen>6 && nRecRxPos<768)
			{
				memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);
				nTmp = (nRxLen-7);
				nRecRxPos += nTmp;
				
				szBuf[0] = 0;
				sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szBuf,szBuf2);
				if(nTmp < 128)
				{
					for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				else
				{
					for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
					strcat(szBuf,"..");
					for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				strcat(szBuf,"\r\n");
				user_DebugPrint(szBuf);
			}
		}
		else
		// �߰� ���ڵ� ����
		if(nKind >= 2 && nKind <= 5)
		{
			nRxLen = user_LonWorkRx(nKind,btRxBuf);
			if(nRxLen>6 && nRecRxPos<768)
			{
				memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);
				nTmp = (nRxLen-7);
				nRecRxPos += nTmp;

				szBuf[0] = 0;
				sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szBuf,szBuf2);
				if(nTmp < 128)
				{
					for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				else
				{
					for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
					strcat(szBuf,"..");
					for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				strcat(szBuf,"\r\n");
				user_DebugPrint(szBuf);
			}
		}
		else
		// ��
		if(nKind == 6)
		{
			nRxLen = user_LonWorkRx(nKind,btRxBuf);
			if(nRxLen>6 && nRecRxPos<768)
			{
				memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);
				nTmp = (nRxLen-7);
				nRecRxPos += nTmp;

				szBuf[0] = 0;
				sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szBuf,szBuf2);
				if(nTmp < 128)
				{
					for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				else
				{
					for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
					strcat(szBuf,"..");
					for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szBuf2);}
				}
				strcat(szBuf,"\r\n");
				user_DebugPrint(szBuf);
			}
		}

		// ���̰� 0~127���� �´ٸ� �����͸� �����Ѵ�.
		if((nRxLen>6 && nRxLen<134))
		{
			if(NVSRAM_WAYSIDEONBUF_SIZE > m_nNvsramPos)
			{
				user_DebugPrint("***FTP File receive... ^^;;***\r\n");
				memcpy(&pNvsram[m_nNvsramPos],btFtpOneRecRxBuf,nRecRxPos);
				m_nNvsramPos += nRecRxPos;
			}
			else
			{
				MyPrintf("***FTP data buffer full..\r\n");
			}
				
			m_bLnWkFtpEndFlag = TRUE;
		}
		else
		if(nKind == 6)
		{
			if(NVSRAM_WAYSIDEONBUF_SIZE > m_nNvsramPos)
			{
				user_DebugPrint("***FTP File receive End ^..^ ***\r\n");
				memcpy(&pNvsram[m_nNvsramPos],btFtpOneRecRxBuf,nRecRxPos);
				m_nNvsramPos += nRecRxPos;
			}
			else
			{
				MyPrintf("***FTP data buffer full..\r\n");
			}
		}
							
		nOldKind = nKind;
		
		break;
			
	// �Ϲ� ��������(����)
	case 7:
		nRxLen = user_LonWorkRx(7,btRxBuf);

		if(m_nDbgTxPos == 0xFFFFFFFF)
		{
			szBuf[0] = 0;
			sprintf(szBuf2,"[RX:%02d] ",nRxLen); strcat(szBuf,szBuf2);
			for(i=0;i<nRxLen;i++) {sprintf(szBuf2,"%02X ",btRxBuf[i]); strcat(szBuf,szBuf2);}
			strcat(szBuf,"\r\n");
			user_DebugPrint(szBuf);
		}
		
		if(nRxLen)
		{
			nTxPos = 0;

			switch(btRxBuf[1])
			{
			// WAYSIDE ON ACK ����
			case 0x02: 
				m_nLnWkWaySideOnRxOk = 1;
				break;
				
			// FTP���� ��
			case 0x06: 
				if(m_nLnWkWaySideOnRxOk)
				{
					m_nLnWkWaySideOnRxOk--; 
					m_bLnWkFtpEndFlag = TRUE; 
				}
				break;
				
			// �ð���û, MPU�� DPRAM�� �����͸� ���� ���� ���ͷ�Ʈ�� �������������� LIC_LON���� �������� ����
			case 0x08:
				nTxPos = 0;
				//if(m_LIC_CNCS_TimSetFlag && m_nCncsRxCheck1msTimer)
				{
					btTxBuf[nTxPos++] = STX; // STX
					btTxBuf[nTxPos++] = 0x09; // Command Code
					btTxBuf[nTxPos++] = 0x00; // 0x00���� ����
					btTxBuf[nTxPos++] = 0x06; // ����
					
					// Y.J ����
					btTxBuf[nTxPos++] = m_tmUtcTime.year;								// �� BCD
					btTxBuf[nTxPos++] = m_tmUtcTime.month;								// ��
					btTxBuf[nTxPos++] = m_tmUtcTime.day;								// ��
					btTxBuf[nTxPos++] = m_tmUtcTime.hour;								// ��
					btTxBuf[nTxPos++] = m_tmUtcTime.minute; 							// ��
					btTxBuf[nTxPos++] = m_tmUtcTime.second; 							// ��
					
					btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
					btTxBuf[nTxPos++] = ETX; // ETX
					user_LonWorkTx(btTxBuf,nTxPos);
				}
				break;
				
			// ���µ����� ��û, MPU�� DPRAM�� �����͸� ���� ���� ���ͷ�Ʈ�� �������������� LIC_LON���� �������� ����
			case 0x0A:
				m_nCarCnt = btRxBuf[4];
				if(m_nCarCnt < 1 && m_nCarCnt > 2) m_nCarCnt = 1;
				nTxPos = 0;
				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x0B; // Command Code
				btTxBuf[nTxPos++] = 0x00; // 0x00���� ����
				btTxBuf[nTxPos++] = 0x05; // ����
				btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[0]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[1]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[2]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[3]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[4]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[5]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[6]); // ���� ������
				btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[7]); // ���� ������
				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX
				user_LonWorkTx(btTxBuf,nTxPos);		
				
				memcpy(m_btSenseCommStBuf,m_btCommSt,8);
				break;
				
			//������û
			case 0x0C:
				nTxPos = 0;
				memset(btTxBuf,0x00,sizeof(btTxBuf));

				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x0D; // Command Code

				// 2 : Firmware
				// 0 : Not used�� ����ϰ� ������ ��¥�� ��������ʴ´�.
				// 6 : ��������(LIC -> CDT) ����

				nTmp = MAX(1,WORD_L(btRxBuf[4]));
				nTmp = MIN((VER_BDD_MAX_CNT)+1,WORD_L(btRxBuf[4]));
				nTmp--;
				btTxBuf[nTxPos++] = LIC_VerList[nTmp][0] == NULL ? 6 : 2; // 2:����&����Ʈ, 6:����
				
				btTxBuf[nTxPos++] = 31; // �����ͱ���
				
				btTxBuf[nTxPos++] = btRxBuf[4]; // Index ��ȣ
				btTxBuf[nTxPos++] = LIC_VerList[nTmp][0] == NULL ? 6 : 4; // Type

				memcpy(&btTxBuf[nTxPos],&LIC_VerList[nTmp][0],strlen((char*)&LIC_VerList[nTmp][0]));
				nTxPos = nTxPos+9;

				btTxBuf[nTxPos+0] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]>>12)&0x0F); // Production Version
				btTxBuf[nTxPos+1] = '.'; // Production Version
				btTxBuf[nTxPos+2] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]>>8)&0x0F); // Production Version
				btTxBuf[nTxPos+3] = '.'; // Production Version
				btTxBuf[nTxPos+4] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]>>4)&0x0F); // Production Version
				btTxBuf[nTxPos+5] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]&0x0F)); // Production Version
				btTxBuf[nTxPos+6] = '';
				nTxPos = nTxPos+9;

				btTxBuf[nTxPos+0] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>28)&0xF);// '2': // Year
				btTxBuf[nTxPos+1] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>24)&0xF);// '0': // Year
				btTxBuf[nTxPos+2] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>20)&0xF);// '1': // Year
				btTxBuf[nTxPos+3] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>16)&0xF);// '2': // Year
				btTxBuf[nTxPos+4] = '-';
				btTxBuf[nTxPos+5] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>12)&0xF);// '0': // Month
				btTxBuf[nTxPos+6] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>8)&0xF);// '1': // Month
				btTxBuf[nTxPos+7] = '-';
				btTxBuf[nTxPos+8] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>4)&0xF);// '0': // Day
				btTxBuf[nTxPos+9] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)])&0xF);// '1' : // Day
				btTxBuf[nTxPos+10] = '';
				nTxPos = nTxPos+11;

				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX

				if(WORD_L(btRxBuf[4]) != 2)
				{
					user_LonWorkTx(btTxBuf,nTxPos);
				}
				break;

			//�������(Single or married A)
			case 0x0E:
				m_btCttSignalA = btRxBuf[4];
				break;
				
			// �������� ���� ��û
			case 0x10:
				nTxPos = 0;
				memset(btTxBuf,0x00,sizeof(btTxBuf));

				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x11; // Command Code
				btTxBuf[nTxPos++] = 0x00; // Message Code
				btTxBuf[nTxPos++] = 0x02; // ����
				btTxBuf[nTxPos++] = WORD_H(m_TrainCofVal); // ������
				btTxBuf[nTxPos++] = WORD_L(m_TrainCofVal); // ������
				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX
				user_LonWorkTx(btTxBuf,nTxPos);
				break;
				
			// CI ��ġ ��û
			case 0x12:
				nTxPos = 0;
				memset(btTxBuf,0x00,sizeof(btTxBuf));

				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x13; // Command Code
				btTxBuf[nTxPos++] = 0x00; // Message Code
				btTxBuf[nTxPos++] = 0x01; // ����
				if(m_nCarPos >= 1 && m_nCarPos <= 8)
				{
					btTxBuf[nTxPos++] = 0x00; // ������
					btTxBuf[nTxPos++] = MASKBIT(1,m_nCarPos-1); // ������
				}
				else
				{
					btTxBuf[nTxPos++] = 0x80; // ������
					btTxBuf[nTxPos++] = 0x00; // ������
				}
				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX
				user_LonWorkTx(btTxBuf,nTxPos);
				break;
			
			// ������ȣ ��û
			case 0x14:
				nTxPos = 0;
				memset(btTxBuf,0x00,sizeof(btTxBuf));

				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x15; // Command Code
				btTxBuf[nTxPos++] = 0x00; // Message Code
				btTxBuf[nTxPos++] = 0x02; // ����
				btTxBuf[nTxPos++] = WORD_H(m_nCarNo);
				btTxBuf[nTxPos++] = WORD_L(m_nCarNo);
				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX
				user_LonWorkTx(btTxBuf,nTxPos);
				break;

			// CI���峭 ���� ��ġ ��û
			case 0x16:
				nTxPos = 0;
				memset(btTxBuf,0x00,sizeof(btTxBuf));

				btTxBuf[nTxPos++] = STX; // STX
				btTxBuf[nTxPos++] = 0x17; // Command Code
				btTxBuf[nTxPos++] = 0x00; // Message Code
				btTxBuf[nTxPos++] = 0x02; // ����
				if(m_btCiFaultVal != 0x8000 && m_btTestOtherCiFault != 0x8000) //
				{
					btTxBuf[nTxPos++] = 0x00;
					switch(m_TrainCofVal)
					{
					// 2��
					case 0: btTxBuf[nTxPos++] = 0xFC | m_btCiFaultVal | m_btTestOtherCiFault; break; // ������
					// 4��
					case 1: btTxBuf[nTxPos++] = 0xF0 | m_btCiFaultVal | m_btTestOtherCiFault; break; // ������
					// 6��
					case 2: btTxBuf[nTxPos++] = 0xC0 | m_btCiFaultVal | m_btTestOtherCiFault; break; // ������
					// 8��
					case 3: btTxBuf[nTxPos++] = 0x00 | m_btCiFaultVal | m_btTestOtherCiFault; break; // ������
					default:
							btTxBuf[nTxPos++] = 0x00 | m_btCiFaultVal | m_btTestOtherCiFault; break; // ������
					}
					//btTxBuf[nTxPos++] = m_btCiFaultVal | m_btTestOtherCiFault;
				}
				else
				{
					btTxBuf[nTxPos++] = 0x80;
					btTxBuf[nTxPos++] = 0x00;
				}
				btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
				btTxBuf[nTxPos++] = ETX; // ETX
				user_LonWorkTx(btTxBuf,nTxPos);
				break;
			}

			if(nTxPos)
			{
				if(m_nDbgTxPos == 0xFFFFFFFF)
				{
					szBuf[0] = 0;
					sprintf(szBuf2,"[TX:%02d] ",nTxPos); strcat(szBuf,szBuf2);
					for(i=0;i<nTxPos;i++) {sprintf(szBuf2,"%02X ",WORD_L(btTxBuf[i])); strcat(szBuf,szBuf2);}
					strcat(szBuf,"\r\n");
					user_DebugPrint(szBuf);
				}			
			}
		}
		break;
	}
}

//************************************************************************
// ��Ʈ�� �����Ѵ�.
//************************************************************************
UCHAR BitSwap(UCHAR btDat)
{
	UCHAR btBuf = 0x00;
	
	btBuf |= MASKBIT(btDat&0x01?1:0,7);
	btBuf |= MASKBIT(btDat&0x02?1:0,6);
	btBuf |= MASKBIT(btDat&0x04?1:0,5);
	btBuf |= MASKBIT(btDat&0x08?1:0,4);
	btBuf |= MASKBIT(btDat&0x10?1:0,3);
	btBuf |= MASKBIT(btDat&0x20?1:0,2);
	btBuf |= MASKBIT(btDat&0x40?1:0,1);
	btBuf |= MASKBIT(btDat&0x80?1:0,0);
	
	return btBuf;
}

UCHAR user_LonWorkRx(int nRxPos, UCHAR *pRxBuf)
{
	int i;
	UCHAR nRxLen;
	UCHAR *pBuf;
	PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;
	
	if(nRxPos >= 1 && nRxPos <= 6)
	{
		nRxLen = MIN(sizeof(LNWKFTPIT)-1,WORD_L(pLnWkDp->lfBuf[nRxPos-1].btLen)+6);
		if(nRxLen > 6)
		{
			pBuf = &pLnWkDp->lfBuf[nRxPos-1].btStx;
			for(i=0;i<nRxLen;i++) pRxBuf[i] = WORD_L(pBuf[i]);
			
			//MyPrintf("[Len:%d,Pos:%d->",nRxLen,nRxPos);
			//for(i=0;i<nRxLen;i++) MyPrintf("%02X ",pRxBuf[i]);
			//MyPrintf("]\r\n");

			if(pRxBuf[0] == STX && pRxBuf[nRxLen-1] == ETX)
			{
				return nRxLen;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}
	else
	if(nRxPos == 7)
	{
		nRxLen = MIN(sizeof(LNWKGERIT),WORD_L(pLnWkDp->lgRxBuf.btLen)+6);
		if(nRxLen > 5)
		{
			pBuf = &pLnWkDp->lfBuf[nRxPos-1].btStx;
			for(i=0;i<nRxLen;i++) pRxBuf[i] = WORD_L(pBuf[i]);

			//MyPrintf("[Len:%d,Pos:%d->",nRxLen,nRxPos);
			//for(i=0;i<nRxLen;i++) MyPrintf("%02X ",pRxBuf[i]);
			//MyPrintf("]\r\n");

			if(pRxBuf[0] == STX && pRxBuf[nRxLen-1] == ETX && !Make1ByteBcc(&pRxBuf[1],nRxLen-2))
			{
				return nRxLen;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return 0;
	}
	
	return 0;
}

void user_LonWorkTx(UCHAR *pTxBuf,UCHAR nLen)
{
	int i;
	char szBuf[512];
	char szBuf2[64];

	UCHAR *pBuf;
	PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;
	
	pBuf = &pLnWkDp->lgTxBuf.btStx;

	memcpy(pBuf,pTxBuf,(int)nLen);
	LNWK_TXINTREQ();
}

//******************************************************************************************
//	LIC<->CNCS(RS232)
//******************************************************************************************
void user_WithCncsRs232Loop()
{
	int i;
	int nRxLen;
	UCHAR btBuf[256]; //���� ������Ʈ���� �о� ���� ����
	UCHAR sTimeBuf[10];//�ð� ���� ����.
	int sPotoLen = 0; //���� ��Ŷ Index. 
	UCHAR sBcc = 0;
	static int nRxPos = 0; //���� ī����.
	static UCHAR nOldUart2RxOneByteGapDelayTime = 0; //10ms �̻� ������ �ʵǸ� ���� ó�� �Ѵ�.
	static UCHAR btRx2chBuf[512]; //���� ����
	static UCHAR btTx2chBuf[512]; //���� ����.
	static int nTimeSendCnt = 0;
	UCHAR LL,LH,HL,HH;

	int nBlkSize = 0;
	int nTempBlkEnd = 0;
	int sTxDataSize = 0; //���ž� ����Ÿ size�� ��� �Ͽ� 128�̸� �߰� ������ ������ ������ �̴�.

	UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;

	PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó���� ���� ���Ƿ� �������.
	PLIC_CNCS_HD pLic_Cncs;
	PCNCS_LIC_SD pCncsLicSd;

	PCNCS_LIC_T_F pCnsc_Lic_T_F;
	PCNCS_LIC_T_F_C pCncs_Lic_T_F_C = (CNCS_LIC_T_F_C *) btRx2chBuf;				// ���� ��Ŷ ���� �Ϸ� Ȯ�� �������� �߰�(Y.J 2011-05-10)
	
	// Fault Block Information;
	PFAULT_INFO pInfo = NULL;

	// ����
	nRxLen = user_CncsRx(btBuf,128);
	if(nRxLen)
	{
		if(!m_nUart2RxOneByteGapDelayTime) nRxPos = 0;
		m_nUart2RxOneByteGapDelayTime = 10;
		
		if(nRxPos + nRxLen < 511)
		{
			memcpy(&btRx2chBuf[nRxPos],btBuf,nRxLen);
			nRxPos += nRxLen;
		}
	}
	
	if(nOldUart2RxOneByteGapDelayTime && !m_nUart2RxOneByteGapDelayTime)
	{
		pCncsLicSd = (CNCS_LIC_SD *)btRx2chBuf;

		pCnsc_Lic_T_F = (CNCS_LIC_T_F *) btRx2chBuf;

		if(pCncsLicSd->phHdBuf.btSoh == SOH &&
		   pCncsLicSd->btEot == EOT &&
		   sizeof(CNCS_LIC_SD) == nRxPos &&
		   (TWOBYTE_ASC2HEX(pCncsLicSd->phHdBuf.chDestDev) == m_chCarKindNum) && 
		   (TWOBYTE_ASC2HEX(pCncsLicSd->sCommand) == 0x09) &&  //CNCS�� �ð� ����
		   !((Make1ByteBcc(&pCncsLicSd->phHdBuf.chSrcDev[0],nRxPos-4)^(TWOBYTE_ASC2HEX(pCncsLicSd->chChkSum)))))
		{
			for(i=0;i<VER_BDD_MAX_CNT;i++)
			{
				if(!MAKE_DWORD(0x00,m_tmUtcTime.year,m_tmUtcTime.month,m_tmUtcTime.day))
				{
					pLicVerDp->VerCnt = FALSE;
					memset(pLicVerDp->cvbBuf[i].chVer,'0',4);
					memset(pLicVerDp->cvbBuf[i].chBuildDate,'0',6);
					break;
				}
				else
				{
					pLicVerDp->VerCnt = TRUE;

					// ���� �Է�
					pLicVerDp->cvbBuf[i].chVer[0] = pCncsLicSd->cvbBuf[i].chVer[0]; 
					pLicVerDp->cvbBuf[i].chVer[1] = pCncsLicSd->cvbBuf[i].chVer[1]; 
					pLicVerDp->cvbBuf[i].chVer[2] = pCncsLicSd->cvbBuf[i].chVer[2]; 
					pLicVerDp->cvbBuf[i].chVer[3] = pCncsLicSd->cvbBuf[i].chVer[3];

					// ������� ��¥ �Է�
					pLicVerDp->cvbBuf[i].chBuildDate[0] = pCncsLicSd->cvbBuf[i].chBuildDate[0];
					pLicVerDp->cvbBuf[i].chBuildDate[1] = pCncsLicSd->cvbBuf[i].chBuildDate[1];
					pLicVerDp->cvbBuf[i].chBuildDate[2] = pCncsLicSd->cvbBuf[i].chBuildDate[2];
					pLicVerDp->cvbBuf[i].chBuildDate[3] = pCncsLicSd->cvbBuf[i].chBuildDate[3];
					pLicVerDp->cvbBuf[i].chBuildDate[4] = pCncsLicSd->cvbBuf[i].chBuildDate[4];
					pLicVerDp->cvbBuf[i].chBuildDate[5] = pCncsLicSd->cvbBuf[i].chBuildDate[5];
				}
			}

			if(TWOBYTE_ASC2HEX(pCncsLicSd->sWaySide) == 0x01 && !m_LIC_CNCS_Tx_Flag) // wayside on �˸�
			{
				m_nCDT_FaultDataStFlag = 1;

				//2011_03_03 ���� 
				m_nFaultCnt = 0;						// ���� ������ 0���� �ʱ�ȭ.(Y.J �߰�);
				memset((UCHAR *)NVSRAM_BASE,0x00,1024); // ���� ������ "0" ���� �ʽ�ȭ �Ѵ�. �ʱ� ��ġ 0���� 1024������ �ʱ�ȭ �Ѵ�.
				ClearFltBlkInfo();						// ���� ������ Clear�ϴ� �κ�.
				
				//memset(aaa_FaultBlkList, 0xFF, 1024);

				m_nNvsramPos = 0;	//��ü ��� ���� ��ġ�� ó������
				nRecving_Posi = 0;	//���� ���� ������ ��ġ�� ó������
				m_nLnWkTxFlag = 0;	//���� �ڵ� ������ 0���� �ʱ�ȭ

				m_nLnWkTxFlag = TWOBYTE_ASC2HEX(pCncsLicSd->sDaType);

				// ���� �ð� ��û WORD -> DWORD�� ����.(2011.05.08)
				m_nDateTime2SecondCnt = MAKE_DWORD( MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->sFaultTime[0]),ConvAsc2Hex(pCncsLicSd->sFaultTime[1])),
													MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->sFaultTime[2]),ConvAsc2Hex(pCncsLicSd->sFaultTime[3])),
													MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->sFaultTime[4]),ConvAsc2Hex(pCncsLicSd->sFaultTime[5])),
													MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->sFaultTime[6]),ConvAsc2Hex(pCncsLicSd->sFaultTime[7])));
			}
		}
		else if(pCncs_Lic_T_F_C->phHdBuf.btSoh == SOH &&																			// ���� �ð� ��û WORD -> DWORD�� ����.(2011.05.11)
			pCncs_Lic_T_F_C->btEot == EOT &&
			sizeof(CNCS_LIC_T_F_C) == nRxPos &&
		   (TWOBYTE_ASC2HEX(pCncs_Lic_T_F_C->phHdBuf.chDestDev) == m_chCarKindNum) &&
		   (TWOBYTE_ASC2HEX(pCncsLicSd->sCommand) == 0x07) &&  //���� ���� Ȯ�� ����(CNCS-> LIC)
		   !((Make1ByteBcc(&pCncs_Lic_T_F_C->phHdBuf.chSrcDev[0],nRxPos-4)^(TWOBYTE_ASC2HEX(pCncs_Lic_T_F_C->chChkSum)))))
		{
			// Y.J 2011-05-10 ��û�� ���� Index�� ����Ͽ�, �����ϵ��� ����.
			sPotoLen = MAKE_WORD(MAKE_BYTE(ConvAsc2Hex(pCnsc_Lic_T_F->sTEXT[0]),ConvAsc2Hex(pCnsc_Lic_T_F->sTEXT[1])),
			                     MAKE_BYTE(ConvAsc2Hex(pCnsc_Lic_T_F->sTEXT[2]),ConvAsc2Hex(pCnsc_Lic_T_F->sTEXT[3])));
			if(sPotoLen)
			{
				// �������� ���� ���� ������ ����.
				pInfo = GetFltBlkInfo(m_chCarKind);
				
				if(pInfo != NULL)
				{
					// ������ ���� ��ġ�� �̵�.
					nRecving_Posi = pInfo->nStPosi + ((sPotoLen-1) * 128);

					// ������ ���� ũ�⸦ ���ϴ� �κ�.
					if(sPotoLen < pInfo->nTCnt) //  (sPotoLen*128) <= nTempBlkEnd)
					{
						nBlkSize = 128;
					}
					else if(sPotoLen == pInfo->nTCnt)
					{
						nBlkSize = (pInfo->nEdPosi - pInfo->nStPosi) % 128; // - ((sPotoLen - 1) * 128);
					}
					else
					{
						nBlkSize = 0;
					}

					if(nBlkSize < 0) nBlkSize = 0; 

					// ������ ������ ��ġ�� ����.
					nTempBlkEnd = pInfo->nEdPosi;
				}

				sTxDataSize = nBlkSize + 2;

				// ���� �����͸� �����ϴ� �κ�.
				user_FaultDataTx(btTx2chBuf,sTxDataSize,TRUE,sPotoLen);
				user_CncsTx(btTx2chBuf,(sTxDataSize*2)+18);

				// ���� ��, ���� ��ġ�� ������ ��ġ�� ����.
				nRecving_Posi = nTempBlkEnd;
			}
			else 
			//�ٷ� ���� �ڵ尡 ���� �ɼ� �ִ�.
			{ 
				user_FtpEnd_CarNumFun();
			}
		}
	}
	else // ����Ÿ ����
	{
		if(m_nTxDbg1msTimer > 150)
		{
			//���� ���� ����.
			if(m_LIC_CNCS_Tx_Flag)
			{ 
				m_nTxDbg1msTimer = 0;

				m_LIC_CNCS_TX_DelyTime++;

				if(m_LIC_CNCS_TX_DelyTime > 50){m_bLnWkFtpEndFlag = TRUE;} 

				if((m_nNvsramPos !=  (nRecving_Posi)) && (m_nNvsramPos >= (nRecving_Posi+128)))
				{
					m_nFaultCnt++;
					if(m_nFaultCnt == 1) 
						SetFltBlkStPos(m_chCarKind, nRecving_Posi);									// ù��° ������ ���, ���� ������ ���� ��ġ�� ���.

					sTxDataSize = 128 + 2;

					user_FaultDataTx(btTx2chBuf,sTxDataSize,FALSE,0);

					nRecving_Posi += 128;

					user_CncsTx(btTx2chBuf,(sTxDataSize*2)+18);
				}
				else 
				//�ٷ� ���� �ڵ尡 ���� �ɼ� �ִ�.
				if(m_bLnWkFtpEndFlag)
				{ 
					m_nFaultCnt++;
					//aaa_CarAFautlCnt = m_nFaultCnt;

					if(m_nFaultCnt == 1) 
						SetFltBlkStPos(m_chCarKind, nRecving_Posi);									// ù��° ������ ���, ���� ������ ���� ��ġ�� ���.

					// ���� ������ �����ϴ� �κ�.					
					SetFltBlkEdInfo(m_chCarKind, m_nNvsramPos, m_nFaultCnt);

					sTxDataSize = (m_nNvsramPos - nRecving_Posi) + 2;
					user_FaultDataTx(btTx2chBuf,sTxDataSize,TRUE,0);
					nRecving_Posi += (sTxDataSize-2);

					// user_FtpEnd_CarNumFun();

					user_CncsTx(btTx2chBuf,(sTxDataSize*2)+18);

					m_LIC_CNCS_Tx_Flag = FALSE;
				} 				
			}
			else
			//�ð� ���� ��û.
			if(m_nTxDbg1msTimer > 1000)
			{ 
				m_nTxDbg1msTimer = 0;

				nTimeSendCnt++;
				nTimeSendCnt = nTimeSendCnt%255;

				pCnsc_Lic_T_F = (CNCS_LIC_T_F *) btTx2chBuf;

				sTxDataSize = 4;

				pCnsc_Lic_T_F->phHdBuf.btSoh =  0x01;
				pCnsc_Lic_T_F->phHdBuf.chSrcDev[0] =  ConvHex2Asc(BYTE_H(0x11));
				pCnsc_Lic_T_F->phHdBuf.chSrcDev[1] =  ConvHex2Asc(BYTE_L(0x11));
				pCnsc_Lic_T_F->phHdBuf.chDestDev[0] =  ConvHex2Asc(BYTE_H(0x15));
				pCnsc_Lic_T_F->phHdBuf.chDestDev[1] =  ConvHex2Asc(BYTE_L(0x15));

				pCnsc_Lic_T_F->phHdBuf.chMsgCnt[0] = ConvHex2Asc(BYTE_H(WORD_H(nTimeSendCnt)));
				pCnsc_Lic_T_F->phHdBuf.chMsgCnt[1] = ConvHex2Asc(BYTE_L(WORD_H(nTimeSendCnt)));
				pCnsc_Lic_T_F->phHdBuf.chMsgCnt[2] = ConvHex2Asc(BYTE_H(WORD_L(nTimeSendCnt)));
				pCnsc_Lic_T_F->phHdBuf.chMsgCnt[3] = ConvHex2Asc(BYTE_L(WORD_L(nTimeSendCnt)));

				pCnsc_Lic_T_F->phHdBuf.chCmdCode[0] = ConvHex2Asc(BYTE_H(0x10));
				pCnsc_Lic_T_F->phHdBuf.chCmdCode[1] = ConvHex2Asc(BYTE_L(0x10));

				pCnsc_Lic_T_F->phHdBuf.chDataLen[0] = ConvHex2Asc(BYTE_H(WORD_H(sTxDataSize))); // ����
				pCnsc_Lic_T_F->phHdBuf.chDataLen[1] = ConvHex2Asc(BYTE_L(WORD_H(sTxDataSize))); // ����
				pCnsc_Lic_T_F->phHdBuf.chDataLen[2] = ConvHex2Asc(BYTE_H(WORD_L(sTxDataSize))); // ����
				pCnsc_Lic_T_F->phHdBuf.chDataLen[3] = ConvHex2Asc(BYTE_L(WORD_L(sTxDataSize))); // ����

				pCnsc_Lic_T_F->sCommand[0] = ConvHex2Asc(BYTE_H(0x08));
				pCnsc_Lic_T_F->sCommand[1] = ConvHex2Asc(BYTE_L(0x08));

				pCnsc_Lic_T_F->sTEXT[0] = ConvHex2Asc(BYTE_H(WORD_H(m_nCarNo)));  //���� ��ȣ ����
				pCnsc_Lic_T_F->sTEXT[1] = ConvHex2Asc(BYTE_L(WORD_H(m_nCarNo)));  //���� ��ȣ ����
				pCnsc_Lic_T_F->sTEXT[2] = ConvHex2Asc(BYTE_H(WORD_L(m_nCarNo)));  //���� ��ȣ ����
				pCnsc_Lic_T_F->sTEXT[3] = ConvHex2Asc(BYTE_L(WORD_L(m_nCarNo)));  //���� ��ȣ ����

				pCnsc_Lic_T_F->chContactSignalBuf[0] = ConvHex2Asc(BYTE_H(m_btCttSignalA | m_btCttSignalB));
				pCnsc_Lic_T_F->chContactSignalBuf[1] = ConvHex2Asc(BYTE_L(m_btCttSignalA | m_btCttSignalB));

				sBcc = Make1ByteBcc(&pCnsc_Lic_T_F->phHdBuf.chSrcDev[0],(sTxDataSize*2)+14);

				pCnsc_Lic_T_F->chChkSum[0] = ConvHex2Asc(BYTE_H(sBcc));
				pCnsc_Lic_T_F->chChkSum[1] = ConvHex2Asc(BYTE_L(sBcc));

				pCnsc_Lic_T_F->btEot = 0x04; 

				user_CncsTx(&pCnsc_Lic_T_F->phHdBuf.btSoh,(sTxDataSize*2)+18);
			}
		}
	}

	nOldUart2RxOneByteGapDelayTime = m_nUart2RxOneByteGapDelayTime;
}

// CDT�� ���� ������ �����ϴ� �κ�.
void ClearFltBlkInfo()
{
	memset(&m_tFaultInfo, 0x00, sizeof(m_tFaultInfo));			// ���� ���� ����.
}

// CDT�� ���� ������ ���� ��ġ�� ����.
void SetFltBlkStPos(char chCarKind, int nStPosi)
{
	PFAULT_INFO pInfo = GetFltBlkInfo(chCarKind);

	if(pInfo != NULL) 
		pInfo->nStPosi = nStPosi;								// ���� ���� ��ġ�� ����.
}

// CDT�� ���� ������ �����ϴ� �κ�.
void SetFltBlkEdInfo(char chCarKind, int nEndPosi, int nFltTCnt)
{
	PFAULT_INFO pInfo = GetFltBlkInfo(chCarKind);

	if(pInfo != NULL) 
	{
		pInfo->nTCnt = nFltTCnt;									// ���� ��ü ������ ���.
		pInfo->nEdPosi = nEndPosi;									// ���� ������ ��ġ�� ����.
	}
}

// CDT ���� ������ �����ִ� �κ�.
PFAULT_INFO GetFltBlkInfo(char chCarKind)
{
	int nIdx = chCarKind - 'A';

	if(nIdx < eCDT_MAXIMUM)
		return &m_tFaultInfo[nIdx];

	return NULL;
}

// CDT ���� ������  ������ġ�� �����ִ� �κ�.
int GetFltBlkStPos(char chCarKind)
{
	int nStPos = -1;
	PFAULT_INFO pInfo = GetFltBlkInfo(chCarKind);

	if(pInfo != NULL) 
		nStPos = pInfo->nStPosi;

	return nStPos;
}

void user_FaultDataTx(UCHAR *pTxBuf,UCHAR nLen,UCHAR nEndFlag,int nFltIdx)
{
	UCHAR sTempData = 0;
	PLIC_CNCS_HD pLic_Cncs;
	UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;

	pLic_Cncs =(LIC_CNCS_HD *) pTxBuf;

	pLic_Cncs->phHdBuf.btSoh = 0x01;
	pLic_Cncs->phHdBuf.chSrcDev[0] =  ConvHex2Asc(BYTE_H(0x11));
	pLic_Cncs->phHdBuf.chSrcDev[1] =  ConvHex2Asc(BYTE_L(0x11));
	pLic_Cncs->phHdBuf.chDestDev[0] =  ConvHex2Asc(BYTE_H(0x15));
	pLic_Cncs->phHdBuf.chDestDev[1] =  ConvHex2Asc(BYTE_L(0x15));

	// ���� �ε����� �űԷ� ����(Y.J ����)
	if(!nFltIdx) nFltIdx = m_nFaultCnt;

	pLic_Cncs->phHdBuf.chMsgCnt[0] = ConvHex2Asc(BYTE_H(WORD_H(nFltIdx)));
	pLic_Cncs->phHdBuf.chMsgCnt[1] = ConvHex2Asc(BYTE_L(WORD_H(nFltIdx)));
	pLic_Cncs->phHdBuf.chMsgCnt[2] = ConvHex2Asc(BYTE_H(WORD_L(nFltIdx)));
	pLic_Cncs->phHdBuf.chMsgCnt[3] = ConvHex2Asc(BYTE_L(WORD_L(nFltIdx)));

	pLic_Cncs->phHdBuf.chCmdCode[0] = ConvHex2Asc(BYTE_H(0x10));
	pLic_Cncs->phHdBuf.chCmdCode[1] = ConvHex2Asc(BYTE_L(0x10));

	pLic_Cncs->phHdBuf.chDataLen[0] = ConvHex2Asc(BYTE_H(WORD_H(nLen)));
	pLic_Cncs->phHdBuf.chDataLen[1] = ConvHex2Asc(BYTE_L(WORD_H(nLen)));
	pLic_Cncs->phHdBuf.chDataLen[2] = ConvHex2Asc(BYTE_H(WORD_L(nLen)));
	pLic_Cncs->phHdBuf.chDataLen[3] = ConvHex2Asc(BYTE_L(WORD_L(nLen)));

	if(nEndFlag)
	{
		pLic_Cncs->sCommand[0] = ConvHex2Asc(BYTE_H(0x06));//���� ���� ���� ��.
		pLic_Cncs->sCommand[1] = ConvHex2Asc(BYTE_L(0x06));//���� ���� ���� ��.
	}
	else
	{
		pLic_Cncs->sCommand[0] = ConvHex2Asc(BYTE_H(0x04));//���� ���� ���� ��.
		pLic_Cncs->sCommand[1] = ConvHex2Asc(BYTE_L(0x04));//���� ���� ���� ��.
	}

	pLic_Cncs->sCarKind[0] = ConvHex2Asc(BYTE_H(m_chCarKind));
	pLic_Cncs->sCarKind[1] = ConvHex2Asc(BYTE_L(m_chCarKind));

	FunConvHexAsc(&pNvsram[nRecving_Posi],(char *)pLic_Cncs->sTextDataAsc,(nLen-2));

	sTempData = Make1ByteBcc(&pLic_Cncs->phHdBuf.chSrcDev[0],(nLen*2)+14);

	pLic_Cncs->sTextDataAsc[((nLen-2)*2)] = ConvHex2Asc(BYTE_H(sTempData));
	pLic_Cncs->sTextDataAsc[((nLen-2)*2)+1] = ConvHex2Asc(BYTE_L(sTempData));

	pLic_Cncs->sTextDataAsc[((nLen-2)*2)+2] = 0x04;

	m_LIC_CNCS_TX_DelyTime = 0;
}

//*****************************************************************************************
// ���������� �� ������ ī�� �־� �ٷ� �����Ѵ�.
//*****************************************************************************************
void user_FtpEnd_CarNumFun()
{
	m_bLnWkFtpEndFlag = FALSE;

	m_LIC_CNCS_Tx_Flag = FALSE; //���� ���� ������ ���� �̹Ƿ� ���� ��.
	m_nNvsramPos = 0;
	nRecving_Posi = 0;
	m_nLnWkWaySideOnRxOk = 0;
	m_nFaultCnt = 0;
	//m_chCarKind = 'A';
	m_nLnWkTxFlag = 0;

	/*
	// Single car�� ���
	if(BYTE_L(m_wCarNo>>8) == 0x07)
	{
		m_LIC_CNCS_Tx_Flag = FALSE; //���� ���� ������ ���� �̹Ƿ� ���� ��.
		m_nNvsramPos = 0;
		nRecving_Posi = 0;
		m_nLnWkWaySideOnRxOk = 0;
		m_nFaultCnt = 0;
		m_chCarKind = 'A';
		m_nLnWkTxFlag = 0;
	}
	else
	// Married car�� ��� 
	if(BYTE_L(m_wCarNo>>8) == 0x08)
	{
		if(WORD_L(m_chCarKind) == 'A')
		{
			m_nLnWkWaySideOnRxOk = 0;
			m_nFaultCnt = 0;
			m_chCarKind = 'B';

			m_LIC_CNCS_Tx_Flag = FALSE; //���� ���� ������ ���� �̹Ƿ� ���� ��.

			m_nCDT_FaultDataStFlag = 10;
		}
		else
		{
			m_nNvsramPos = 0;
			nRecving_Posi = 0;
			m_nLnWkWaySideOnRxOk = 0;
			m_nFaultCnt = 0;
			m_chCarKind = 'A';
			m_nLnWkTxFlag = 0;

			m_LIC_CNCS_Tx_Flag = FALSE; //���� ���� ������ ���� �̹Ƿ� ���� ��.
		}
	}
	*/
}

//******************************************************************************************
//	LIC <-> PAC(RS485)
//******************************************************************************************
int d_CI_Fault = 0;
int d_CI_Index = 0;
void user_WithPacRs485Loop()
{
	int i;
	int nRxLen;
	int nCciCnt = 0;
	UCHAR btTmp;
	UCHAR btTmpBuf[100];
	UCHAR btBuf[256];
	static int nRxPos = 0;
	static UCHAR nOldUart3RxOneByteGapDelayTime = 0;
	static UCHAR btRx3chBuf[256];
	PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;

	PPACSDR pPaSdrBuf;
	LICSD lsLicSdBuf;
	PPAC_PAC pPa_PaBuf;

	PCCP_PAC pCcp_Pac;

	PCRA_STATION pPac_Pac_Sta;

	PCOMMSTATUS_PA pCommStatus;
	PCOMMSTATUS_LIC pCommStatus_Lic; 

	// ����
	nRxLen = user_PacRx(btBuf,128);
	if(nRxLen)
	{
		if(!m_nUart3RxOneByteGapDelayTime) nRxPos = 0;
		m_nUart3RxOneByteGapDelayTime = 3;
		
		if(nRxPos + nRxLen < 250)
		{
			memcpy(&btRx3chBuf[nRxPos],btBuf,nRxLen);
			nRxPos += nRxLen;
		}
	}
	
	if(nOldUart3RxOneByteGapDelayTime && !m_nUart3RxOneByteGapDelayTime)
	{
		
		if(nRxPos >= 10)
		{
			pPaSdrBuf = (PACSDR *)btRx3chBuf;

			pPa_PaBuf = (PAC_PAC *)btRx3chBuf;

			
			pCcp_Pac = (CCP_PAC *)btRx3chBuf;

			//PAC -> LIC �κ� ���������� �и� �Ѵ�.
			if(
				WORD_L(pPaSdrBuf->phHdBuf.btSoh) == SOH &&
				WORD_L(pPaSdrBuf->btEot) == EOT &&
				sizeof(PACSDR) == nRxPos &&
				(TWOBYTE_ASC2HEX(pPaSdrBuf->phHdBuf.chDestDev) == m_chCarKindNum)&&

				ConvAsc2Hex(pPaSdrBuf->nCRC[0]) == BYTE_H(WORD_H(crc16_ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&
				ConvAsc2Hex(pPaSdrBuf->nCRC[1]) == BYTE_L(WORD_H(crc16_ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&
				ConvAsc2Hex(pPaSdrBuf->nCRC[2]) == BYTE_H(WORD_L(crc16_ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&
				ConvAsc2Hex(pPaSdrBuf->nCRC[3]) == BYTE_L(WORD_L(crc16_ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6))))
			{
				switch(TWOBYTE_ASC2HEX(pPaSdrBuf->phHdBuf.chCmdCode))
				{
				case REQ_CMD: //PAC -> LIC

					lsLicSdBuf.phHdBuf.btSoh = SOH;
					lsLicSdBuf.phHdBuf.chSrcDev[0] = ConvHex2Asc(BYTE_H(m_chCarKindNum));
					lsLicSdBuf.phHdBuf.chSrcDev[1] = ConvHex2Asc(BYTE_L(m_chCarKindNum));
					lsLicSdBuf.phHdBuf.chDestDev[0] = pPaSdrBuf->phHdBuf.chSrcDev[0];
					lsLicSdBuf.phHdBuf.chDestDev[1] = pPaSdrBuf->phHdBuf.chSrcDev[1];
					lsLicSdBuf.phHdBuf.chMsgCnt[0] = pPaSdrBuf->phHdBuf.chMsgCnt[0];
					lsLicSdBuf.phHdBuf.chMsgCnt[1] = pPaSdrBuf->phHdBuf.chMsgCnt[1];
					lsLicSdBuf.phHdBuf.chCmdCode[0] = ConvHex2Asc(BYTE_H(RPY_CMD));
					lsLicSdBuf.phHdBuf.chCmdCode[1] = ConvHex2Asc(BYTE_L(RPY_CMD));
					lsLicSdBuf.phHdBuf.chDataLen[0] = ConvHex2Asc(BYTE_H(((sizeof(LICSD)-16)/2)));
					lsLicSdBuf.phHdBuf.chDataLen[1] = ConvHex2Asc(BYTE_L(((sizeof(LICSD)-16)/2)));

					lsLicSdBuf.DATA1.BIT.All_Doors_Closed = 0;
					lsLicSdBuf.DATA1.BIT.EP_Mode = 0;
					lsLicSdBuf.DATA1.BIT.Traction = 0;
					lsLicSdBuf.DATA1.BIT.Atcive_Cab = 0;
				
					lsLicSdBuf.DATA2.BIT.CI_Fault = d_CI_Fault;
					lsLicSdBuf.DATA2.BIT.DST = 0;

					lsLicSdBuf.DATA1.BYTE = ConvHex2Asc(BYTE_L(lsLicSdBuf.DATA1.BYTE));

					lsLicSdBuf.DATA2.BYTE = ConvHex2Asc(BYTE_L(lsLicSdBuf.DATA2.BYTE));

					lsLicSdBuf.CI_Index_Num[0] = ConvHex2Asc(BYTE_H(d_CI_Index));
					lsLicSdBuf.CI_Index_Num[1] = ConvHex2Asc(BYTE_L(d_CI_Index));

					lsLicSdBuf.chCarn[0][0] = ConvHex2Asc(BYTE_H(WORD_H(m_nCarNo))); // Car Number(-.���ڸ�)
					lsLicSdBuf.chCarn[0][1] = ConvHex2Asc(BYTE_L(WORD_H(m_nCarNo)));
					lsLicSdBuf.chCarn[1][0] = ConvHex2Asc(BYTE_H(m_nCarNo)); // Car Number(���ڸ�,���ڸ�)
					lsLicSdBuf.chCarn[1][1] = ConvHex2Asc(BYTE_L(m_nCarNo));

					btTmp = crc16_ccitt(&lsLicSdBuf.phHdBuf.chSrcDev[0],sizeof(LICSD)-6);
					lsLicSdBuf.nCRC[0] = ConvHex2Asc(BYTE_H(WORD_H(btTmp)));
					lsLicSdBuf.nCRC[1] = ConvHex2Asc(BYTE_L(WORD_H(btTmp)));
					lsLicSdBuf.nCRC[2] = ConvHex2Asc(BYTE_H(WORD_L(btTmp)));
					lsLicSdBuf.nCRC[3] = ConvHex2Asc(BYTE_L(WORD_L(btTmp)));
					lsLicSdBuf.btEot = EOT;
					
					user_PacTx((UCHAR *)&lsLicSdBuf,sizeof(LICSD));
					break;
				default:
					break;

				}
			}
			else
			if(WORD_L(pPa_PaBuf->phHdBuf.btSoh) == SOH &&  // PAC <-> PAC ���� ���� ������ �����Ѵ�.
				    WORD_L(pPa_PaBuf->btEot) == EOT &&
				    sizeof(PAC_PAC) == nRxPos &&
					(TWOBYTE_ASC2HEX(pPa_PaBuf->phHdBuf.chSrcDev) == PAC_DEV_NO) && 
				    (TWOBYTE_ASC2HEX(pPa_PaBuf->phHdBuf.chDestDev) == PAC_BAKDEV_NO)&&

				    ConvAsc2Hex(pPa_PaBuf->nCRC[0]) == BYTE_H(WORD_H(crc16_ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&
					ConvAsc2Hex(pPa_PaBuf->nCRC[1]) == BYTE_L(WORD_H(crc16_ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&
					ConvAsc2Hex(pPa_PaBuf->nCRC[2]) == BYTE_H(WORD_L(crc16_ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&
					ConvAsc2Hex(pPa_PaBuf->nCRC[3]) == BYTE_L(WORD_L(crc16_ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))
				    )
			{
					memset(m_btCommSt,0x00,sizeof(m_btCommSt));
					
					pCommStatus_Lic = (COMMSTATUS_LIC *)m_btCommSt;

					for(i=0;i<4;i++)
					{
						FunConvAscHex((char *)&pPa_PaBuf->phCRA_Sta[i][0][0] ,btTmpBuf,22);

						pPac_Pac_Sta = (CRA_STATION *) btTmpBuf;

						if(m_chCarKind == 'A')
						{
							if(DWORD_L(m_nCarNo) == MAKE_WORD(pPac_Pac_Sta->CarNum_H,pPac_Pac_Sta->CarNum_L))
							{
								pCommStatus_Lic->BYTE_1.BIT.nCcp = pPac_Pac_Sta->CRA_2.BIT.sACCP1;
								pCommStatus_Lic->BYTE_1.BIT.nCncs = pPac_Pac_Sta->CRA_3.BIT.sACNCS;
								pCommStatus_Lic->BYTE_1.BIT.nGps = pPac_Pac_Sta->CRA_2.BIT.sAGPS;
								pCommStatus_Lic->BYTE_1.BIT.nLic = pPac_Pac_Sta->CRA_3.BIT.sALIC;
								pCommStatus_Lic->BYTE_1.BIT.nPac = pPac_Pac_Sta->CRA_3.BIT.sAPAC;
								pCommStatus_Lic->BYTE_1.BIT.nVoip = pPac_Pac_Sta->CRA_2.BIT.sAVOIP;
								pCommStatus_Lic->BYTE_1.BIT.nVtx = pPac_Pac_Sta->CRA_3.BIT.sAVTX;
								pCommStatus_Lic->BYTE_1.BIT.nWlr = pPac_Pac_Sta->CRA_2.BIT.sAWLR;


								pCommStatus_Lic->BYTE_2.BIT.nFdi = pPac_Pac_Sta->CRA_4.BIT.sAFDI;
								pCommStatus_Lic->BYTE_2.BIT.nPii1 = pPac_Pac_Sta->CRA_4.BIT.sAPII1;
								pCommStatus_Lic->BYTE_2.BIT.nPii2 = pPac_Pac_Sta->CRA_4.BIT.sAPII2;
								pCommStatus_Lic->BYTE_2.BIT.nSdi1 = pPac_Pac_Sta->CRA_5.BIT.sASDI1;
								pCommStatus_Lic->BYTE_2.BIT.nSdi2 = pPac_Pac_Sta->CRA_5.BIT.sASDI2;
								pCommStatus_Lic->BYTE_2.BIT.nSdi3 = pPac_Pac_Sta->CRA_5.BIT.sASDI3;
								pCommStatus_Lic->BYTE_2.BIT.nSdi4 = pPac_Pac_Sta->CRA_5.BIT.sASDI4;

								pCommStatus_Lic->BYTE_3.BIT.nPid1_1 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_1;
								pCommStatus_Lic->BYTE_3.BIT.nPid1_2 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_2;
								pCommStatus_Lic->BYTE_3.BIT.nPid1_3 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_3;
								pCommStatus_Lic->BYTE_3.BIT.nPid1_4 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_4;
								pCommStatus_Lic->BYTE_3.BIT.nPid2_1 = pPac_Pac_Sta->CRA_7.BIT.sAPID2_1;

								pCommStatus_Lic->BYTE_4.BIT.nDph = pPac_Pac_Sta->CRA_9.BIT.sADPH;
								pCommStatus_Lic->BYTE_4.BIT.nDpo = pPac_Pac_Sta->CRA_9.BIT.sADPO;
								pCommStatus_Lic->BYTE_4.BIT.nPei1 = pPac_Pac_Sta->CRA_7.BIT.sAPEI1;
								pCommStatus_Lic->BYTE_4.BIT.nPei2 = pPac_Pac_Sta->CRA_7.BIT.sAPEI2;
								
								break;
							}
						}
						else if(m_chCarKind == 'B') //�������ݿ��� MA ���� ��ȣ�� �����Ƿ� MB�� ������ �ν� �ؾ� �Ѵ�.
						{
							if(DWORD_L(m_nCarNo) == (MAKE_WORD(pPac_Pac_Sta->CarNum_H,pPac_Pac_Sta->CarNum_L)+1))
							{
								pCommStatus_Lic->BYTE_1.BIT.nCcp = pPac_Pac_Sta->CRA_2.BIT.sBCCP1;
								pCommStatus_Lic->BYTE_1.BIT.nCncs = pPac_Pac_Sta->CRA_3.BIT.sBCNCS;
								pCommStatus_Lic->BYTE_1.BIT.nGps = pPac_Pac_Sta->CRA_2.BIT.sBGPS;
								pCommStatus_Lic->BYTE_1.BIT.nLic = pPac_Pac_Sta->CRA_3.BIT.sBLIC;
								pCommStatus_Lic->BYTE_1.BIT.nPac = pPac_Pac_Sta->CRA_3.BIT.sBPAC;
								pCommStatus_Lic->BYTE_1.BIT.nVoip = pPac_Pac_Sta->CRA_2.BIT.sBVOIP;
								pCommStatus_Lic->BYTE_1.BIT.nVtx = pPac_Pac_Sta->CRA_3.BIT.sBVTX;
								pCommStatus_Lic->BYTE_1.BIT.nWlr = pPac_Pac_Sta->CRA_2.BIT.sBWLR;


								pCommStatus_Lic->BYTE_2.BIT.nFdi = pPac_Pac_Sta->CRA_4.BIT.sBFDI;
								pCommStatus_Lic->BYTE_2.BIT.nPii1 = pPac_Pac_Sta->CRA_4.BIT.sBPII1;
								pCommStatus_Lic->BYTE_2.BIT.nPii2 = pPac_Pac_Sta->CRA_4.BIT.sBPII2;
								pCommStatus_Lic->BYTE_2.BIT.nSdi1 = pPac_Pac_Sta->CRA_5.BIT.sBSDI1;
								pCommStatus_Lic->BYTE_2.BIT.nSdi2 = pPac_Pac_Sta->CRA_5.BIT.sBSDI2;
								pCommStatus_Lic->BYTE_2.BIT.nSdi3 = pPac_Pac_Sta->CRA_5.BIT.sBSDI3;
								pCommStatus_Lic->BYTE_2.BIT.nSdi4 = pPac_Pac_Sta->CRA_5.BIT.sBSDI4;

								pCommStatus_Lic->BYTE_3.BIT.nPid1_1 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_1;
								pCommStatus_Lic->BYTE_3.BIT.nPid1_2 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_2;
								pCommStatus_Lic->BYTE_3.BIT.nPid1_3 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_3;
								pCommStatus_Lic->BYTE_3.BIT.nPid1_4 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_4;
								pCommStatus_Lic->BYTE_3.BIT.nPid2_1 = pPac_Pac_Sta->CRA_7.BIT.sBPID2_1;

								pCommStatus_Lic->BYTE_4.BIT.nDph = pPac_Pac_Sta->CRA_9.BIT.sBDPH;
								pCommStatus_Lic->BYTE_4.BIT.nDpo = pPac_Pac_Sta->CRA_9.BIT.sBDPO;
								pCommStatus_Lic->BYTE_4.BIT.nPei1 = pPac_Pac_Sta->CRA_7.BIT.sBPEI1;
								pCommStatus_Lic->BYTE_4.BIT.nPei2 = pPac_Pac_Sta->CRA_7.BIT.sBPEI2;
								break;
							}
						}
						
					}

			}
			else
				if(WORD_L(pCcp_Pac->phHdBuf.btSoh) == SOH &&  // CCP -> PAC ���� ���� ������ �����Ѵ�.
					WORD_L(pCcp_Pac->btEot) == EOT &&
					sizeof(CCP_PAC) == nRxPos &&
					(TWOBYTE_ASC2HEX(pCcp_Pac->phHdBuf.chSrcDev) == CCP_DEV_NO) &&
					(TWOBYTE_ASC2HEX(pCcp_Pac->phHdBuf.chDestDev) == PAC_DEV_NO)&&

					ConvAsc2Hex(pCcp_Pac->nCRC[0]) == BYTE_H(WORD_H(crc16_ccitt(&pCcp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))&&
					ConvAsc2Hex(pCcp_Pac->nCRC[1]) == BYTE_L(WORD_H(crc16_ccitt(&pCcp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))&&
					ConvAsc2Hex(pCcp_Pac->nCRC[2]) == BYTE_H(WORD_L(crc16_ccitt(&pCcp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))&&
					ConvAsc2Hex(pCcp_Pac->nCRC[3]) == BYTE_L(WORD_L(crc16_ccitt(&pCcp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))
					)
			{
					d_CI_Index = MAKE_BYTE(ConvAsc2Hex(pCcp_Pac->sCI_Index[0][0]),ConvAsc2Hex(pCcp_Pac->sCI_Index[0][1]) );

					FunConvAscHex((char *)&pCcp_Pac->sCCP_Date[0][0],btTmpBuf,12);

					memcpy(&m_tmCurTime.second,btTmpBuf,6);

				/*	m_tmCurTime.second = TWOBYTE_ASC2HEX(pCcp_Pac->sSecond);
					m_tmCurTime.minute = TWOBYTE_ASC2HEX(pCncsLicSd->sMinute);
					m_tmCurTime.hour   = TWOBYTE_ASC2HEX(pCncsLicSd->sHour);
					m_tmCurTime.day    = TWOBYTE_ASC2HEX(pCncsLicSd->sDay);
					m_tmCurTime.month  = TWOBYTE_ASC2HEX(pCncsLicSd->sMonth);
					m_tmCurTime.year   = TWOBYTE_ASC2HEX(pCncsLicSd->sYear);*/

					memset(&m_tmUtcTime, 0x00, sizeof(DATE_TIME_TYPE));

					if(m_LIC_CNCS_TimSetFlag = GetLocalTimeToUTC(&m_tmCurTime, -5, &m_tmUtcTime))
					{
						m_tmUtcTime.year	= ConvDec2Hex(m_tmUtcTime.year	);
						m_tmUtcTime.month	= ConvDec2Hex(m_tmUtcTime.month );
						m_tmUtcTime.day		= ConvDec2Hex(m_tmUtcTime.day	);
						m_tmUtcTime.hour	= ConvDec2Hex(m_tmUtcTime.hour	);
						m_tmUtcTime.minute	= ConvDec2Hex(m_tmUtcTime.minute);
						m_tmUtcTime.second	= ConvDec2Hex(m_tmUtcTime.second);
				
						m_nCncsRxCheck1msTimer = 2000;
					}



			}
		
		}
	}

	nOldUart3RxOneByteGapDelayTime = m_nUart3RxOneByteGapDelayTime;
}

//******************************************************************************************
//	UTC �ð��� ���ϴ� �κ�.
//*****************************************************************************************
BOOL GetLocalTimeToUTC( DATE_TIME_PTR pLocal, int nHour, DATE_TIME_PTR pUTC )
{
	// �ð��� ����ϴ� �κ�.
	int nHourT = pLocal->hour - nHour;
	int nDayT = pLocal->day;
	int nLastDays = GetDaysOfMonth( pLocal->month, pLocal->year );													
	int nMonthT = pLocal->month;
	int nYearT = 2000 + pLocal->year;

	// �ð� ������ ���ϴ� �κ�.
	if(nHourT < 0 ) {
		nHourT += 24;
		nDayT += -1;
	}
	else if( 24 <= nHourT ) {
		nHourT -= 24;
		nDayT += 1;
	}

	// ���ڸ� ���ϴ� �κ�.
	// �ð��� ����Ͽ� ���ڸ� �����ؾ��ϴ� ���.
	if(nDayT < 1)																										
	{
		nDayT = GetDaysOfMonth( nMonthT, nYearT );
		
		if(--nMonthT < 1)
		{
			nYearT--;
			nMonthT = 12;
		}
	}
	else if(nLastDays < nDayT)
	{
		nDayT = 1;
		
		if(12 < ++nMonthT)
		{
			nYearT++;
			nMonthT = 1;
		}
	}

	// ���� �ú��� ������ UTC �ð����� �̵���Ű�� �κ�.
	pUTC->second = pLocal->second;
	pUTC->minute = pLocal->minute;
	pUTC->hour = nHourT;
	pUTC->day = nDayT;
	pUTC->month = nMonthT;
	pUTC->year = nYearT - 2000;

	return      (( 10 <= pUTC->year ) &&																		// 10�� �̻�
				(( 1 <= pUTC->month ) && ( pUTC->month <= 12 )) &&											// ��
				(( 1 <= pUTC->day )   && ( pUTC->day <= GetDaysOfMonth(nMonthT, nYearT) )) && 				// ��
				(( 0 <= pUTC->hour )  && ( pUTC->hour < 24 ))   && 											// ��
				(( 0 <= pUTC->minute) && ( pUTC->minute < 60 )) &&											// ��
				(( 0 <= pUTC->second) && ( pUTC->second < 60 )));											// ��
}

//******************************************************************************************
//	���� ������ ���� ������ ���ϴ� �κ�.
//******************************************************************************************
int IsLeapYear( int nYear ) 								// ���� ������ ���ϴ� �κ�.
{
  if( nYear % 400 == 0 )
   return 1;

  if( nYear % 100 == 0 )
   return 0;

  if( nYear % 4 == 0 )
   return 1;

  return 0;
}

int GetDaysOfMonth( int nMonth, int nYear ) 				// ���� ������ ���ڸ� ���ϴ� �κ�.
{
	/* ���� �ϼ��� �����ϴ� ���� */
	int nDays = 0;

	switch( nMonth )
	{
	case 1 :												// 31�� ������ ����
	case 3 :
	case 5 :
	case 7 :
	case 8 :
	case 10 :
	case 12 :		
		nDays = 31;
		break;
	case 2 :
		nDays = 28;
		if( IsLeapYear( nYear ) )							// ������ ����Ͽ�, ������ ���, +1
			nDays += 1;
		break;
	case 4 :												// 30�� ������ ����
	case 6 :
	case 9 :
	case 11 : 
		nDays = 30;
		break;
	}

	return nDays;
}

//******************************************************************************************
//	������ȣ�� LON���� �����Ͽ� Aī���� Bī���� �˷��ش�.
// �� �Լ��� ȣ���ϸ� 5ȸ �ݺ��Ͽ� �����ش�.
//******************************************************************************************
void user_CarNoForCarKindToLon()
{
	m_nCarKindToLonCnt = 0;
}

//******************************************************************************************
//	1ms Loop
//******************************************************************************************
void user_1msLoop()
{	
	int i;
	int nTxPos = 0;
	UCHAR btTxBuf[32];
	static UINT nDelayCnt = 0;
	
	m_nTxDbg1msTimer++;
	m_nUserDebug1msTimer++;
	m_nSingleOrMarriedCarUpdate1msTimer++;
	m_nTest1msTimer++;

	if(!(m_nUserDebug1msTimer%100)) //A�� ���� �ϰ� 1�� �ִٰ� B�� ���� �ϱ� ���Ͽ� �ð��� ������ �Ѵ�.
	{
		if(m_nCDT_FaultDataStFlag) m_nCDT_FaultDataStFlag--;
	}
	
	if(m_nUart1RxOneByteGapDelayTime) m_nUart1RxOneByteGapDelayTime--;
	if(m_nUart2RxOneByteGapDelayTime) m_nUart2RxOneByteGapDelayTime--;
	if(m_nUart3RxOneByteGapDelayTime) m_nUart3RxOneByteGapDelayTime--;
		
	if(m_nGiaRxCheck1msTimer) m_nGiaRxCheck1msTimer--;

	if(m_nCncsRxCheck1msTimer) m_nCncsRxCheck1msTimer--;
		
	if(m_nCarKindToLonCnt < 6 && !(nDelayCnt%2000))
	{
		m_nCarKindToLonCnt++;

		nTxPos = 0;
		btTxBuf[nTxPos++] = STX; // STX
		btTxBuf[nTxPos++] = 0xF0; // Command Code
		btTxBuf[nTxPos++] = 0x00; // Message Code
		btTxBuf[nTxPos++] = 0x02; // ����
		btTxBuf[nTxPos++] = WORD_H(m_nCarNo); // ������ȣ ����
		btTxBuf[nTxPos++] = WORD_L(m_nCarNo); // ������ȣ ����
		btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum
		btTxBuf[nTxPos++] = ETX; // ETX
		user_LonWorkTx(btTxBuf,nTxPos);

		MyPrintf("[TX:%02d] ",nTxPos);
		for(i=0;i<nTxPos;i++) MyPrintf("%02X ",WORD_L(btTxBuf[i]));
		MyPrintf("\r\n");
	}
	
	nDelayCnt++;
}

