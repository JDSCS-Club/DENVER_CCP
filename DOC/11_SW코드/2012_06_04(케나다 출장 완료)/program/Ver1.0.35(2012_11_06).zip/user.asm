;******************************************************************************
;* TMS320C3x/4x ANSI C Code Generator                            Version 5.11 *
;* Date/Time created: Tue Nov  6 13:31:53 2012                                *
;******************************************************************************
	.regalias	; enable floating point register aliases
fp	.set	ar3
FP	.set	ar3
;******************************************************************************
;* GLOBAL FILE PARAMETERS                                                     *
;*                                                                            *
;*   Optimization       : Always Choose Smaller Code Size                     *
;*   Memory             : Small Memory Model                                  *
;*   Float-to-Int       : Normal Conversions (round toward zero)              *
;*   Multiply           : in Hardware (24 bits max)                           *
;*   Memory Info        : Unmapped Memory Exists                              *
;*   Repeat Loops       : Use RPTS and/or RPTB                                *
;*   Calls              : Normal Library ASM calls                            *
;*   Debug Info         : Optimized TI Debug Information                      *
;******************************************************************************
;	c:\lang\tms320c3x\511\bin\ac30.exe user.c C:\Users\JDS\AppData\Local\Temp\user.if 
	.file	"user.c"
	.file	"string.h"
	.sym	_size_t,0,14,13,32
	.file	"def.h"
	.sym	_WORD,0,13,13,32
	.sym	_USHORT,0,13,13,32
	.sym	_BYTE,0,12,13,32
	.sym	_UCHAR,0,12,13,32
	.sym	_UINT,0,14,13,32
	.sym	_BOOL,0,4,13,32
	.sym	_DWORD,0,15,13,32
	.file	"ds1647.h"
	.stag	.fake1,32
	.member	_R,6,4,18,1
	.member	_W,7,4,18,1
	.eos
	.stag	.fake2,32
	.member	_Sec,0,4,18,7
	.member	_Osc,7,4,18,1
	.eos
	.stag	.fake3,32
	.member	_Day,0,4,18,3
	.member	_SPare2,3,4,18,3
	.member	_FT,6,4,18,1
	.member	_Spare1,7,4,18,1
	.eos
	.utag	.fake0,32
	.member	_CtrlBit,0,8,11,32,.fake1
	.member	_SecBit,0,8,11,32,.fake2
	.member	_DayBit,0,8,11,32,.fake3
	.member	_B8,0,12,11,32
	.eos
	.sym	_DS1647ONELTP,0,9,13,32,.fake0
	.sym	_PDS1647ONELTP,0,25,13,32,.fake0
	.stag	.fake4,256
	.member	_Ctrl,0,9,8,32,.fake0
	.member	_Second,32,9,8,32,.fake0
	.member	_Minute,64,9,8,32,.fake0
	.member	_Hour,96,9,8,32,.fake0
	.member	_Day,128,9,8,32,.fake0
	.member	_Date,160,9,8,32,.fake0
	.member	_Month,192,9,8,32,.fake0
	.member	_Year,224,9,8,32,.fake0
	.eos
	.sym	_DS1647BDY,0,8,13,256,.fake4
	.sym	_PDS1647BDY,0,24,13,32,.fake4
	.stag	.fake5,224
	.member	_second,0,12,8,32
	.member	_minute,32,12,8,32
	.member	_hour,64,12,8,32
	.member	_day,96,12,8,32
	.member	_month,128,12,8,32
	.member	_year,160,12,8,32
	.member	_weekday,192,12,8,32
	.eos
	.sym	_DATE_TIME_TYPE,0,8,13,224,.fake5
	.sym	_DATE_TIME_PTR,0,24,13,32,.fake5
	.file	"main.h"
	.file	"xr16l784.h"
	.utag	.fake7,32
	.member	_btRxd,0,12,11,32
	.member	_btTxd,0,12,11,32
	.member	_btDll,0,12,11,32
	.eos
	.utag	.fake8,32
	.member	_btDlm,0,12,11,32
	.member	_btIer,0,12,11,32
	.eos
	.utag	.fake9,32
	.member	_btIir,0,12,11,32
	.member	_btFcr,0,12,11,32
	.eos
	.stag	.fake6,512
	.member	_CREG1,0,9,8,32,.fake7
	.member	_CREG2,32,9,8,32,.fake8
	.member	_CREG3,64,9,8,32,.fake9
	.member	_btLcr,96,12,8,32
	.member	_btMcr,128,12,8,32
	.member	_btLsr,160,12,8,32
	.member	_btMsr_U,192,12,8,32
	.member	_btScr,224,12,8,32
	.member	_btSp,256,60,8,256,,8
	.eos
	.sym	_XR16L784ST,0,8,13,512,.fake6
	.sym	_PXR16L784ST,0,24,13,32,.fake6
	.stag	.fake10,2048
	.member	_xr16Reg,0,56,8,2048,.fake6,4
	.eos
	.sym	_XR16L784BDY,0,8,13,2048,.fake10
	.sym	_PXR16L784BDY,0,24,13,32,.fake10
	.file	"user.h"
	.stag	.fake11,6400
	.member	_btStx,0,12,8,32
	.member	_btCmd,32,12,8,32
	.member	_btMessCode,64,12,8,32
	.member	_btLen,96,12,8,32
	.member	_btDat,128,60,8,6272,,196
	.eos
	.sym	_LNWKFTPIT,0,8,13,6400,.fake11
	.sym	_PLNWKFTPIT,0,24,13,32,.fake11
	.stag	.fake12,6400
	.member	_btStx,0,12,8,32
	.member	_btCmd,32,12,8,32
	.member	_btMessCode,64,12,8,32
	.member	_btLen,96,12,8,32
	.member	_btDat,128,60,8,6272,,196
	.eos
	.sym	_LNWKGERIT,0,8,13,6400,.fake12
	.sym	_PLNWKGERIT,0,24,13,32,.fake12
	.stag	.fake13,51712
	.member	_btKind,0,12,8,32
	.member	_btVerH,32,12,8,32
	.member	_btVerL,64,12,8,32
	.member	_btBuildDateHH,96,12,8,32
	.member	_btBuildDateHL,128,12,8,32
	.member	_btBuildDateLH,160,12,8,32
	.member	_btBuildDateLL,192,12,8,32
	.member	_btSpare,224,60,8,288,,9
	.member	_lfBuf,512,56,8,38400,.fake11,6
	.member	_lgRxBuf,38912,8,8,6400,.fake12
	.member	_lgTxBuf,45312,8,8,6400,.fake12
	.eos
	.sym	_LNWKDP,0,8,13,51712,.fake13
	.sym	_PLNWKDP,0,24,13,32,.fake13
	.stag	.fake14,352
	.member	_btSoh,0,12,8,32
	.member	_chSrcDev,32,60,8,64,,2
	.member	_chDestDev,96,60,8,64,,2
	.member	_chMsgCnt,160,60,8,64,,2
	.member	_chCmdCode,224,60,8,64,,2
	.member	_chDataLen,288,60,8,64,,2
	.eos
	.sym	_PTCHD,0,8,13,352,.fake14
	.sym	_PPTCHD,0,24,13,32,.fake14
	.stag	.fake15,768
	.member	_chPacT,0,60,8,64,,2
	.member	_chCcpM,64,60,8,64,,2
	.member	_chCncsT,128,60,8,64,,2
	.member	_chD0,192,60,8,64,,2
	.member	_chD1,256,60,8,64,,2
	.member	_chTran,320,252,8,192,,3,2
	.member	_chCid,512,252,8,192,,3,2
	.member	_chDs,704,60,8,64,,2
	.eos
	.sym	_PROTOCOL_1,0,8,13,768,.fake15
	.stag	.fake16,576
	.member	_phHdBuf,0,8,8,352,.fake14
	.member	_nDdata,352,60,8,64,,2
	.member	_nCRC,416,60,8,128,,4
	.member	_btEot,544,12,8,32
	.eos
	.sym	_PACSDR,0,8,13,576,.fake16
	.sym	_PPACSDR,0,24,13,32,.fake16
	.stag	.fake19,32
	.member	_sBCab_ON,0,14,18,1
	.member	_sBSp_1,1,14,18,1
	.member	_sBSp_2,2,14,18,1
	.member	_sBHead_Bit,3,14,18,1
	.member	_sACab_ON,4,14,18,1
	.member	_sASp_1,5,14,18,1
	.member	_sASp_2,6,14,18,1
	.member	_sAHead_Bit,7,14,18,1
	.eos
	.utag	.fake18,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake19
	.eos
	.stag	.fake21,32
	.member	_sBWLR,0,14,18,1
	.member	_sBGPS,1,14,18,1
	.member	_sBVOIP,2,14,18,1
	.member	_sBCCP1,3,14,18,1
	.member	_sAWLR,4,14,18,1
	.member	_sAGPS,5,14,18,1
	.member	_sAVOIP,6,14,18,1
	.member	_sACCP1,7,14,18,1
	.eos
	.utag	.fake20,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake21
	.eos
	.stag	.fake23,32
	.member	_sBCNCS,0,14,18,1
	.member	_sBVTX,1,14,18,1
	.member	_sBLIC,2,14,18,1
	.member	_sBPAC,3,14,18,1
	.member	_sACNCS,4,14,18,1
	.member	_sAVTX,5,14,18,1
	.member	_sALIC,6,14,18,1
	.member	_sAPAC,7,14,18,1
	.eos
	.utag	.fake22,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake23
	.eos
	.stag	.fake25,32
	.member	_sBPII2,0,14,18,1
	.member	_sBPII1,1,14,18,1
	.member	_sBFDI,2,14,18,1
	.member	_sBSp_3,3,14,18,1
	.member	_sAPII2,4,14,18,1
	.member	_sAPII1,5,14,18,1
	.member	_sAFDI,6,14,18,1
	.member	_sASp_3,7,14,18,1
	.eos
	.utag	.fake24,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake25
	.eos
	.stag	.fake27,32
	.member	_sBSDI4,0,14,18,1
	.member	_sBSDI3,1,14,18,1
	.member	_sBSDI2,2,14,18,1
	.member	_sBSDI1,3,14,18,1
	.member	_sASDI4,4,14,18,1
	.member	_sASDI3,5,14,18,1
	.member	_sASDI2,6,14,18,1
	.member	_sASDI1,7,14,18,1
	.eos
	.utag	.fake26,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake27
	.eos
	.stag	.fake29,32
	.member	_sBPID1_4,0,14,18,1
	.member	_sBPID1_3,1,14,18,1
	.member	_sBPID1_2,2,14,18,1
	.member	_sBPID1_1,3,14,18,1
	.member	_sAPID1_4,4,14,18,1
	.member	_sAPID1_3,5,14,18,1
	.member	_sAPID1_2,6,14,18,1
	.member	_sAPID1_1,7,14,18,1
	.eos
	.utag	.fake28,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake29
	.eos
	.stag	.fake31,32
	.member	_sBPEI1,0,14,18,1
	.member	_sBPEI2,1,14,18,1
	.member	_sBSp_3,2,14,18,1
	.member	_sBPID2_1,3,14,18,1
	.member	_sAPEI1,4,14,18,1
	.member	_sAPEI2,5,14,18,1
	.member	_sASp_3,6,14,18,1
	.member	_sAPID2_1,7,14,18,1
	.eos
	.utag	.fake30,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake31
	.eos
	.stag	.fake33,32
	.member	_sBPEI1_Call,0,14,18,1
	.member	_sBPEI2_Call,1,14,18,1
	.member	_sBSp_2,2,14,18,1
	.member	_sBSp_3,3,14,18,1
	.member	_sAPEI1_Call,4,14,18,1
	.member	_sAPEI2_Call,5,14,18,1
	.member	_sASp_2,6,14,18,1
	.member	_sASp_3,7,14,18,1
	.eos
	.utag	.fake32,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake33
	.eos
	.stag	.fake35,32
	.member	_sBDPO,0,14,18,1
	.member	_sBSp_2,1,14,18,1
	.member	_sBSp_3,2,14,18,1
	.member	_sBDPH,3,14,18,1
	.member	_sADPO,4,14,18,1
	.member	_sASp_2,5,14,18,1
	.member	_sASp_3,6,14,18,1
	.member	_sADPH,7,14,18,1
	.eos
	.utag	.fake34,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake35
	.eos
	.stag	.fake17,352
	.member	_CRA_1,0,9,8,32,.fake18
	.member	_CRA_2,32,9,8,32,.fake20
	.member	_CRA_3,64,9,8,32,.fake22
	.member	_CRA_4,96,9,8,32,.fake24
	.member	_CRA_5,128,9,8,32,.fake26
	.member	_CRA_6,160,9,8,32,.fake28
	.member	_CRA_7,192,9,8,32,.fake30
	.member	_CRA_8,224,9,8,32,.fake32
	.member	_CRA_9,256,9,8,32,.fake34
	.member	_CarNum_H,288,12,8,32
	.member	_CarNum_L,320,12,8,32
	.eos
	.sym	_CRA_STATION,0,8,13,352,.fake17
	.sym	_PCRA_STATION,0,24,13,32,.fake17
	.stag	.fake36,8128
	.member	_phHdBuf,0,8,8,352,.fake14
	.member	_sPAC_T,352,252,8,128,,2,2
	.member	_sC_ID,480,60,8,64,,2
	.member	_sDO,544,60,8,64,,2
	.member	_sD1,608,60,8,64,,2
	.member	_sODM,672,252,8,256,,4,2
	.member	_sANS,928,60,8,64,,2
	.member	_sTRAN_NO,992,252,8,192,,3,2
	.member	_sCRAW_ID,1184,252,8,192,,3,2
	.member	_sTRIP,1376,252,8,192,,3,2
	.member	_sD2,1568,60,8,64,,2
	.member	_sSTST,1632,252,8,128,,2,2
	.member	_sNOST,1760,252,8,128,,2,2
	.member	_sNEST,1888,252,8,128,,2,2
	.member	_sDEST,2016,252,8,128,,2,2
	.member	_sSPK,2144,252,8,256,,4,2
	.member	_sD3,2400,252,8,128,,2,2
	.member	_sD4,2528,252,8,128,,2,2
	.member	_sPR,2656,60,8,64,,2
	.member	_sPRVector,2720,252,8,128,,2,2
	.member	_sPACVector,2848,252,8,128,,2,2
	.member	_sFDI_SDI_Color,2976,252,8,128,,2,2
	.member	_sFDI_SDI_Vector1,3104,252,8,128,,2,2
	.member	_sFDI_SDI_Vector2,3232,252,8,128,,2,2
	.member	_sPII_Vector,3360,252,8,128,,2,2
	.member	_sPP_Line_Vector,3488,252,8,128,,2,2
	.member	_sPP_Vector,3616,252,8,128,,2,2
	.member	_sSP_Vector,3744,252,8,128,,2,2
	.member	_sROUTE_SKIP,3872,252,8,640,,10,2
	.member	_sCI_Index,4512,252,8,512,,8,2
	.member	_sCI_Fault,5024,60,8,64,,2
	.member	_sCCI,5088,60,8,64,,2
	.member	_phCRA_Sta,5152,1020,8,2816,,4,11,2
	.member	_nCRC,7968,60,8,128,,4
	.member	_btEot,8096,12,8,32
	.eos
	.sym	_PAC_PAC,0,8,13,8128,.fake36
	.sym	_PPAC_PAC,0,24,13,32,.fake36
	.stag	.fake37,4992
	.member	_phHdBuf,0,8,8,352,.fake14
	.member	_sDO,352,60,8,64,,2
	.member	_sTRAN_NO,416,252,8,192,,3,2
	.member	_sCRAW_ID,608,252,8,192,,3,2
	.member	_sTRIP,800,252,8,192,,3,2
	.member	_sD1,992,60,8,64,,2
	.member	_sSTST,1056,252,8,128,,2,2
	.member	_sNOST,1184,252,8,128,,2,2
	.member	_sNEST,1312,252,8,128,,2,2
	.member	_sDEST,1440,252,8,128,,2,2
	.member	_sSPK,1568,252,8,256,,4,2
	.member	_sD2,1824,252,8,128,,2,2
	.member	_sD3,1952,252,8,128,,2,2
	.member	_sPR,2080,60,8,64,,2
	.member	_sPRVector,2144,252,8,128,,2,2
	.member	_sPACVector,2272,252,8,128,,2,2
	.member	_sFDI_SDI_Color,2400,252,8,128,,2,2
	.member	_sFDI_SDI_Vector1,2528,252,8,128,,2,2
	.member	_sFDI_SDI_Vector2,2656,252,8,128,,2,2
	.member	_sPII_Vector,2784,252,8,128,,2,2
	.member	_sPP_Line_Vector,2912,252,8,128,,2,2
	.member	_sPP_Vector,3040,252,8,128,,2,2
	.member	_sSP_Vector,3168,252,8,128,,2,2
	.member	_sROUTE_SKIP,3296,252,8,640,,10,2
	.member	_sCI_Index,3936,252,8,512,,8,2
	.member	_sCCP_Date,4448,252,8,384,,6,2
	.member	_nCRC,4832,60,8,128,,4
	.member	_btEot,4960,12,8,32
	.eos
	.sym	_CCP_PAC,0,8,13,4992,.fake37
	.sym	_PCCP_PAC,0,24,13,32,.fake37
	.stag	.fake40,32
	.member	_Sp_0,0,14,18,1
	.member	_Sp_1,1,14,18,1
	.member	_CI_Fault,2,14,18,1
	.member	_DST,3,14,18,1
	.member	_Sp_4,4,14,18,1
	.member	_Sp_5,5,14,18,1
	.member	_Sp_6,6,14,18,1
	.member	_Sp_7,7,14,18,1
	.eos
	.utag	.fake39,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake40
	.eos
	.stag	.fake42,32
	.member	_All_Doors_Closed,0,14,18,1
	.member	_EP_Mode,1,14,18,1
	.member	_Traction,2,14,18,1
	.member	_Atcive_Cab,3,14,18,1
	.member	_Sp_4,4,14,18,1
	.member	_Sp_5,5,14,18,1
	.member	_Sp_6,6,14,18,1
	.member	_Sp_7,7,14,18,1
	.eos
	.utag	.fake41,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake42
	.eos
	.stag	.fake38,768
	.member	_phHdBuf,0,8,8,352,.fake14
	.member	_DATA2,352,9,8,32,.fake39
	.member	_DATA1,384,9,8,32,.fake41
	.member	_CI_Index_Num,416,60,8,64,,2
	.member	_chCarn,480,252,8,128,,2,2
	.member	_nCRC,608,60,8,128,,4
	.member	_btEot,736,12,8,32
	.eos
	.sym	_LICSD,0,8,13,768,.fake38
	.sym	_PLICSDR,0,24,13,32,.fake38
	.stag	.fake43,480
	.member	_btSoh,0,12,8,32
	.member	_chSrcDev,32,60,8,64,,2
	.member	_chDestDev,96,60,8,64,,2
	.member	_chMsgCnt,160,60,8,128,,4
	.member	_chCmdCode,288,60,8,64,,2
	.member	_chDataLen,352,60,8,128,,4
	.eos
	.sym	_CNCSHD,0,8,13,480,.fake43
	.sym	_PCNCSHD,0,24,13,32,.fake43
	.stag	.fake44,10208
	.member	_phHdBuf,0,8,8,480,.fake43
	.member	_sCommand,480,60,8,64,,2
	.member	_sCarKind,544,60,8,64,,2
	.member	_sTextDataAsc,608,60,8,9600,,300
	.eos
	.sym	_LIC_CNCS_HD,0,8,13,10208,.fake44
	.sym	_PLIC_CNCS_HD,0,24,13,32,.fake44
	.stag	.fake45,320
	.member	_chVer,0,50,8,128,,4
	.member	_chBuildDate,128,50,8,192,,6
	.eos
	.sym	_CNCS_LIC_VERBDD_SD,0,8,13,320,.fake45
	.sym	_PCNCS_LIC_VERBDD_SD,0,24,13,32,.fake45
	.stag	.fake46,10336
	.member	_VerCnt,0,13,8,32
	.member	_cvbBuf,32,56,8,10240,.fake45,32
	.member	_CarNum,10272,61,8,64,,2
	.eos
	.sym	_LIC_DPRAM_Ver,0,8,13,10336,.fake46
	.sym	_PLIC_DPRAM_Ver,0,24,13,32,.fake46
	.stag	.fake47,4096
	.member	_s1TRIC,0,252,8,256,,2,4
	.member	_s2CCP,256,252,8,256,,2,4
	.member	_s3LIC_LON,512,252,8,256,,2,4
	.member	_s4GIA,768,252,8,256,,2,4
	.member	_s5VTX,1024,252,8,256,,2,4
	.member	_s6PAC,1280,252,8,256,,2,4
	.member	_s7FDI,1536,252,8,256,,2,4
	.member	_s8SDI,1792,252,8,256,,2,4
	.member	_s9PII,2048,252,8,256,,2,4
	.member	_s10VRX,2304,252,8,256,,2,4
	.member	_s11CN_MAIN,2560,252,8,256,,2,4
	.member	_s12CN_LAVN,2816,252,8,256,,2,4
	.member	_s13CN_VP,3072,252,8,256,,2,4
	.member	_s14CN_PPLOY,3328,252,8,256,,2,4
	.member	_s15CN_SPLAY,3584,252,8,256,,2,4
	.member	_s16CN_PTU,3840,252,8,256,,2,4
	.eos
	.sym	_LIC_VER_LIST,0,8,13,4096,.fake47
	.sym	_PLIC_VER_LIST,0,24,13,32,.fake47
	.stag	.fake48,11648
	.member	_phHdBuf,0,8,8,480,.fake43
	.member	_sCommand,480,60,8,64,,2
	.member	_sYear,544,60,8,64,,2
	.member	_sMonth,608,60,8,64,,2
	.member	_sDay,672,60,8,64,,2
	.member	_sHour,736,60,8,64,,2
	.member	_sMinute,800,60,8,64,,2
	.member	_sSecond,864,60,8,64,,2
	.member	_sWaySide,928,60,8,64,,2
	.member	_sDaType,992,60,8,64,,2
	.member	_sFaultTime,1056,60,8,256,,8
	.member	_cvbBuf,1312,56,8,10240,.fake45,32
	.member	_chChkSum,11552,60,8,64,,2
	.member	_btEot,11616,12,8,32
	.eos
	.sym	_CNCS_LIC_SD,0,8,13,11648,.fake48
	.sym	_PCNCS_LIC_SD,0,24,13,32,.fake48
	.stag	.fake49,832
	.member	_phHdBuf,0,8,8,480,.fake43
	.member	_sCommand,480,60,8,64,,2
	.member	_sTEXT,544,60,8,128,,4
	.member	_chContactSignalBuf,672,60,8,64,,2
	.member	_chChkSum,736,60,8,64,,2
	.member	_btEot,800,12,8,32
	.eos
	.sym	_CNCS_LIC_T_F,0,8,13,832,.fake49
	.sym	_PCNCS_LIC_T_F,0,24,13,32,.fake49
	.stag	.fake50,768
	.member	_phHdBuf,0,8,8,480,.fake43
	.member	_sCommand,480,60,8,64,,2
	.member	_sTEXT,544,60,8,128,,4
	.member	_chChkSum,672,60,8,64,,2
	.member	_btEot,736,12,8,32
	.eos
	.sym	_CNCS_LIC_T_F_C,0,8,13,768,.fake50
	.sym	_PCNCS_LIC_T_F_C,0,24,13,32,.fake50
	.stag	.fake51,96
	.member	_sChSum,0,60,8,64,,2
	.member	_sETX,64,12,8,32
	.eos
	.sym	_LIC_CNCS_ED,0,8,13,96,.fake51
	.sym	_PLIC_CNCS_ED,0,24,13,32,.fake51
	.stag	.fake53,32
	.member	_n1VTX,0,14,18,1
	.member	_n2CNCS,1,14,18,1
	.member	_n3PAC2,2,14,18,1
	.member	_n4LIC,3,14,18,1
	.member	_n5WLAN,4,14,18,1
	.member	_n6GPS,5,14,18,1
	.member	_n7PAC1,6,14,18,1
	.member	_n8sp,7,14,18,1
	.eos
	.stag	.fake54,32
	.member	_n1DPO1,0,14,18,1
	.member	_n2DPO2,1,14,18,1
	.member	_n3CCP1,2,14,18,1
	.member	_n4CCP2,3,14,18,1
	.member	_n5TRIC1,4,14,18,1
	.member	_n6TRIC2,5,14,18,1
	.member	_n7TR1,6,14,18,1
	.member	_n8TR2,7,14,18,1
	.eos
	.stag	.fake55,32
	.member	_n1Sp,0,14,18,1
	.member	_n2Sp,1,14,18,1
	.member	_n3CPO1,2,14,18,1
	.member	_n4CPO2,3,14,18,1
	.member	_n5CPO3,4,14,18,1
	.member	_n6CPO4,5,14,18,1
	.member	_n7Sp,6,14,18,1
	.member	_n8Sp,7,14,18,1
	.eos
	.stag	.fake56,32
	.member	_n1PEI1,0,14,18,1
	.member	_n2PEI2,1,14,18,1
	.member	_n3PEI3,2,14,18,1
	.member	_n4PEI4,3,14,18,1
	.member	_n5PEI5,4,14,18,1
	.member	_n6PEI6,5,14,18,1
	.member	_n7FDI1,6,14,18,1
	.member	_n8FDI2,7,14,18,1
	.eos
	.stag	.fake57,32
	.member	_n1SDI1,0,14,18,1
	.member	_n2SDI2,1,14,18,1
	.member	_n3SDI3,2,14,18,1
	.member	_n4SDI4,3,14,18,1
	.member	_n5SDI5,4,14,18,1
	.member	_n6SDI6,5,14,18,1
	.member	_n7SDI7,6,14,18,1
	.member	_n8SDI8,7,14,18,1
	.eos
	.stag	.fake58,32
	.member	_n1PID1_1,0,14,18,1
	.member	_n2PID1_2,1,14,18,1
	.member	_n3PID1_3,2,14,18,1
	.member	_n4PID1_4,3,14,18,1
	.member	_n5PID1_5,4,14,18,1
	.member	_n6PID1_6,5,14,18,1
	.member	_n7PID1_7,6,14,18,1
	.member	_n8PID1_8,7,14,18,1
	.eos
	.stag	.fake59,32
	.member	_n1PID2_1,0,14,18,1
	.member	_n2PID2_2,1,14,18,1
	.member	_n3PID2_3,2,14,18,1
	.member	_n4PID2_4,3,14,18,1
	.member	_n5PII1,4,14,18,1
	.member	_n6PII2,5,14,18,1
	.member	_n7PII3,6,14,18,1
	.member	_n8PII4,7,14,18,1
	.eos
	.stag	.fake52,256
	.member	_BYTE_1,0,8,8,32,.fake53
	.member	_BYTE_2,32,8,8,32,.fake54
	.member	_BYTE_3,64,8,8,32,.fake55
	.member	_BYTE_4,96,8,8,32,.fake56
	.member	_BYTE_5,128,12,8,32
	.member	_BYTE_6,160,8,8,32,.fake57
	.member	_BYTE_7,192,8,8,32,.fake58
	.member	_BYTE_8,224,8,8,32,.fake59
	.eos
	.sym	_COMMSTATUS_PA,0,8,13,256,.fake52
	.sym	_PCOMMSTATUS_PA,0,24,13,32,.fake52
	.stag	.fake62,32
	.member	_nCncs,0,14,18,1
	.member	_nVtx,1,14,18,1
	.member	_nLic,2,14,18,1
	.member	_nPac,3,14,18,1
	.member	_nWlr,4,14,18,1
	.member	_nGps,5,14,18,1
	.member	_nVoip,6,14,18,1
	.member	_nCcp,7,14,18,1
	.eos
	.utag	.fake61,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake62
	.eos
	.stag	.fake64,32
	.member	_nSdi4,0,14,18,1
	.member	_nSdi3,1,14,18,1
	.member	_nSdi2,2,14,18,1
	.member	_nSdi1,3,14,18,1
	.member	_nPii2,4,14,18,1
	.member	_nPii1,5,14,18,1
	.member	_nFdi,6,14,18,1
	.member	_sp_7,7,14,18,1
	.eos
	.utag	.fake63,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake64
	.eos
	.stag	.fake66,32
	.member	_nPid2_1,0,14,18,1
	.member	_nPid1_4,1,14,18,1
	.member	_nPid1_3,2,14,18,1
	.member	_nPid1_2,3,14,18,1
	.member	_nPid1_1,4,14,18,1
	.member	_sp_5,5,14,18,1
	.member	_sp_4,6,14,18,1
	.member	_sp_7,7,14,18,1
	.eos
	.utag	.fake65,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake66
	.eos
	.stag	.fake68,32
	.member	_nPei1,0,14,18,1
	.member	_nPei2,1,14,18,1
	.member	_sp_2,2,14,18,1
	.member	_sp_3,3,14,18,1
	.member	_nDpo,4,14,18,1
	.member	_sp_5,5,14,18,1
	.member	_sp_6,6,14,18,1
	.member	_nDph,7,14,18,1
	.eos
	.utag	.fake67,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake68
	.eos
	.stag	.fake70,32
	.member	_sp_0,0,14,18,1
	.member	_sp_1,1,14,18,1
	.member	_sp_2,2,14,18,1
	.member	_sp_3,3,14,18,1
	.member	_sp_4,4,14,18,1
	.member	_sp_5,5,14,18,1
	.member	_sp_6,6,14,18,1
	.member	_sp_7,7,14,18,1
	.eos
	.utag	.fake69,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake70
	.eos
	.stag	.fake60,160
	.member	_BYTE_1,0,9,8,32,.fake61
	.member	_BYTE_2,32,9,8,32,.fake63
	.member	_BYTE_3,64,9,8,32,.fake65
	.member	_BYTE_4,96,9,8,32,.fake67
	.member	_BYTE_5,128,9,8,32,.fake69
	.eos
	.sym	_COMMSTATUS_LIC,0,8,13,160,.fake60
	.sym	_PCOMMSTATUS_LIC,0,24,13,32,.fake60
	.stag	.fake73,32
	.member	_n1Reverse,0,14,18,1
	.member	_n2ForWard,1,14,18,1
	.member	_n3Uncouple,2,14,18,1
	.member	_n4Simulation,3,14,18,1
	.member	_n5Pattern,4,14,18,1
	.member	_n6A_CabOn,5,14,18,1
	.member	_n7B_CabOn,6,14,18,1
	.member	_n8sp,7,14,18,1
	.eos
	.utag	.fake72,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake73
	.eos
	.stag	.fake71,32
	.member	_n1DATA,0,9,8,32,.fake72
	.eos
	.sym	_RACK_DI,0,8,13,32,.fake71
	.sym	_PRACK_DI,0,24,13,32,.fake71
	.etag	_eCDT_TYPE,32
	.member	_eCDT_A,0,4,16,32
	.member	_eCDT_B,1,4,16,32
	.member	_eCDT_MAXIMUM,2,4,16,32
	.eos
	.stag	.fake74,96
	.member	_nTCnt,0,4,8,32
	.member	_nStPosi,32,4,8,32
	.member	_nEdPosi,64,4,8,32
	.eos
	.sym	_T_FAULT_INFO,0,8,13,96,.fake74
	.sym	_PFAULT_INFO,0,24,13,32,.fake74
	.file	"user.c"

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nUserDebug1msTimer+0,32
	.field  	0,32		; _m_nUserDebug1msTimer @ 0

	.sect	".text"

	.global	_m_nUserDebug1msTimer
	.bss	_m_nUserDebug1msTimer,1
	.sym	_m_nUserDebug1msTimer,_m_nUserDebug1msTimer,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nTest1msTimer+0,32
	.field  	0,32		; _m_nTest1msTimer @ 0

	.sect	".text"

	.global	_m_nTest1msTimer
	.bss	_m_nTest1msTimer,1
	.sym	_m_nTest1msTimer,_m_nTest1msTimer,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nUart1RxOneByteGapDelayTime+0,32
	.field  	0,32		; _m_nUart1RxOneByteGapDelayTime @ 0

	.sect	".text"

	.global	_m_nUart1RxOneByteGapDelayTime
	.bss	_m_nUart1RxOneByteGapDelayTime,1
	.sym	_m_nUart1RxOneByteGapDelayTime,_m_nUart1RxOneByteGapDelayTime,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nUart2RxOneByteGapDelayTime+0,32
	.field  	0,32		; _m_nUart2RxOneByteGapDelayTime @ 0

	.sect	".text"

	.global	_m_nUart2RxOneByteGapDelayTime
	.bss	_m_nUart2RxOneByteGapDelayTime,1
	.sym	_m_nUart2RxOneByteGapDelayTime,_m_nUart2RxOneByteGapDelayTime,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nUart3RxOneByteGapDelayTime+0,32
	.field  	0,32		; _m_nUart3RxOneByteGapDelayTime @ 0

	.sect	".text"

	.global	_m_nUart3RxOneByteGapDelayTime
	.bss	_m_nUart3RxOneByteGapDelayTime,1
	.sym	_m_nUart3RxOneByteGapDelayTime,_m_nUart3RxOneByteGapDelayTime,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_LIC_CNCS_Tx_Flag+0,32
	.field  	0,32		; _m_LIC_CNCS_Tx_Flag @ 0

	.sect	".text"

	.global	_m_LIC_CNCS_Tx_Flag
	.bss	_m_LIC_CNCS_Tx_Flag,1
	.sym	_m_LIC_CNCS_Tx_Flag,_m_LIC_CNCS_Tx_Flag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_LIC_CNCS_TX_DelyTime+0,32
	.field  	0,32		; _m_LIC_CNCS_TX_DelyTime @ 0

	.sect	".text"

	.global	_m_LIC_CNCS_TX_DelyTime
	.bss	_m_LIC_CNCS_TX_DelyTime,1
	.sym	_m_LIC_CNCS_TX_DelyTime,_m_LIC_CNCS_TX_DelyTime,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nLnWkTxFlag+0,32
	.field  	0,32		; _m_nLnWkTxFlag @ 0

	.sect	".text"

	.global	_m_nLnWkTxFlag
	.bss	_m_nLnWkTxFlag,1
	.sym	_m_nLnWkTxFlag,_m_nLnWkTxFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nFaultCnt+0,32
	.field  	0,32		; _m_nFaultCnt @ 0

	.sect	".text"

	.global	_m_nFaultCnt
	.bss	_m_nFaultCnt,1
	.sym	_m_nFaultCnt,_m_nFaultCnt,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_nRecving_Posi+0,32
	.field  	0,32		; _nRecving_Posi @ 0

	.sect	".text"

	.global	_nRecving_Posi
	.bss	_nRecving_Posi,1
	.sym	_nRecving_Posi,_nRecving_Posi,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nCDT_FaultDataStFlag+0,32
	.field  	0,32		; _m_nCDT_FaultDataStFlag @ 0

	.sect	".text"

	.global	_m_nCDT_FaultDataStFlag
	.bss	_m_nCDT_FaultDataStFlag,1
	.sym	_m_nCDT_FaultDataStFlag,_m_nCDT_FaultDataStFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_TrainCofVal+0,32
	.field  	0,32		; _m_TrainCofVal @ 0

	.sect	".text"

	.global	_m_TrainCofVal
	.bss	_m_TrainCofVal,1
	.sym	_m_TrainCofVal,_m_TrainCofVal,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nCarPos+0,32
	.field  	1,32		; _m_nCarPos @ 0

	.sect	".text"

	.global	_m_nCarPos
	.bss	_m_nCarPos,1
	.sym	_m_nCarPos,_m_nCarPos,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_btCiFaultVal+0,32
	.field  	32768,32		; _m_btCiFaultVal @ 0

	.sect	".text"

	.global	_m_btCiFaultVal
	.bss	_m_btCiFaultVal,1
	.sym	_m_btCiFaultVal,_m_btCiFaultVal,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nCarNo+0,32
	.field  	0,32		; _m_nCarNo @ 0

	.sect	".text"

	.global	_m_nCarNo
	.bss	_m_nCarNo,1
	.sym	_m_nCarNo,_m_nCarNo,13,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_chCarKind+0,32
	.field  	65,32		; _m_chCarKind @ 0

	.sect	".text"

	.global	_m_chCarKind
	.bss	_m_chCarKind,1
	.sym	_m_chCarKind,_m_chCarKind,2,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nCarKindToLonCnt+0,32
	.field  	0,32		; _m_nCarKindToLonCnt @ 0

	.sect	".text"

	.global	_m_nCarKindToLonCnt
	.bss	_m_nCarKindToLonCnt,1
	.sym	_m_nCarKindToLonCnt,_m_nCarKindToLonCnt,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_chCarKindNum+0,32
	.field  	0,32		; _m_chCarKindNum @ 0

	.sect	".text"

	.global	_m_chCarKindNum
	.bss	_m_chCarKindNum,1
	.sym	_m_chCarKindNum,_m_chCarKindNum,2,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_bLnWkDbgTxFlag+0,32
	.field  	0,32		; _m_bLnWkDbgTxFlag @ 0

	.sect	".text"

	.global	_m_bLnWkDbgTxFlag
	.bss	_m_bLnWkDbgTxFlag,1
	.sym	_m_bLnWkDbgTxFlag,_m_bLnWkDbgTxFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nLnWkWaySideOnRxOk+0,32
	.field  	0,32		; _m_nLnWkWaySideOnRxOk @ 0

	.sect	".text"

	.global	_m_nLnWkWaySideOnRxOk
	.bss	_m_nLnWkWaySideOnRxOk,1
	.sym	_m_nLnWkWaySideOnRxOk,_m_nLnWkWaySideOnRxOk,12,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nCarCnt+0,32
	.field  	0,32		; _m_nCarCnt @ 0

	.sect	".text"

	.global	_m_nCarCnt
	.bss	_m_nCarCnt,1
	.sym	_m_nCarCnt,_m_nCarCnt,12,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nNvsramPos+0,32
	.field  	0,32		; _m_nNvsramPos @ 0

	.sect	".text"

	.global	_m_nNvsramPos
	.bss	_m_nNvsramPos,1
	.sym	_m_nNvsramPos,_m_nNvsramPos,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_bLnWkFtpEndFlag+0,32
	.field  	0,32		; _m_bLnWkFtpEndFlag @ 0

	.sect	".text"

	.global	_m_bLnWkFtpEndFlag
	.bss	_m_bLnWkFtpEndFlag,1
	.sym	_m_bLnWkFtpEndFlag,_m_bLnWkFtpEndFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nDateTime2SecondCnt+0,32
	.field  	0,32		; _m_nDateTime2SecondCnt @ 0

	.sect	".text"

	.global	_m_nDateTime2SecondCnt
	.bss	_m_nDateTime2SecondCnt,1
	.sym	_m_nDateTime2SecondCnt,_m_nDateTime2SecondCnt,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nTxDbg1msTimer+0,32
	.field  	0,32		; _m_nTxDbg1msTimer @ 0

	.sect	".text"

	.global	_m_nTxDbg1msTimer
	.bss	_m_nTxDbg1msTimer,1
	.sym	_m_nTxDbg1msTimer,_m_nTxDbg1msTimer,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nDbgTxPos+0,32
	.field  	-1,32		; _m_nDbgTxPos @ 0

	.sect	".text"

	.global	_m_nDbgTxPos
	.bss	_m_nDbgTxPos,1
	.sym	_m_nDbgTxPos,_m_nDbgTxPos,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nSingleOrMarriedCarUpdate1msTimer+0,32
	.field  	0,32		; _m_nSingleOrMarriedCarUpdate1msTimer @ 0

	.sect	".text"

	.global	_m_nSingleOrMarriedCarUpdate1msTimer
	.bss	_m_nSingleOrMarriedCarUpdate1msTimer,1
	.sym	_m_nSingleOrMarriedCarUpdate1msTimer,_m_nSingleOrMarriedCarUpdate1msTimer,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_btCttSignalA+0,32
	.field  	0,32		; _m_btCttSignalA @ 0

	.sect	".text"

	.global	_m_btCttSignalA
	.bss	_m_btCttSignalA,1
	.sym	_m_btCttSignalA,_m_btCttSignalA,12,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_btCttSignalB+0,32
	.field  	0,32		; _m_btCttSignalB @ 0

	.sect	".text"

	.global	_m_btCttSignalB
	.bss	_m_btCttSignalB,1
	.sym	_m_btCttSignalB,_m_btCttSignalB,12,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_LIC_CNCS_TimSetFlag+0,32
	.field  	0,32		; _m_LIC_CNCS_TimSetFlag @ 0

	.sect	".text"

	.global	_m_LIC_CNCS_TimSetFlag
	.bss	_m_LIC_CNCS_TimSetFlag,1
	.sym	_m_LIC_CNCS_TimSetFlag,_m_LIC_CNCS_TimSetFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_LIC_GIA_TimSetFlag+0,32
	.field  	0,32		; _m_LIC_GIA_TimSetFlag @ 0

	.sect	".text"

	.global	_m_LIC_GIA_TimSetFlag
	.bss	_m_LIC_GIA_TimSetFlag,1
	.sym	_m_LIC_GIA_TimSetFlag,_m_LIC_GIA_TimSetFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nCncsRxCheck1msTimer+0,32
	.field  	0,32		; _m_nCncsRxCheck1msTimer @ 0

	.sect	".text"

	.global	_m_nCncsRxCheck1msTimer
	.bss	_m_nCncsRxCheck1msTimer,1
	.sym	_m_nCncsRxCheck1msTimer,_m_nCncsRxCheck1msTimer,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nGiaRxCheck1msTimer+0,32
	.field  	0,32		; _m_nGiaRxCheck1msTimer @ 0

	.sect	".text"

	.global	_m_nGiaRxCheck1msTimer
	.bss	_m_nGiaRxCheck1msTimer,1
	.sym	_m_nGiaRxCheck1msTimer,_m_nGiaRxCheck1msTimer,14,2,32

	.sect	".cinit"
	.field  	IR_1,32
	.field  	_LIC_VerList+0,32
	.field  	67,32		; _LIC_VerList[0] @ 0
	.field  	67,32		; _LIC_VerList[1] @ 32
	.field  	80,32		; _LIC_VerList[2] @ 64
	.field  	0,32		; _LIC_VerList[3] @ 96
IR_1:	.set	4

	.sect	".text"

	.sect	".cinit"
	.field  	IR_2,32
	.field  	_LIC_VerList+9,32
	.field  	67,32		; _LIC_VerList[9] @ 288
	.field  	82,32		; _LIC_VerList[10] @ 320
	.field  	65,32		; _LIC_VerList[11] @ 352
	.field  	45,32		; _LIC_VerList[12] @ 384
	.field  	76,32		; _LIC_VerList[13] @ 416
	.field  	73,32		; _LIC_VerList[14] @ 448
	.field  	67,32		; _LIC_VerList[15] @ 480
	.field  	76,32		; _LIC_VerList[16] @ 512
	.field  	0,32		; _LIC_VerList[17] @ 544
	.field  	67,32		; _LIC_VerList[18] @ 576
	.field  	82,32		; _LIC_VerList[19] @ 608
	.field  	65,32		; _LIC_VerList[20] @ 640
	.field  	45,32		; _LIC_VerList[21] @ 672
	.field  	86,32		; _LIC_VerList[22] @ 704
	.field  	84,32		; _LIC_VerList[23] @ 736
	.field  	88,32		; _LIC_VerList[24] @ 768
	.field  	0,32		; _LIC_VerList[25] @ 800
	.field  	0,32
	.field  	67,32		; _LIC_VerList[27] @ 864
	.field  	82,32		; _LIC_VerList[28] @ 896
	.field  	65,32		; _LIC_VerList[29] @ 928
	.field  	45,32		; _LIC_VerList[30] @ 960
	.field  	86,32		; _LIC_VerList[31] @ 992
	.field  	79,32		; _LIC_VerList[32] @ 1024
	.field  	73,32		; _LIC_VerList[33] @ 1056
	.field  	80,32		; _LIC_VerList[34] @ 1088
	.field  	0,32		; _LIC_VerList[35] @ 1120
	.field  	67,32		; _LIC_VerList[36] @ 1152
	.field  	82,32		; _LIC_VerList[37] @ 1184
	.field  	65,32		; _LIC_VerList[38] @ 1216
	.field  	45,32		; _LIC_VerList[39] @ 1248
	.field  	80,32		; _LIC_VerList[40] @ 1280
	.field  	65,32		; _LIC_VerList[41] @ 1312
	.field  	67,32		; _LIC_VerList[42] @ 1344
	.field  	0,32		; _LIC_VerList[43] @ 1376
	.field  	0,32
	.field  	67,32		; _LIC_VerList[45] @ 1440
	.field  	82,32		; _LIC_VerList[46] @ 1472
	.field  	65,32		; _LIC_VerList[47] @ 1504
	.field  	45,32		; _LIC_VerList[48] @ 1536
	.field  	76,32		; _LIC_VerList[49] @ 1568
	.field  	73,32		; _LIC_VerList[50] @ 1600
	.field  	67,32		; _LIC_VerList[51] @ 1632
	.field  	77,32		; _LIC_VerList[52] @ 1664
	.field  	0,32		; _LIC_VerList[53] @ 1696
	.field  	70,32		; _LIC_VerList[54] @ 1728
	.field  	68,32		; _LIC_VerList[55] @ 1760
	.field  	73,32		; _LIC_VerList[56] @ 1792
	.field  	49,32		; _LIC_VerList[57] @ 1824
	.field  	0,32		; _LIC_VerList[58] @ 1856
	.space	4
	.field  	83,32		; _LIC_VerList[63] @ 2016
	.field  	68,32		; _LIC_VerList[64] @ 2048
	.field  	73,32		; _LIC_VerList[65] @ 2080
	.field  	49,32		; _LIC_VerList[66] @ 2112
	.field  	0,32		; _LIC_VerList[67] @ 2144
	.space	4
	.field  	83,32		; _LIC_VerList[72] @ 2304
	.field  	68,32		; _LIC_VerList[73] @ 2336
	.field  	73,32		; _LIC_VerList[74] @ 2368
	.field  	50,32		; _LIC_VerList[75] @ 2400
	.field  	0,32		; _LIC_VerList[76] @ 2432
	.space	4
	.field  	83,32		; _LIC_VerList[81] @ 2592
	.field  	68,32		; _LIC_VerList[82] @ 2624
	.field  	73,32		; _LIC_VerList[83] @ 2656
	.field  	51,32		; _LIC_VerList[84] @ 2688
	.field  	0,32		; _LIC_VerList[85] @ 2720
	.space	4
	.field  	83,32		; _LIC_VerList[90] @ 2880
	.field  	68,32		; _LIC_VerList[91] @ 2912
	.field  	73,32		; _LIC_VerList[92] @ 2944
	.field  	52,32		; _LIC_VerList[93] @ 2976
	.field  	0,32		; _LIC_VerList[94] @ 3008
	.space	4
	.field  	80,32		; _LIC_VerList[99] @ 3168
	.field  	73,32		; _LIC_VerList[100] @ 3200
	.field  	73,32		; _LIC_VerList[101] @ 3232
	.field  	49,32		; _LIC_VerList[102] @ 3264
	.field  	0,32		; _LIC_VerList[103] @ 3296
	.space	4
	.field  	80,32		; _LIC_VerList[108] @ 3456
	.field  	73,32		; _LIC_VerList[109] @ 3488
	.field  	73,32		; _LIC_VerList[110] @ 3520
	.field  	50,32		; _LIC_VerList[111] @ 3552
	.field  	0,32		; _LIC_VerList[112] @ 3584
	.space	4
	.field  	86,32		; _LIC_VerList[117] @ 3744
	.field  	82,32		; _LIC_VerList[118] @ 3776
	.field  	88,32		; _LIC_VerList[119] @ 3808
	.field  	49,32		; _LIC_VerList[120] @ 3840
	.field  	0,32		; _LIC_VerList[121] @ 3872
	.space	4
	.field  	86,32		; _LIC_VerList[126] @ 4032
	.field  	82,32		; _LIC_VerList[127] @ 4064
	.field  	88,32		; _LIC_VerList[128] @ 4096
	.field  	50,32		; _LIC_VerList[129] @ 4128
	.field  	0,32		; _LIC_VerList[130] @ 4160
	.space	4
	.field  	86,32		; _LIC_VerList[135] @ 4320
	.field  	82,32		; _LIC_VerList[136] @ 4352
	.field  	88,32		; _LIC_VerList[137] @ 4384
	.field  	51,32		; _LIC_VerList[138] @ 4416
	.field  	0,32		; _LIC_VerList[139] @ 4448
	.space	4
	.field  	86,32		; _LIC_VerList[144] @ 4608
	.field  	82,32		; _LIC_VerList[145] @ 4640
	.field  	88,32		; _LIC_VerList[146] @ 4672
	.field  	52,32		; _LIC_VerList[147] @ 4704
	.field  	0,32		; _LIC_VerList[148] @ 4736
	.space	4
	.field  	86,32		; _LIC_VerList[153] @ 4896
	.field  	82,32		; _LIC_VerList[154] @ 4928
	.field  	88,32		; _LIC_VerList[155] @ 4960
	.field  	53,32		; _LIC_VerList[156] @ 4992
	.field  	0,32		; _LIC_VerList[157] @ 5024
	.space	4
	.field  	67,32		; _LIC_VerList[162] @ 5184
	.field  	82,32		; _LIC_VerList[163] @ 5216
	.field  	65,32		; _LIC_VerList[164] @ 5248
	.field  	45,32		; _LIC_VerList[165] @ 5280
	.field  	77,32		; _LIC_VerList[166] @ 5312
	.field  	65,32		; _LIC_VerList[167] @ 5344
	.field  	73,32		; _LIC_VerList[168] @ 5376
	.field  	78,32		; _LIC_VerList[169] @ 5408
	.field  	0,32		; _LIC_VerList[170] @ 5440
	.field  	67,32		; _LIC_VerList[171] @ 5472
	.field  	82,32		; _LIC_VerList[172] @ 5504
	.field  	65,32		; _LIC_VerList[173] @ 5536
	.field  	45,32		; _LIC_VerList[174] @ 5568
	.field  	76,32		; _LIC_VerList[175] @ 5600
	.field  	65,32		; _LIC_VerList[176] @ 5632
	.field  	85,32		; _LIC_VerList[177] @ 5664
	.field  	78,32		; _LIC_VerList[178] @ 5696
	.field  	0,32		; _LIC_VerList[179] @ 5728
	.field  	67,32		; _LIC_VerList[180] @ 5760
	.field  	82,32		; _LIC_VerList[181] @ 5792
	.field  	65,32		; _LIC_VerList[182] @ 5824
	.field  	45,32		; _LIC_VerList[183] @ 5856
	.field  	85,32		; _LIC_VerList[184] @ 5888
	.field  	80,32		; _LIC_VerList[185] @ 5920
	.field  	0,32		; _LIC_VerList[186] @ 5952
	.space	2
	.field  	67,32		; _LIC_VerList[189] @ 6048
	.field  	82,32		; _LIC_VerList[190] @ 6080
	.field  	65,32		; _LIC_VerList[191] @ 6112
	.field  	45,32		; _LIC_VerList[192] @ 6144
	.field  	80,32		; _LIC_VerList[193] @ 6176
	.field  	80,32		; _LIC_VerList[194] @ 6208
	.field  	0,32		; _LIC_VerList[195] @ 6240
	.space	2
	.field  	67,32		; _LIC_VerList[198] @ 6336
	.field  	82,32		; _LIC_VerList[199] @ 6368
	.field  	65,32		; _LIC_VerList[200] @ 6400
	.field  	45,32		; _LIC_VerList[201] @ 6432
	.field  	83,32		; _LIC_VerList[202] @ 6464
	.field  	80,32		; _LIC_VerList[203] @ 6496
	.field  	0,32		; _LIC_VerList[204] @ 6528
	.space	2
	.field  	67,32		; _LIC_VerList[207] @ 6624
	.field  	82,32		; _LIC_VerList[208] @ 6656
	.field  	65,32		; _LIC_VerList[209] @ 6688
	.field  	45,32		; _LIC_VerList[210] @ 6720
	.field  	70,32		; _LIC_VerList[211] @ 6752
	.field  	84,32		; _LIC_VerList[212] @ 6784
	.field  	80,32		; _LIC_VerList[213] @ 6816
	.field  	0,32		; _LIC_VerList[214] @ 6848
	.field  	0,32
	.field  	67,32		; _LIC_VerList[216] @ 6912
	.field  	82,32		; _LIC_VerList[217] @ 6944
	.field  	65,32		; _LIC_VerList[218] @ 6976
	.field  	45,32		; _LIC_VerList[219] @ 7008
	.field  	67,32		; _LIC_VerList[220] @ 7040
	.field  	68,32		; _LIC_VerList[221] @ 7072
	.field  	84,32		; _LIC_VerList[222] @ 7104
	.field  	0,32		; _LIC_VerList[223] @ 7136
	.field  	0,32
	.field  	0,32		; _LIC_VerList[225] @ 7200
IR_2:	.set	217

	.sect	".text"

	.global	_LIC_VerList
	.bss	_LIC_VerList,288
	.sym	_LIC_VerList,_LIC_VerList,252,2,9216,,32,9
	.sect	 ".text"

	.global	_user_Init
	.sym	_user_Init,_user_Init,32,2,0
	.func	108
;******************************************************************************
;* FUNCTION NAME: _user_Init                                                  *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,r3,r4,r5,ar0,fp,ir0,bk,sp,st               *
;*   Regs Saved         : r4,r5                                               *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 136 Auto + 2 SOE = 140 words      *
;******************************************************************************
_user_Init:
	.sym	_i,1,4,1,32
	.sym	_wCarNo,2,4,1,32
	.sym	_LL,3,12,1,32
	.sym	_LH,4,12,1,32
	.sym	_HL,5,12,1,32
	.sym	_HH,6,12,1,32
	.sym	_szBuf,7,50,1,4096,,128
	.sym	_pDpram,135,28,1,32
	.sym	_pLicVerDp,136,24,1,32,.fake46
	.line	1
;----------------------------------------------------------------------
; 108 | void user_Init()                                                       
; 110 | int i;                                                                 
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      136,sp
        push      r4
        push      r5
	.line	4
;----------------------------------------------------------------------
; 111 | int wCarNo = 0;                                                        
; 112 | UCHAR LL,LH,HL,HH;                                                     
; 113 | char szBuf[128];                                                       
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(2)
	.line	7
;----------------------------------------------------------------------
; 114 | UCHAR *pDpram = (UCHAR *)DPRAM_BASE;                                   
;----------------------------------------------------------------------
        ldiu      @CL1,r0
        sti       r0,*+fp(135)
	.line	9
;----------------------------------------------------------------------
; 116 | PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó�
;     | ��� ���� ���Ƿ� �������.                                              
; 118 | // �ʱ�ȭ�ϱ�                                                          
; 119 | //timeGet(&m_tmCurTime);                                               
;----------------------------------------------------------------------
        ldiu      @CL2,r0
        sti       r0,*+fp(136)
	.line	13
;----------------------------------------------------------------------
; 120 | memset(m_btCommSt,0x00,sizeof(m_btCommSt)); //���� ����Ÿ ���� ����    
;----------------------------------------------------------------------
        ldiu      8,r2
        ldiu      0,r1
        push      r2
        ldiu      @CL3,r0
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	14
;----------------------------------------------------------------------
; 121 | memset(m_btOldCommSt,0x00,sizeof(m_btOldCommSt)); //���� ����Ÿ ���� ��
;     | ��                                                                     
;----------------------------------------------------------------------
        ldiu      8,r0
        ldiu      0,r1
        push      r0
        push      r1
        ldiu      @CL4,r2
        push      r2
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	15
;----------------------------------------------------------------------
; 122 | memset(m_btSenseCommStBuf,0x00,sizeof(m_btSenseCommStBuf)); //���� ����
;     | Ÿ ���� ����                                                           
;----------------------------------------------------------------------
        ldiu      8,r0
        push      r0
        ldiu      0,r1
        push      r1
        ldiu      @CL5,r2
        push      r2
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	17
;----------------------------------------------------------------------
; 124 | memset(m_btExVersionTbl,0x0000,sizeof(m_btExVersionTbl));              
;----------------------------------------------------------------------
        ldiu      36,r0
        push      r0
        ldiu      0,r1
        ldiu      @CL6,r2
        push      r1
        push      r2
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	18
;----------------------------------------------------------------------
; 125 | memset(m_btExVersion_DAYTbl,0x0000,sizeof(m_btExVersion_DAYTbl));      
;----------------------------------------------------------------------
        ldiu      36,r0
        ldiu      0,r1
        push      r0
        push      r1
        ldiu      @CL7,r2
        push      r2
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	21
;----------------------------------------------------------------------
; 128 | for(i=0;i<VER_BDD_MAX_CNT;i++)                                         
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      32,r0
        bge       L19
;*      Branch Occurs to L19 
L2:        
	.line	23
;----------------------------------------------------------------------
; 130 | if(WORD_L(pLicVerDp->VerCnt) == TRUE)                                  
; 132 |         if(                                                            
;----------------------------------------------------------------------
        ldiu      *+fp(136),ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        cmpi      1,r0
        bned      L17
	nop
        ldine     *+fp(136),ar0
        ldine     1,r0
;*      Branch Occurs to L17 
	.line	26
;----------------------------------------------------------------------
; 133 | !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chVer[0])) || !IsNumAsc(WORD_L(pL
;     | icVerDp->cvbBuf[i].chVer[1])) ||                                       
; 134 | !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chVer[2])) || !IsNumAsc(WORD_L(pL
;     | icVerDp->cvbBuf[i].chVer[3])) ||                                       
; 136 | !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[0])) || !IsNumAsc(WOR
;     | D_L(pLicVerDp->cvbBuf[i].chBuildDate[1])) ||                           
; 137 | !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[2])) || !IsNumAsc(WOR
;     | D_L(pLicVerDp->cvbBuf[i].chBuildDate[3])) ||                           
; 138 | !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[4])) || !IsNumAsc(WOR
;     | D_L(pLicVerDp->cvbBuf[i].chBuildDate[5]))                              
; 139 | )                                                                      
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(1),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(2),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(3),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(4),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(5),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(6),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(7),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(8),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(9),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(10),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        bned      L15
        subi      1,sp
	nop
        ldine     *+fp(1),ar0
;*      Branch Occurs to L15 
L13:        
	.line	34
;----------------------------------------------------------------------
; 141 | memset(pLicVerDp->cvbBuf[i].chVer,'0',4);                              
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        ldiu      4,r2
        ldiu      48,r1
        mpyi      10,r0
        addi      *+fp(136),r0          ; Unsigned
        push      r2
        addi      1,r0                  ; Unsigned
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	35
;----------------------------------------------------------------------
; 142 | memset(pLicVerDp->cvbBuf[i].chBuildDate,'0',6);                        
; 144 | else                                                                   
;----------------------------------------------------------------------
        ldiu      6,r2
        ldiu      *+fp(1),r0
        ldiu      48,r1
        mpyi      10,r0
        addi      *+fp(136),r0          ; Unsigned
        push      r2
        push      r1
        addi      5,r0                  ; Unsigned
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
        bu        L18
;*      Branch Occurs to L18 
	.line	39
;----------------------------------------------------------------------
; 146 | LH = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[0])),ConvA
;     | sc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[1])));                        
;----------------------------------------------------------------------
L15:        
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(1),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      255,r1
        ldiu      *+fp(1),ar0
        ldiu      r0,r4
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ash       4,r4
        and       *+ar0(2),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(4)
	.line	40
;----------------------------------------------------------------------
; 147 | LL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[2])),ConvA
;     | sc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[3])));                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        ldiu      255,r1
        addi      *+fp(136),ar0         ; Unsigned
        ash       4,r4
        and       *+ar0(4),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(3)
	.line	41
;----------------------------------------------------------------------
; 148 | m_btExVersionTbl[i] = MAKE_WORD(LH,LL);                                
;----------------------------------------------------------------------
        ldiu      255,r0
        ldiu      *+fp(4),r1
        and       *+fp(3),r0
        ash       8,r1
        or3       r1,r0,r0
        ldiu      @CL6,ar0
        ldiu      *+fp(1),ir0
        and       65535,r0
        sti       r0,*+ar0(ir0)
	.line	42
;----------------------------------------------------------------------
; 149 | HH = 0x20;                                                             
;----------------------------------------------------------------------
        ldiu      32,r0
        sti       r0,*+fp(6)
	.line	43
;----------------------------------------------------------------------
; 150 | HL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[0]))
;     | ,ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[1])));            
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(5),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r1
        ldiu      r0,r4
        ash       4,r4
        and       *+ar0(6),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        subi      1,sp
        or3       r4,r0,r0
        and       255,r0
        sti       r0,*+fp(5)
	.line	44
;----------------------------------------------------------------------
; 151 | LH = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[2]))
;     | ,ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[3])));            
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(7),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        ldiu      255,r0
        subi      1,sp
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ash       4,r4
        and       *+ar0(8),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        sti       r0,*+fp(4)
	.line	45
;----------------------------------------------------------------------
; 152 | LL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[4]))
;     | ,ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[5])));            
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(9),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(1),ar0
        ldiu      255,r1
        mpyi      10,ar0
        ldiu      r0,r4
        addi      *+fp(136),ar0         ; Unsigned
        ash       4,r4
        and       *+ar0(10),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(3)
	.line	47
;----------------------------------------------------------------------
; 154 | m_btExVersion_DAYTbl[i] = MAKE_DWORD(HH,HL,LH,LL);                     
; 157 | else //�ѹ��� ���� ���� �Է��� �������� ��� 0 ���� �ʱ�ȭ �Ѵ�.       
;----------------------------------------------------------------------
        ldiu      255,r0
        ldiu      *+fp(6),r3
        and       *+fp(5),r0
        ash       24,r3
        ash       16,r0
        or3       r3,r0,r0
        ldiu      255,r1
        and       *+fp(4),r1
        ldiu      255,r2
        ash       8,r1
        and       *+fp(3),r2
        ldiu      @CL7,ar0
        or3       r0,r1,r0
        ldiu      *+fp(1),ir0
        or3       r0,r2,r0
        sti       r0,*+ar0(ir0)
        bu        L18
;*      Branch Occurs to L18 
	.line	52
;----------------------------------------------------------------------
; 159 | pLicVerDp->VerCnt = TRUE;                                              
;----------------------------------------------------------------------
L17:        
        sti       r0,*ar0
	.line	53
;----------------------------------------------------------------------
; 160 | memset(pLicVerDp->cvbBuf[i].chVer,'0',4);                              
;----------------------------------------------------------------------
        ldiu      4,r2
        ldiu      48,r1
        ldiu      *+fp(1),r0
        mpyi      10,r0
        addi      *+fp(136),r0          ; Unsigned
        push      r2
        addi      1,r0                  ; Unsigned
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	54
;----------------------------------------------------------------------
; 161 | memset(pLicVerDp->cvbBuf[i].chBuildDate,'0',6);                        
; 165 | //if(MAKE_WORD(pLicVerDp->CarNum[0],pLicVerDp->CarNum[1]) != 0xFFFF)   
; 166 | //{                                                                    
; 167 | //      m_nCarNo = MAKE_WORD(pLicVerDp->CarNum[0],pLicVerDp->CarNum[1])
;     | ;                                                                      
; 168 | //}                                                                    
; 170 | // LIC-MPU����� ���� & ���嵥��Ʈ                                     
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        mpyi      10,r0
        addi      *+fp(136),r0          ; Unsigned
        ldiu      6,r2
        push      r2
        ldiu      48,r1
        push      r1
        addi      5,r0                  ; Unsigned
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
L18:        
	.line	21
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      32,r0
        blt       L2
;*      Branch Occurs to L2 
L19:        
	.line	64
;----------------------------------------------------------------------
; 171 | m_btExVersionTbl[5] = MAKE_WORD(                                       
; 172 |                                                         MAKE_BYTE(ConvH
;     | ex2Asc(GetFirmwareVersion(1)/1000%10),ConvHex2Asc(GetFirmwareVersion(1)
;     | /100%10)),                                                             
; 173 |                                                         MAKE_BYTE(ConvH
;     | ex2Asc(GetFirmwareVersion(1)/10%10),ConvHex2Asc(GetFirmwareVersion(1)%1
;     | 0))                                                                    
; 174 |                                                         );             
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      1000,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      1,r1
        ldiu      r0,r4
        subi      1,sp
        push      r1
        ash       4,r4
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      100,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      1,r1
        and       15,r0
        or3       r4,r0,r5
        and       255,r5
        subi      1,sp
        ash       8,r5
        push      r1
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      10,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      1,r1
        ldiu      r0,r4
        push      r1
        ash       4,r4
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        or3       r5,r0,r0
        and       65535,r0
        sti       r0,@_m_btExVersionTbl+5
        subi      1,sp
	.line	69
;----------------------------------------------------------------------
; 176 | m_btExVersion_DAYTbl[5] = MAKE_DWORD(                                  
; 177 |                                                         0x20,          
; 178 |                                                         MAKE_BYTE(ConvH
;     | ex2Asc(GetFirmwareVersion(2)/100000%10),ConvHex2Asc(GetFirmwareVersion(
;     | 2)/10000%10)),                                                         
; 179 |                                                         MAKE_BYTE(ConvH
;     | ex2Asc(GetFirmwareVersion(2)/1000%10),ConvHex2Asc(GetFirmwareVersion(2)
;     | /100%10)),                                                             
; 180 |                                                         MAKE_BYTE(ConvH
;     | ex2Asc(GetFirmwareVersion(2)/10%10),ConvHex2Asc(GetFirmwareVersion(2)%1
;     | 0))                                                                    
; 181 |                                                         );             
;----------------------------------------------------------------------
        ldiu      2,r0
        push      r0
        call      _GetFirmwareVersion
                                        ; Call Occurs
        ldiu      @CL8,r1
        subi      1,sp
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      2,r1
        push      r1
        ldiu      r0,r4
        ash       4,r4
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      10000,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      2,r1
        and       15,r0
        subi      1,sp
        or3       r4,r0,r4
        push      r1
        and       255,r4
        ash       16,r4
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      1000,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      r0,r5
        ldiu      2,r1
        subi      1,sp
        push      r1
        ash       4,r5
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      100,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        and       15,r0
        ldiu      2,r1
        or3       r5,r0,r0
        and       255,r0
        ash       8,r0
        subi      1,sp
        or3       r4,r0,r5
        push      r1
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      10,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      2,r1
        ldiu      r0,r4
        push      r1
        ash       4,r4
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        or3       r5,r0,r0
        or        @CL9,r0
        sti       r0,@_m_btExVersion_DAYTbl+5
        subi      1,sp
	.line	76
;----------------------------------------------------------------------
; 183 | i = GetFirmwareVersion(1);                                             
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        sti       r0,*+fp(1)
	.line	77
;----------------------------------------------------------------------
; 184 | sprintf(szBuf,"Lonwork Monitor Program, Version:%d.%d%d%d\r\n",i/1000%1
;     | 0,i/100%10,i/10%10,i%10);                                              
;----------------------------------------------------------------------
        ldiu      1000,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      100,r1
        ldiu      r0,bk
        ldiu      *+fp(1),r0
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      r0,r3
        ldiu      10,r1
        ldiu      *+fp(1),r0
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      r0,ir0
        ldiu      10,r1
        ldiu      *+fp(1),r0
        call      MOD_I30
                                        ; Call Occurs
        ldiu      fp,r1
        ldiu      @CL10,r2
        push      r0
        push      ir0
        push      r3
        push      bk
        addi      7,r1
        push      r2
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      6,sp
	.line	78
;----------------------------------------------------------------------
; 185 | user_DebugPrint(szBuf);                                                
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      7,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	81
;----------------------------------------------------------------------
; 188 | if(DI_ADDRESS_A)                                                       
;----------------------------------------------------------------------
        ldiu      @CL11,ar0
        ldiu      1,r0
        tstb3     *ar0,r0
        beqd      L26
	nop
        ldieq     @CL11,ar0
        ldieq     -1,r0
;*      Branch Occurs to L26 
	.line	83
;----------------------------------------------------------------------
; 190 | m_chCarKindNum = LIC_DEV_NO;                                           
;----------------------------------------------------------------------
        ldiu      34,r0
        sti       r0,@_m_chCarKindNum+0
	.line	84
;----------------------------------------------------------------------
; 191 | m_chCarKind = 'A';                                                     
;----------------------------------------------------------------------
        ldiu      65,r0
        sti       r0,@_m_chCarKind+0
        bu        L28
;*      Branch Occurs to L28 
	.line	86
;----------------------------------------------------------------------
; 193 | else if(DI_ADDRESS_B)                                                  
;----------------------------------------------------------------------
L26:        
        lsh3      r0,*ar0,r0
        tstb      1,r0
        beq       L28
;*      Branch Occurs to L28 
	.line	88
;----------------------------------------------------------------------
; 195 | m_chCarKindNum = LIC_BAKDEV_NO;                                        
;----------------------------------------------------------------------
        ldiu      38,r0
        sti       r0,@_m_chCarKindNum+0
	.line	89
;----------------------------------------------------------------------
; 196 | m_chCarKind = 'B';                                                     
;----------------------------------------------------------------------
        ldiu      66,r0
        sti       r0,@_m_chCarKind+0
L28:        
	.line	91
        pop       r5
        ldiu      *-fp(1),bk
        pop       r4
        ldiu      *fp,fp
        subi      138,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	198,000000030h,136


	.sect	 ".text"

	.global	_user_Loop
	.sym	_user_Loop,_user_Loop,32,2,0
	.func	203
;******************************************************************************
;* FUNCTION NAME: _user_Loop                                                  *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,ar0,st                                           *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 1 Auto + 0 SOE = 3 words          *
;******************************************************************************
_user_Loop:
	.sym	_i,1,4,1,32
	.line	1
;----------------------------------------------------------------------
; 203 | void user_Loop()                                                       
; 205 | int i;                                                                 
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      1,sp
	.line	5
;----------------------------------------------------------------------
; 207 | user_LonWorkLoop();                                                    
; 209 | //user_Lic2LicLoop();                                                  
;----------------------------------------------------------------------
        call      _user_LonWorkLoop
                                        ; Call Occurs
	.line	9
;----------------------------------------------------------------------
; 211 | user_DebugLoop();                                                      
;----------------------------------------------------------------------
        call      _user_DebugLoop
                                        ; Call Occurs
	.line	11
;----------------------------------------------------------------------
; 213 | user_WithCncsRs232Loop();                                              
;----------------------------------------------------------------------
        call      _user_WithCncsRs232Loop
                                        ; Call Occurs
	.line	13
;----------------------------------------------------------------------
; 215 | user_WithPacRs485Loop();                                               
;----------------------------------------------------------------------
        call      _user_WithPacRs485Loop
                                        ; Call Occurs
	.line	15
;----------------------------------------------------------------------
; 217 | if(m_nSingleOrMarriedCarUpdate1msTimer > 500)                          
;----------------------------------------------------------------------
        ldiu      @_m_nSingleOrMarriedCarUpdate1msTimer+0,r0
        cmpi      500,r0
        bls       L33
;*      Branch Occurs to L33 
	.line	17
;----------------------------------------------------------------------
; 219 | m_nSingleOrMarriedCarUpdate1msTimer = 0;                               
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nSingleOrMarriedCarUpdate1msTimer+0
	.line	18
;----------------------------------------------------------------------
; 220 | if(user_IsSingleOrMarried()) SINGLE_OR_MARRIED_CAR = user_IsSingleOrMar
;     | ried();                                                                
;----------------------------------------------------------------------
        call      _user_IsSingleOrMarried
                                        ; Call Occurs
        cmpi      0,r0
        beq       L33
;*      Branch Occurs to L33 
        call      _user_IsSingleOrMarried
                                        ; Call Occurs
        ldiu      @CL12,ar0
        sti       r0,*ar0
L33:        
	.line	20
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      3,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	222,000000000h,1



	.sect	".cinit"
	.field  	1,32
	.field  	_m_btTestOtherCiFault+0,32
	.field  	32768,32		; _m_btTestOtherCiFault @ 0

	.sect	".text"

	.global	_m_btTestOtherCiFault
	.bss	_m_btTestOtherCiFault,1
	.sym	_m_btTestOtherCiFault,_m_btTestOtherCiFault,12,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_bCiFaultFlag+0,32
	.field  	0,32		; _m_bCiFaultFlag @ 0

	.sect	".text"

	.global	_m_bCiFaultFlag
	.bss	_m_bCiFaultFlag,1
	.sym	_m_bCiFaultFlag,_m_bCiFaultFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_nRxPos$1+0,32
	.field  	0,32		; _nRxPos$1 @ 0

	.sect	".text"

	.sect	".cinit"
	.field  	1,32
	.field  	_nOldUart3RxOneByteGapDelayTime$2+0,32
	.field  	0,32		; _nOldUart3RxOneByteGapDelayTime$2 @ 0

	.sect	".text"
	.sect	 ".text"

	.global	_user_Lic2LicLoop
	.sym	_user_Lic2LicLoop,_user_Lic2LicLoop,32,2,0
	.func	229
;******************************************************************************
;* FUNCTION NAME: _user_Lic2LicLoop                                           *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,ar0,fp,ir0,sp,st                           *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 258 Auto + 0 SOE = 260 words      *
;******************************************************************************
_user_Lic2LicLoop:
	.bss	_nRxPos$1,1
	.sym	_nRxPos,_nRxPos$1,4,3,32
	.bss	_nOldUart3RxOneByteGapDelayTime$2,1
	.sym	_nOldUart3RxOneByteGapDelayTime,_nOldUart3RxOneByteGapDelayTime$2,12,3,32
	.bss	_btRx3chBuf$3,256
	.sym	_btRx3chBuf,_btRx3chBuf$3,60,3,8192,,256
	.sym	_nTxPos,1,4,1,32
	.sym	_btBuf,2,60,1,4096,,128
	.sym	_btTxBuf,130,60,1,4096,,128
	.sym	_nRxLen,258,4,1,32
	.line	1
;----------------------------------------------------------------------
; 229 | void user_Lic2LicLoop()                                                
; 231 | int nTxPos;                                                            
; 232 | UCHAR btBuf[128];                                                      
; 233 | UCHAR btTxBuf[128];                                                    
; 234 | int nRxLen;                                                            
; 235 | static int nRxPos = 0;                                                 
; 236 | static UCHAR nOldUart3RxOneByteGapDelayTime = 0;                       
; 237 | static UCHAR btRx3chBuf[256];                                          
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      258,sp
	.line	11
;----------------------------------------------------------------------
; 239 | m_bCiFaultFlag = m_btCttSignalA & 0x10 ? TRUE : FALSE;                 
;----------------------------------------------------------------------
        ldiu      16,r0
        tstb      @_m_btCttSignalA+0,r0
        beq       L37
;*      Branch Occurs to L37 
        bud       L38
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L38 
L37:        
        ldiu      0,r0
L38:        
        sti       r0,@_m_bCiFaultFlag+0
	.line	13
;----------------------------------------------------------------------
; 241 | if(m_nCarPos >= 1 && m_nCarPos <= 8) m_btCiFaultVal = MASKBIT(m_bCiFaul
;     | tFlag,m_nCarPos-1);                                                    
; 243 | // �����ϱ�                                                            
;----------------------------------------------------------------------
        ldi       @_m_nCarPos+0,r0
        ble       L41
;*      Branch Occurs to L41 
        cmpi      8,r0
        bgt       L41
;*      Branch Occurs to L41 
        ldiu      1,r0
        ldiu      1,r1
        and       @_m_bCiFaultFlag+0,r0
        subri     @_m_nCarPos+0,r1
        ash3      r1,r0,r0
        sti       r0,@_m_btCiFaultVal+0
L41:        
	.line	16
;----------------------------------------------------------------------
; 244 | if(m_nTest1msTimer > 100)                                              
;----------------------------------------------------------------------
        ldiu      @_m_nTest1msTimer+0,r0
        cmpi      100,r0
        bls       L44
;*      Branch Occurs to L44 
	.line	18
;----------------------------------------------------------------------
; 246 | m_nTest1msTimer = 0;                                                   
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nTest1msTimer+0
	.line	20
;----------------------------------------------------------------------
; 248 | if(m_chCarKind == 'A')                                                 
;----------------------------------------------------------------------
        ldiu      @_m_chCarKind+0,r0
        cmpi      65,r0
        bne       L44
;*      Branch Occurs to L44 
	.line	22
;----------------------------------------------------------------------
; 250 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
	.line	23
;----------------------------------------------------------------------
; 251 | btTxBuf[nTxPos++] = 0x02;                                              
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      2,r1
        ldiu      r0,ir0
        addi      130,ar0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	24
;----------------------------------------------------------------------
; 252 | btTxBuf[nTxPos++] = m_btCiFaultVal;                                    
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r0
        addi      130,ar0
        ldiu      *+fp(1),ir0
        ldiu      @_m_btCiFaultVal+0,r1
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	25
;----------------------------------------------------------------------
; 253 | btTxBuf[nTxPos++] = m_btCiFaultVal;                                    
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        ldiu      fp,ar0
        addi      ir0,r0
        sti       r0,*+fp(1)
        addi      130,ar0
        ldiu      @_m_btCiFaultVal+0,r1
        sti       r1,*+ar0(ir0)
	.line	26
;----------------------------------------------------------------------
; 254 | btTxBuf[nTxPos++] = 0x03;                                              
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        ldiu      fp,ar0
        addi      ir0,r0
        addi      130,ar0
        ldiu      3,r1
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	28
;----------------------------------------------------------------------
; 256 | xr16l784_RtsDelayStartSend(XR16L784_3CHL,(UCHAR *)btTxBuf,nTxPos,1);   
; 260 | // ���� �ޱ�                                                           
;----------------------------------------------------------------------
        ldiu      2,r2
        ldiu      1,r1
        push      r1
        ldiu      *+fp(1),r1
        push      r1
        ldiu      fp,r0
        addi      130,r0
        push      r0
        push      r2
        call      _xr16l784_RtsDelayStartSend
                                        ; Call Occurs
        subi      4,sp
L44:        
	.line	33
;----------------------------------------------------------------------
; 261 | nRxLen = user_PacRx(btBuf,128);                                        
;----------------------------------------------------------------------
        ldiu      128,r1
        ldiu      fp,r0
        push      r1
        addi      2,r0
        push      r0
        call      _user_PacRx
                                        ; Call Occurs
        ldiu      258,ir0
        subi      2,sp
        sti       r0,*+fp(ir0)
	.line	34
;----------------------------------------------------------------------
; 262 | if(nRxLen)                                                             
;----------------------------------------------------------------------
        ldi       *+fp(ir0),r0
        beq       L49
;*      Branch Occurs to L49 
	.line	36
;----------------------------------------------------------------------
; 264 | if(!m_nUart3RxOneByteGapDelayTime) nRxPos = 0;                         
;----------------------------------------------------------------------
        ldi       @_m_nUart3RxOneByteGapDelayTime+0,r0
        bne       L47
;*      Branch Occurs to L47 
        ldiu      0,r0
        sti       r0,@_nRxPos$1+0
L47:        
	.line	37
;----------------------------------------------------------------------
; 265 | nOldUart3RxOneByteGapDelayTime = m_nUart3RxOneByteGapDelayTime = 10;   
;----------------------------------------------------------------------
        ldiu      10,r0
        sti       r0,@_m_nUart3RxOneByteGapDelayTime+0
        sti       r0,@_nOldUart3RxOneByteGapDelayTime$2+0
	.line	39
;----------------------------------------------------------------------
; 267 | if(nRxPos + nRxLen < 250)                                              
;----------------------------------------------------------------------
        ldiu      258,ir0
        ldiu      *+fp(ir0),r0
        addi      @_nRxPos$1+0,r0
        cmpi      250,r0
        bge       L49
;*      Branch Occurs to L49 
	.line	41
;----------------------------------------------------------------------
; 269 | memcpy(&btRx3chBuf[nRxPos],btBuf,nRxLen);                              
;----------------------------------------------------------------------
        ldiu      @CL13,r0
        ldiu      fp,r2
        ldiu      *+fp(ir0),r1
        addi      @_nRxPos$1+0,r0       ; Unsigned
        addi      2,r2
        push      r1
        push      r2
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	42
;----------------------------------------------------------------------
; 270 | nRxPos += nRxLen;                                                      
;----------------------------------------------------------------------
        ldiu      258,ir0
        ldiu      *+fp(ir0),r0
        addi      @_nRxPos$1+0,r0
        sti       r0,@_nRxPos$1+0
L49:        
	.line	46
;----------------------------------------------------------------------
; 274 | if(nOldUart3RxOneByteGapDelayTime && !m_nUart3RxOneByteGapDelayTime)   
;----------------------------------------------------------------------
        ldi       @_nOldUart3RxOneByteGapDelayTime$2+0,r0
        beq       L57
;*      Branch Occurs to L57 
        ldi       @_m_nUart3RxOneByteGapDelayTime+0,r0
        bne       L57
;*      Branch Occurs to L57 
	.line	48
;----------------------------------------------------------------------
; 276 | if(nRxPos >= 4)                                                        
;----------------------------------------------------------------------
        ldiu      @_nRxPos$1+0,r0
        cmpi      4,r0
        blt       L56
;*      Branch Occurs to L56 
	.line	50
;----------------------------------------------------------------------
; 278 | if(btRx3chBuf[0] == 0x02 && btRx3chBuf[3] == 0x03 && btRx3chBuf[1] == b
;     | tRx3chBuf[2])                                                          
;----------------------------------------------------------------------
        ldiu      @_btRx3chBuf$3+0,r0
        cmpi      2,r0
        bne       L56
;*      Branch Occurs to L56 
        ldiu      @_btRx3chBuf$3+3,r0
        cmpi      3,r0
        bne       L56
;*      Branch Occurs to L56 
        ldiu      @_btRx3chBuf$3+1,r0
        cmpi      @_btRx3chBuf$3+2,r0
        bne       L56
;*      Branch Occurs to L56 
	.line	52
;----------------------------------------------------------------------
; 280 | m_btTestOtherCiFault = btRx3chBuf[1];                                  
;----------------------------------------------------------------------
        sti       r0,@_m_btTestOtherCiFault+0
	.line	54
;----------------------------------------------------------------------
; 282 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
	.line	55
;----------------------------------------------------------------------
; 283 | btTxBuf[nTxPos++] = 0x02;                                              
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        addi      130,ar0
        ldiu      r0,ir0
        addi      ir0,r1
        ldiu      2,r0
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	56
;----------------------------------------------------------------------
; 284 | btTxBuf[nTxPos++] = m_btCiFaultVal;                                    
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      130,ar0
        addi      ir0,r1
        ldiu      @_m_btCiFaultVal+0,r0
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	57
;----------------------------------------------------------------------
; 285 | btTxBuf[nTxPos++] = m_btCiFaultVal;                                    
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      130,ar0
        addi      ir0,r1
        sti       r1,*+fp(1)
        ldiu      @_m_btCiFaultVal+0,r0
        sti       r0,*+ar0(ir0)
	.line	58
;----------------------------------------------------------------------
; 286 | btTxBuf[nTxPos++] = 0x03;                                              
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        ldiu      3,r0
        ldiu      fp,ar0
        addi      130,ar0
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	60
;----------------------------------------------------------------------
; 288 | xr16l784_RtsDelayStartSend(XR16L784_3CHL,(UCHAR *)btTxBuf,nTxPos,10);  
;----------------------------------------------------------------------
        ldiu      10,r2
        push      r2
        ldiu      *+fp(1),r2
        push      r2
        ldiu      fp,r0
        addi      130,r0
        push      r0
        ldiu      2,r1
        push      r1
        call      _xr16l784_RtsDelayStartSend
                                        ; Call Occurs
        subi      4,sp
L56:        
	.line	64
;----------------------------------------------------------------------
; 292 | nOldUart3RxOneByteGapDelayTime = m_nUart3RxOneByteGapDelayTime;        
;----------------------------------------------------------------------
        ldiu      @_m_nUart3RxOneByteGapDelayTime+0,r0
        sti       r0,@_nOldUart3RxOneByteGapDelayTime$2+0
L57:        
	.line	66
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      260,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	294,000000000h,258



	.sect	".cinit"
	.field  	1,32
	.field  	_nRxPos$4+0,32
	.field  	0,32		; _nRxPos$4 @ 0

	.sect	".text"

	.sect	".cinit"
	.field  	1,32
	.field  	_nOldUart1RxOneByteGapDelayTime$5+0,32
	.field  	0,32		; _nOldUart1RxOneByteGapDelayTime$5 @ 0

	.sect	".text"
	.sect	 ".text"

	.global	_user_DebugLoop
	.sym	_user_DebugLoop,_user_DebugLoop,32,2,0
	.func	299
;******************************************************************************
;* FUNCTION NAME: _user_DebugLoop                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,r3,r4,r5,ar0,ar1,ar2,fp,ar4,ar5,ir0,ir1,bk,*
;*                        sp,st,rs,re,rc                                      *
;*   Regs Saved         : r4,r5,ar4,ar5                                       *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 796 Auto + 4 SOE = 802 words      *
;******************************************************************************
_user_DebugLoop:
	.bss	_nRxPos$4,1
	.sym	_nRxPos,_nRxPos$4,4,3,32
	.bss	_nOldUart1RxOneByteGapDelayTime$5,1
	.sym	_nOldUart1RxOneByteGapDelayTime,_nOldUart1RxOneByteGapDelayTime$5,12,3,32
	.bss	_btRxBuf$6,256
	.sym	_btRxBuf,_btRxBuf$6,60,3,8192,,256
	.sym	_i,1,4,1,32
	.sym	_j,2,4,1,32
	.sym	_sIndex,3,4,1,32
	.sym	_szBuf1,4,50,1,8192,,256
	.sym	_szBuf2,260,50,1,8192,,256
	.sym	_btBuf,516,60,1,8192,,256
	.sym	_sTemp,772,60,1,320,,10
	.sym	_nRxLen,782,4,1,32
	.sym	_tmBuf,783,8,1,224,.fake5
	.sym	_pLnWkDp,790,24,1,32,.fake13
	.sym	_pLicVerDp,791,24,1,32,.fake46
	.sym	_pCommStatus_Lic,792,24,1,32,.fake60
	.sym	_HH,793,12,1,32
	.sym	_HL,794,12,1,32
	.sym	_LH,795,12,1,32
	.sym	_LL,796,12,1,32
	.line	1
;----------------------------------------------------------------------
; 299 | void user_DebugLoop()                                                  
; 301 | int i,j;                                                               
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      796,sp
        push      r4
        push      r5
        push      ar4
        push      ar5
	.line	4
;----------------------------------------------------------------------
; 302 | int sIndex = 0;                                                        
; 303 | char szBuf1[256];                                                      
; 304 | char szBuf2[256];                                                      
; 305 | UCHAR btBuf[256];                                                      
; 306 | UCHAR sTemp[10];                                                       
; 307 | int nRxLen;                                                            
; 308 | static int nRxPos = 0;                                                 
; 309 | static UCHAR nOldUart1RxOneByteGapDelayTime = 0;                       
; 310 | static UCHAR btRxBuf[256];                                             
; 311 | DATE_TIME_TYPE tmBuf;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(3)
	.line	14
;----------------------------------------------------------------------
; 312 | PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;                                
;----------------------------------------------------------------------
        ldiu      790,ir0
        ldiu      @CL14,r0
        sti       r0,*+fp(ir0)
	.line	15
;----------------------------------------------------------------------
; 313 | PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó�
;     | ��� ���� ���Ƿ� �������.                                              
; 314 | PCOMMSTATUS_LIC pCommStatus_Lic;  //��ġ Status                        
; 315 | UCHAR HH,HL,LH,LL;                                                     
; 317 | // ����                                                                
;----------------------------------------------------------------------
        ldiu      791,ir0
        ldiu      @CL2,r0
        sti       r0,*+fp(ir0)
	.line	20
;----------------------------------------------------------------------
; 318 | nRxLen = user_DebugRx(btBuf,128);                                      
;----------------------------------------------------------------------
        ldiu      128,r1
        ldiu      516,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _user_DebugRx
                                        ; Call Occurs
        subi      2,sp
        ldiu      782,ir0
        sti       r0,*+fp(ir0)
	.line	21
;----------------------------------------------------------------------
; 319 | if(nRxLen)                                                             
;----------------------------------------------------------------------
        ldi       *+fp(ir0),r0
        beq       L64
;*      Branch Occurs to L64 
	.line	23
;----------------------------------------------------------------------
; 321 | if(!m_nUart1RxOneByteGapDelayTime) nRxPos = 0;                         
;----------------------------------------------------------------------
        ldi       @_m_nUart1RxOneByteGapDelayTime+0,r0
        bne       L62
;*      Branch Occurs to L62 
        ldiu      0,r0
        sti       r0,@_nRxPos$4+0
L62:        
	.line	24
;----------------------------------------------------------------------
; 322 | nOldUart1RxOneByteGapDelayTime = m_nUart1RxOneByteGapDelayTime = 10;   
;----------------------------------------------------------------------
        ldiu      10,r0
        sti       r0,@_m_nUart1RxOneByteGapDelayTime+0
        sti       r0,@_nOldUart1RxOneByteGapDelayTime$5+0
	.line	26
;----------------------------------------------------------------------
; 324 | if(nRxPos + nRxLen < 250)                                              
;----------------------------------------------------------------------
        ldiu      782,ir0
        ldiu      *+fp(ir0),r0
        addi      @_nRxPos$4+0,r0
        cmpi      250,r0
        bge       L64
;*      Branch Occurs to L64 
	.line	28
;----------------------------------------------------------------------
; 326 | memcpy(&btRxBuf[nRxPos],btBuf,nRxLen);                                 
;----------------------------------------------------------------------
        ldiu      @CL15,r0
        ldiu      516,r1
        ldiu      *+fp(ir0),r2
        addi      @_nRxPos$4+0,r0       ; Unsigned
        addi      fp,r1
        push      r2
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	29
;----------------------------------------------------------------------
; 327 | nRxPos += nRxLen;                                                      
;----------------------------------------------------------------------
        ldiu      782,ir0
        ldiu      *+fp(ir0),r0
        addi      @_nRxPos$4+0,r0
        sti       r0,@_nRxPos$4+0
L64:        
	.line	33
;----------------------------------------------------------------------
; 331 | if(nOldUart1RxOneByteGapDelayTime && !m_nUart1RxOneByteGapDelayTime)   
;----------------------------------------------------------------------
        ldi       @_nOldUart1RxOneByteGapDelayTime$5+0,r0
        beq       L353
;*      Branch Occurs to L353 
        ldi       @_m_nUart1RxOneByteGapDelayTime+0,r0
        bne       L353
;*      Branch Occurs to L353 
	.line	35
;----------------------------------------------------------------------
; 333 | strncpy(szBuf1,(char *)btRxBuf,MIN(32,nRxPos));                        
;----------------------------------------------------------------------
        ldiu      32,r0
        cmpi      @_nRxPos$4+0,r0
        bge       L68
;*      Branch Occurs to L68 
        bu        L69
;*      Branch Occurs to L69 
L68:        
        ldiu      @_nRxPos$4+0,r0
L69:        
        ldiu      fp,r1
        push      r0
        ldiu      @CL15,r2
        addi      4,r1
        push      r2
        push      r1
        call      _strncpy
                                        ; Call Occurs
        subi      3,sp
	.line	36
;----------------------------------------------------------------------
; 334 | szBuf1[32] = NULL;                                                     
; 335 | //for(i=0;i<strlen(szBuf1);i++) if(!IS_ASCALPHABET(szBuf1[i]) && !IS_AS
;     | CSPEC(szBuf1[i])) {szBuf1[i] = NULL; break;}                           
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      36,ar0
        ldiu      0,r0
        sti       r0,*ar0
	.line	39
;----------------------------------------------------------------------
; 337 | if(btRxBuf[0] == '\r' || btRxBuf[0] == '\n')                           
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+0,r0
        cmpi      13,r0
        beq       L71
;*      Branch Occurs to L71 
        cmpi      10,r0
        bned      L73
        ldine     4,r2
        ldine     fp,r0
        ldine     @CL17,r1
;*      Branch Occurs to L73 
L71:        
	.line	41
;----------------------------------------------------------------------
; 339 | MyPrintf((char *)"->\r\n");                                            
; 341 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL16,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	44
;----------------------------------------------------------------------
; 342 | if(!strncmp(szBuf1,"Time",4))                                          
;----------------------------------------------------------------------
L73:        
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L105
        subi      3,sp
        ldine     1,r2
        ldine     fp,r0
;*      Branch Occurs to L105 
	.line	46
;----------------------------------------------------------------------
; 344 | if(IS_ASCNUMBER(btRxBuf[5]) && IS_ASCNUMBER(btRxBuf[6]) &&             
; 345 |         IS_ASCNUMBER(btRxBuf[7]) && IS_ASCNUMBER(btRxBuf[8]) &&        
; 346 |         IS_ASCNUMBER(btRxBuf[9]) && IS_ASCNUMBER(btRxBuf[10]) &&       
; 347 |         IS_ASCNUMBER(btRxBuf[11]) && IS_ASCNUMBER(btRxBuf[12]) &&      
; 348 |         IS_ASCNUMBER(btRxBuf[13]) && IS_ASCNUMBER(btRxBuf[14]) &&      
; 349 |         IS_ASCNUMBER(btRxBuf[15]) && IS_ASCNUMBER(btRxBuf[16]))        
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+5,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
        ldiu      @_btRxBuf$6+6,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
        ldiu      @_btRxBuf$6+7,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
        ldiu      @_btRxBuf$6+8,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
        ldiu      @_btRxBuf$6+9,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
        ldiu      @_btRxBuf$6+10,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
        ldiu      @_btRxBuf$6+11,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
        ldiu      @_btRxBuf$6+12,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
        ldiu      @_btRxBuf$6+13,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
        ldiu      @_btRxBuf$6+14,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
        ldiu      @_btRxBuf$6+15,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
        ldiu      @_btRxBuf$6+16,r0
        cmpi      48,r0
        blo       L103
;*      Branch Occurs to L103 
        cmpi      57,r0
        bhi       L103
;*      Branch Occurs to L103 
	.line	53
;----------------------------------------------------------------------
; 351 | tmBuf.second = MAKE_BYTE(ConvAsc2Hex(btRxBuf[15]),ConvAsc2Hex(btRxBuf[1
;     | 6]));                                                                  
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+15,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      r0,r4
        ldiu      @_btRxBuf$6+16,r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      783,ir0
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	54
;----------------------------------------------------------------------
; 352 | tmBuf.minute = MAKE_BYTE(ConvAsc2Hex(btRxBuf[13]),ConvAsc2Hex(btRxBuf[1
;     | 4]));                                                                  
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+13,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      @_btRxBuf$6+14,r1
        push      r1
        ldiu      r0,r4
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      784,ir0
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	55
;----------------------------------------------------------------------
; 353 | tmBuf.hour = MAKE_BYTE(ConvAsc2Hex(btRxBuf[11]),ConvAsc2Hex(btRxBuf[12]
;     | ));                                                                    
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+11,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      r0,r4
        ldiu      @_btRxBuf$6+12,r0
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      785,ir0
        and       15,r0
        subi      1,sp
        or3       r4,r0,r0
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	56
;----------------------------------------------------------------------
; 354 | tmBuf.day = MAKE_BYTE(ConvAsc2Hex(btRxBuf[9]),ConvAsc2Hex(btRxBuf[10]))
;     | ;                                                                      
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+9,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        subi      1,sp
        ldiu      @_btRxBuf$6+10,r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      786,ir0
        subi      1,sp
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	57
;----------------------------------------------------------------------
; 355 | tmBuf.month = MAKE_BYTE(ConvAsc2Hex(btRxBuf[7]),ConvAsc2Hex(btRxBuf[8])
;     | );                                                                     
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+7,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        ldiu      @_btRxBuf$6+8,r0
        subi      1,sp
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      787,ir0
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	58
;----------------------------------------------------------------------
; 356 | tmBuf.year = MAKE_BYTE(ConvAsc2Hex(btRxBuf[5]),ConvAsc2Hex(btRxBuf[6]))
;     | ;                                                                      
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+5,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        subi      1,sp
        ldiu      @_btRxBuf$6+6,r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      788,ir0
        and       15,r0
        subi      1,sp
        or3       r4,r0,r0
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	59
;----------------------------------------------------------------------
; 357 | tmBuf.weekday = 0;                                                     
;----------------------------------------------------------------------
        ldiu      789,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	61
;----------------------------------------------------------------------
; 359 | m_tmCurTime.second = HEXA2BIN(tmBuf.second);                           
;----------------------------------------------------------------------
        ldiu      -4,r1
        ldiu      783,ir0
        ldiu      783,ir1
        lsh3      r1,*+fp(ir0),r1
        mpyi      10,r1
        ldiu      15,r0
        and3      r0,*+fp(ir1),r0
        addi3     r0,r1,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+0
	.line	62
;----------------------------------------------------------------------
; 360 | m_tmCurTime.minute = HEXA2BIN(tmBuf.minute);                           
;----------------------------------------------------------------------
        ldiu      784,ir0
        ldiu      784,ir1
        ldiu      -4,r1
        lsh3      r1,*+fp(ir1),r1
        ldiu      15,r0
        mpyi      10,r1
        and3      r0,*+fp(ir0),r0
        addi3     r0,r1,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+1
	.line	63
;----------------------------------------------------------------------
; 361 | m_tmCurTime.hour = HEXA2BIN(tmBuf.hour);                               
;----------------------------------------------------------------------
        ldiu      785,ir1
        ldiu      -4,r0
        lsh3      r0,*+fp(ir1),r0
        ldiu      785,ir0
        ldiu      15,r1
        and3      r1,*+fp(ir0),r1
        mpyi      10,r0
        addi3     r1,r0,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+2
	.line	64
;----------------------------------------------------------------------
; 362 | m_tmCurTime.day = HEXA2BIN(tmBuf.day);                                 
;----------------------------------------------------------------------
        ldiu      786,ir1
        ldiu      786,ir0
        ldiu      -4,r0
        ldiu      15,r1
        lsh3      r0,*+fp(ir1),r0
        mpyi      10,r0
        and3      r1,*+fp(ir0),r1
        addi3     r1,r0,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+3
	.line	65
;----------------------------------------------------------------------
; 363 | m_tmCurTime.month = HEXA2BIN(tmBuf.month);                             
;----------------------------------------------------------------------
        ldiu      -4,r0
        ldiu      787,ir1
        ldiu      787,ir0
        ldiu      15,r1
        lsh3      r0,*+fp(ir1),r0
        and3      r1,*+fp(ir0),r1
        mpyi      10,r0
        addi3     r1,r0,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+4
	.line	66
;----------------------------------------------------------------------
; 364 | m_tmCurTime.year = HEXA2BIN(tmBuf.year);                               
;----------------------------------------------------------------------
        ldiu      -4,r0
        ldiu      15,r1
        ldiu      788,ir1
        ldiu      788,ir0
        lsh3      r0,*+fp(ir1),r0
        and3      r1,*+fp(ir0),r1
        mpyi      10,r0
        addi3     r1,r0,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+5
	.line	68
;----------------------------------------------------------------------
; 366 | memset(&m_tmUtcTime, 0x00, sizeof(DATE_TIME_TYPE));                    
;----------------------------------------------------------------------
        ldiu      7,r2
        push      r2
        ldiu      0,r1
        push      r1
        ldiu      @CL18,r0
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	70
;----------------------------------------------------------------------
; 368 | if(m_LIC_CNCS_TimSetFlag = GetLocalTimeToUTC(&m_tmCurTime, -7, &m_tmUtc
;     | Time))                                                                 
;----------------------------------------------------------------------
        ldiu      @CL18,r2
        push      r2
        ldiu      -7,r1
        ldiu      @CL19,r0
        push      r1
        push      r0
        call      _GetLocalTimeToUTC
                                        ; Call Occurs
        cmpi      0,r0
        beqd      L101
	nop
        subi      3,sp
        sti       r0,@_m_LIC_CNCS_TimSetFlag+0
;*      Branch Occurs to L101 
	.line	72
;----------------------------------------------------------------------
; 370 | m_tmUtcTime.year        = ConvDec2Hex(m_tmUtcTime.year  );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+5,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+5
        subi      1,sp
	.line	73
;----------------------------------------------------------------------
; 371 | m_tmUtcTime.month       = ConvDec2Hex(m_tmUtcTime.month );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+4,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+4
        subi      1,sp
	.line	74
;----------------------------------------------------------------------
; 372 | m_tmUtcTime.day         = ConvDec2Hex(m_tmUtcTime.day   );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+3,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+3
        subi      1,sp
	.line	75
;----------------------------------------------------------------------
; 373 | m_tmUtcTime.hour        = ConvDec2Hex(m_tmUtcTime.hour  );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+2,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+2
        subi      1,sp
	.line	76
;----------------------------------------------------------------------
; 374 | m_tmUtcTime.minute      = ConvDec2Hex(m_tmUtcTime.minute);             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+1,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+1
        subi      1,sp
	.line	77
;----------------------------------------------------------------------
; 375 | m_tmUtcTime.second      = ConvDec2Hex(m_tmUtcTime.second);             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+0,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+0
        subi      1,sp
	.line	79
;----------------------------------------------------------------------
; 377 | m_nCncsRxCheck1msTimer = 100000;                                       
;----------------------------------------------------------------------
        ldiu      @CL20,r0
        sti       r0,@_m_nCncsRxCheck1msTimer+0
L101:        
	.line	82
;----------------------------------------------------------------------
; 380 | m_tmUtcTime.year        = ConvDec2Hex(m_tmUtcTime.year  );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+5,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+5
        subi      1,sp
	.line	83
;----------------------------------------------------------------------
; 381 | m_tmUtcTime.month       = ConvDec2Hex(m_tmUtcTime.month );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+4,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+4
        subi      1,sp
	.line	84
;----------------------------------------------------------------------
; 382 | m_tmUtcTime.day         = ConvDec2Hex(m_tmUtcTime.day   );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+3,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+3
        subi      1,sp
	.line	85
;----------------------------------------------------------------------
; 383 | m_tmUtcTime.hour        = ConvDec2Hex(m_tmUtcTime.hour  );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+2,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+2
        subi      1,sp
	.line	86
;----------------------------------------------------------------------
; 384 | m_tmUtcTime.minute      = ConvDec2Hex(m_tmUtcTime.minute);             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+1,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+1
        subi      1,sp
	.line	87
;----------------------------------------------------------------------
; 385 | m_tmUtcTime.second      = ConvDec2Hex(m_tmUtcTime.second);
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+0,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+0
        subi      1,sp
	.line	89
;----------------------------------------------------------------------
; 387 | sprintf(btBuf,"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour
;     | ],%02X[minute],%02X[second] \r\n",                                     
; 389 |         BIN2HEXA(m_tmUtcTime.year),                                    
; 390 |         BIN2HEXA(m_tmUtcTime.month),                                   
; 391 |         BIN2HEXA(m_tmUtcTime.day),                                     
; 392 |         BIN2HEXA(m_tmUtcTime.hour),                                    
; 393 |         BIN2HEXA(m_tmUtcTime.minute),                                  
; 394 |         BIN2HEXA(m_tmUtcTime.second));                                 
;----------------------------------------------------------------------
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+5,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      10,r1
        ldiu      r0,r2
        ash       4,r2
        ldiu      @_m_tmUtcTime+5,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        ldiu      @_m_tmUtcTime+4,r0
        or3       r2,r1,ir1
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      @_m_tmUtcTime+4,r0
        ldiu      10,r1
        ash       4,r2
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        ldiu      @_m_tmUtcTime+3,r0
        or3       r2,r1,ar2
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+3,r0
        ash       4,r2
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,bk
        ldiu      @_m_tmUtcTime+2,r0
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      @_m_tmUtcTime+2,r0
        ldiu      10,r1
        ash       4,r2
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,r3
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+1,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      10,r1
        ash       4,r2
        ldiu      @_m_tmUtcTime+1,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+0,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,ir0
        ldiu      @_m_tmUtcTime+0,r0
        ldiu      10,r1
        call      MOD_U30
                                        ; Call Occurs
        ash       4,ir0
        or3       ir0,r0,r0
        push      r0
        push      r2
        push      r3
        push      bk
        ldiu      @CL21,r0
        push      ar2
        push      ir1
        push      r0
        ldiu      516,r1
        addi      fp,r1
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      8,sp
	.line	98
;----------------------------------------------------------------------
; 396 | user_DebugPrint((char *)btBuf);                                        
; 398 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
L103:        
	.line	102
;----------------------------------------------------------------------
; 400 | user_DebugPrint("Not Date&time format \r\n");                          
; 403 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL22,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	106
;----------------------------------------------------------------------
; 404 | if(!strncmp(szBuf1,"t",1))                                             
;----------------------------------------------------------------------
L105:        
        ldiu      @CL23,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L109
        subi      3,sp
        ldine     7,r2
        ldine     fp,r0
;*      Branch Occurs to L109 
	.line	108
;----------------------------------------------------------------------
; 406 | sprintf(btBuf,"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour
;     | ],%02X[minute],%02X[second] \r\n",                                     
; 407 |         BIN2HEXA(m_tmUtcTime.year),                                    
; 408 |         BIN2HEXA(m_tmUtcTime.month),                                   
; 409 |         BIN2HEXA(m_tmUtcTime.day),                                     
; 410 |         BIN2HEXA(m_tmUtcTime.hour),                                    
; 411 |         BIN2HEXA(m_tmUtcTime.minute),                                  
; 412 |         BIN2HEXA(m_tmUtcTime.second));                                 
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+5,r0
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      10,r1
        ash       4,r2
        ldiu      @_m_tmUtcTime+5,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,ir1
        ldiu      @_m_tmUtcTime+4,r0
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ash       4,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+4,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,ar2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+3,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      @_m_tmUtcTime+3,r0
        ldiu      10,r1
        ash       4,r2
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,bk
        ldiu      @_m_tmUtcTime+2,r0
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      @_m_tmUtcTime+2,r0
        ash       4,r2
        ldiu      10,r1
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,r3
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+1,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      @_m_tmUtcTime+1,r0
        ash       4,r2
        ldiu      10,r1
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+0,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,ir0
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+0,r0
        call      MOD_U30
                                        ; Call Occurs
        ash       4,ir0
        or3       ir0,r0,r0
        ldiu      516,r1
        push      r0
        push      r2
        addi      fp,r1
        push      r3
        ldiu      @CL21,r0
        push      bk
        push      ar2
        push      ir1
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      8,sp
	.line	115
;----------------------------------------------------------------------
; 413 | user_DebugPrint((char *)btBuf);                                        
; 415 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	118
;----------------------------------------------------------------------
; 416 | if(!strncmp(szBuf1,"Version",7))                                       
;----------------------------------------------------------------------
L109:        
        ldiu      @CL24,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L117
        subi      3,sp
        ldine     6,r2
        ldine     fp,r0
;*      Branch Occurs to L117 
	.line	120
;----------------------------------------------------------------------
; 418 | i = GetFirmwareVersion(1);                                             
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        sti       r0,*+fp(1)
	.line	122
;----------------------------------------------------------------------
; 420 | memcpy(sTemp,&pLnWkDp->btVerH,2);                                      
;----------------------------------------------------------------------
        ldiu      790,ir0
        ldiu      772,ar1
        ldiu      1,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        addi      fp,ar1
        ldiu      *ar0,r0
        sti       r0,*ar1
        ldiu      *+ar0,r0
        sti       r0,*+ar1
	.line	123
;----------------------------------------------------------------------
; 421 | j = MAKE_WORD(sTemp[0],sTemp[1]);                                      
;----------------------------------------------------------------------
        ldiu      773,ir1
        ldiu      255,r1
        ldiu      772,ir0
        ldiu      8,r0
        and3      r1,*+fp(ir1),r1
        ash3      r0,*+fp(ir0),r0
        or3       r0,r1,r0
        and       65535,r0
        sti       r0,*+fp(2)
	.line	125
;----------------------------------------------------------------------
; 423 | sprintf(btBuf,"LIC-MPU Version:%d.%d%d%d,Build Date:20%06d, LIC-LON Ver
;     | sion:%d.%d%d%d,Build Date:%08X\r\n",                                   
; 424 |         i/1000%10,                                                     
; 425 |         i/100%10,                                                      
; 426 |         i/10%10,                                                       
; 427 |         i%10,                                                          
; 428 |         GetFirmwareVersion(2),                                         
; 429 |         BYTE_H(WORD_H(j)),                                             
; 430 |         BYTE_L(WORD_H(j)),                                             
; 431 |         BYTE_H(WORD_L(j)),                                             
; 432 |         BYTE_L(WORD_L(j)),                                             
; 433 |         MAKE_DWORD(pLnWkDp->btBuildDateHH,pLnWkDp->btBuildDateHL,pLnWkD
;     | p->btBuildDateLH,pLnWkDp->btBuildDateLL));                             
;----------------------------------------------------------------------
        ldiu      1000,r1
        ldiu      *+fp(1),r0
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      r0,r5
        ldiu      100,r1
        ldiu      *+fp(1),r0
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      r0,ar5
        ldiu      10,r1
        ldiu      *+fp(1),r0
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      r0,ar4
        ldiu      *+fp(1),r0
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      2,r1
        push      r1
        ldiu      r0,r4
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      790,ir0
        ldiu      790,ir1
        ldiu      255,re
        ldiu      255,r1
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        and       *+ar0(4),r1
        ash       16,r1
        ldiu      *+fp(ir0),ar2
        ldiu      *+ar1(3),r2
        ash       24,r2
        or3       r2,r1,bk
        ldiu      255,r2
        ldiu      *+fp(2),r1
        ldiu      r1,r3
        ash       -8,r3
        and       15,r3
        and       *+fp(2),r2
        ldiu      255,rc
        and       *+ar2(5),re
        ldiu      *+fp(ir0),ar0
        ldiu      15,rs
        ash       8,re
        and       *+ar0(6),rc
        or3       bk,re,re
        and       *+fp(2),rs
        or3       re,rc,re
        push      re
        ash       -4,r2
        push      rs
        and       15,r2
        ash       -8,r1
        push      r2
        and       255,r1
        push      r3
        ash       -4,r1
        and       15,r1
        push      r1
        push      r0
        ldiu      @CL25,r1
        push      r4
        push      ar4
        ldiu      ar5,r0
        push      r0
        push      r5
        push      r1
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      12,sp
	.line	137
;----------------------------------------------------------------------
; 435 | user_DebugPrint((char *)btBuf);                                        
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	139
;----------------------------------------------------------------------
; 437 | memset(btBuf,0x00,256);                                                
; 439 | //2011_03_03 ����                                                      
;----------------------------------------------------------------------
        ldiu      256,r0
        ldiu      0,r1
        push      r0
        ldiu      516,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	142
;----------------------------------------------------------------------
; 440 | for(i=0;i<VER_BDD_MAX_CNT;i++) //CNCS�� ���� ���� ���� ���� ǥ�� �ϴ� �
;     | κ� �߰�                                                               
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      32,r0
        bge       L115
;*      Branch Occurs to L115 
L112:        
	.line	144
;----------------------------------------------------------------------
; 442 | if(LIC_VerList[i][0] == NULL) break;                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      @CL26,ar0
        mpyi      9,ir0
        ldi       *+ar0(ir0),r0
        beq       L115
;*      Branch Occurs to L115 
	.line	145
;----------------------------------------------------------------------
; 443 | memset(btBuf,0x00,256);                                                
;----------------------------------------------------------------------
        ldiu      256,r2
        ldiu      516,r1
        ldiu      0,r0
        push      r2
        addi      fp,r1
        push      r0
        push      r1
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	146
;----------------------------------------------------------------------
; 444 | strncpy((char *)btBuf,(char *)&LIC_VerList[i][0],strlen((char*)&LIC_Ver
;     | List[i][0]));                                                          
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        mpyi      9,r0
        addi      @CL26,r0              ; Unsigned
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(1),r1
        mpyi      9,r1
        push      r0
        addi      @CL26,r1              ; Unsigned
        ldiu      516,r0
        addi      fp,r0
        push      r1
        push      r0
        call      _strncpy
                                        ; Call Occurs
        subi      3,sp
	.line	147
;----------------------------------------------------------------------
; 445 | sprintf(&btBuf[strlen((char*)&btBuf)],":");                            
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      @CL27,r1
        subi      1,sp
        push      r1
        addi3     r0,fp,r0              ; Unsigned
        addi      516,r0                ; Unsigned
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	148
;----------------------------------------------------------------------
; 446 | strncpy((char *)&btBuf[strlen((char*)&btBuf)],(char *)&pLicVerDp->cvbBu
;     | f[i].chVer[0],4);                                                      
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(1),r1
        ldiu      791,ir0
        mpyi      10,r1
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        ldiu      4,r2
        push      r2
        addi3     r0,fp,r0              ; Unsigned
        addi      516,r0                ; Unsigned
        addi      1,r1                  ; Unsigned
        push      r1
        push      r0
        call      _strncpy
                                        ; Call Occurs
        subi      3,sp
	.line	149
;----------------------------------------------------------------------
; 447 | sprintf(&btBuf[strlen((char*)&btBuf)],":");                            
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      @CL27,r1
        subi      1,sp
        addi3     r0,fp,r0              ; Unsigned
        push      r1
        addi      516,r0                ; Unsigned
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	150
;----------------------------------------------------------------------
; 448 | strncpy((char *)&btBuf[strlen((char*)&btBuf)],(char *)&pLicVerDp->cvbBu
;     | f[i].chBuildDate[0],6);                                                
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      791,ir0
        subi      1,sp
        ldiu      *+fp(1),r1
        mpyi      10,r1
        ldiu      6,r2
        addi3     r0,fp,r0              ; Unsigned
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        addi      516,r0                ; Unsigned
        push      r2
        addi      5,r1                  ; Unsigned
        push      r1
        push      r0
        call      _strncpy
                                        ; Call Occurs
        subi      3,sp
	.line	151
;----------------------------------------------------------------------
; 449 | sprintf(&btBuf[strlen((char*)&btBuf)],"\r\n");                         
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      @CL28,r1
        addi3     r0,fp,r0              ; Unsigned
        push      r1
        addi      516,r0                ; Unsigned
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	153
;----------------------------------------------------------------------
; 451 | user_DebugPrint((char *)btBuf);                                        
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	142
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      32,r0
        blt       L112
;*      Branch Occurs to L112 
L115:        
	.line	156
;----------------------------------------------------------------------
; 454 | MyPrintf("\r\n\r\n");                                                  
; 456 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL29,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	159
;----------------------------------------------------------------------
; 457 | if(!strncmp(szBuf1,"Recent",6))                                        
;----------------------------------------------------------------------
L117:        
        ldiu      @CL30,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L120
        subi      3,sp
        ldine     10,r2
        ldine     fp,r0
;*      Branch Occurs to L120 
	.line	161
;----------------------------------------------------------------------
; 459 | m_nLnWkTxFlag = 1;                                                     
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_nLnWkTxFlag+0
	.line	162
;----------------------------------------------------------------------
; 460 | user_DebugPrint("Recent fault read start send \r\n");                  
; 462 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL31,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	165
;----------------------------------------------------------------------
; 463 | if(!strncmp(szBuf1,"Historical",10))                                   
;----------------------------------------------------------------------
L120:        
        ldiu      @CL32,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L123
        subi      3,sp
        ldine     6,r2
        ldine     fp,r0
;*      Branch Occurs to L123 
	.line	167
;----------------------------------------------------------------------
; 465 | m_nLnWkTxFlag = 2;                                                     
;----------------------------------------------------------------------
        ldiu      2,r0
        sti       r0,@_m_nLnWkTxFlag+0
	.line	168
;----------------------------------------------------------------------
; 466 | gm_SysTimeToRtc(&tmBuf,m_nDateTime2SecondCnt);                         
;----------------------------------------------------------------------
        ldiu      @_m_nDateTime2SecondCnt+0,r1
        ldiu      783,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _gm_SysTimeToRtc
                                        ; Call Occurs
        subi      2,sp
	.line	169
;----------------------------------------------------------------------
; 467 | sprintf(btBuf,"Historical read start send, Historical start time : %08X
;     | H, Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%02X[minut
;     | e],%02X[second] \r\n",                                                 
; 468 |         m_nDateTime2SecondCnt,                                         
; 469 |         tmBuf.year,                                                    
; 470 |         tmBuf.month,                                                   
; 471 |         tmBuf.day,                                                     
; 472 |         tmBuf.hour,                                                    
; 473 |         tmBuf.minute,                                                  
; 474 |         tmBuf.second);                                                 
;----------------------------------------------------------------------
        ldiu      783,ir0
        ldiu      *+fp(ir0),r0
        ldiu      786,ir1
        ldiu      784,ir0
        push      r0
        ldiu      *+fp(ir0),r0
        ldiu      785,ir0
        push      r0
        ldiu      *+fp(ir0),r0
        push      r0
        ldiu      *+fp(ir1),r0
        ldiu      787,ir1
        push      r0
        ldiu      *+fp(ir1),r1
        push      r1
        ldiu      788,ir0
        ldiu      516,r2
        ldiu      *+fp(ir0),r1
        push      r1
        ldiu      @_m_nDateTime2SecondCnt+0,r1
        addi      fp,r2
        push      r1
        ldiu      @CL33,r0
        push      r0
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      9,sp
	.line	177
;----------------------------------------------------------------------
; 475 | user_DebugPrint((char *)btBuf);                                        
; 477 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	180
;----------------------------------------------------------------------
; 478 | if(!strncmp(szBuf1,"Rxinfo",6))                                        
;----------------------------------------------------------------------
L123:        
        ldiu      @CL34,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L129
        subi      3,sp
        ldine     8,r2
        ldine     fp,r0
;*      Branch Occurs to L129 
	.line	182
;----------------------------------------------------------------------
; 480 | if(!m_nNvsramPos)                                                      
;----------------------------------------------------------------------
        ldi       @_m_nNvsramPos+0,r0
        bne       L126
;*      Branch Occurs to L126 
	.line	184
;----------------------------------------------------------------------
; 482 | sprintf(btBuf,"Total byte : %d, Packet count : %d, window count : %d, r
;     | emaind packet : %d, m_nLnWkWaySideOnRxOk : %d, m_bLnWkFtpEndFlag : %d, 
;     | Historical start time : %08XH \r\n",                                   
; 483 |         0,0,0,0,                                                       
; 484 |         m_nLnWkWaySideOnRxOk,                                          
; 485 |         m_bLnWkFtpEndFlag,                                             
; 486 |         m_nDateTime2SecondCnt);                                        
; 488 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @_m_nDateTime2SecondCnt+0,r0
        ldiu      516,rc
        ldiu      0,rs
        ldiu      0,r3
        ldiu      0,r1
        push      r0
        ldiu      0,r2
        ldiu      @_m_bLnWkFtpEndFlag+0,r0
        addi      fp,rc
        push      r0
        ldiu      @_m_nLnWkWaySideOnRxOk+0,re
        push      re
        ldiu      @CL35,r0
        push      rs
        push      r3
        push      r1
        push      r2
        push      r0
        push      rc
        call      _sprintf
                                        ; Call Occurs
        subi      9,sp
        bu        L127
;*      Branch Occurs to L127 
L126:        
	.line	192
;----------------------------------------------------------------------
; 490 | sprintf(btBuf,"Total byte : %d, Packet count : %d, window count : %d, r
;     | emaind packet : %d, m_nLnWkWaySideOnRxOk : %d, m_bLnWkFtpEndFlag : %d, 
;     | Historical start time : %08XH \r\n",                                   
; 491 |         m_nNvsramPos,                                                  
; 492 |         ((m_nNvsramPos-1)/128)+1,                                      
; 493 |         ((m_nNvsramPos-1)/128/6)+1,                                    
; 494 |         m_nNvsramPos%128,                                              
; 495 |         m_nLnWkWaySideOnRxOk,                                          
; 496 |         m_bLnWkFtpEndFlag,                                             
; 497 |         m_nDateTime2SecondCnt);                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     @_m_nNvsramPos+0,r0   ; Unsigned
        ldiu      768,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      127,r2
        ldiu      @_m_nDateTime2SecondCnt+0,r3
        ldiu      1,r1
        and       @_m_nNvsramPos+0,r2
        subri     @_m_nNvsramPos+0,r1   ; Unsigned
        push      r3
        ldiu      @_m_bLnWkFtpEndFlag+0,r3
        addi      1,r0                  ; Unsigned
        push      r3
        ldiu      @_m_nLnWkWaySideOnRxOk+0,r3
        push      r3
        push      r2
        lsh       -7,r1
        push      r0
        addi      1,r1                  ; Unsigned
        ldiu      @CL35,rs
        push      r1
        ldiu      @_m_nNvsramPos+0,r0
        push      r0
        ldiu      516,r3
        addi      fp,r3
        push      rs
        push      r3
        call      _sprintf
                                        ; Call Occurs
        subi      9,sp
L127:        
	.line	201
;----------------------------------------------------------------------
; 499 | user_DebugPrint((char *)btBuf);                                        
; 501 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	204
;----------------------------------------------------------------------
; 502 | if(!strncmp(szBuf1,"LnWayClr",8))                                      
;----------------------------------------------------------------------
L129:        
        ldiu      @CL36,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L132
        subi      3,sp
        ldine     8,r2
        ldine     fp,r0
;*      Branch Occurs to L132 
	.line	206
;----------------------------------------------------------------------
; 504 | m_nLnWkWaySideOnRxOk = 0;                                              
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nLnWkWaySideOnRxOk+0
	.line	207
;----------------------------------------------------------------------
; 505 | user_DebugPrint("'m_nLnWkWaySideOnRxOk' Clear OK \r\n");               
; 507 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL37,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	210
;----------------------------------------------------------------------
; 508 | if(!strncmp(szBuf1,"LnFtpClr",8))                                      
;----------------------------------------------------------------------
L132:        
        ldiu      @CL38,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L135
        subi      3,sp
        ldine     7,r2
        ldine     fp,r0
;*      Branch Occurs to L135 
	.line	212
;----------------------------------------------------------------------
; 510 | m_bLnWkFtpEndFlag = FALSE;                                             
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_bLnWkFtpEndFlag+0
	.line	213
;----------------------------------------------------------------------
; 511 | user_DebugPrint("'m_bLnWkFtpEndFlag' Clear OK \r\n");                  
; 513 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL39,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	216
;----------------------------------------------------------------------
; 514 | if(!strncmp(szBuf1,"HisStTm",7))                                       
;----------------------------------------------------------------------
L135:        
        ldiu      @CL40,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L188
        subi      3,sp
        ldine     8,r2
        ldine     fp,r0
;*      Branch Occurs to L188 
	.line	218
;----------------------------------------------------------------------
; 516 | if(IS_ASCHEX(btRxBuf[8]) && IS_ASCHEX(btRxBuf[9]) &&                   
; 517 |         IS_ASCHEX(btRxBuf[10]) && IS_ASCHEX(btRxBuf[11]) &&            
; 518 |         IS_ASCHEX(btRxBuf[12]) && IS_ASCHEX(btRxBuf[13]) &&            
; 519 |         IS_ASCHEX(btRxBuf[14]) && IS_ASCHEX(btRxBuf[15]))              
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+8,r0
        cmpi      48,r0
        blo       L138
;*      Branch Occurs to L138 
        cmpi      57,r0
        bls       L142
;*      Branch Occurs to L142 
L138:        
        ldiu      @_btRxBuf$6+8,r0
        cmpi      65,r0
        blo       L140
;*      Branch Occurs to L140 
        cmpi      70,r0
        bls       L142
;*      Branch Occurs to L142 
L140:        
        ldiu      @_btRxBuf$6+8,r0
        cmpi      97,r0
        blo       L186
;*      Branch Occurs to L186 
        cmpi      102,r0
        bhi       L186
;*      Branch Occurs to L186 
L142:        
        ldiu      @_btRxBuf$6+9,r0
        cmpi      48,r0
        blo       L144
;*      Branch Occurs to L144 
        cmpi      57,r0
        bls       L148
;*      Branch Occurs to L148 
L144:        
        ldiu      @_btRxBuf$6+9,r0
        cmpi      65,r0
        blo       L146
;*      Branch Occurs to L146 
        cmpi      70,r0
        bls       L148
;*      Branch Occurs to L148 
L146:        
        ldiu      @_btRxBuf$6+9,r0
        cmpi      97,r0
        blo       L186
;*      Branch Occurs to L186 
        cmpi      102,r0
        bhi       L186
;*      Branch Occurs to L186 
L148:        
        ldiu      @_btRxBuf$6+10,r0
        cmpi      48,r0
        blo       L150
;*      Branch Occurs to L150 
        cmpi      57,r0
        bls       L154
;*      Branch Occurs to L154 
L150:        
        ldiu      @_btRxBuf$6+10,r0
        cmpi      65,r0
        blo       L152
;*      Branch Occurs to L152 
        cmpi      70,r0
        bls       L154
;*      Branch Occurs to L154 
L152:        
        ldiu      @_btRxBuf$6+10,r0
        cmpi      97,r0
        blo       L186
;*      Branch Occurs to L186 
        cmpi      102,r0
        bhi       L186
;*      Branch Occurs to L186 
L154:        
        ldiu      @_btRxBuf$6+11,r0
        cmpi      48,r0
        blo       L156
;*      Branch Occurs to L156 
        cmpi      57,r0
        bls       L160
;*      Branch Occurs to L160 
L156:        
        ldiu      @_btRxBuf$6+11,r0
        cmpi      65,r0
        blo       L158
;*      Branch Occurs to L158 
        cmpi      70,r0
        bls       L160
;*      Branch Occurs to L160 
L158:        
        ldiu      @_btRxBuf$6+11,r0
        cmpi      97,r0
        blo       L186
;*      Branch Occurs to L186 
        cmpi      102,r0
        bhi       L186
;*      Branch Occurs to L186 
L160:        
        ldiu      @_btRxBuf$6+12,r0
        cmpi      48,r0
        blo       L162
;*      Branch Occurs to L162 
        cmpi      57,r0
        bls       L166
;*      Branch Occurs to L166 
L162:        
        ldiu      @_btRxBuf$6+12,r0
        cmpi      65,r0
        blo       L164
;*      Branch Occurs to L164 
        cmpi      70,r0
        bls       L166
;*      Branch Occurs to L166 
L164:        
        ldiu      @_btRxBuf$6+12,r0
        cmpi      97,r0
        blo       L186
;*      Branch Occurs to L186 
        cmpi      102,r0
        bhi       L186
;*      Branch Occurs to L186 
L166:        
        ldiu      @_btRxBuf$6+13,r0
        cmpi      48,r0
        blo       L168
;*      Branch Occurs to L168 
        cmpi      57,r0
        bls       L172
;*      Branch Occurs to L172 
L168:        
        ldiu      @_btRxBuf$6+13,r0
        cmpi      65,r0
        blo       L170
;*      Branch Occurs to L170 
        cmpi      70,r0
        bls       L172
;*      Branch Occurs to L172 
L170:        
        ldiu      @_btRxBuf$6+13,r0
        cmpi      97,r0
        blo       L186
;*      Branch Occurs to L186 
        cmpi      102,r0
        bhi       L186
;*      Branch Occurs to L186 
L172:        
        ldiu      @_btRxBuf$6+14,r0
        cmpi      48,r0
        blo       L174
;*      Branch Occurs to L174 
        cmpi      57,r0
        bls       L178
;*      Branch Occurs to L178 
L174:        
        ldiu      @_btRxBuf$6+14,r0
        cmpi      65,r0
        blo       L176
;*      Branch Occurs to L176 
        cmpi      70,r0
        bls       L178
;*      Branch Occurs to L178 
L176:        
        ldiu      @_btRxBuf$6+14,r0
        cmpi      97,r0
        blo       L186
;*      Branch Occurs to L186 
        cmpi      102,r0
        bhi       L186
;*      Branch Occurs to L186 
L178:        
        ldiu      @_btRxBuf$6+15,r0
        cmpi      48,r0
        blo       L180
;*      Branch Occurs to L180 
        cmpi      57,r0
        bls       L184
;*      Branch Occurs to L184 
L180:        
        ldiu      @_btRxBuf$6+15,r0
        cmpi      65,r0
        blo       L182
;*      Branch Occurs to L182 
        cmpi      70,r0
        bls       L184
;*      Branch Occurs to L184 
L182:        
        ldiu      @_btRxBuf$6+15,r0
        cmpi      97,r0
        blo       L186
;*      Branch Occurs to L186 
        cmpi      102,r0
        bhi       L186
;*      Branch Occurs to L186 
L184:        
	.line	223
;----------------------------------------------------------------------
; 521 | m_nDateTime2SecondCnt = MAKE_DWORD(                                    
; 522 |         MAKE_BYTE(ConvAsc2Hex(btRxBuf[8]),ConvAsc2Hex(btRxBuf[9])),    
; 523 |         MAKE_BYTE(ConvAsc2Hex(btRxBuf[10]),ConvAsc2Hex(btRxBuf[11])),  
; 524 |         MAKE_BYTE(ConvAsc2Hex(btRxBuf[12]),ConvAsc2Hex(btRxBuf[13])),  
; 525 |         MAKE_BYTE(ConvAsc2Hex(btRxBuf[14]),ConvAsc2Hex(btRxBuf[15]))); 
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+8,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      r0,r4
        ldiu      @_btRxBuf$6+9,r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      @_btRxBuf$6+10,r1
        push      r1
        and       15,r0
        or3       r4,r0,r5
        and       255,r5
        ash       24,r5
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        ldiu      @_btRxBuf$6+11,r0
        subi      1,sp
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r1
        and       255,r1
        ash       16,r1
        ldiu      @_btRxBuf$6+12,r0
        subi      1,sp
        or3       r5,r1,r5
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        ldiu      @_btRxBuf$6+13,r0
        subi      1,sp
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r1
        and       255,r1
        subi      1,sp
        ldiu      @_btRxBuf$6+14,r0
        ash       8,r1
        push      r0
        or3       r5,r1,r5
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        ldiu      @_btRxBuf$6+15,r0
        subi      1,sp
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        or3       r5,r0,r0
        sti       r0,@_m_nDateTime2SecondCnt+0
        subi      1,sp
	.line	230
;----------------------------------------------------------------------
; 528 | gm_SysTimeToRtc(&tmBuf,m_nDateTime2SecondCnt);                         
;----------------------------------------------------------------------
        ldiu      r0,r1
        push      r1
        ldiu      783,r0
        addi      fp,r0
        push      r0
        call      _gm_SysTimeToRtc
                                        ; Call Occurs
        subi      2,sp
	.line	231
;----------------------------------------------------------------------
; 529 | sprintf(btBuf,"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour
;     | ],%02X[minute],%02X[second], Setting OK \r\n",                         
; 530 |         tmBuf.year,                                                    
; 531 |         tmBuf.month,                                                   
; 532 |         tmBuf.day,                                                     
; 533 |         tmBuf.hour,                                                    
; 534 |         tmBuf.minute,                                                  
; 535 |         tmBuf.second                                                   
; 536 |         );                                                             
;----------------------------------------------------------------------
        ldiu      783,ir0
        ldiu      *+fp(ir0),r0
        ldiu      784,ir1
        push      r0
        ldiu      *+fp(ir1),r0
        ldiu      785,ir0
        push      r0
        ldiu      *+fp(ir0),r0
        ldiu      786,ir0
        push      r0
        ldiu      *+fp(ir0),r1
        ldiu      787,ir1
        push      r1
        ldiu      *+fp(ir1),r1
        push      r1
        ldiu      788,ir0
        ldiu      @CL41,r0
        ldiu      *+fp(ir0),r1
        push      r1
        push      r0
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      8,sp
	.line	239
;----------------------------------------------------------------------
; 537 | user_DebugPrint((char *)btBuf);                                        
; 539 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
L186:        
	.line	243
;----------------------------------------------------------------------
; 541 | user_DebugPrint("No format \r\n");                                     
; 544 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL42,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	247
;----------------------------------------------------------------------
; 545 | if(!strncmp(szBuf1,"CarNoSet",8))                                      
;----------------------------------------------------------------------
L188:        
        ldiu      @CL43,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L204
        subi      3,sp
        ldine     9,r2
        ldine     fp,r0
;*      Branch Occurs to L204 
	.line	249
;----------------------------------------------------------------------
; 547 | if(IS_ASCNUMBER(btRxBuf[9]) && IS_ASCNUMBER(btRxBuf[10]) && IS_ASCNUMBE
;     | R(btRxBuf[11]) && IS_ASCNUMBER(btRxBuf[12]))                           
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+9,r0
        cmpi      48,r0
        blo       L201
;*      Branch Occurs to L201 
        cmpi      57,r0
        bhi       L201
;*      Branch Occurs to L201 
        ldiu      @_btRxBuf$6+10,r0
        cmpi      48,r0
        blo       L201
;*      Branch Occurs to L201 
        cmpi      57,r0
        bhi       L201
;*      Branch Occurs to L201 
        ldiu      @_btRxBuf$6+11,r0
        cmpi      48,r0
        blo       L201
;*      Branch Occurs to L201 
        cmpi      57,r0
        bhi       L201
;*      Branch Occurs to L201 
        ldiu      @_btRxBuf$6+12,r0
        cmpi      48,r0
        blo       L201
;*      Branch Occurs to L201 
        cmpi      57,r0
        bhi       L201
;*      Branch Occurs to L201 
	.line	251
;----------------------------------------------------------------------
; 549 | m_nCarNo = ConvAsc2Dec(btRxBuf[9])*1000 + ConvAsc2Dec(btRxBuf[10])*100
;     | + ConvAsc2Dec(btRxBuf[11])*10 + ConvAsc2Dec(btRxBuf[12]);              
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+9,r0
        push      r0
        call      _ConvAsc2Dec
                                        ; Call Occurs
        subi      1,sp
        ldiu      1000,r1
        ldiu      @_btRxBuf$6+10,r2
        mpyi3     r1,r0,r4
        push      r2
        call      _ConvAsc2Dec
                                        ; Call Occurs
        ldiu      100,r1
        ldiu      @_btRxBuf$6+11,r2
        subi      1,sp
        push      r2
        mpyi3     r1,r0,r0
        addi3     r0,r4,r4
        call      _ConvAsc2Dec
                                        ; Call Occurs
        ldiu      10,r1
        ldiu      @_btRxBuf$6+12,r2
        subi      1,sp
        mpyi3     r1,r0,r0
        push      r2
        addi3     r0,r4,r4
        call      _ConvAsc2Dec
                                        ; Call Occurs
        subi      1,sp
        addi3     r0,r4,r0              ; Unsigned
        sti       r0,@_m_nCarNo+0
	.line	252
;----------------------------------------------------------------------
; 550 | m_chCarKind = m_nCarNo&0x01 ? 'A' : 'B';                               
;----------------------------------------------------------------------
        ldiu      1,r0
        tstb      @_m_nCarNo+0,r0
        beq       L199
;*      Branch Occurs to L199 
        bud       L200
	nop
	nop
        ldiu      65,r0
;*      Branch Occurs to L200 
L199:        
        ldiu      66,r0
L200:        
        sti       r0,@_m_chCarKind+0
	.line	253
;----------------------------------------------------------------------
; 551 | MyPrintf("Car Number = %d,%c Car \r\n",m_nCarNo,m_chCarKind);          
; 553 | else                                                                   
;----------------------------------------------------------------------
        push      r0
        ldiu      @CL44,r1
        ldiu      @_m_nCarNo+0,r0
        push      r0
        push      r1
        call      _MyPrintf
                                        ; Call Occurs
        subi      3,sp
        bu        L202
;*      Branch Occurs to L202 
L201:        
	.line	257
;----------------------------------------------------------------------
; 555 | MyPrintf("Invalid syntax\r\n");                                        
;----------------------------------------------------------------------
        ldiu      @CL45,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
L202:        
	.line	260
;----------------------------------------------------------------------
; 558 | user_CarNoForCarKindToLon();                                           
; 560 | else                                                                   
;----------------------------------------------------------------------
        call      _user_CarNoForCarKindToLon
                                        ; Call Occurs
        bu        L352
;*      Branch Occurs to L352 
	.line	263
;----------------------------------------------------------------------
; 561 | if(!strncmp(szBuf1,"WaySideON",9))                                     
;----------------------------------------------------------------------
L204:        
        ldiu      @CL46,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L210
        subi      3,sp
        ldine     9,r2
        ldine     fp,r0
;*      Branch Occurs to L210 
	.line	265
;----------------------------------------------------------------------
; 563 | m_nCDT_FaultDataStFlag = 1;                                            
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_nCDT_FaultDataStFlag+0
	.line	266
;----------------------------------------------------------------------
; 564 | nRecving_Posi = 0;                                                     
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_nRecving_Posi+0
	.line	268
;----------------------------------------------------------------------
; 566 | gm_SysTimeToRtc(&tmBuf,m_nDateTime2SecondCnt);                         
;----------------------------------------------------------------------
        ldiu      @_m_nDateTime2SecondCnt+0,r1
        ldiu      783,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _gm_SysTimeToRtc
                                        ; Call Occurs
        subi      2,sp
	.line	269
;----------------------------------------------------------------------
; 567 | sprintf(btBuf,"m_nCDT_FaultDataStFlag  = %d,%s, Date&Time : 20%02X[year
;     | ],%02X[month],%02X[day],%02X[hour],%02X[minute],%02X[second]\r\n",m_nCD
;     | T_FaultDataStFlag,m_nLnWkTxFlag == 2 ? "Historical" : "Recently",      
; 568 |                 tmBuf.year,                                            
; 569 |                 tmBuf.month,                                           
; 570 |                 tmBuf.day,                                             
; 571 |                 tmBuf.hour,                                            
; 572 |                 tmBuf.minute,                                          
; 573 |                 tmBuf.second                                           
; 574 |         );                                                             
;----------------------------------------------------------------------
        ldiu      @_m_nLnWkTxFlag+0,r0
        cmpi      2,r0
        bned      L208
        ldine     @CL47,r1
        ldine     783,ir1
        ldine     784,ir0
;*      Branch Occurs to L208 
        ldiu      @CL32,r1
        ldiu      783,ir1
        ldiu      784,ir0
L208:        
        ldiu      *+fp(ir1),r0
        push      r0
        ldiu      *+fp(ir0),r2
        ldiu      786,ir1
        ldiu      785,ir0
        push      r2
        ldiu      *+fp(ir0),r0
        push      r0
        ldiu      *+fp(ir1),r0
        push      r0
        ldiu      787,ir0
        ldiu      *+fp(ir0),r0
        ldiu      788,ir0
        push      r0
        ldiu      *+fp(ir0),r3
        push      r3
        push      r1
        ldiu      @CL48,r2
        ldiu      @_m_nCDT_FaultDataStFlag+0,r1
        ldiu      516,r0
        push      r1
        addi      fp,r0
        push      r2
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      10,sp
	.line	277
;----------------------------------------------------------------------
; 575 | user_DebugPrint((char *)btBuf);                                        
; 577 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	280
;----------------------------------------------------------------------
; 578 | if(!strncmp(szBuf1,"CommStSet",9))                                     
;----------------------------------------------------------------------
L210:        
        ldiu      @CL49,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L288
        subi      3,sp
        ldine     9,r1
        ldine     fp,r0
;*      Branch Occurs to L288 
	.line	282
;----------------------------------------------------------------------
; 580 | if( IS_ASCHEX(btRxBuf[10]) &&IS_ASCHEX(btRxBuf[11]) &&                 
; 581 |         IS_ASCHEX(btRxBuf[12]) &&IS_ASCHEX(btRxBuf[13]) &&             
; 582 |         IS_ASCHEX(btRxBuf[14]) &&IS_ASCHEX(btRxBuf[15]) &&             
; 583 |         IS_ASCHEX(btRxBuf[16]) &&IS_ASCHEX(btRxBuf[17]))               
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+10,r0
        cmpi      48,r0
        blo       L213
;*      Branch Occurs to L213 
        cmpi      57,r0
        bls       L217
;*      Branch Occurs to L217 
L213:        
        ldiu      @_btRxBuf$6+10,r0
        cmpi      65,r0
        blo       L215
;*      Branch Occurs to L215 
        cmpi      70,r0
        bls       L217
;*      Branch Occurs to L217 
L215:        
        ldiu      @_btRxBuf$6+10,r0
        cmpi      97,r0
        blo       L286
;*      Branch Occurs to L286 
        cmpi      102,r0
        bhi       L286
;*      Branch Occurs to L286 
L217:        
        ldiu      @_btRxBuf$6+11,r0
        cmpi      48,r0
        blo       L219
;*      Branch Occurs to L219 
        cmpi      57,r0
        bls       L223
;*      Branch Occurs to L223 
L219:        
        ldiu      @_btRxBuf$6+11,r0
        cmpi      65,r0
        blo       L221
;*      Branch Occurs to L221 
        cmpi      70,r0
        bls       L223
;*      Branch Occurs to L223 
L221:        
        ldiu      @_btRxBuf$6+11,r0
        cmpi      97,r0
        blo       L286
;*      Branch Occurs to L286 
        cmpi      102,r0
        bhi       L286
;*      Branch Occurs to L286 
L223:        
        ldiu      @_btRxBuf$6+12,r0
        cmpi      48,r0
        blo       L225
;*      Branch Occurs to L225 
        cmpi      57,r0
        bls       L229
;*      Branch Occurs to L229 
L225:        
        ldiu      @_btRxBuf$6+12,r0
        cmpi      65,r0
        blo       L227
;*      Branch Occurs to L227 
        cmpi      70,r0
        bls       L229
;*      Branch Occurs to L229 
L227:        
        ldiu      @_btRxBuf$6+12,r0
        cmpi      97,r0
        blo       L286
;*      Branch Occurs to L286 
        cmpi      102,r0
        bhi       L286
;*      Branch Occurs to L286 
L229:        
        ldiu      @_btRxBuf$6+13,r0
        cmpi      48,r0
        blo       L231
;*      Branch Occurs to L231 
        cmpi      57,r0
        bls       L235
;*      Branch Occurs to L235 
L231:        
        ldiu      @_btRxBuf$6+13,r0
        cmpi      65,r0
        blo       L233
;*      Branch Occurs to L233 
        cmpi      70,r0
        bls       L235
;*      Branch Occurs to L235 
L233:        
        ldiu      @_btRxBuf$6+13,r0
        cmpi      97,r0
        blo       L286
;*      Branch Occurs to L286 
        cmpi      102,r0
        bhi       L286
;*      Branch Occurs to L286 
L235:        
        ldiu      @_btRxBuf$6+14,r0
        cmpi      48,r0
        blo       L237
;*      Branch Occurs to L237 
        cmpi      57,r0
        bls       L241
;*      Branch Occurs to L241 
L237:        
        ldiu      @_btRxBuf$6+14,r0
        cmpi      65,r0
        blo       L239
;*      Branch Occurs to L239 
        cmpi      70,r0
        bls       L241
;*      Branch Occurs to L241 
L239:        
        ldiu      @_btRxBuf$6+14,r0
        cmpi      97,r0
        blo       L286
;*      Branch Occurs to L286 
        cmpi      102,r0
        bhi       L286
;*      Branch Occurs to L286 
L241:        
        ldiu      @_btRxBuf$6+15,r0
        cmpi      48,r0
        blo       L243
;*      Branch Occurs to L243 
        cmpi      57,r0
        bls       L247
;*      Branch Occurs to L247 
L243:        
        ldiu      @_btRxBuf$6+15,r0
        cmpi      65,r0
        blo       L245
;*      Branch Occurs to L245 
        cmpi      70,r0
        bls       L247
;*      Branch Occurs to L247 
L245:        
        ldiu      @_btRxBuf$6+15,r0
        cmpi      97,r0
        blo       L286
;*      Branch Occurs to L286 
        cmpi      102,r0
        bhi       L286
;*      Branch Occurs to L286 
L247:        
        ldiu      @_btRxBuf$6+16,r0
        cmpi      48,r0
        blo       L249
;*      Branch Occurs to L249 
        cmpi      57,r0
        bls       L253
;*      Branch Occurs to L253 
L249:        
        ldiu      @_btRxBuf$6+16,r0
        cmpi      65,r0
        blo       L251
;*      Branch Occurs to L251 
        cmpi      70,r0
        bls       L253
;*      Branch Occurs to L253 
L251:        
        ldiu      @_btRxBuf$6+16,r0
        cmpi      97,r0
        blo       L286
;*      Branch Occurs to L286 
        cmpi      102,r0
        bhi       L286
;*      Branch Occurs to L286 
L253:        
        ldiu      @_btRxBuf$6+17,r0
        cmpi      48,r0
        blo       L255
;*      Branch Occurs to L255 
        cmpi      57,r0
        bls       L259
;*      Branch Occurs to L259 
L255:        
        ldiu      @_btRxBuf$6+17,r0
        cmpi      65,r0
        blo       L257
;*      Branch Occurs to L257 
        cmpi      70,r0
        bls       L259
;*      Branch Occurs to L259 
L257:        
        ldiu      @_btRxBuf$6+17,r0
        cmpi      97,r0
        blo       L286
;*      Branch Occurs to L286 
        cmpi      102,r0
        bhi       L286
;*      Branch Occurs to L286 
L259:        
	.line	288
;----------------------------------------------------------------------
; 586 | FunConvAscHex((char *)&btRxBuf[10],sTemp,8);                           
;----------------------------------------------------------------------
        ldiu      8,r1
        ldiu      772,r0
        ldiu      @CL50,r2
        push      r1
        addi      fp,r0
        push      r0
        push      r2
        call      _FunConvAscHex
                                        ; Call Occurs
        subi      3,sp
	.line	290
;----------------------------------------------------------------------
; 588 | memset(m_btCommSt,0x00,sizeof(m_btCommSt));                            
;----------------------------------------------------------------------
        ldiu      8,r2
        ldiu      0,r1
        ldiu      @CL3,r0
        push      r2
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	291
;----------------------------------------------------------------------
; 589 | pCommStatus_Lic = (COMMSTATUS_LIC *)m_btCommSt;                        
;----------------------------------------------------------------------
        ldiu      792,ir0
        ldiu      @CL3,r0
        sti       r0,*+fp(ir0)
	.line	293
;----------------------------------------------------------------------
; 591 | pCommStatus_Lic->BYTE_1.BYTE = sTemp[0];                               
;----------------------------------------------------------------------
        ldiu      792,ir1
        ldiu      772,ir0
        ldiu      *+fp(ir1),ar0
        ldiu      *+fp(ir0),r0
        sti       r0,*ar0
	.line	294
;----------------------------------------------------------------------
; 592 | pCommStatus_Lic->BYTE_2.BYTE = sTemp[1];                               
;----------------------------------------------------------------------
        ldiu      792,ir0
        ldiu      773,ir1
        ldiu      *+fp(ir0),ar0
        ldiu      *+fp(ir1),r0
        sti       r0,*+ar0(1)
	.line	295
;----------------------------------------------------------------------
; 593 | pCommStatus_Lic->BYTE_3.BYTE = sTemp[2];                               
;----------------------------------------------------------------------
        ldiu      774,ir1
        ldiu      *+fp(ir0),ar0
        ldiu      *+fp(ir1),r0
        sti       r0,*+ar0(2)
	.line	296
;----------------------------------------------------------------------
; 594 | pCommStatus_Lic->BYTE_4.BYTE = sTemp[3];                               
;----------------------------------------------------------------------
        ldiu      775,ir1
        ldiu      *+fp(ir0),ar0
        ldiu      *+fp(ir1),r0
        sti       r0,*+ar0(3)
	.line	298
;----------------------------------------------------------------------
; 596 | MyPrintf("CommStSet =  %02X-%02X-%02X-%02X \r\n",                      
; 597 | m_btCommSt[0],                                                         
; 598 | m_btCommSt[1],                                                         
; 599 | m_btCommSt[2],                                                         
; 600 | m_btCommSt[3]);                                                        
;----------------------------------------------------------------------
        ldiu      @_m_btCommSt+0,rs
        ldiu      @_m_btCommSt+1,r0
        ldiu      @_m_btCommSt+3,r2
        ldiu      @_m_btCommSt+2,r1
        push      r2
        push      r1
        push      r0
        ldiu      @CL51,r3
        push      rs
        push      r3
        call      _MyPrintf
                                        ; Call Occurs
        subi      5,sp
	.line	304
;----------------------------------------------------------------------
; 602 | for(i=0;i<8;i++)                                                       
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        bge       L285
;*      Branch Occurs to L285 
L260:        
	.line	306
;----------------------------------------------------------------------
; 604 | if(!(m_btOldCommSt[i]&0x01) && (m_btCommSt[i]&0x01)) m_btSenseCommStBuf
;     | [i] |= 0x01;                                                           
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      @CL4,ar0
        ldiu      1,r0
        tstb3     *+ar0(ir0),r0
        bne       L263
;*      Branch Occurs to L263 
        ldiu      @CL3,ar0
        tstb3     *+ar0(ir0),r0
        beq       L263
;*      Branch Occurs to L263 
        ldiu      ir0,ar0
        ldiu      @CL5,ir0
        or3       r0,*+ar0(ir0),r0
        sti       r0,*+ar0(ir0)
L263:        
	.line	307
;----------------------------------------------------------------------
; 605 | if(!(m_btOldCommSt[i]&0x02) && (m_btCommSt[i]&0x02)) m_btSenseCommStBuf
;     | [i] |= 0x02;                                                           
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      @CL4,ar0
        ldiu      2,r0
        tstb3     *+ar0(ir0),r0
        bne       L266
;*      Branch Occurs to L266 
        ldiu      @CL3,ar0
        tstb3     *+ar0(ir0),r0
        beq       L266
;*      Branch Occurs to L266 
        ldiu      ir0,ar0
        ldiu      @CL5,ir0
        or3       r0,*+ar0(ir0),r0
        sti       r0,*+ar0(ir0)
L266:        
	.line	308
;----------------------------------------------------------------------
; 606 | if(!(m_btOldCommSt[i]&0x04) && (m_btCommSt[i]&0x04)) m_btSenseCommStBuf
;     | [i] |= 0x04;                                                           
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      @CL4,ar0
        ldiu      4,r0
        tstb3     *+ar0(ir0),r0
        bne       L269
;*      Branch Occurs to L269 
        ldiu      @CL3,ar0
        tstb3     *+ar0(ir0),r0
        beq       L269
;*      Branch Occurs to L269 
        ldiu      ir0,ar0
        ldiu      @CL5,ir0
        or3       r0,*+ar0(ir0),r0
        sti       r0,*+ar0(ir0)
L269:        
	.line	309
;----------------------------------------------------------------------
; 607 | if(!(m_btOldCommSt[i]&0x08) && (m_btCommSt[i]&0x08)) m_btSenseCommStBuf
;     | [i] |= 0x08;                                                           
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      @CL4,ar0
        ldiu      8,r0
        tstb3     *+ar0(ir0),r0
        bne       L272
;*      Branch Occurs to L272 
        ldiu      @CL3,ar0
        tstb3     *+ar0(ir0),r0
        beq       L272
;*      Branch Occurs to L272 
        ldiu      ir0,ar0
        ldiu      @CL5,ir0
        or3       r0,*+ar0(ir0),r0
        sti       r0,*+ar0(ir0)
L272:        
	.line	310
;----------------------------------------------------------------------
; 608 | if(!(m_btOldCommSt[i]&0x10) && (m_btCommSt[i]&0x10)) m_btSenseCommStBuf
;     | [i] |= 0x10;                                                           
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      @CL4,ar0
        ldiu      16,r0
        tstb3     *+ar0(ir0),r0
        bne       L275
;*      Branch Occurs to L275 
        ldiu      @CL3,ar0
        tstb3     *+ar0(ir0),r0
        beq       L275
;*      Branch Occurs to L275 
        ldiu      ir0,ar0
        ldiu      @CL5,ir0
        or3       r0,*+ar0(ir0),r0
        sti       r0,*+ar0(ir0)
L275:        
	.line	311
;----------------------------------------------------------------------
; 609 | if(!(m_btOldCommSt[i]&0x20) && (m_btCommSt[i]&0x20)) m_btSenseCommStBuf
;     | [i] |= 0x20;                                                           
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      @CL4,ar0
        ldiu      32,r0
        tstb3     *+ar0(ir0),r0
        bne       L278
;*      Branch Occurs to L278 
        ldiu      @CL3,ar0
        tstb3     *+ar0(ir0),r0
        beq       L278
;*      Branch Occurs to L278 
        ldiu      ir0,ar0
        ldiu      @CL5,ir0
        or3       r0,*+ar0(ir0),r0
        sti       r0,*+ar0(ir0)
L278:        
	.line	312
;----------------------------------------------------------------------
; 610 | if(!(m_btOldCommSt[i]&0x40) && (m_btCommSt[i]&0x40)) m_btSenseCommStBuf
;     | [i] |= 0x40;                                                           
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      @CL4,ar0
        ldiu      64,r0
        tstb3     *+ar0(ir0),r0
        bne       L281
;*      Branch Occurs to L281 
        ldiu      @CL3,ar0
        tstb3     *+ar0(ir0),r0
        beq       L281
;*      Branch Occurs to L281 
        ldiu      ir0,ar0
        ldiu      @CL5,ir0
        or3       r0,*+ar0(ir0),r0
        sti       r0,*+ar0(ir0)
L281:        
	.line	313
;----------------------------------------------------------------------
; 611 | if(!(m_btOldCommSt[i]&0x80) && (m_btCommSt[i]&0x80)) m_btSenseCommStBuf
;     | [i] |= 0x80;                                                           
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      @CL4,ar0
        ldiu      128,r0
        tstb3     *+ar0(ir0),r0
        bne       L284
;*      Branch Occurs to L284 
        ldiu      @CL3,ar0
        tstb3     *+ar0(ir0),r0
        beq       L284
;*      Branch Occurs to L284 
        ldiu      ir0,ar0
        ldiu      @CL5,ir0
        or3       r0,*+ar0(ir0),r0
        sti       r0,*+ar0(ir0)
L284:        
	.line	304
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        blt       L260
;*      Branch Occurs to L260 
L285:        
	.line	316
;----------------------------------------------------------------------
; 614 | memcpy(m_btOldCommSt,m_btCommSt,8);                                    
; 616 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL4,ar1
        ldiu      @CL3,ar0
        ldiu      *ar0++(1),r0
        rpts      6                     ; Fast MEMCPY(#3)
        sti       r0,*ar1++(1)
||      ldi       *ar0++(1),r0
        sti       r0,*ar1++(1)
        bu        L352
;*      Branch Occurs to L352 
L286:        
	.line	320
;----------------------------------------------------------------------
; 618 | MyPrintf("Invalid syntax\r\n");                                        
; 621 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL45,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	324
;----------------------------------------------------------------------
; 622 | if(!strncmp(szBuf1,"TrainConf",9))                                     
;----------------------------------------------------------------------
L288:        
        ldiu      @CL52,r2
        push      r1
        addi      4,r0
        push      r2
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L297
        subi      3,sp
        ldine     9,r1
        ldine     fp,r0
;*      Branch Occurs to L297 
	.line	326
;----------------------------------------------------------------------
; 624 | if(IS_ASCNUMBER(btRxBuf[10]))                                          
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+10,r0
        cmpi      48,r0
        blo       L295
;*      Branch Occurs to L295 
        cmpi      57,r0
        bhi       L295
;*      Branch Occurs to L295 
	.line	328
;----------------------------------------------------------------------
; 626 | m_TrainCofVal = MIN(3,ConvAsc2Hex(btRxBuf[10]));                       
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+10,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      3,r1
        cmpi3     r0,r1
        bhsd      L293
        subi      1,sp
	nop
        ldihs     @_btRxBuf$6+10,r0
;*      Branch Occurs to L293 
        bud       L294
	nop
	nop
        ldiu      3,r0
;*      Branch Occurs to L294 
L293:        
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
L294:        
        sti       r0,@_m_TrainCofVal+0
	.line	329
;----------------------------------------------------------------------
; 627 | MyPrintf("TrainConf value = %02X \r\n",m_TrainCofVal);                 
; 629 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL53,r1
        push      r0
        push      r1
        call      _MyPrintf
                                        ; Call Occurs
        subi      2,sp
        bu        L352
;*      Branch Occurs to L352 
L295:        
	.line	333
;----------------------------------------------------------------------
; 631 | MyPrintf("Invalid syntax\r\n");                                        
; 634 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL45,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	337
;----------------------------------------------------------------------
; 635 | if(!strncmp(szBuf1,"CarPosSet",9))                                     
;----------------------------------------------------------------------
L297:        
        ldiu      @CL54,r2
        push      r1
        addi      4,r0
        push      r2
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L306
        subi      3,sp
        ldine     10,r1
        ldine     fp,r0
;*      Branch Occurs to L306 
	.line	339
;----------------------------------------------------------------------
; 637 | if(IS_ASCNUMBER(btRxBuf[10]))                                          
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+10,r0
        cmpi      48,r0
        blo       L304
;*      Branch Occurs to L304 
        cmpi      57,r0
        bhi       L304
;*      Branch Occurs to L304 
	.line	341
;----------------------------------------------------------------------
; 639 | if(ConvAsc2Dec(btRxBuf[10]) >= 1 && ConvAsc2Dec(btRxBuf[10]) <= 8)     
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+10,r0
        push      r0
        call      _ConvAsc2Dec
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        ble       L303
;*      Branch Occurs to L303 
        ldiu      @_btRxBuf$6+10,r0
        push      r0
        call      _ConvAsc2Dec
                                        ; Call Occurs
        cmpi      8,r0
        subi      1,sp
        bgt       L303
;*      Branch Occurs to L303 
	.line	343
;----------------------------------------------------------------------
; 641 | m_nCarPos = ConvAsc2Dec(btRxBuf[10]);                                  
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+10,r0
        push      r0
        call      _ConvAsc2Dec
                                        ; Call Occurs
        sti       r0,@_m_nCarPos+0
        subi      1,sp
	.line	344
;----------------------------------------------------------------------
; 642 | MyPrintf("CarPosVal = %02X \r\n",m_nCarPos);                           
; 644 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL55,r1
        push      r0
        push      r1
        call      _MyPrintf
                                        ; Call Occurs
        subi      2,sp
        bu        L352
;*      Branch Occurs to L352 
L303:        
	.line	348
;----------------------------------------------------------------------
; 646 | MyPrintf("Invalid syntax [%d]\r\n",ConvAsc2Dec(btRxBuf[10]));          
; 649 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+10,r0
        push      r0
        call      _ConvAsc2Dec
                                        ; Call Occurs
        ldiu      @CL56,r1
        subi      1,sp
        push      r0
        push      r1
        call      _MyPrintf
                                        ; Call Occurs
        subi      2,sp
        bu        L352
;*      Branch Occurs to L352 
L304:        
	.line	353
;----------------------------------------------------------------------
; 651 | MyPrintf("Invalid syntax\r\n");                                        
; 654 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL45,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	357
;----------------------------------------------------------------------
; 655 | if(!strncmp(szBuf1,"CiFaultSet",10))                                   
;----------------------------------------------------------------------
L306:        
        ldiu      @CL57,r2
        push      r1
        addi      4,r0
        push      r2
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L314
        subi      3,sp
        ldine     6,r1
        ldine     fp,r0
;*      Branch Occurs to L314 
	.line	359
;----------------------------------------------------------------------
; 657 | if( IS_ASCNUMBER(btRxBuf[11]) && IS_ASCNUMBER(btRxBuf[12]))            
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+11,r0
        cmpi      48,r0
        blo       L312
;*      Branch Occurs to L312 
        cmpi      57,r0
        bhi       L312
;*      Branch Occurs to L312 
        ldiu      @_btRxBuf$6+12,r0
        cmpi      48,r0
        blo       L312
;*      Branch Occurs to L312 
        cmpi      57,r0
        bhi       L312
;*      Branch Occurs to L312 
	.line	361
;----------------------------------------------------------------------
; 659 | m_btCiFaultVal = MAKE_WORD(ConvAsc2Hex(btRxBuf[11]),ConvAsc2Hex(btRxBuf
;     | [12]));                                                                
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+11,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      @_btRxBuf$6+12,r1
        ldiu      r0,r4
        ash       8,r4
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       255,r0
        or3       r4,r0,r0
        and       65535,r0
        sti       r0,@_m_btCiFaultVal+0
        subi      1,sp
	.line	362
;----------------------------------------------------------------------
; 660 | MyPrintf("CiFault Val = %02X \r\n",m_btCiFaultVal);                    
; 662 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL58,r1
        push      r0
        push      r1
        call      _MyPrintf
                                        ; Call Occurs
        subi      2,sp
        bu        L352
;*      Branch Occurs to L352 
L312:        
	.line	366
;----------------------------------------------------------------------
; 664 | MyPrintf("Invalid syntax\r\n");                                        
; 667 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL45,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	370
;----------------------------------------------------------------------
; 668 | if(!strncmp(szBuf1,"VerSet",6))                                        
;----------------------------------------------------------------------
L314:        
        ldiu      @CL59,r2
        push      r1
        addi      4,r0
        push      r2
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L347
        subi      3,sp
        ldine     1,r2
        ldine     fp,r0
;*      Branch Occurs to L347 
	.line	373
;----------------------------------------------------------------------
; 671 | if( IS_ASCNUMBER(btRxBuf[7]) && IS_ASCNUMBER(btRxBuf[8]) &&            
; 673 |         IS_ASCNUMBER(btRxBuf[10]) && IS_ASCNUMBER(btRxBuf[11]) &&      
; 674 |         IS_ASCNUMBER(btRxBuf[12]) && IS_ASCNUMBER(btRxBuf[13]) &&      
; 676 |         IS_ASCNUMBER(btRxBuf[15]) && IS_ASCNUMBER(btRxBuf[16]) &&      
; 677 |         IS_ASCNUMBER(btRxBuf[17]) && IS_ASCNUMBER(btRxBuf[18]) &&      
; 678 |         IS_ASCNUMBER(btRxBuf[19]) && IS_ASCNUMBER(btRxBuf[20])         
; 679 |         )                                                              
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+7,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
        ldiu      @_btRxBuf$6+8,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
        ldiu      @_btRxBuf$6+10,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
        ldiu      @_btRxBuf$6+11,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
        ldiu      @_btRxBuf$6+12,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
        ldiu      @_btRxBuf$6+13,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
        ldiu      @_btRxBuf$6+15,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
        ldiu      @_btRxBuf$6+16,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
        ldiu      @_btRxBuf$6+17,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
        ldiu      @_btRxBuf$6+18,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
        ldiu      @_btRxBuf$6+19,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
        ldiu      @_btRxBuf$6+20,r0
        cmpi      48,r0
        blo       L345
;*      Branch Occurs to L345 
        cmpi      57,r0
        bhi       L345
;*      Branch Occurs to L345 
	.line	383
;----------------------------------------------------------------------
; 681 | sIndex = ConvAsc2Dec(btRxBuf[7])*10 + ConvAsc2Dec(btRxBuf[8]);         
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$6+7,r0
        push      r0
        call      _ConvAsc2Dec
                                        ; Call Occurs
        subi      1,sp
        ldiu      10,r1
        ldiu      @_btRxBuf$6+8,r2
        mpyi3     r1,r0,r4
        push      r2
        call      _ConvAsc2Dec
                                        ; Call Occurs
        subi      1,sp
        addi3     r0,r4,r0
        sti       r0,*+fp(3)
	.line	384
;----------------------------------------------------------------------
; 682 | sIndex = MIN(VER_BDD_MAX_CNT,sIndex);                                  
;----------------------------------------------------------------------
        ldiu      32,r0
        cmpi      *+fp(3),r0
        bge       L341
;*      Branch Occurs to L341 
        bu        L342
;*      Branch Occurs to L342 
L341:        
        ldiu      *+fp(3),r0
L342:        
        sti       r0,*+fp(3)
	.line	386
;----------------------------------------------------------------------
; 684 | pLicVerDp->cvbBuf[sIndex].chVer[0] = btRxBuf[10];                      
;----------------------------------------------------------------------
        ldiu      791,ir0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$6+10,r0
        sti       r0,*+ar0(1)
	.line	387
;----------------------------------------------------------------------
; 685 | pLicVerDp->cvbBuf[sIndex].chVer[1] = btRxBuf[11];                      
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$6+11,r0
        sti       r0,*+ar0(2)
	.line	388
;----------------------------------------------------------------------
; 686 | pLicVerDp->cvbBuf[sIndex].chVer[2] = btRxBuf[12];                      
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$6+12,r0
        sti       r0,*+ar0(3)
	.line	389
;----------------------------------------------------------------------
; 687 | pLicVerDp->cvbBuf[sIndex].chVer[3] = btRxBuf[13];                      
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$6+13,r0
        sti       r0,*+ar0(4)
	.line	391
;----------------------------------------------------------------------
; 689 | pLicVerDp->cvbBuf[sIndex].chBuildDate[0]=btRxBuf[15];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$6+15,r0
        sti       r0,*+ar0(5)
	.line	392
;----------------------------------------------------------------------
; 690 | pLicVerDp->cvbBuf[sIndex].chBuildDate[1]=btRxBuf[16];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$6+16,r0
        sti       r0,*+ar0(6)
	.line	393
;----------------------------------------------------------------------
; 691 | pLicVerDp->cvbBuf[sIndex].chBuildDate[2]=btRxBuf[17];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$6+17,r0
        sti       r0,*+ar0(7)
	.line	394
;----------------------------------------------------------------------
; 692 | pLicVerDp->cvbBuf[sIndex].chBuildDate[3]=btRxBuf[18];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$6+18,r0
        sti       r0,*+ar0(8)
	.line	395
;----------------------------------------------------------------------
; 693 | pLicVerDp->cvbBuf[sIndex].chBuildDate[4]=btRxBuf[19];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$6+19,r0
        sti       r0,*+ar0(9)
	.line	396
;----------------------------------------------------------------------
; 694 | pLicVerDp->cvbBuf[sIndex].chBuildDate[5]=btRxBuf[20];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$6+20,r0
        sti       r0,*+ar0(10)
	.line	398
;----------------------------------------------------------------------
; 696 | LH = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chVer[0])),
;     | ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chVer[1])));              
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      255,r0
        and       *+ar0(1),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      791,ir0
        ldiu      *+fp(3),r2
        ldiu      255,r1
        ldiu      r0,r4
        mpyi      10,r2
        addi3     r2,*+fp(ir0),ar0      ; Unsigned
        ash       4,r4
        and       *+ar0(2),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      795,ir0
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	399
;----------------------------------------------------------------------
; 697 | LL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chVer[2])),
;     | ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chVer[3])));              
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        ldiu      791,ir0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      255,r0
        and       *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      255,r1
        ldiu      *+fp(3),r2
        mpyi      10,r2
        ldiu      791,ir0
        ldiu      r0,r4
        addi3     r2,*+fp(ir0),ar0      ; Unsigned
        ash       4,r4
        and       *+ar0(4),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      796,ir0
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	400
;----------------------------------------------------------------------
; 698 | m_btExVersionTbl[sIndex] = MAKE_WORD(LH,LL);                           
;----------------------------------------------------------------------
        ldiu      8,r1
        ldiu      795,ir0
        ldiu      796,ir1
        ash3      r1,*+fp(ir0),r1
        ldiu      255,r0
        and3      r0,*+fp(ir1),r0
        or3       r1,r0,r0
        ldiu      *+fp(3),ir0
        ldiu      @CL6,ar0
        and       65535,r0
        sti       r0,*+ar0(ir0)
	.line	401
;----------------------------------------------------------------------
; 699 | HH = 0x20;                                                             
;----------------------------------------------------------------------
        ldiu      793,ir0
        ldiu      32,r0
        sti       r0,*+fp(ir0)
	.line	402
;----------------------------------------------------------------------
; 700 | HL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate
;     | [0])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate[1])));  
;----------------------------------------------------------------------
        ldiu      791,ir0
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      255,r0
        and       *+ar0(5),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      791,ir0
        subi      1,sp
        ldiu      255,r1
        ldiu      *+fp(3),r2
        ldiu      r0,r4
        mpyi      10,r2
        addi3     r2,*+fp(ir0),ar0      ; Unsigned
        ash       4,r4
        and       *+ar0(6),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      794,ir0
        and       15,r0
        subi      1,sp
        or3       r4,r0,r0
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	403
;----------------------------------------------------------------------
; 701 | LH = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate
;     | [2])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate[3])));  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        ldiu      791,ir0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      255,r0
        and       *+ar0(7),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(3),r2
        ldiu      791,ir0
        mpyi      10,r2
        addi3     r2,*+fp(ir0),ar0      ; Unsigned
        ldiu      255,r1
        ldiu      r0,r4
        ash       4,r4
        and       *+ar0(8),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      795,ir0
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	404
;----------------------------------------------------------------------
; 702 | LL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate
;     | [4])),ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[sIndex].chBuildDate[5])));  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        ldiu      791,ir0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      255,r0
        and       *+ar0(9),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        subi      1,sp
        ldiu      791,ir0
        ldiu      *+fp(3),r2
        ldiu      255,r1
        mpyi      10,r2
        addi3     r2,*+fp(ir0),ar0      ; Unsigned
        ash       4,r4
        and       *+ar0(10),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      796,ir0
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	405
;----------------------------------------------------------------------
; 703 | m_btExVersion_DAYTbl[sIndex] = MAKE_DWORD(HH,HL,LH,LL);                
;----------------------------------------------------------------------
        ldiu      255,r2
        ldiu      794,ir1
        ldiu      795,ir0
        ldiu      255,r0
        and3      r2,*+fp(ir0),r2
        and3      r0,*+fp(ir1),r1
        ldiu      793,ir0
        ldiu      24,r0
        ash3      r0,*+fp(ir0),r0
        ash       16,r1
        ldiu      255,r3
        ash       8,r2
        or3       r0,r1,r0
        ldiu      796,ir1
        or3       r0,r2,r0
        and3      r3,*+fp(ir1),r1
        ldiu      @CL7,ar0
        ldiu      *+fp(3),ir0
        or3       r0,r1,r0
        sti       r0,*+ar0(ir0)
	.line	407
;----------------------------------------------------------------------
; 705 | memset(btBuf,0x00,256);                                                
;----------------------------------------------------------------------
        ldiu      256,r1
        push      r1
        ldiu      0,r0
        push      r0
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	408
;----------------------------------------------------------------------
; 706 | memcpy(btBuf,&LIC_VerList[sIndex][0],strlen((char*)&LIC_VerList[sIndex]
;     | [0]));                                                                 
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      9,r0
        addi      @CL26,r0              ; Unsigned
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(3),r2
        ldiu      516,r1
        push      r0
        mpyi      9,r2
        addi      fp,r1
        ldiu      @CL26,r0
        addi      r2,r0
        push      r0
        push      r1
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	409
;----------------------------------------------------------------------
; 707 | sprintf(&btBuf[strlen((char*)&btBuf)],":");                            
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      @CL27,r1
        subi      1,sp
        addi3     r0,fp,r0              ; Unsigned
        push      r1
        addi      516,r0                ; Unsigned
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	410
;----------------------------------------------------------------------
; 708 | memcpy(&btBuf[strlen((char*)&btBuf)],&pLicVerDp->cvbBuf[sIndex].chVer[0
;     | ],4);                                                                  
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      791,ir0
        subi      1,sp
        ldiu      *+fp(3),r1
        mpyi      10,r1
        addi3     r1,*+fp(ir0),ar0      ; Unsigned
        addi3     r0,fp,ar1             ; Unsigned
        addi      1,ar0                 ; Unsigned
        addi      516,ar1               ; Unsigned
        ldiu      *ar0,r0
        sti       r0,*ar1
        ldiu      *+ar0,r0
        sti       r0,*+ar1
        ldiu      *+ar0(2),r0
        sti       r0,*+ar1(2)
        ldiu      *+ar0(3),r0
        sti       r0,*+ar1(3)
	.line	411
;----------------------------------------------------------------------
; 709 | sprintf(&btBuf[strlen((char*)&btBuf)],":");                            
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      @CL27,r1
        subi      1,sp
        addi3     r0,fp,r0              ; Unsigned
        push      r1
        addi      516,r0                ; Unsigned
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	412
;----------------------------------------------------------------------
; 710 | memcpy(&btBuf[strlen((char*)&btBuf)],&pLicVerDp->cvbBuf[sIndex].chBuild
;     | Date[0],6);                                                            
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      791,ir0
        ldiu      *+fp(3),r1
        mpyi      10,r1
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        addi3     r0,fp,ar0             ; Unsigned
        addi      516,ar0               ; Unsigned
        addi      5,ar1                 ; Unsigned
        ldiu      *ar1++(1),r0
        rpts      4                     ; Fast MEMCPY(#6)
        sti       r0,*ar0++(1)
||      ldi       *ar1++(1),r0
        sti       r0,*ar0++(1)
	.line	413
;----------------------------------------------------------------------
; 711 | sprintf(&btBuf[strlen((char*)&btBuf)],"\r\n");                         
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      @CL28,r1
        subi      1,sp
        push      r1
        addi3     r0,fp,r0              ; Unsigned
        addi      516,r0                ; Unsigned
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	415
;----------------------------------------------------------------------
; 713 | user_DebugPrint((char *)btBuf);                                        
; 716 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
L345:        
	.line	420
;----------------------------------------------------------------------
; 718 | user_DebugPrint("Syntax error\r\n");                                   
; 722 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL60,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	425
;----------------------------------------------------------------------
; 723 | if(!strncmp(szBuf1,"?",1))                                             
;----------------------------------------------------------------------
L347:        
        ldiu      @CL61,r1
        push      r2
        addi      4,r0
        push      r1
        push      r0
        call      _strncmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L351
        subi      3,sp
	nop
        ldine     @CL60,r0
;*      Branch Occurs to L351 
	.line	427
;----------------------------------------------------------------------
; 725 | MyPrintf("[ENTER]      : Move next line after out '->' \r\n");         
;----------------------------------------------------------------------
        ldiu      @CL62,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	428
;----------------------------------------------------------------------
; 726 | MyPrintf("'?'          : Help \r\n");                                  
;----------------------------------------------------------------------
        ldiu      @CL63,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	429
;----------------------------------------------------------------------
; 727 | MyPrintf("'Time'       : Date&time setting , 'Time=YYMMDDHHMNSS', 'EX)T
;     | ime=120102030405' \r\n");                                              
;----------------------------------------------------------------------
        ldiu      @CL64,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	430
;----------------------------------------------------------------------
; 728 | MyPrintf("'t'          : Date&time read \r\n");                        
;----------------------------------------------------------------------
        ldiu      @CL65,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	431
;----------------------------------------------------------------------
; 729 | MyPrintf("'Version     : Version \r\n");                               
;----------------------------------------------------------------------
        ldiu      @CL66,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	432
;----------------------------------------------------------------------
; 730 | MyPrintf("'Recent'     : Recently faults start \r\n");                 
;----------------------------------------------------------------------
        ldiu      @CL67,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	433
;----------------------------------------------------------------------
; 731 | MyPrintf("'Historical' : Historical data start \r\n");                 
;----------------------------------------------------------------------
        ldiu      @CL68,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	434
;----------------------------------------------------------------------
; 732 | MyPrintf("'Rxinfo'     : Recieve info \r\n");                          
;----------------------------------------------------------------------
        ldiu      @CL69,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	435
;----------------------------------------------------------------------
; 733 | MyPrintf("'LnWayClr'   : 'm_nLnWkWaySideOnRxOk' variable clear \r\n"); 
;----------------------------------------------------------------------
        ldiu      @CL70,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	436
;----------------------------------------------------------------------
; 734 | MyPrintf("'LnFtpClr'   : 'm_bLnWkFtpEndFlag' variable clear \r\n");    
;----------------------------------------------------------------------
        ldiu      @CL71,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	437
;----------------------------------------------------------------------
; 735 | MyPrintf("'HisStTm'    : Historical data start time set(2000/1/1 0:0:0
;     | ~ total second), HisStTm=XXXXXXXX, 'EX)HisStTm=0000000F' \r\n");       
;----------------------------------------------------------------------
        ldiu      @CL72,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	438
;----------------------------------------------------------------------
; 736 | MyPrintf("'CarNoSet'   : Car number set. CarNoSet=XXXX, EX)CarNoSet=400
;     | 1 -> [%d[0x%X],%c CAR]\r\n",m_nCarNo,m_nCarNo,m_chCarKind);            
;----------------------------------------------------------------------
        ldiu      @_m_chCarKind+0,r1
        ldiu      @CL73,r0
        push      r1
        ldiu      @_m_nCarNo+0,r1
        push      r1
        ldiu      @_m_nCarNo+0,r1
        push      r1
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      4,sp
	.line	439
;----------------------------------------------------------------------
; 737 | MyPrintf("'TrainConf'  : Train Configuration. TrainConf=X(X : 0~3[2,4,6
;     | ,8Car]) => [%d]\r\n",m_TrainCofVal);                                   
;----------------------------------------------------------------------
        ldiu      @_m_TrainCofVal+0,r0
        push      r0
        ldiu      @CL74,r1
        push      r1
        call      _MyPrintf
                                        ; Call Occurs
        subi      2,sp
	.line	440
;----------------------------------------------------------------------
; 738 | MyPrintf("'CarPosSet'  : Car index position. CarPosSet=X(X:1~8) 'EX)Car
;     | PosSet=1' => [%d]\r\n",m_nCarPos);                                     
;----------------------------------------------------------------------
        ldiu      @_m_nCarPos+0,r0
        push      r0
        ldiu      @CL75,r1
        push      r1
        call      _MyPrintf
                                        ; Call Occurs
        subi      2,sp
	.line	441
;----------------------------------------------------------------------
; 739 | MyPrintf("'CiFaultSet' : Other C/I Fault. CiFaultSet=XX 'EX)CiFaultSet=
;     | 00' => [0x%02X]\r\n",m_btCiFaultVal);                                  
;----------------------------------------------------------------------
        ldiu      @_m_btCiFaultVal+0,r1
        ldiu      @CL76,r0
        push      r1
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      2,sp
	.line	442
;----------------------------------------------------------------------
; 740 | MyPrintf("'WaySideON'  : WaySide_ON \r\n");                            
;----------------------------------------------------------------------
        ldiu      @CL77,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	443
;----------------------------------------------------------------------
; 741 | MyPrintf("'CommStSet'  : Comm Status. CommStSet=XXXXXXXX  'EX) CommStSe
;     | t=FF7F1F53' => [0x%02X,0x%02X,0x%02X,0x%02X]\r\n",WORD_L(m_btCommSt[0])
;     | ,WORD_L(m_btCommSt[1]),WORD_L(m_btCommSt[2]),WORD_L(m_btCommSt[3]));   
;----------------------------------------------------------------------
        ldiu      255,r1
        ldiu      255,r3
        ldiu      255,rs
        and       @_m_btCommSt+2,r3
        ldiu      255,r0
        and       @_m_btCommSt+1,r1
        and       @_m_btCommSt+0,rs
        and       @_m_btCommSt+3,r0
        push      r0
        push      r3
        push      r1
        push      rs
        ldiu      @CL78,r2
        push      r2
        call      _MyPrintf
                                        ; Call Occurs
        subi      5,sp
	.line	444
;----------------------------------------------------------------------
; 742 | MyPrintf("'VerSet'     : Each unit version set. VerSet=XX(incdex):XXXX(
;     | Ver):XXXXXX(BuildDate) \r\n");                                         
;----------------------------------------------------------------------
        ldiu      @CL79,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
	.line	445
;----------------------------------------------------------------------
; 743 | MyPrintf("\r\n");                                                      
; 745 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL28,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
        bu        L352
;*      Branch Occurs to L352 
	.line	449
;----------------------------------------------------------------------
; 747 | user_DebugPrint("Syntax error\r\n");                                   
;----------------------------------------------------------------------
L351:        
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
L352:        
	.line	452
;----------------------------------------------------------------------
; 750 | nOldUart1RxOneByteGapDelayTime = m_nUart1RxOneByteGapDelayTime;        
;----------------------------------------------------------------------
        ldiu      @_m_nUart1RxOneByteGapDelayTime+0,r0
        sti       r0,@_nOldUart1RxOneByteGapDelayTime$5+0
L353:        
	.line	454
        pop       ar5
        ldiu      *-fp(1),bk
        pop       ar4
        pop       r5
        ldiu      *fp,fp
        pop       r4
        subi      798,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	752,000003030h,796


	.sect	 ".text"

	.global	_user_IsSingleOrMarried
	.sym	_user_IsSingleOrMarried,_user_IsSingleOrMarried,36,2,0
	.func	762
;******************************************************************************
;* FUNCTION NAME: _user_IsSingleOrMarried                                     *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0                                                  *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 0 Auto + 0 SOE = 2 words          *
;******************************************************************************
_user_IsSingleOrMarried:
	.line	1
;----------------------------------------------------------------------
; 762 | int user_IsSingleOrMarried()                                           
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	3
;----------------------------------------------------------------------
; 764 | return 1;                                                              
;----------------------------------------------------------------------
        ldiu      1,r0
	.line	4
        ldiu      *-fp(1),r1
        ldiu      *fp,fp
        subi      2,sp
        bu        r1
;*      Branch Occurs to r1 
	.endfunc	765,000000000h,0


	.sect	 ".text"

	.global	_user_SetVersionEnableTbl
	.sym	_user_SetVersionEnableTbl,_user_SetVersionEnableTbl,32,2,0
	.func	770
;******************************************************************************
;* FUNCTION NAME: _user_SetVersionEnableTbl                                   *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,ar0,ir0,st                                    *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 1 Parm + 1 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_SetVersionEnableTbl:
	.sym	_nVal,-2,4,9,32
	.sym	_nPos,1,4,1,32
	.line	1
;----------------------------------------------------------------------
; 770 | void user_SetVersionEnableTbl(int nVal)                                
;----------------------------------------------------------------------
	.line	2
;----------------------------------------------------------------------
; 772 | int nPos;                                                              
; 774 | switch(nVal)                                                           
; 776 | // �̱�ī�� ���                                                       
; 777 | case 1:                                                                
;----------------------------------------------------------------------
        bud       L362
        push      fp
        ldiu      sp,fp
        addi      1,sp
;*      Branch Occurs to L362 
L359:        
	.line	9
;----------------------------------------------------------------------
; 778 | nPos = 0;                                                              
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
	.line	10
;----------------------------------------------------------------------
; 779 | m_bExVersionEnableTbl[nPos++] = TRUE;   //TRIC, A/F                    
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      @CL80,ar0
        ldiu      r0,ir0
        addi      ir0,r1
        ldiu      1,r0
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	11
;----------------------------------------------------------------------
; 780 | m_bExVersionEnableTbl[nPos++] = TRUE;   //TRIC, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	12
;----------------------------------------------------------------------
; 781 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CCP, F/A end
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	13
;----------------------------------------------------------------------
; 782 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CCP, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	14
;----------------------------------------------------------------------
; 783 | m_bExVersionEnableTbl[nPos++] = TRUE;   //LIC-LON
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	15
;----------------------------------------------------------------------
; 784 | m_bExVersionEnableTbl[nPos++] = TRUE;   //LIC-MPU
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	16
;----------------------------------------------------------------------
; 785 | m_bExVersionEnableTbl[nPos++] = TRUE;   //GIA
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	17
;----------------------------------------------------------------------
; 786 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VTX
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	18
;----------------------------------------------------------------------
; 787 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PAC, F/A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	19
;----------------------------------------------------------------------
; 788 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PAC, F/A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	20
;----------------------------------------------------------------------
; 789 | m_bExVersionEnableTbl[nPos++] = TRUE;   //FDI, F /A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	21
;----------------------------------------------------------------------
; 790 | m_bExVersionEnableTbl[nPos++] = TRUE;   //FDI, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	22
;----------------------------------------------------------------------
; 791 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	23
;----------------------------------------------------------------------
; 792 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	24
;----------------------------------------------------------------------
; 793 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	25
;----------------------------------------------------------------------
; 794 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	26
;----------------------------------------------------------------------
; 795 | m_bExVersionEnableTbl[nPos++] = FALSE;  //SDI 5
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        ldiu      0,r1
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	27
;----------------------------------------------------------------------
; 796 | m_bExVersionEnableTbl[nPos++] = FALSE;  //SDI 6
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	28
;----------------------------------------------------------------------
; 797 | m_bExVersionEnableTbl[nPos++] = FALSE;  //SDI 7
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	29
;----------------------------------------------------------------------
; 798 | m_bExVersionEnableTbl[nPos++] = FALSE;  //SDI 8
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	30
;----------------------------------------------------------------------
; 799 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        ldiu      1,r1
        sti       r1,*+ar0(ir0)
	.line	31
;----------------------------------------------------------------------
; 800 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	32
;----------------------------------------------------------------------
; 801 | m_bExVersionEnableTbl[nPos++] = FALSE;  //PII 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      0,r1
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	33
;----------------------------------------------------------------------
; 802 | m_bExVersionEnableTbl[nPos++] = FALSE;  //PII 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	34
;----------------------------------------------------------------------
; 803 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        ldiu      1,r1
        sti       r1,*+ar0(ir0)
	.line	35
;----------------------------------------------------------------------
; 804 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	36
;----------------------------------------------------------------------
; 805 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	37
;----------------------------------------------------------------------
; 806 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	38
;----------------------------------------------------------------------
; 807 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 5
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	39
;----------------------------------------------------------------------
; 808 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 6
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	40
;----------------------------------------------------------------------
; 809 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 7
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        ldiu      0,r1
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	41
;----------------------------------------------------------------------
; 810 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 8
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	42
;----------------------------------------------------------------------
; 811 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 9
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	43
;----------------------------------------------------------------------
; 812 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 10
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	44
;----------------------------------------------------------------------
; 813 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 11
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	45
;----------------------------------------------------------------------
; 814 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 12
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	46
;----------------------------------------------------------------------
; 815 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-MAIN
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	47
;----------------------------------------------------------------------
; 816 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-LAUN
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	48
;----------------------------------------------------------------------
; 817 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-UP
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	49
;----------------------------------------------------------------------
; 818 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-PPLAY
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	50
;----------------------------------------------------------------------
; 819 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-SPLAY
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	51
;----------------------------------------------------------------------
; 820 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-FTPDATA
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	52
;----------------------------------------------------------------------
; 821 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-CDTDATA
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	53
;----------------------------------------------------------------------
; 822 | break;                                                                 
; 824 | // �޸��� ī�� ���                                                    
; 825 | case 2:                                                                
;----------------------------------------------------------------------
        bu        L364
;*      Branch Occurs to L364 
L360:        
	.line	57
;----------------------------------------------------------------------
; 826 | nPos = 0;                                                              
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
	.line	58
;----------------------------------------------------------------------
; 827 | m_bExVersionEnableTbl[nPos++] = TRUE;   //TRIC, A/F                    
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      @CL80,ar0
        ldiu      r0,ir0
        addi      ir0,r1
        ldiu      1,r0
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	59
;----------------------------------------------------------------------
; 828 | m_bExVersionEnableTbl[nPos++] = TRUE;   //TRIC, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	60
;----------------------------------------------------------------------
; 829 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CCP, F/A end
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	61
;----------------------------------------------------------------------
; 830 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CCP, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	62
;----------------------------------------------------------------------
; 831 | m_bExVersionEnableTbl[nPos++] = TRUE;   //LIC-LON
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	63
;----------------------------------------------------------------------
; 832 | m_bExVersionEnableTbl[nPos++] = TRUE;   //LIC-MPU
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	64
;----------------------------------------------------------------------
; 833 | m_bExVersionEnableTbl[nPos++] = TRUE;   //GIA
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	65
;----------------------------------------------------------------------
; 834 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VTX
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	66
;----------------------------------------------------------------------
; 835 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PAC, F/A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	67
;----------------------------------------------------------------------
; 836 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PAC, F/A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	68
;----------------------------------------------------------------------
; 837 | m_bExVersionEnableTbl[nPos++] = TRUE;   //FDI, F /A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	69
;----------------------------------------------------------------------
; 838 | m_bExVersionEnableTbl[nPos++] = TRUE;   //FDI, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	70
;----------------------------------------------------------------------
; 839 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	71
;----------------------------------------------------------------------
; 840 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	72
;----------------------------------------------------------------------
; 841 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	73
;----------------------------------------------------------------------
; 842 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	74
;----------------------------------------------------------------------
; 843 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 5
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	75
;----------------------------------------------------------------------
; 844 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 6
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	76
;----------------------------------------------------------------------
; 845 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 7
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	77
;----------------------------------------------------------------------
; 846 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 8
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	78
;----------------------------------------------------------------------
; 847 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	79
;----------------------------------------------------------------------
; 848 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	80
;----------------------------------------------------------------------
; 849 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	81
;----------------------------------------------------------------------
; 850 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	82
;----------------------------------------------------------------------
; 851 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	83
;----------------------------------------------------------------------
; 852 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	84
;----------------------------------------------------------------------
; 853 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	85
;----------------------------------------------------------------------
; 854 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	86
;----------------------------------------------------------------------
; 855 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 5
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	87
;----------------------------------------------------------------------
; 856 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 6
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	88
;----------------------------------------------------------------------
; 857 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 7
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	89
;----------------------------------------------------------------------
; 858 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 8
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	90
;----------------------------------------------------------------------
; 859 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 9
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	91
;----------------------------------------------------------------------
; 860 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 10
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	92
;----------------------------------------------------------------------
; 861 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 11
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	93
;----------------------------------------------------------------------
; 862 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 12
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	94
;----------------------------------------------------------------------
; 863 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-MAIN
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	95
;----------------------------------------------------------------------
; 864 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-LAUN
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	96
;----------------------------------------------------------------------
; 865 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-UP
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	97
;----------------------------------------------------------------------
; 866 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-PPLAY
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	98
;----------------------------------------------------------------------
; 867 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-SPLAY
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	99
;----------------------------------------------------------------------
; 868 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-FTPDATA
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	100
;----------------------------------------------------------------------
; 869 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-CDTDATA                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	101
;----------------------------------------------------------------------
; 870 | break;                                                                 
;----------------------------------------------------------------------
        bu        L364
;*      Branch Occurs to L364 
L362:        
	.line	5
        ldiu      *-fp(2),r0
        cmpi      1,r0
        beq       L359
;*      Branch Occurs to L359 
        cmpi      2,r0
        beq       L360
;*      Branch Occurs to L360 
L364:        
	.line	103
        ldiu      *-fp(1),ir0
        ldiu      *fp,fp
        subi      3,sp
        bu        ir0
;*      Branch Occurs to ir0 
	.endfunc	872,000000000h,1


	.sect	 ".text"

	.global	_user_DebugRx
	.sym	_user_DebugRx,_user_DebugRx,36,2,0
	.func	877
;******************************************************************************
;* FUNCTION NAME: _user_DebugRx                                               *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,fp,sp                                            *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 0 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_DebugRx:
	.sym	_pBuf,-2,28,9,32
	.sym	_nRxBuffLen,-3,4,9,32
	.line	1
;----------------------------------------------------------------------
; 877 | int user_DebugRx(UCHAR *pBuf,int nRxBuffLen)                           
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 879 | return xr16l784_GetRxBuffer1Ch(pBuf,nRxBuffLen);                       
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        call      _xr16l784_GetRxBuffer1Ch
                                        ; Call Occurs
        subi      2,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	880,000000000h,0


	.sect	 ".text"

	.global	_user_DebugPrint
	.sym	_user_DebugPrint,_user_DebugPrint,32,2,0
	.func	882
;******************************************************************************
;* FUNCTION NAME: _user_DebugPrint                                            *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,fp,sp                                         *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 1 Parm + 0 Auto + 0 SOE = 3 words          *
;******************************************************************************
_user_DebugPrint:
	.sym	_pTxBuf,-2,18,9,32
	.line	1
;----------------------------------------------------------------------
; 882 | void user_DebugPrint(char *pTxBuf)                                     
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 884 | xr16l784_Send(XR16L784_1CHL,(UCHAR *)pTxBuf,strlen(pTxBuf));           
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      0,r1
        subi      1,sp
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        push      r1
        call      _xr16l784_Send
                                        ; Call Occurs
        subi      3,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	885,000000000h,0


	.sect	 ".text"

	.global	_user_CncsRx
	.sym	_user_CncsRx,_user_CncsRx,36,2,0
	.func	887
;******************************************************************************
;* FUNCTION NAME: _user_CncsRx                                                *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,fp,sp                                            *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 0 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_CncsRx:
	.sym	_pBuf,-2,28,9,32
	.sym	_nRxBuffLen,-3,4,9,32
	.line	1
;----------------------------------------------------------------------
; 887 | int user_CncsRx(UCHAR *pBuf,int nRxBuffLen)                            
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 889 | return xr16l784_GetRxBuffer2Ch(pBuf,nRxBuffLen);                       
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        call      _xr16l784_GetRxBuffer2Ch
                                        ; Call Occurs
        subi      2,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	890,000000000h,0


	.sect	 ".text"

	.global	_user_CncsTx
	.sym	_user_CncsTx,_user_CncsTx,32,2,0
	.func	892
;******************************************************************************
;* FUNCTION NAME: _user_CncsTx                                                *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,fp,sp                                         *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 0 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_CncsTx:
	.sym	_pTxBuf,-2,28,9,32
	.sym	_nTxLen,-3,4,9,32
	.line	1
;----------------------------------------------------------------------
; 892 | void user_CncsTx(UCHAR *pTxBuf,int nTxLen)                             
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 894 | xr16l784_RtsDelayStartSend(XR16L784_2CHL,(UCHAR *)pTxBuf,nTxLen,10);   
; 895 | //xr16l784_Send(XR16L784_2CHL,(UCHAR *)pTxBuf,nTxLen);                 
;----------------------------------------------------------------------
        ldiu      10,r0
        ldiu      1,r1
        push      r0
        ldiu      *-fp(3),r0
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        push      r1
        call      _xr16l784_RtsDelayStartSend
                                        ; Call Occurs
        subi      4,sp
	.line	5
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	896,000000000h,0


	.sect	 ".text"

	.global	_user_PacRx
	.sym	_user_PacRx,_user_PacRx,36,2,0
	.func	898
;******************************************************************************
;* FUNCTION NAME: _user_PacRx                                                 *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,fp,sp                                            *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 0 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_PacRx:
	.sym	_pBuf,-2,28,9,32
	.sym	_nRxBuffLen,-3,4,9,32
	.line	1
;----------------------------------------------------------------------
; 898 | int user_PacRx(UCHAR *pBuf,int nRxBuffLen)                             
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 900 | return xr16l784_GetRxBuffer3Ch(pBuf,nRxBuffLen);                       
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        call      _xr16l784_GetRxBuffer3Ch
                                        ; Call Occurs
        subi      2,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	901,000000000h,0


	.sect	 ".text"

	.global	_user_PacTx
	.sym	_user_PacTx,_user_PacTx,32,2,0
	.func	903
;******************************************************************************
;* FUNCTION NAME: _user_PacTx                                                 *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,fp,sp                                         *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 0 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_PacTx:
	.sym	_pTxBuf,-2,28,9,32
	.sym	_nTxLen,-3,4,9,32
	.line	1
;----------------------------------------------------------------------
; 903 | void user_PacTx(UCHAR *pTxBuf,int nTxLen)                              
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 905 | xr16l784_RtsDelayStartSend(XR16L784_3CHL,(UCHAR *)pTxBuf,nTxLen,10);   
;----------------------------------------------------------------------
        ldiu      10,r0
        ldiu      2,r1
        push      r0
        ldiu      *-fp(3),r0
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        push      r1
        call      _xr16l784_RtsDelayStartSend
                                        ; Call Occurs
        subi      4,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	906,000000000h,0


	.sect	 ".text"

	.global	_user_LonWorkLoop
	.sym	_user_LonWorkLoop,_user_LonWorkLoop,32,2,0
	.func	911
;******************************************************************************
;* FUNCTION NAME: _user_LonWorkLoop                                           *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,r4,ar0,fp,ir0,sp,st                        *
;*   Regs Saved         : r4                                                  *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 707 Auto + 1 SOE = 710 words      *
;******************************************************************************
_user_LonWorkLoop:
	.sym	_i,1,4,1,32
	.sym	_nTxPos,2,4,1,32
	.sym	_btTxBuf,3,60,1,4096,,128
	.sym	_pNvsram,131,28,1,32
	.sym	_szBuf,132,50,1,16384,,512
	.sym	_szBuf2,644,50,1,2048,,64
	.line	1
;----------------------------------------------------------------------
; 911 | void user_LonWorkLoop()                                                
; 913 | int i;                                                                 
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      707,sp
        push      r4
	.line	4
;----------------------------------------------------------------------
; 914 | int nTxPos = 0;                                                        
; 915 | UCHAR btTxBuf[128];                                                    
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(2)
	.line	6
;----------------------------------------------------------------------
; 916 | UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;                                 
; 917 | char szBuf[512];                                                       
; 918 | char szBuf2[64];                                                       
;----------------------------------------------------------------------
        ldiu      @CL81,r0
        sti       r0,*+fp(131)
	.line	10
;----------------------------------------------------------------------
; 920 | if(m_nCDT_FaultDataStFlag == 1)                                        
;----------------------------------------------------------------------
        ldiu      @_m_nCDT_FaultDataStFlag+0,r0
        cmpi      1,r0
        bne       L388
;*      Branch Occurs to L388 
	.line	12
;----------------------------------------------------------------------
; 922 | m_nCDT_FaultDataStFlag = 0;                                            
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nCDT_FaultDataStFlag+0
	.line	14
;----------------------------------------------------------------------
; 924 | m_LIC_CNCS_Tx_Flag = TRUE;                                             
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_LIC_CNCS_Tx_Flag+0
	.line	15
;----------------------------------------------------------------------
; 925 | m_nTxDbg1msTimer = 0;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nTxDbg1msTimer+0
	.line	17
;----------------------------------------------------------------------
; 927 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        sti       r0,*+fp(2)
	.line	18
;----------------------------------------------------------------------
; 928 | btTxBuf[nTxPos++] = STX;  // STX                                       
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        addi      3,ar0
        ldiu      r0,ir0
        addi      ir0,r1
        ldiu      2,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	19
;----------------------------------------------------------------------
; 929 | btTxBuf[nTxPos++] = 0x01; // Command Code                              
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      fp,ar0
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r1
        ldiu      1,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	20
;----------------------------------------------------------------------
; 930 | btTxBuf[nTxPos++] = 0x00; // 0x00���� ����                             
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        sti       r1,*+fp(2)
        ldiu      fp,ar0
        addi      3,ar0
        ldiu      0,r0
        sti       r0,*+ar0(ir0)
	.line	21
;----------------------------------------------------------------------
; 931 | btTxBuf[nTxPos++] = 0x06; // ����                                      
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      fp,ar0
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        sti       r1,*+fp(2)
        addi      3,ar0
        ldiu      6,r0
        sti       r0,*+ar0(ir0)
	.line	22
;----------------------------------------------------------------------
; 932 | btTxBuf[nTxPos++] = m_nLnWkTxFlag; // �����̼�(Recently):0x01, ����â(H
;     | istorycal):0x02                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(2),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(2)
        ldiu      fp,ar0
        addi      3,ar0
        ldiu      @_m_nLnWkTxFlag+0,r0
        sti       r0,*+ar0(ir0)
	.line	23
;----------------------------------------------------------------------
; 933 | btTxBuf[nTxPos++] = 0x00; //                                           
;----------------------------------------------------------------------
        ldiu      0,r0
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        ldiu      fp,ar0
        addi      ir0,r1
        addi      3,ar0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	24
;----------------------------------------------------------------------
; 934 | btTxBuf[nTxPos++] = WORD_H(DWORD_H(m_nDateTime2SecondCnt)); // �ð�(HH)
;----------------------------------------------------------------------
        ldiu      @_m_nDateTime2SecondCnt+0,r0
        lsh       -16,r0
        and       65535,r0
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        lsh       -8,r0
        ldiu      fp,ar0
        and       255,r0
        addi      3,ar0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	25
;----------------------------------------------------------------------
; 935 | btTxBuf[nTxPos++] = WORD_L(DWORD_H(m_nDateTime2SecondCnt)); // �ð�(HL)
;----------------------------------------------------------------------
        ldiu      @_m_nDateTime2SecondCnt+0,r0
        ldiu      *+fp(2),ir0
        lsh       -16,r0
        ldiu      1,r1
        ldiu      fp,ar0
        addi      ir0,r1
        addi      3,ar0
        and       255,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	26
;----------------------------------------------------------------------
; 936 | btTxBuf[nTxPos++] = WORD_H(DWORD_L(m_nDateTime2SecondCnt)); // �ð�(LH)
;----------------------------------------------------------------------
        ldiu      @_m_nDateTime2SecondCnt+0,r0
        ldiu      *+fp(2),ir0
        ldiu      1,r1
        ldiu      fp,ar0
        addi      ir0,r1
        and       65535,r0
        addi      3,ar0
        lsh       -8,r0
        sti       r1,*+fp(2)
        and       255,r0
        sti       r0,*+ar0(ir0)
	.line	27
;----------------------------------------------------------------------
; 937 | btTxBuf[nTxPos++] = WORD_L(DWORD_L(m_nDateTime2SecondCnt)); // �ð�(LL)
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        ldiu      255,r0
        ldiu      fp,ar0
        and       @_m_nDateTime2SecondCnt+0,r0
        addi      ir0,r1
        addi      3,ar0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	28
;----------------------------------------------------------------------
; 938 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      4,r0
        ldiu      1,r1
        subri     *+fp(2),r1
        push      r1
        push      r0
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        ldiu      fp,ar0
        addi      ir0,r1
        addi      3,ar0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	29
;----------------------------------------------------------------------
; 939 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      3,r0
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r1
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	30
;----------------------------------------------------------------------
; 940 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      3,r0
        ldiu      *+fp(2),r1
        push      r1
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	32
;----------------------------------------------------------------------
; 942 | MyPrintf("[TX:%02d] ",nTxPos);                                         
;----------------------------------------------------------------------
        ldiu      @CL82,r0
        ldiu      *+fp(2),r1
        push      r1
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      2,sp
	.line	33
;----------------------------------------------------------------------
; 943 | for(i=0;i<nTxPos;i++) MyPrintf("%02X ",WORD_L(btTxBuf[i]));            
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        ldiu      255,r4
        cmpi      *+fp(2),r0
        bge       L387
;*      Branch Occurs to L387 
L386:        
        ldiu      fp,ar0
        ldiu      *+fp(1),ir0
        addi      3,ar0
        ldiu      @CL83,r1
        and3      r4,*+ar0(ir0),r0
        push      r0
        push      r1
        call      _MyPrintf
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        blt       L386
;*      Branch Occurs to L386 
L387:        
	.line	34
;----------------------------------------------------------------------
; 944 | MyPrintf("\r\n");                                                      
; 947 | // NVSRAM�� ����� ������ RS232�� �����Ͽ� ������Ѵ�.                 
;----------------------------------------------------------------------
        ldiu      @CL28,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
L388:        
	.line	38
;----------------------------------------------------------------------
; 948 | if(m_bLnWkDbgTxFlag)                                                   
;----------------------------------------------------------------------
        ldi       @_m_bLnWkDbgTxFlag+0,r0
        beq       L390
;*      Branch Occurs to L390 
	.line	40
;----------------------------------------------------------------------
; 950 | m_bLnWkDbgTxFlag = FALSE;                                              
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_bLnWkDbgTxFlag+0
	.line	41
;----------------------------------------------------------------------
; 951 | m_nDbgTxPos = 0;                                                       
;----------------------------------------------------------------------
        sti       r0,@_m_nDbgTxPos+0
	.line	42
;----------------------------------------------------------------------
; 952 | m_nTxDbg1msTimer = 0;                                                  
;----------------------------------------------------------------------
        sti       r0,@_m_nTxDbg1msTimer+0
L390:        
	.line	45
;----------------------------------------------------------------------
; 955 | if(m_nDbgTxPos < m_nNvsramPos) //m_nDbgTxPos = 0xFFFFFFFF �� �׻� ū ��
;     | �� ������ �ִٰ� �����϶�� ���ɿ� ���� 0���� Ŭ���� �ȴ�.             
;----------------------------------------------------------------------
        ldiu      @_m_nDbgTxPos+0,r0
        cmpi      @_m_nNvsramPos+0,r0
        bhs       L400
;*      Branch Occurs to L400 
	.line	47
;----------------------------------------------------------------------
; 957 | if(m_nTxDbg1msTimer > 200)                                             
;----------------------------------------------------------------------
        ldiu      @_m_nTxDbg1msTimer+0,r0
        cmpi      200,r0
        bls       L405
;*      Branch Occurs to L405 
	.line	49
;----------------------------------------------------------------------
; 959 | m_nTxDbg1msTimer = 0;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nTxDbg1msTimer+0
	.line	50
;----------------------------------------------------------------------
; 960 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      132,ar0
        sti       r0,*ar0
	.line	51
;----------------------------------------------------------------------
; 961 | for(i=0;i<(MIN(128,(UINT)(m_nNvsramPos-m_nDbgTxPos)));i++) {sprintf(szB
;     | uf2,"%02X ",pNvsram[m_nDbgTxPos+i]); strcat(szBuf,szBuf2);}            
;----------------------------------------------------------------------
        sti       r0,*+fp(1)
        bu        L395
;*      Branch Occurs to L395 
	.line	51
L394:        
        addi      *+fp(131),ir0         ; Unsigned
        ldiu      @CL83,r0
        ldiu      *+ar0(ir0),r2
        addi      fp,r1
        push      r2
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      644,r1
        ldiu      fp,r0
        addi      fp,r1
        addi      132,r0
        push      r1
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
L395:        
        ldiu      @_m_nDbgTxPos+0,r0
        ldiu      128,r1
        subri     @_m_nNvsramPos+0,r0   ; Unsigned
        cmpi3     r0,r1
        bhs       L397
;*      Branch Occurs to L397 
        bud       L398
	nop
	nop
        ldiu      128,r0
;*      Branch Occurs to L398 
L397:        
        ldiu      @_m_nDbgTxPos+0,r0
        subri     @_m_nNvsramPos+0,r0   ; Unsigned
L398:        
        ldiu      *+fp(1),r1
        cmpi3     r0,r1
        blod      L394
        ldilo     @_m_nDbgTxPos+0,ir0
        ldilo     *+fp(1),ar0
        ldilo     644,r1
;*      Branch Occurs to L394 
	.line	52
;----------------------------------------------------------------------
; 962 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL28,r1
        ldiu      fp,r0
        push      r1
        addi      132,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	53
;----------------------------------------------------------------------
; 963 | user_DebugPrint(szBuf);                                                
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      132,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	54
;----------------------------------------------------------------------
; 964 | m_nDbgTxPos += 128;                                                    
; 967 | else                                                                   
;----------------------------------------------------------------------
        ldiu      128,r0
        addi      @_m_nDbgTxPos+0,r0    ; Unsigned
        sti       r0,@_m_nDbgTxPos+0
        bu        L405
;*      Branch Occurs to L405 
L400:        
	.line	58
;----------------------------------------------------------------------
; 968 | if(m_nDbgTxPos == 0xFFFFFFFF)                                          
;----------------------------------------------------------------------
        ldiu      @_m_nDbgTxPos+0,r0
        cmpi      @CL84,r0
        bne       L405
;*      Branch Occurs to L405 
	.line	60
;----------------------------------------------------------------------
; 970 | if(nTxPos)                                                             
;----------------------------------------------------------------------
        ldi       *+fp(2),r0
        beq       L405
;*      Branch Occurs to L405 
	.line	62
;----------------------------------------------------------------------
; 972 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      132,ar0
        ldiu      0,r0
        sti       r0,*ar0
	.line	63
;----------------------------------------------------------------------
; 973 | sprintf(szBuf2,"[TX:%02d] ",nTxPos); strcat(szBuf,szBuf2);             
;----------------------------------------------------------------------
        ldiu      644,r1
        ldiu      @CL82,r2
        addi      fp,r1
        ldiu      *+fp(2),r0
        push      r0
        push      r2
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      644,r1
        ldiu      fp,r0
        addi      fp,r1
        addi      132,r0
        push      r1
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	64
;----------------------------------------------------------------------
; 974 | for(i=0;i<nTxPos;i++) {sprintf(szBuf2,"%02X ",WORD_L(btTxBuf[i])); strc
;     | at(szBuf,szBuf2);}                                                     
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        ldiu      255,r4
        cmpi      *+fp(2),r0
        bge       L404
;*      Branch Occurs to L404 
L403:        
        ldiu      fp,ar0
        ldiu      *+fp(1),ir0
        ldiu      644,r1
        addi      3,ar0
        ldiu      @CL83,r2
        and3      r4,*+ar0(ir0),r0
        addi      fp,r1
        push      r0
        push      r2
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      644,r1
        ldiu      fp,r0
        addi      fp,r1
        addi      132,r0
        push      r1
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        blt       L403
;*      Branch Occurs to L403 
L404:        
	.line	65
;----------------------------------------------------------------------
; 975 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL28,r1
        ldiu      fp,r0
        push      r1
        addi      132,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	66
;----------------------------------------------------------------------
; 976 | user_DebugPrint(szBuf);                                                
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      132,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
L405:        
	.line	69
        ldiu      *-fp(1),bk
        pop       r4
        ldiu      *fp,fp
        subi      709,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	979,000000010h,707



	.sect	".cinit"
	.field  	1,32
	.field  	_nOldKind$7+0,32
	.field  	0,32		; _nOldKind$7 @ 0

	.sect	".text"

	.sect	".cinit"
	.field  	1,32
	.field  	_nRecRxPos$8+0,32
	.field  	0,32		; _nRecRxPos$8 @ 0

	.sect	".text"
	.sect	 ".text"

	.global	_user_LonWorkRead
	.sym	_user_LonWorkRead,_user_LonWorkRead,32,2,0
	.func	981
;******************************************************************************
;* FUNCTION NAME: _user_LonWorkRead                                           *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,r3,r4,ar0,ar1,fp,ar4,ir0,ir1,sp,st,rs,re,  *
;*                        rc                                                  *
;*   Regs Saved         : r4,ar4                                              *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 968 Auto + 2 SOE = 972 words      *
;******************************************************************************
_user_LonWorkRead:
	.bss	_nOldKind$7,1
	.sym	_nOldKind,_nOldKind$7,12,3,32
	.bss	_nRecRxPos$8,1
	.sym	_nRecRxPos,_nRecRxPos$8,4,3,32
	.bss	_btFtpOneRecRxBuf$9,1024
	.sym	_btFtpOneRecRxBuf,_btFtpOneRecRxBuf$9,60,3,32768,,1024
	.sym	_i,1,4,1,32
	.sym	_nTmp,2,4,1,32
	.sym	_pLnWkDp,3,24,1,32,.fake13
	.sym	_pNvsram,4,28,1,32
	.sym	_pLicVerDp,5,24,1,32,.fake46
	.sym	_nKind,6,12,1,32
	.sym	_nRxLen,7,12,1,32
	.sym	_btRxBuf,8,60,1,8192,,256
	.sym	_nTxPos,264,4,1,32
	.sym	_btTxBuf,265,60,1,4096,,128
	.sym	_szBuf,393,50,1,16384,,512
	.sym	_szBuf2,905,50,1,2048,,64
	.line	1
;----------------------------------------------------------------------
; 981 | void user_LonWorkRead()                                                
; 983 | int i;                                                                 
; 984 | int nTmp;                                                              
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      968,sp
        push      r4
        push      ar4
	.line	5
;----------------------------------------------------------------------
; 985 | PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;                                
;----------------------------------------------------------------------
        ldiu      @CL14,r0
        sti       r0,*+fp(3)
	.line	6
;----------------------------------------------------------------------
; 986 | UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;                                 
;----------------------------------------------------------------------
        ldiu      @CL81,r0
        sti       r0,*+fp(4)
	.line	7
;----------------------------------------------------------------------
; 987 | PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó�
;     | ��� ���� ���Ƿ� �������.                                              
; 988 | UCHAR nKind;                                                           
; 989 | static UCHAR nOldKind = 0;                                             
; 990 | UCHAR nRxLen;                                                          
; 991 | static int nRecRxPos = 0;                                              
; 992 | UCHAR btRxBuf[256];                                                    
; 993 | static UCHAR btFtpOneRecRxBuf[1024];                                   
;----------------------------------------------------------------------
        ldiu      @CL2,r0
        sti       r0,*+fp(5)
	.line	14
;----------------------------------------------------------------------
; 994 | int nTxPos = 0;                                                        
; 995 | UCHAR btTxBuf[128];                                                    
; 996 | char szBuf[512];                                                       
; 997 | char szBuf2[64];                                                       
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	19
;----------------------------------------------------------------------
; 999 | nKind = WORD_L(pLnWkDp->btKind);                                       
; 1001 | switch(nKind)                                                          
; 1003 | // FTP1~6 ��������                                                     
; 1004 | case 1: case 2: case 3: case 4: case 5: case 6:                        
;----------------------------------------------------------------------
        ldiu      *+fp(3),ar0
        bud       L540
        ldiu      255,r0
        and3      r0,*ar0,r0
        sti       r0,*+fp(6)
;*      Branch Occurs to L540 
L408:        
	.line	25
;----------------------------------------------------------------------
; 1005 | nRxLen = 0;                                                            
; 1007 | // ����                                                                
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(7)
	.line	28
;----------------------------------------------------------------------
; 1008 | if(nKind == 1)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(6),r0
        cmpi      1,r0
        bne       L420
;*      Branch Occurs to L420 
	.line	30
;----------------------------------------------------------------------
; 1010 | nRecRxPos = 0;                                                         
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_nRecRxPos$8+0
	.line	31
;----------------------------------------------------------------------
; 1011 | nRxLen = user_LonWorkRx(nKind,btRxBuf);                                
;----------------------------------------------------------------------
        ldiu      *+fp(6),r1
        ldiu      fp,r0
        addi      8,r0
        push      r0
        push      r1
        call      _user_LonWorkRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(7)
	.line	32
;----------------------------------------------------------------------
; 1012 | if(nRxLen>6 && nRecRxPos<768)                                          
;----------------------------------------------------------------------
        cmpi      6,r0
        bls       L445
;*      Branch Occurs to L445 
        ldiu      @_nRecRxPos$8+0,r0
        cmpi      768,r0
        bge       L445
;*      Branch Occurs to L445 
	.line	34
;----------------------------------------------------------------------
; 1014 | memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);             
;----------------------------------------------------------------------
        ldiu      @CL85,r0
        ldiu      7,r1
        ldiu      fp,r2
        addi      @_nRecRxPos$8+0,r0    ; Unsigned
        subri     *+fp(7),r1            ; Unsigned
        addi      13,r2
        push      r1
        push      r2
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	35
;----------------------------------------------------------------------
; 1015 | nTmp = (nRxLen-7);                                                     
;----------------------------------------------------------------------
        ldiu      7,r0
        subri     *+fp(7),r0            ; Unsigned
        sti       r0,*+fp(2)
	.line	36
;----------------------------------------------------------------------
; 1016 | nRecRxPos += nTmp;                                                     
;----------------------------------------------------------------------
        addi      @_nRecRxPos$8+0,r0
        sti       r0,@_nRecRxPos$8+0
	.line	38
;----------------------------------------------------------------------
; 1018 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        ldiu      393,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	39
;----------------------------------------------------------------------
; 1019 | sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szB
;     | uf,szBuf2);                                                            
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      @CL86,r1
        ldiu      905,r2
        ldiu      *ar0,r0
        push      r0
        ldiu      *+fp(7),r0
        push      r0
        ldiu      *+fp(6),r0
        push      r0
        push      r1
        addi      fp,r2
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      5,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	40
;----------------------------------------------------------------------
; 1020 | if(nTmp < 128)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        cmpi      128,r0
        bge       L415
;*      Branch Occurs to L415 
	.line	42
;----------------------------------------------------------------------
; 1022 | for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,
;     | szBuf2);}                                                              
; 1024 | else                                                                   
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        bge       L419
;*      Branch Occurs to L419 
L413:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r1
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL87,r0
        ldiu      *+ar0(ir0),r2
        addi      fp,r1
        push      r2
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        blt       L413
;*      Branch Occurs to L413 
        bu        L419
;*      Branch Occurs to L419 
L415:        
	.line	46
;----------------------------------------------------------------------
; 1026 | for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szB
;     | uf2);}                                                                 
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        bge       L417
;*      Branch Occurs to L417 
L416:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r2
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL87,r0
        ldiu      *+ar0(ir0),r1
        addi      fp,r2
        push      r1
        push      r0
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        blt       L416
;*      Branch Occurs to L416 
L417:        
	.line	47
;----------------------------------------------------------------------
; 1027 | strcat(szBuf,"..");                                                    
;----------------------------------------------------------------------
        ldiu      @CL88,r1
        ldiu      393,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	48
;----------------------------------------------------------------------
; 1028 | for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf
;     | ,szBuf2);}                                                             
;----------------------------------------------------------------------
        ldiu      120,r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        bge       L419
;*      Branch Occurs to L419 
L418:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r0
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL87,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        blt       L418
;*      Branch Occurs to L418 
L419:        
	.line	50
;----------------------------------------------------------------------
; 1030 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL28,r0
        ldiu      393,r1
        push      r0
        addi      fp,r1
        push      r1
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	51
;----------------------------------------------------------------------
; 1031 | user_DebugPrint(szBuf);                                                
; 1034 | else                                                                   
; 1035 | // �߰� ���ڵ� ����                                                    
;----------------------------------------------------------------------
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L445
;*      Branch Occurs to L445 
L420:        
	.line	56
;----------------------------------------------------------------------
; 1036 | if(nKind >= 2 && nKind <= 5)                                           
;----------------------------------------------------------------------
        ldiu      *+fp(6),r0
        cmpi      2,r0
        blo       L433
;*      Branch Occurs to L433 
        cmpi      5,r0
        bhi       L433
;*      Branch Occurs to L433 
	.line	58
;----------------------------------------------------------------------
; 1038 | nRxLen = user_LonWorkRx(nKind,btRxBuf);                                
;----------------------------------------------------------------------
        ldiu      fp,r0
        ldiu      *+fp(6),r1
        addi      8,r0
        push      r0
        push      r1
        call      _user_LonWorkRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(7)
	.line	59
;----------------------------------------------------------------------
; 1039 | if(nRxLen>6 && nRecRxPos<768)                                          
;----------------------------------------------------------------------
        cmpi      6,r0
        bls       L445
;*      Branch Occurs to L445 
        ldiu      @_nRecRxPos$8+0,r0
        cmpi      768,r0
        bge       L445
;*      Branch Occurs to L445 
	.line	61
;----------------------------------------------------------------------
; 1041 | memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);             
;----------------------------------------------------------------------
        ldiu      @CL85,r0
        ldiu      7,r1
        ldiu      fp,r2
        addi      @_nRecRxPos$8+0,r0    ; Unsigned
        subri     *+fp(7),r1            ; Unsigned
        addi      13,r2
        push      r1
        push      r2
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	62
;----------------------------------------------------------------------
; 1042 | nTmp = (nRxLen-7);                                                     
;----------------------------------------------------------------------
        ldiu      7,r0
        subri     *+fp(7),r0            ; Unsigned
        sti       r0,*+fp(2)
	.line	63
;----------------------------------------------------------------------
; 1043 | nRecRxPos += nTmp;                                                     
;----------------------------------------------------------------------
        addi      @_nRecRxPos$8+0,r0
        sti       r0,@_nRecRxPos$8+0
	.line	65
;----------------------------------------------------------------------
; 1045 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        ldiu      393,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	66
;----------------------------------------------------------------------
; 1046 | sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szB
;     | uf,szBuf2);                                                            
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      *ar0,r1
        push      r1
        ldiu      *+fp(7),r1
        push      r1
        ldiu      905,r2
        ldiu      *+fp(6),r1
        push      r1
        ldiu      @CL86,r0
        push      r0
        addi      fp,r2
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      5,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	67
;----------------------------------------------------------------------
; 1047 | if(nTmp < 128)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        cmpi      128,r0
        bge       L428
;*      Branch Occurs to L428 
	.line	69
;----------------------------------------------------------------------
; 1049 | for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,
;     | szBuf2);}                                                              
; 1051 | else                                                                   
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        bge       L432
;*      Branch Occurs to L432 
L426:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r0
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL87,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        blt       L426
;*      Branch Occurs to L426 
        bu        L432
;*      Branch Occurs to L432 
L428:        
	.line	73
;----------------------------------------------------------------------
; 1053 | for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szB
;     | uf2);}                                                                 
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        bge       L430
;*      Branch Occurs to L430 
L429:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r1
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL87,r0
        ldiu      *+ar0(ir0),r2
        addi      fp,r1
        push      r2
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        blt       L429
;*      Branch Occurs to L429 
L430:        
	.line	74
;----------------------------------------------------------------------
; 1054 | strcat(szBuf,"..");                                                    
;----------------------------------------------------------------------
        ldiu      @CL88,r1
        ldiu      393,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	75
;----------------------------------------------------------------------
; 1055 | for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf
;     | ,szBuf2);}                                                             
;----------------------------------------------------------------------
        ldiu      120,r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        bge       L432
;*      Branch Occurs to L432 
L431:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r0
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL87,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        blt       L431
;*      Branch Occurs to L431 
L432:        
	.line	77
;----------------------------------------------------------------------
; 1057 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL28,r0
        ldiu      393,r1
        push      r0
        addi      fp,r1
        push      r1
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	78
;----------------------------------------------------------------------
; 1058 | user_DebugPrint(szBuf);                                                
; 1061 | else                                                                   
; 1062 | // ��                                                                  
;----------------------------------------------------------------------
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L445
;*      Branch Occurs to L445 
L433:        
	.line	83
;----------------------------------------------------------------------
; 1063 | if(nKind == 6)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(6),r0
        cmpi      6,r0
        bne       L445
;*      Branch Occurs to L445 
	.line	85
;----------------------------------------------------------------------
; 1065 | nRxLen = user_LonWorkRx(nKind,btRxBuf);                                
;----------------------------------------------------------------------
        ldiu      fp,r0
        ldiu      *+fp(6),r1
        addi      8,r0
        push      r0
        push      r1
        call      _user_LonWorkRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(7)
	.line	86
;----------------------------------------------------------------------
; 1066 | if(nRxLen>6 && nRecRxPos<768)                                          
;----------------------------------------------------------------------
        cmpi      6,r0
        bls       L445
;*      Branch Occurs to L445 
        ldiu      @_nRecRxPos$8+0,r0
        cmpi      768,r0
        bge       L445
;*      Branch Occurs to L445 
	.line	88
;----------------------------------------------------------------------
; 1068 | memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);             
;----------------------------------------------------------------------
        ldiu      @CL85,r0
        ldiu      7,r1
        ldiu      fp,r2
        addi      @_nRecRxPos$8+0,r0    ; Unsigned
        subri     *+fp(7),r1            ; Unsigned
        addi      13,r2
        push      r1
        push      r2
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	89
;----------------------------------------------------------------------
; 1069 | nTmp = (nRxLen-7);                                                     
;----------------------------------------------------------------------
        ldiu      7,r0
        subri     *+fp(7),r0            ; Unsigned
        sti       r0,*+fp(2)
	.line	90
;----------------------------------------------------------------------
; 1070 | nRecRxPos += nTmp;                                                     
;----------------------------------------------------------------------
        addi      @_nRecRxPos$8+0,r0
        sti       r0,@_nRecRxPos$8+0
	.line	92
;----------------------------------------------------------------------
; 1072 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        ldiu      393,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	93
;----------------------------------------------------------------------
; 1073 | sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szB
;     | uf,szBuf2);                                                            
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      *ar0,r1
        push      r1
        ldiu      *+fp(7),r1
        push      r1
        ldiu      905,r2
        ldiu      *+fp(6),r1
        push      r1
        ldiu      @CL86,r0
        push      r0
        addi      fp,r2
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      5,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	94
;----------------------------------------------------------------------
; 1074 | if(nTmp < 128)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        cmpi      128,r0
        bge       L440
;*      Branch Occurs to L440 
	.line	96
;----------------------------------------------------------------------
; 1076 | for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,
;     | szBuf2);}                                                              
; 1078 | else                                                                   
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        bge       L444
;*      Branch Occurs to L444 
L438:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r1
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL87,r0
        ldiu      *+ar0(ir0),r2
        addi      fp,r1
        push      r2
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        blt       L438
;*      Branch Occurs to L438 
        bu        L444
;*      Branch Occurs to L444 
L440:        
	.line	100
;----------------------------------------------------------------------
; 1080 | for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szB
;     | uf2);}                                                                 
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        bge       L442
;*      Branch Occurs to L442 
L441:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r1
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL87,r0
        ldiu      *+ar0(ir0),r2
        addi      fp,r1
        push      r2
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        blt       L441
;*      Branch Occurs to L441 
L442:        
	.line	101
;----------------------------------------------------------------------
; 1081 | strcat(szBuf,"..");                                                    
;----------------------------------------------------------------------
        ldiu      @CL88,r1
        ldiu      393,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	102
;----------------------------------------------------------------------
; 1082 | for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf
;     | ,szBuf2);}                                                             
;----------------------------------------------------------------------
        ldiu      120,r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        bge       L444
;*      Branch Occurs to L444 
L443:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r0
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL87,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        blt       L443
;*      Branch Occurs to L443 
L444:        
	.line	104
;----------------------------------------------------------------------
; 1084 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL28,r0
        ldiu      393,r1
        push      r0
        addi      fp,r1
        push      r1
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	105
;----------------------------------------------------------------------
; 1085 | user_DebugPrint(szBuf);                                                
; 1089 | // ���̰� 0~127���� �´ٸ� �����͸� �����Ѵ�.                          
;----------------------------------------------------------------------
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
L445:        
	.line	110
;----------------------------------------------------------------------
; 1090 | if((nRxLen>6 && nRxLen<134))                                           
;----------------------------------------------------------------------
        ldiu      *+fp(7),r0
        cmpi      6,r0
        bls       L451
;*      Branch Occurs to L451 
        cmpi      134,r0
        bhs       L451
;*      Branch Occurs to L451 
	.line	112
;----------------------------------------------------------------------
; 1092 | if(NVSRAM_WAYSIDEONBUF_SIZE > m_nNvsramPos)                            
;----------------------------------------------------------------------
        ldiu      @CL89,r0
        cmpi      @_m_nNvsramPos+0,r0
        bls       L449
;*      Branch Occurs to L449 
	.line	114
;----------------------------------------------------------------------
; 1094 | user_DebugPrint("***FTP File receive... ^^;;***\r\n");                 
;----------------------------------------------------------------------
        ldiu      @CL90,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	115
;----------------------------------------------------------------------
; 1095 | memcpy(&pNvsram[m_nNvsramPos],btFtpOneRecRxBuf,nRecRxPos);             
;----------------------------------------------------------------------
        ldiu      @_m_nNvsramPos+0,r0
        ldiu      @_nRecRxPos$8+0,r2
        ldiu      @CL85,r1
        addi      *+fp(4),r0            ; Unsigned
        push      r2
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	116
;----------------------------------------------------------------------
; 1096 | m_nNvsramPos += nRecRxPos;                                             
; 1098 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @_nRecRxPos$8+0,r0
        addi      @_m_nNvsramPos+0,r0   ; Unsigned
        sti       r0,@_m_nNvsramPos+0
        bu        L450
;*      Branch Occurs to L450 
L449:        
	.line	120
;----------------------------------------------------------------------
; 1100 | MyPrintf("***FTP data buffer full..\r\n");                             
;----------------------------------------------------------------------
        ldiu      @CL91,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
L450:        
	.line	123
;----------------------------------------------------------------------
; 1103 | m_bLnWkFtpEndFlag = TRUE;                                              
; 1105 | else                                                                   
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_bLnWkFtpEndFlag+0
        bu        L455
;*      Branch Occurs to L455 
L451:        
	.line	126
;----------------------------------------------------------------------
; 1106 | if(nKind == 6)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(6),r0
        cmpi      6,r0
        bne       L455
;*      Branch Occurs to L455 
	.line	128
;----------------------------------------------------------------------
; 1108 | if(NVSRAM_WAYSIDEONBUF_SIZE > m_nNvsramPos)                            
;----------------------------------------------------------------------
        ldiu      @CL89,r0
        cmpi      @_m_nNvsramPos+0,r0
        bls       L454
;*      Branch Occurs to L454 
	.line	130
;----------------------------------------------------------------------
; 1110 | user_DebugPrint("***FTP File receive End ^..^ ***\r\n");               
;----------------------------------------------------------------------
        ldiu      @CL92,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	131
;----------------------------------------------------------------------
; 1111 | memcpy(&pNvsram[m_nNvsramPos],btFtpOneRecRxBuf,nRecRxPos);             
;----------------------------------------------------------------------
        ldiu      @_m_nNvsramPos+0,r0
        ldiu      @_nRecRxPos$8+0,r2
        ldiu      @CL85,r1
        addi      *+fp(4),r0            ; Unsigned
        push      r2
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	132
;----------------------------------------------------------------------
; 1112 | m_nNvsramPos += nRecRxPos;                                             
; 1114 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @_nRecRxPos$8+0,r0
        addi      @_m_nNvsramPos+0,r0   ; Unsigned
        sti       r0,@_m_nNvsramPos+0
        bu        L455
;*      Branch Occurs to L455 
L454:        
	.line	136
;----------------------------------------------------------------------
; 1116 | MyPrintf("***FTP data buffer full..\r\n");                             
;----------------------------------------------------------------------
        ldiu      @CL91,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
L455:        
	.line	140
;----------------------------------------------------------------------
; 1120 | nOldKind = nKind;                                                      
;----------------------------------------------------------------------
        ldiu      *+fp(6),r0
        sti       r0,@_nOldKind$7+0
	.line	142
;----------------------------------------------------------------------
; 1122 | break;                                                                 
; 1124 | // �Ϲ� ��������(����)                                                 
; 1125 | case 7:                                                                
;----------------------------------------------------------------------
        bu        L547
;*      Branch Occurs to L547 
	.line	146
;----------------------------------------------------------------------
; 1126 | nRxLen = user_LonWorkRx(7,btRxBuf);                                    
;----------------------------------------------------------------------
L457:        
        addi      8,r0
        push      r0
        push      r1
        call      _user_LonWorkRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(7)
	.line	148
;----------------------------------------------------------------------
; 1128 | if(m_nDbgTxPos == 0xFFFFFFFF)                                          
;----------------------------------------------------------------------
        ldiu      @_m_nDbgTxPos+0,r0
        cmpi      @CL84,r0
        bned      L461
	nop
        ldieq     393,ir0
        ldieq     0,r0
;*      Branch Occurs to L461 
	.line	150
;----------------------------------------------------------------------
; 1130 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        sti       r0,*+fp(ir0)
	.line	151
;----------------------------------------------------------------------
; 1131 | sprintf(szBuf2,"[RX:%02d] ",nRxLen); strcat(szBuf,szBuf2);             
;----------------------------------------------------------------------
        ldiu      905,r2
        ldiu      @CL93,r1
        addi      fp,r2
        ldiu      *+fp(7),r0
        push      r0
        push      r1
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	152
;----------------------------------------------------------------------
; 1132 | for(i=0;i<nRxLen;i++) {sprintf(szBuf2,"%02X ",btRxBuf[i]); strcat(szBuf
;     | ,szBuf2);}                                                             
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(7),r0
        bhs       L460
;*      Branch Occurs to L460 
L459:        
        ldiu      fp,ar0
        ldiu      *+fp(1),ir0
        ldiu      905,r0
        addi      8,ar0
        ldiu      @CL83,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(7),r0
        blo       L459
;*      Branch Occurs to L459 
L460:        
	.line	153
;----------------------------------------------------------------------
; 1133 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL28,r1
        ldiu      393,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	154
;----------------------------------------------------------------------
; 1134 | user_DebugPrint(szBuf);                                                
;----------------------------------------------------------------------
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
L461:        
	.line	157
;----------------------------------------------------------------------
; 1137 | if(nRxLen)                                                             
;----------------------------------------------------------------------
        ldi       *+fp(7),r0
        beqd      L547
	nop
        ldine     264,ir0
        ldine     0,r0
;*      Branch Occurs to L547 
	.line	159
;----------------------------------------------------------------------
; 1139 | nTxPos = 0;                                                            
; 1141 | switch(btRxBuf[1])                                                     
; 1143 | // WAYSIDE ON ACK ����                                                 
; 1144 | case 0x02:                                                             
;----------------------------------------------------------------------
        bud       L522
        sti       r0,*+fp(ir0)
        ldiu      fp,ar0
        addi      9,ar0
;*      Branch Occurs to L522 
L463:        
	.line	165
;----------------------------------------------------------------------
; 1145 | m_nLnWkWaySideOnRxOk = 1;                                              
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_nLnWkWaySideOnRxOk+0
	.line	166
;----------------------------------------------------------------------
; 1146 | break;                                                                 
; 1148 | // FTP���� ��                                                          
; 1149 | case 0x06:                                                             
;----------------------------------------------------------------------
        bu        L534
;*      Branch Occurs to L534 
L464:        
	.line	170
;----------------------------------------------------------------------
; 1150 | if(m_nLnWkWaySideOnRxOk)                                               
;----------------------------------------------------------------------
        ldi       @_m_nLnWkWaySideOnRxOk+0,r0
        beq       L534
;*      Branch Occurs to L534 
	.line	172
;----------------------------------------------------------------------
; 1152 | m_nLnWkWaySideOnRxOk--;                                                
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     @_m_nLnWkWaySideOnRxOk+0,r0 ; Unsigned
        sti       r0,@_m_nLnWkWaySideOnRxOk+0
	.line	173
;----------------------------------------------------------------------
; 1153 | m_bLnWkFtpEndFlag = TRUE;                                              
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_bLnWkFtpEndFlag+0
	.line	175
;----------------------------------------------------------------------
; 1155 | break;                                                                 
; 1157 | // �ð���û, MPU�� DPRAM�� �����͸� ���� ���� ���ͷ�Ʈ�� ��������������
;     |  LIC_LON���� �������� ����                                             
; 1158 | case 0x08:                                                             
;----------------------------------------------------------------------
        bu        L534
;*      Branch Occurs to L534 
	.line	179
;----------------------------------------------------------------------
; 1159 | nTxPos = 0;                                                            
; 1160 | //if(m_LIC_CNCS_TimSetFlag && m_nCncsRxCheck1msTimer)                  
;----------------------------------------------------------------------
L467:        
        sti       r0,*+fp(ir0)
	.line	182
;----------------------------------------------------------------------
; 1162 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      1,r2
        ldiu      265,ar0
        ldiu      2,r1
        ldiu      *+fp(ir1),r0
        addi      r0,r2
        addi3     r0,fp,ir1             ; Unsigned
        sti       r2,*+fp(ir0)
        sti       r1,*+ar0(ir1)
	.line	183
;----------------------------------------------------------------------
; 1163 | btTxBuf[nTxPos++] = 0x09; // Command Code                              
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      1,r2
        ldiu      *+fp(ir1),r0
        ldiu      9,r1
        addi      r0,r2
        addi3     r0,fp,ir1             ; Unsigned
        sti       r2,*+fp(ir0)
        sti       r1,*+ar0(ir1)
	.line	184
;----------------------------------------------------------------------
; 1164 | btTxBuf[nTxPos++] = 0x00; // 0x00���� ����                             
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      *+fp(ir1),r0
        ldiu      1,r2
        addi      r0,r2
        ldiu      0,r1
        addi3     r0,fp,ir1             ; Unsigned
        sti       r2,*+fp(ir0)
        sti       r1,*+ar0(ir1)
	.line	185
;----------------------------------------------------------------------
; 1165 | btTxBuf[nTxPos++] = 0x06; // ����                                      
; 1167 | // Y.J ����                                                            
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      *+fp(ir1),r0
        addi3     r0,fp,ir1             ; Unsigned
        ldiu      1,r2
        addi      r0,r2
        sti       r2,*+fp(ir0)
        ldiu      6,r1
        sti       r1,*+ar0(ir1)
	.line	188
;----------------------------------------------------------------------
; 1168 | btTxBuf[nTxPos++] = m_tmUtcTime.year;
;     |                          // �� BCD                                     
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      *+fp(ir1),r0
        ldiu      1,r1
        addi3     r0,fp,ir1             ; Unsigned
        addi      r0,r1
        sti       r1,*+fp(ir0)
        ldiu      @_m_tmUtcTime+5,r0
        sti       r0,*+ar0(ir1)
	.line	189
;----------------------------------------------------------------------
; 1169 | btTxBuf[nTxPos++] = m_tmUtcTime.month;
;     |                          // ��                                         
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      *+fp(ir0),r0
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      1,r1
        addi      r0,r1
        sti       r1,*+fp(ir1)
        ldiu      @_m_tmUtcTime+4,r0
        sti       r0,*+ar0(ir0)
	.line	190
;----------------------------------------------------------------------
; 1170 | btTxBuf[nTxPos++] = m_tmUtcTime.day;
;     |                          // ��                                         
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r1
        ldiu      *+fp(ir0),r0
        addi      r0,r1
        sti       r1,*+fp(ir1)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      @_m_tmUtcTime+3,r0
        sti       r0,*+ar0(ir0)
	.line	191
;----------------------------------------------------------------------
; 1171 | btTxBuf[nTxPos++] = m_tmUtcTime.hour;
;     |                          // ��                                         
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r1
        ldiu      *+fp(ir0),r0
        addi      r0,r1
        sti       r1,*+fp(ir1)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      @_m_tmUtcTime+2,r0
        sti       r0,*+ar0(ir0)
	.line	192
;----------------------------------------------------------------------
; 1172 | btTxBuf[nTxPos++] = m_tmUtcTime.minute;
;     |                          // ��                                         
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r1
        ldiu      *+fp(ir1),r0
        addi      r0,r1
        sti       r1,*+fp(ir0)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      @_m_tmUtcTime+1,r0
        sti       r0,*+ar0(ir0)
	.line	193
;----------------------------------------------------------------------
; 1173 | btTxBuf[nTxPos++] = m_tmUtcTime.second;
;     |                          // ��                                         
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        ldiu      1,r1
        addi      r0,r1
        sti       r1,*+fp(ir1)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      @_m_tmUtcTime+0,r0
        sti       r0,*+ar0(ir0)
	.line	195
;----------------------------------------------------------------------
; 1175 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r0
        ldiu      266,r1
        addi      fp,r1
        subi3     r0,*+fp(ir0),r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r2
        ldiu      264,ir0
        ldiu      264,ir1
        ldiu      *+fp(ir0),r1
        addi3     r1,fp,ir0             ; Unsigned
        ldiu      265,ar0
        addi      r1,r2
        sti       r2,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	196
;----------------------------------------------------------------------
; 1176 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        addi      r0,r2
        ldiu      3,r1
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	197
;----------------------------------------------------------------------
; 1177 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        push      r0
        ldiu      265,r0
        addi      fp,r0
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	199
;----------------------------------------------------------------------
; 1179 | break;                                                                 
; 1181 | // ���µ����� ��û, MPU�� DPRAM�� �����͸� ���� ���� ���ͷ�Ʈ�� �������
;     | ������� LIC_LON���� �������� ����                                      
; 1182 | case 0x0A:                                                             
;----------------------------------------------------------------------
        bu        L534
;*      Branch Occurs to L534 
L468:        
	.line	203
;----------------------------------------------------------------------
; 1183 | m_nCarCnt = btRxBuf[4];                                                
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldi       *ar0,r0
        sti       r0,@_m_nCarCnt+0
	.line	204
;----------------------------------------------------------------------
; 1184 | if(m_nCarCnt < 1 && m_nCarCnt > 2) m_nCarCnt = 1;                      
;----------------------------------------------------------------------
        bne       L471
;*      Branch Occurs to L471 
        cmpi      2,r0
        bls       L471
;*      Branch Occurs to L471 
        ldiu      1,r0
        sti       r0,@_m_nCarCnt+0
L471:        
	.line	205
;----------------------------------------------------------------------
; 1185 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	206
;----------------------------------------------------------------------
; 1186 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      1,r2
        ldiu      264,ir1
        ldiu      265,ar0
        ldiu      2,r1
        ldiu      *+fp(ir0),r0
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	207
;----------------------------------------------------------------------
; 1187 | btTxBuf[nTxPos++] = 0x0B; // Command Code                              
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r1
        ldiu      *+fp(ir0),r2
        ldiu      11,r0
        addi      r2,r1
        addi3     r2,fp,ir0             ; Unsigned
        sti       r1,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	208
;----------------------------------------------------------------------
; 1188 | btTxBuf[nTxPos++] = 0x00; // 0x00���� ����                             
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        ldiu      1,r1
        addi3     r0,fp,ir0             ; Unsigned
        addi      r0,r1
        ldiu      0,r2
        sti       r1,*+fp(ir1)
        sti       r2,*+ar0(ir0)
	.line	209
;----------------------------------------------------------------------
; 1189 | btTxBuf[nTxPos++] = 0x05; // ����                                      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r2
        ldiu      1,r1
        addi3     r2,fp,ir0             ; Unsigned
        addi      r2,r1
        ldiu      5,r0
        sti       r1,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	210
;----------------------------------------------------------------------
; 1190 | btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[0]); // ���� ������     
;----------------------------------------------------------------------
        ldiu      @_m_btSenseCommStBuf+0,r0
        push      r0
        call      _BitSwap
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        ldiu      1,r1
        ldiu      *+fp(ir0),r2
        addi      r2,r1
        addi3     r2,fp,ir0             ; Unsigned
        ldiu      264,ir1
        ldiu      265,ar0
        sti       r1,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	211
;----------------------------------------------------------------------
; 1191 | btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[1]); // ���� ������     
;----------------------------------------------------------------------
        ldiu      @_m_btSenseCommStBuf+1,r0
        push      r0
        call      _BitSwap
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      264,ir1
        ldiu      *+fp(ir0),r1
        ldiu      265,ar0
        addi3     r1,fp,ir0             ; Unsigned
        ldiu      1,r2
        addi      r1,r2
        sti       r2,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	212
;----------------------------------------------------------------------
; 1192 | btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[2]); // ���� ������     
;----------------------------------------------------------------------
        ldiu      @_m_btSenseCommStBuf+2,r0
        push      r0
        call      _BitSwap
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      *+fp(ir0),r1
        addi3     r1,fp,ir0             ; Unsigned
        ldiu      264,ir1
        ldiu      265,ar0
        addi      1,r1
        sti       r1,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	213
;----------------------------------------------------------------------
; 1193 | btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[3]); // ���� ������     
;----------------------------------------------------------------------
        ldiu      @_m_btSenseCommStBuf+3,r0
        push      r0
        call      _BitSwap
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      *+fp(ir0),r1
        ldiu      1,r2
        ldiu      265,ar0
        addi      r1,r2
        ldiu      264,ir1
        addi3     r1,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	214
;----------------------------------------------------------------------
; 1194 | btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[4]); // ���� ������     
;----------------------------------------------------------------------
        ldiu      @_m_btSenseCommStBuf+4,r0
        push      r0
        call      _BitSwap
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        ldiu      *+fp(ir0),r1
        ldiu      264,ir1
        ldiu      265,ar0
        addi3     r1,fp,ir0             ; Unsigned
        ldiu      1,r2
        addi      r1,r2
        sti       r2,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	215
;----------------------------------------------------------------------
; 1195 | btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[5]); // ���� ������     
;----------------------------------------------------------------------
        ldiu      @_m_btSenseCommStBuf+5,r0
        push      r0
        call      _BitSwap
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir1
        ldiu      *+fp(ir1),r2
        ldiu      264,ir0
        ldiu      265,ar0
        ldiu      1,r1
        addi      r2,r1
        sti       r1,*+fp(ir0)
        addi3     r2,fp,ir0             ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	216
;----------------------------------------------------------------------
; 1196 | btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[6]); // ���� ������     
;----------------------------------------------------------------------
        ldiu      @_m_btSenseCommStBuf+6,r0
        push      r0
        call      _BitSwap
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      *+fp(ir0),r1
        ldiu      265,ar0
        ldiu      264,ir1
        ldiu      1,r2
        addi3     r1,fp,ir0             ; Unsigned
        addi      r1,r2
        sti       r2,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	217
;----------------------------------------------------------------------
; 1197 | btTxBuf[nTxPos++] = BitSwap(m_btSenseCommStBuf[7]); // ���� ������     
;----------------------------------------------------------------------
        ldiu      @_m_btSenseCommStBuf+7,r0
        push      r0
        call      _BitSwap
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      1,r1
        ldiu      *+fp(ir0),r2
        ldiu      264,ir1
        addi      r2,r1
        ldiu      265,ar0
        addi3     r2,fp,ir0             ; Unsigned
        sti       r1,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	218
;----------------------------------------------------------------------
; 1198 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      266,r1
        ldiu      264,ir0
        addi      fp,r1
        ldiu      1,r0
        subi3     r0,*+fp(ir0),r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      2,sp
        ldiu      1,r2
        ldiu      *+fp(ir0),r1
        ldiu      264,ir1
        addi      r1,r2
        sti       r2,*+fp(ir1)
        addi3     r1,fp,ir0             ; Unsigned
        ldiu      265,ar0
        sti       r0,*+ar0(ir0)
	.line	219
;----------------------------------------------------------------------
; 1199 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        ldiu      3,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	220
;----------------------------------------------------------------------
; 1200 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        push      r0
        ldiu      265,r0
        addi      fp,r0
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	222
;----------------------------------------------------------------------
; 1202 | memcpy(m_btSenseCommStBuf,m_btCommSt,8);                               
;----------------------------------------------------------------------
        ldiu      @CL3,ar0
        ldiu      @CL5,ar1
        ldiu      *ar0++(1),r0
        rpts      6                     ; Fast MEMCPY(#9)
        sti       r0,*ar1++(1)
||      ldi       *ar0++(1),r0
        sti       r0,*ar1++(1)
	.line	223
;----------------------------------------------------------------------
; 1203 | break;                                                                 
; 1205 | //������û                                                             
; 1206 | case 0x0C:                                                             
;----------------------------------------------------------------------
        bu        L534
;*      Branch Occurs to L534 
	.line	227
;----------------------------------------------------------------------
; 1207 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
L473:        
        sti       r0,*+fp(ir0)
	.line	228
;----------------------------------------------------------------------
; 1208 | memset(btTxBuf,0x00,sizeof(btTxBuf));                                  
;----------------------------------------------------------------------
        ldiu      128,r1
        ldiu      265,r2
        push      r1
        addi      fp,r2
        push      r0
        push      r2
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	230
;----------------------------------------------------------------------
; 1210 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      264,ir1
        ldiu      265,ar0
        ldiu      1,r0
        ldiu      *+fp(ir0),r1
        ldiu      2,r2
        addi      r1,r0
        addi3     r1,fp,ir0             ; Unsigned
        sti       r0,*+fp(ir1)
        sti       r2,*+ar0(ir0)
	.line	231
;----------------------------------------------------------------------
; 1211 | btTxBuf[nTxPos++] = 0x0D; // Command Code                              
; 1213 | // 2 : Firmware                                                        
; 1214 | // 0 : Not used�� ����ϰ� ������ ��¥�� ��������ʴ´�.               
; 1215 | // 6 : ��������(LIC -> CDT) ����                                       
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r0
        ldiu      *+fp(ir0),r2
        addi      r2,r0
        addi3     r2,fp,ir0             ; Unsigned
        ldiu      13,r1
        sti       r0,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	237
;----------------------------------------------------------------------
; 1217 | nTmp = MAX(1,WORD_L(btRxBuf[4]));                                      
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      255,r1
        and3      r1,*ar0,r1
        ldiu      1,r0
        cmpi3     r1,r0
        bls       L475
;*      Branch Occurs to L475 
        bu        L476
;*      Branch Occurs to L476 
L475:        
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
L476:        
        sti       r0,*+fp(2)
	.line	238
;----------------------------------------------------------------------
; 1218 | nTmp = MIN((VER_BDD_MAX_CNT)+1,WORD_L(btRxBuf[4]));                    
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      255,r1
        addi      12,ar0
        ldiu      33,r0
        and3      r1,*ar0,r1
        cmpi3     r1,r0
        bhs       L478
;*      Branch Occurs to L478 
        bu        L479
;*      Branch Occurs to L479 
L478:        
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
L479:        
        sti       r0,*+fp(2)
	.line	239
;----------------------------------------------------------------------
; 1219 | nTmp--;                                                                
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     *+fp(2),r0
        sti       r0,*+fp(2)
	.line	240
;----------------------------------------------------------------------
; 1220 | btTxBuf[nTxPos++] = LIC_VerList[nTmp][0] == NULL ? 6 : 2; // 2:����&���
;     | �Ʈ, 6:����                                                            
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r1
        ldiu      264,ir1
        ldiu      265,ar0
        ldiu      @CL26,ar1
        ldiu      *+fp(ir0),r0
        ldiu      *+fp(2),ir0
        addi      r0,r1
        mpyi      9,ir0
        sti       r1,*+fp(ir1)
        addi3     r0,fp,ir1             ; Unsigned
        ldi       *+ar1(ir0),r0
        bne       L481
;*      Branch Occurs to L481 
        bud       L482
	nop
	nop
        ldiu      6,r0
;*      Branch Occurs to L482 
L481:        
        ldiu      2,r0
L482:        
        sti       r0,*+ar0(ir1)
	.line	242
;----------------------------------------------------------------------
; 1222 | btTxBuf[nTxPos++] = 31; // �����ͱ���                                  
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      264,ir1
        ldiu      264,ir0
        ldiu      265,ar0
        ldiu      *+fp(ir1),r2
        ldiu      31,r0
        addi      r2,r1
        addi3     r2,fp,ir1             ; Unsigned
        sti       r1,*+fp(ir0)
        sti       r0,*+ar0(ir1)
	.line	244
;----------------------------------------------------------------------
; 1224 | btTxBuf[nTxPos++] = btRxBuf[4]; // Index ��ȣ                          
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      265,ar1
        ldiu      1,r1
        ldiu      264,ir1
        ldiu      *+fp(ir0),r0
        addi      12,ar0
        addi      r0,r1
        addi3     r0,fp,ir0             ; Unsigned
        sti       r1,*+fp(ir1)
        ldiu      *ar0,r0
        sti       r0,*+ar1(ir0)
	.line	245
;----------------------------------------------------------------------
; 1225 | btTxBuf[nTxPos++] = LIC_VerList[nTmp][0] == NULL ? 6 : 4; // Type      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r0
        ldiu      *+fp(ir0),r1
        addi      r1,r0
        ldiu      *+fp(2),ir0
        sti       r0,*+fp(ir1)
        mpyi      9,ir0
        ldiu      @CL26,ar1
        ldiu      265,ar0
        ldi       *+ar1(ir0),r0
        bned      L484
        addi3     r1,fp,ir0             ; Unsigned
	nop
        ldine     4,r0
;*      Branch Occurs to L484 
        ldiu      6,r0
L484:        
        sti       r0,*+ar0(ir0)
	.line	247
;----------------------------------------------------------------------
; 1227 | memcpy(&btTxBuf[nTxPos],&LIC_VerList[nTmp][0],strlen((char*)&LIC_VerLis
;     | t[nTmp][0]));                                                          
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        mpyi      9,r0
        addi      @CL26,r0              ; Unsigned
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      *+fp(2),r2
        addi3     fp,*+fp(ir0),r1       ; Unsigned
        push      r0
        mpyi      9,r2
        addi      265,r1                ; Unsigned
        ldiu      @CL26,r0
        addi      r2,r0
        push      r0
        push      r1
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	248
;----------------------------------------------------------------------
; 1228 | nTxPos = nTxPos+9;                                                     
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      9,r0
        ldiu      264,ir0
        addi3     r0,*+fp(ir1),r0
        sti       r0,*+fp(ir0)
	.line	250
;----------------------------------------------------------------------
; 1230 | btTxBuf[nTxPos+0] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]>>12)&0x
;     | 0F); // Production Version                                             
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL6,ar0
        and       *+fp(2),ir0
        ldiu      -12,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      265,ar0
        sti       r0,*+ar0(ir0)
	.line	251
;----------------------------------------------------------------------
; 1231 | btTxBuf[nTxPos+1] = '.'; // Production Version                         
;----------------------------------------------------------------------
        ldiu      264,ir0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      266,ar0
        ldiu      46,r0
        sti       r0,*+ar0(ir0)
	.line	252
;----------------------------------------------------------------------
; 1232 | btTxBuf[nTxPos+2] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]>>8)&0x0
;     | F); // Production Version                                              
;----------------------------------------------------------------------
        ldiu      255,ir0
        and       *+fp(2),ir0
        ldiu      @CL6,ar0
        ldiu      -8,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      267,ar0
        sti       r0,*+ar0(ir0)
	.line	253
;----------------------------------------------------------------------
; 1233 | btTxBuf[nTxPos+3] = '.'; // Production Version                         
;----------------------------------------------------------------------
        ldiu      264,ir0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      268,ar0
        ldiu      46,r0
        sti       r0,*+ar0(ir0)
	.line	254
;----------------------------------------------------------------------
; 1234 | btTxBuf[nTxPos+4] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]>>4)&0x0
;     | F); // Production Version                                              
;----------------------------------------------------------------------
        ldiu      255,ir0
        and       *+fp(2),ir0
        ldiu      @CL6,ar0
        ldiu      -4,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      269,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	255
;----------------------------------------------------------------------
; 1235 | btTxBuf[nTxPos+5] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]&0x0F));
;     |  // Production Version                                                 
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL6,ar0
        and       *+fp(2),ir0
        ldiu      15,r0
        and3      r0,*+ar0(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      270,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	256
;----------------------------------------------------------------------
; 1236 | btTxBuf[nTxPos+6] = '';                                                
;----------------------------------------------------------------------
        ldiu      264,ir0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      271,ar0
        ldiu      0,r0
        sti       r0,*+ar0(ir0)
	.line	257
;----------------------------------------------------------------------
; 1237 | nTxPos = nTxPos+9;                                                     
;----------------------------------------------------------------------
        ldiu      9,r0
        ldiu      264,ir1
        ldiu      264,ir0
        addi3     r0,*+fp(ir1),r0
        sti       r0,*+fp(ir0)
	.line	259
;----------------------------------------------------------------------
; 1239 | btTxBuf[nTxPos+0] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>28
;     | )&0xF);// '2': // Year                                                 
;----------------------------------------------------------------------
        ldiu      255,ir0
        and       *+fp(2),ir0
        ldiu      @CL7,ar0
        ldiu      -28,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        ldiu      265,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	260
;----------------------------------------------------------------------
; 1240 | btTxBuf[nTxPos+1] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>24
;     | )&0xF);// '0': // Year                                                 
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL7,ar0
        and       *+fp(2),ir0
        ldiu      -24,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        ldiu      266,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	261
;----------------------------------------------------------------------
; 1241 | btTxBuf[nTxPos+2] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>20
;     | )&0xF);// '1': // Year                                                 
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL7,ar0
        and       *+fp(2),ir0
        ldiu      -20,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      267,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	262
;----------------------------------------------------------------------
; 1242 | btTxBuf[nTxPos+3] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>16
;     | )&0xF);// '2': // Year                                                 
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL7,ar0
        and       *+fp(2),ir0
        ldiu      -16,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      268,ar0
        sti       r0,*+ar0(ir0)
	.line	263
;----------------------------------------------------------------------
; 1243 | btTxBuf[nTxPos+4] = '-';                                               
;----------------------------------------------------------------------
        ldiu      264,ir0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      269,ar0
        ldiu      45,r0
        sti       r0,*+ar0(ir0)
	.line	264
;----------------------------------------------------------------------
; 1244 | btTxBuf[nTxPos+5] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>12
;     | )&0xF);// '0': // Month                                                
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL7,ar0
        and       *+fp(2),ir0
        ldiu      -12,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      270,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	265
;----------------------------------------------------------------------
; 1245 | btTxBuf[nTxPos+6] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>8)
;     | &0xF);// '1': // Month                                                 
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL7,ar0
        and       *+fp(2),ir0
        ldiu      -8,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        ldiu      271,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	266
;----------------------------------------------------------------------
; 1246 | btTxBuf[nTxPos+7] = '-';                                               
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      272,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      45,r0
        sti       r0,*+ar0(ir0)
	.line	267
;----------------------------------------------------------------------
; 1247 | btTxBuf[nTxPos+8] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>4)
;     | &0xF);// '0': // Day                                                   
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL7,ar0
        and       *+fp(2),ir0
        ldiu      -4,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      273,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	268
;----------------------------------------------------------------------
; 1248 | btTxBuf[nTxPos+9] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)])&0x
;     | F);// '1' : // Day                                                     
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL7,ar0
        and       *+fp(2),ir0
        ldiu      15,r0
        and3      r0,*+ar0(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      274,ar0
        sti       r0,*+ar0(ir0)
	.line	269
;----------------------------------------------------------------------
; 1249 | btTxBuf[nTxPos+10] = '';                                               
;----------------------------------------------------------------------
        ldiu      264,ir0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      275,ar0
        ldiu      0,r0
        sti       r0,*+ar0(ir0)
	.line	270
;----------------------------------------------------------------------
; 1250 | nTxPos = nTxPos+11;                                                    
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      11,r0
        ldiu      264,ir0
        addi3     r0,*+fp(ir1),r0
        sti       r0,*+fp(ir0)
	.line	272
;----------------------------------------------------------------------
; 1252 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      266,r1
        addi      fp,r1
        subi3     r0,*+fp(ir0),r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      264,ir0
        ldiu      *+fp(ir0),r1
        ldiu      264,ir1
        addi3     r1,fp,ir0             ; Unsigned
        ldiu      265,ar0
        addi      1,r1
        sti       r1,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	273
;----------------------------------------------------------------------
; 1253 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      3,r1
        addi      1,r0
        sti       r0,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	275
;----------------------------------------------------------------------
; 1255 | if(WORD_L(btRxBuf[4]) != 2)                                            
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        cmpi      2,r0
        beq       L534
;*      Branch Occurs to L534 
	.line	277
;----------------------------------------------------------------------
; 1257 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      265,r0
        ldiu      *+fp(ir0),r1
        addi      fp,r0
        push      r1
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	279
;----------------------------------------------------------------------
; 1259 | break;                                                                 
; 1261 | //�������(Single or married A)                                        
; 1262 | case 0x0E:                                                             
;----------------------------------------------------------------------
        bu        L534
;*      Branch Occurs to L534 
L487:        
	.line	283
;----------------------------------------------------------------------
; 1263 | m_btCttSignalA = btRxBuf[4];                                           
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      *ar0,r0
        sti       r0,@_m_btCttSignalA+0
	.line	284
;----------------------------------------------------------------------
; 1264 | break;                                                                 
; 1266 | // �������� ���� ��û                                                  
; 1267 | case 0x10:                                                             
;----------------------------------------------------------------------
        bu        L534
;*      Branch Occurs to L534 
	.line	288
;----------------------------------------------------------------------
; 1268 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
L489:        
        sti       r0,*+fp(ir0)
	.line	289
;----------------------------------------------------------------------
; 1269 | memset(btTxBuf,0x00,sizeof(btTxBuf));                                  
;----------------------------------------------------------------------
        ldiu      128,r2
        ldiu      0,r1
        ldiu      265,r0
        push      r2
        addi      fp,r0
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	291
;----------------------------------------------------------------------
; 1271 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      264,ir1
        ldiu      265,ar0
        ldiu      1,r0
        ldiu      *+fp(ir0),r2
        ldiu      2,r1
        addi      r2,r0
        addi3     r2,fp,ir0             ; Unsigned
        sti       r0,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	292
;----------------------------------------------------------------------
; 1272 | btTxBuf[nTxPos++] = 0x11; // Command Code                              
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r2
        ldiu      1,r0
        addi      r2,r0
        ldiu      17,r1
        addi3     r2,fp,ir0             ; Unsigned
        sti       r0,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	293
;----------------------------------------------------------------------
; 1273 | btTxBuf[nTxPos++] = 0x00; // Message Code                              
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r0
        ldiu      *+fp(ir0),r2
        addi      r2,r0
        ldiu      0,r1
        addi3     r2,fp,ir0             ; Unsigned
        sti       r0,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	294
;----------------------------------------------------------------------
; 1274 | btTxBuf[nTxPos++] = 0x02; // ����                                      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r2
        ldiu      1,r0
        addi3     r2,fp,ir0             ; Unsigned
        addi      r2,r0
        sti       r0,*+fp(ir1)
        ldiu      2,r1
        sti       r1,*+ar0(ir0)
	.line	295
;----------------------------------------------------------------------
; 1275 | btTxBuf[nTxPos++] = WORD_H(m_TrainCofVal); // ������                   
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r0
        ldiu      *+fp(ir1),r1
        addi      r1,r0
        sti       r0,*+fp(ir0)
        ldiu      @_m_TrainCofVal+0,r0
        ash       -8,r0
        addi3     r1,fp,ir0             ; Unsigned
        and       255,r0
        sti       r0,*+ar0(ir0)
	.line	296
;----------------------------------------------------------------------
; 1276 | btTxBuf[nTxPos++] = WORD_L(m_TrainCofVal); // ������                   
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      255,r1
        ldiu      *+fp(ir0),r0
        ldiu      1,r2
        addi      r0,r2
        sti       r2,*+fp(ir1)
        addi3     r0,fp,ir0             ; Unsigned
        and       @_m_TrainCofVal+0,r1
        sti       r1,*+ar0(ir0)
	.line	297
;----------------------------------------------------------------------
; 1277 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      266,r1
        addi      fp,r1
        ldiu      264,ir0
        ldiu      1,r0
        subi3     r0,*+fp(ir0),r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      264,ir0
        ldiu      *+fp(ir0),r1
        ldiu      1,r2
        addi3     r1,fp,ir0             ; Unsigned
        addi      r1,r2
        ldiu      265,ar0
        ldiu      264,ir1
        sti       r2,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	298
;----------------------------------------------------------------------
; 1278 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        addi      r0,r2
        sti       r2,*+fp(ir1)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      3,r1
        sti       r1,*+ar0(ir0)
	.line	299
;----------------------------------------------------------------------
; 1279 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        push      r0
        ldiu      265,r0
        addi      fp,r0
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	300
;----------------------------------------------------------------------
; 1280 | break;                                                                 
; 1282 | // CI ��ġ ��û                                                        
; 1283 | case 0x12:                                                             
;----------------------------------------------------------------------
        bu        L534
;*      Branch Occurs to L534 
	.line	304
;----------------------------------------------------------------------
; 1284 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
L491:        
        sti       r0,*+fp(ir0)
	.line	305
;----------------------------------------------------------------------
; 1285 | memset(btTxBuf,0x00,sizeof(btTxBuf));                                  
;----------------------------------------------------------------------
        ldiu      128,r2
        ldiu      0,r1
        ldiu      265,r0
        push      r2
        addi      fp,r0
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	307
;----------------------------------------------------------------------
; 1287 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      264,ir1
        ldiu      265,ar0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        ldiu      2,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	308
;----------------------------------------------------------------------
; 1288 | btTxBuf[nTxPos++] = 0x13; // Command Code                              
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        ldiu      1,r2
        ldiu      19,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	309
;----------------------------------------------------------------------
; 1289 | btTxBuf[nTxPos++] = 0x00; // Message Code                              
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        ldiu      0,r1
        sti       r1,*+ar0(ir0)
	.line	310
;----------------------------------------------------------------------
; 1290 | btTxBuf[nTxPos++] = 0x01; // ����                                      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      1,r2
        addi      r0,r2
        sti       r2,*+fp(ir1)
        ldiu      1,r1
        sti       r1,*+ar0(ir0)
	.line	311
;----------------------------------------------------------------------
; 1291 | if(m_nCarPos >= 1 && m_nCarPos <= 8)                                   
;----------------------------------------------------------------------
        ldi       @_m_nCarPos+0,r0
        ble       L494
;*      Branch Occurs to L494 
        cmpi      8,r0
        bgt       L494
;*      Branch Occurs to L494 
	.line	313
;----------------------------------------------------------------------
; 1293 | btTxBuf[nTxPos++] = 0x00; // ������                                    
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        ldiu      0,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	314
;----------------------------------------------------------------------
; 1294 | btTxBuf[nTxPos++] = MASKBIT(1,m_nCarPos-1); // ������                  
; 1296 | else                                                                   
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      1,r3
        ldiu      *+fp(ir1),r1
        addi      r1,r3
        sti       r3,*+fp(ir0)
        addi3     r1,fp,ir1             ; Unsigned
        subri     @_m_nCarPos+0,r0
        ash3      r0,r2,r0
        sti       r0,*+ar0(ir1)
        bu        L495
;*      Branch Occurs to L495 
L494:        
	.line	318
;----------------------------------------------------------------------
; 1298 | btTxBuf[nTxPos++] = 0x80; // ������                                    
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      264,ir1
        ldiu      265,ar0
        ldiu      *+fp(ir0),r0
        ldiu      128,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	319
;----------------------------------------------------------------------
; 1299 | btTxBuf[nTxPos++] = 0x00; // ������                                    
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        ldiu      0,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
L495:        
	.line	321
;----------------------------------------------------------------------
; 1301 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      266,r1
        ldiu      1,r0
        ldiu      264,ir0
        addi      fp,r1
        subi3     r0,*+fp(ir0),r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        ldiu      264,ir1
        subi      2,sp
        ldiu      265,ar0
        ldiu      264,ir0
        ldiu      *+fp(ir1),r2
        ldiu      1,r1
        addi      r2,r1
        addi3     r2,fp,ir1             ; Unsigned
        sti       r1,*+fp(ir0)
        sti       r0,*+ar0(ir1)
	.line	322
;----------------------------------------------------------------------
; 1302 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      1,r0
        ldiu      *+fp(ir0),r2
        ldiu      3,r1
        addi3     r2,fp,ir0             ; Unsigned
        addi      r2,r0
        sti       r0,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	323
;----------------------------------------------------------------------
; 1303 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      265,r0
        ldiu      *+fp(ir0),r1
        addi      fp,r0
        push      r1
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	324
;----------------------------------------------------------------------
; 1304 | break;                                                                 
; 1306 | // ������ȣ ��û                                                       
; 1307 | case 0x14:                                                             
;----------------------------------------------------------------------
        bu        L534
;*      Branch Occurs to L534 
	.line	328
;----------------------------------------------------------------------
; 1308 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
L497:        
        sti       r0,*+fp(ir0)
	.line	329
;----------------------------------------------------------------------
; 1309 | memset(btTxBuf,0x00,sizeof(btTxBuf));                                  
;----------------------------------------------------------------------
        ldiu      265,r2
        ldiu      0,r1
        addi      fp,r2
        ldiu      128,r0
        push      r0
        push      r1
        push      r2
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	331
;----------------------------------------------------------------------
; 1311 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      264,ir1
        ldiu      1,r1
        ldiu      265,ar0
        ldiu      *+fp(ir0),r2
        addi      r2,r1
        sti       r1,*+fp(ir1)
        addi3     r2,fp,ir0             ; Unsigned
        ldiu      2,r0
        sti       r0,*+ar0(ir0)
	.line	332
;----------------------------------------------------------------------
; 1312 | btTxBuf[nTxPos++] = 0x15; // Command Code                              
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir1),r2
        ldiu      1,r0
        addi3     r2,fp,ir1             ; Unsigned
        addi      r2,r0
        sti       r0,*+fp(ir0)
        ldiu      21,r1
        sti       r1,*+ar0(ir1)
	.line	333
;----------------------------------------------------------------------
; 1313 | btTxBuf[nTxPos++] = 0x00; // Message Code                              
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      *+fp(ir1),r1
        addi3     r1,fp,ir1             ; Unsigned
        ldiu      1,r2
        addi      r1,r2
        sti       r2,*+fp(ir0)
        ldiu      0,r0
        sti       r0,*+ar0(ir1)
	.line	334
;----------------------------------------------------------------------
; 1314 | btTxBuf[nTxPos++] = 0x02; // ����                                      
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      *+fp(ir1),r2
        addi3     r2,fp,ir1             ; Unsigned
        ldiu      1,r0
        addi      r2,r0
        sti       r0,*+fp(ir0)
        ldiu      2,r1
        sti       r1,*+ar0(ir1)
	.line	335
;----------------------------------------------------------------------
; 1315 | btTxBuf[nTxPos++] = WORD_H(m_nCarNo);                                  
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      *+fp(ir1),r1
        ldiu      1,r0
        addi      r1,r0
        sti       r0,*+fp(ir0)
        ldiu      @_m_nCarNo+0,r0
        lsh       -8,r0
        addi3     r1,fp,ir0             ; Unsigned
        and       255,r0
        sti       r0,*+ar0(ir0)
	.line	336
;----------------------------------------------------------------------
; 1316 | btTxBuf[nTxPos++] = WORD_L(m_nCarNo);                                  
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      255,r0
        ldiu      *+fp(ir0),r2
        ldiu      1,r1
        addi      r2,r1
        addi3     r2,fp,ir0             ; Unsigned
        sti       r1,*+fp(ir1)
        and       @_m_nCarNo+0,r0
        sti       r0,*+ar0(ir0)
	.line	337
;----------------------------------------------------------------------
; 1317 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      266,r0
        ldiu      264,ir0
        addi      fp,r0
        subi3     r1,*+fp(ir0),r1
        push      r1
        push      r0
        call      _Make1ByteBcc
                                        ; Call Occurs
        ldiu      264,ir1
        subi      2,sp
        ldiu      1,r1
        ldiu      *+fp(ir1),r2
        ldiu      265,ar0
        addi3     r2,fp,ir1             ; Unsigned
        ldiu      264,ir0
        addi      r2,r1
        sti       r1,*+fp(ir0)
        sti       r0,*+ar0(ir1)
	.line	338
;----------------------------------------------------------------------
; 1318 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      3,r1
        ldiu      1,r0
        ldiu      *+fp(ir0),r2
        addi      r2,r0
        addi3     r2,fp,ir0             ; Unsigned
        sti       r0,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	339
;----------------------------------------------------------------------
; 1319 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        push      r0
        ldiu      265,r0
        addi      fp,r0
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	340
;----------------------------------------------------------------------
; 1320 | break;                                                                 
; 1322 | // CI���峭 ���� ��ġ ��û                                             
; 1323 | case 0x16:                                                             
;----------------------------------------------------------------------
        bu        L534
;*      Branch Occurs to L534 
	.line	344
;----------------------------------------------------------------------
; 1324 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
L499:        
        sti       r0,*+fp(ir0)
	.line	345
;----------------------------------------------------------------------
; 1325 | memset(btTxBuf,0x00,sizeof(btTxBuf));                                  
;----------------------------------------------------------------------
        ldiu      128,r2
        ldiu      0,r1
        ldiu      265,r0
        push      r2
        addi      fp,r0
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	347
;----------------------------------------------------------------------
; 1327 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      264,ir1
        ldiu      265,ar0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        ldiu      2,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	348
;----------------------------------------------------------------------
; 1328 | btTxBuf[nTxPos++] = 0x17; // Command Code                              
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        ldiu      1,r2
        ldiu      23,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	349
;----------------------------------------------------------------------
; 1329 | btTxBuf[nTxPos++] = 0x00; // Message Code                              
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        ldiu      0,r1
        sti       r1,*+ar0(ir0)
	.line	350
;----------------------------------------------------------------------
; 1330 | btTxBuf[nTxPos++] = 0x02; // ����                                      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      1,r2
        addi      r0,r2
        sti       r2,*+fp(ir1)
        ldiu      2,r1
        sti       r1,*+ar0(ir0)
	.line	351
;----------------------------------------------------------------------
; 1331 | if(m_btCiFaultVal != 0x8000 && m_btTestOtherCiFault != 0x8000)         
;----------------------------------------------------------------------
        ldiu      @_m_btCiFaultVal+0,r0
        cmpi      @CL94,r0
        beq       L519
;*      Branch Occurs to L519 
        ldiu      @_m_btTestOtherCiFault+0,r0
        cmpi      @CL95,r0
        beq       L519
;*      Branch Occurs to L519 
	.line	353
;----------------------------------------------------------------------
; 1333 | btTxBuf[nTxPos++] = 0x00;                                              
; 1334 | switch(m_TrainCofVal)                                                  
; 1336 | // 2��                                                                 
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir1),r0
        ldiu      0,r1
        addi      r0,r2
        bud       L513
        addi3     r0,fp,ir1             ; Unsigned
        sti       r2,*+fp(ir0)
        sti       r1,*+ar0(ir1)
;*      Branch Occurs to L513 
	.line	357
;----------------------------------------------------------------------
; 1337 | case 0: btTxBuf[nTxPos++] = 0xFC | m_btCiFaultVal | m_btTestOtherCiFaul
;     | t; break; // ������                                                    
; 1338 | // 4��                                                                 
;----------------------------------------------------------------------
L503:        
        ldiu      *+fp(ir1),r1
        ldiu      265,ar0
        addi      r1,r0
        sti       r0,*+fp(ir0)
        ldiu      @_m_btTestOtherCiFault+0,r0
        addi3     r1,fp,ir0             ; Unsigned
        or        @_m_btCiFaultVal+0,r0
        or        252,r0
        sti       r0,*+ar0(ir0)
        bu        L520
;*      Branch Occurs to L520 
	.line	359
;----------------------------------------------------------------------
; 1339 | case 1: btTxBuf[nTxPos++] = 0xF0 | m_btCiFaultVal | m_btTestOtherCiFaul
;     | t; break; // ������                                                    
; 1340 | // 6��                                                                 
;----------------------------------------------------------------------
L505:        
        ldiu      *+fp(ir1),r1
        ldiu      265,ar0
        addi      r1,r0
        sti       r0,*+fp(ir0)
        ldiu      @_m_btTestOtherCiFault+0,r0
        addi3     r1,fp,ir0             ; Unsigned
        or        @_m_btCiFaultVal+0,r0
        or        240,r0
        sti       r0,*+ar0(ir0)
        bu        L520
;*      Branch Occurs to L520 
	.line	361
;----------------------------------------------------------------------
; 1341 | case 2: btTxBuf[nTxPos++] = 0xC0 | m_btCiFaultVal | m_btTestOtherCiFaul
;     | t; break; // ������                                                    
; 1342 | // 8��                                                                 
;----------------------------------------------------------------------
L507:        
        ldiu      *+fp(ir1),r1
        ldiu      265,ar0
        addi      r1,r0
        sti       r0,*+fp(ir0)
        ldiu      @_m_btTestOtherCiFault+0,r0
        addi3     r1,fp,ir0             ; Unsigned
        or        @_m_btCiFaultVal+0,r0
        or        192,r0
        sti       r0,*+ar0(ir0)
        bu        L520
;*      Branch Occurs to L520 
	.line	363
;----------------------------------------------------------------------
; 1343 | case 3: btTxBuf[nTxPos++] = 0x00 | m_btCiFaultVal | m_btTestOtherCiFaul
;     | t; break; // ������                                                    
; 1344 | default:                                                               
;----------------------------------------------------------------------
L509:        
        ldiu      *+fp(ir1),r0
        ldiu      265,ar0
        addi      r0,r1
        sti       r1,*+fp(ir0)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      @_m_btTestOtherCiFault+0,r0
        or        @_m_btCiFaultVal+0,r0
        sti       r0,*+ar0(ir0)
        bu        L520
;*      Branch Occurs to L520 
	.line	365
;----------------------------------------------------------------------
; 1345 | btTxBuf[nTxPos++] = 0x00 | m_btCiFaultVal | m_btTestOtherCiFault; break
;     | ; // ������                                                            
; 1347 | //btTxBuf[nTxPos++] = m_btCiFaultVal | m_btTestOtherCiFault;           
; 1349 | else                                                                   
;----------------------------------------------------------------------
L511:        
        ldiu      *+fp(ir1),r0
        ldiu      265,ar0
        addi      r0,r1
        sti       r1,*+fp(ir0)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      @_m_btTestOtherCiFault+0,r0
        or        @_m_btCiFaultVal+0,r0
        sti       r0,*+ar0(ir0)
        bu        L520
;*      Branch Occurs to L520 
L513:        
	.line	354
        ldi       @_m_TrainCofVal+0,r0
        beqd      L503
        ldieq     264,ir1
        ldieq     1,r0
        ldieq     264,ir0
;*      Branch Occurs to L503 
        cmpi      1,r0
        beqd      L505
        ldieq     264,ir1
        ldieq     1,r0
        ldieq     264,ir0
;*      Branch Occurs to L505 
        cmpi      2,r0
        beqd      L507
        ldieq     264,ir1
        ldieq     1,r0
        ldieq     264,ir0
;*      Branch Occurs to L507 
        cmpi      3,r0
        beqd      L509
        ldieq     264,ir1
        ldieq     1,r1
        ldieq     264,ir0
;*      Branch Occurs to L509 
        bud       L511
        ldiu      264,ir1
        ldiu      1,r1
        ldiu      264,ir0
;*      Branch Occurs to L511 
L519:        
	.line	371
;----------------------------------------------------------------------
; 1351 | btTxBuf[nTxPos++] = 0x80;                                              
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      264,ir1
        ldiu      265,ar0
        ldiu      *+fp(ir0),r0
        ldiu      128,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	372
;----------------------------------------------------------------------
; 1352 | btTxBuf[nTxPos++] = 0x00;                                              
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        ldiu      0,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
L520:        
	.line	374
;----------------------------------------------------------------------
; 1354 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      266,r1
        ldiu      1,r0
        ldiu      264,ir0
        addi      fp,r1
        subi3     r0,*+fp(ir0),r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      2,sp
        ldiu      265,ar0
        ldiu      264,ir1
        ldiu      *+fp(ir0),r1
        ldiu      1,r2
        addi      r1,r2
        addi3     r1,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	375
;----------------------------------------------------------------------
; 1355 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r1
        ldiu      *+fp(ir0),r2
        addi      r2,r1
        ldiu      3,r0
        addi3     r2,fp,ir0             ; Unsigned
        sti       r1,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	376
;----------------------------------------------------------------------
; 1356 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r1
        push      r1
        ldiu      265,r0
        addi      fp,r0
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	377
;----------------------------------------------------------------------
; 1357 | break;                                                                 
;----------------------------------------------------------------------
        bu        L534
;*      Branch Occurs to L534 
	.line	161
L522:        
        ldiu      *ar0,r0
        cmpi      14,r0
        bgt       L530
;*      Branch Occurs to L530 
        beq       L487
;*      Branch Occurs to L487 
        cmpi      2,r0
        beq       L463
;*      Branch Occurs to L463 
        cmpi      6,r0
        beq       L464
;*      Branch Occurs to L464 
        cmpi      8,r0
        beqd      L467
	nop
        ldieq     264,ir0
        ldieq     0,r0
;*      Branch Occurs to L467 
        cmpi      10,r0
        beq       L468
;*      Branch Occurs to L468 
        cmpi      12,r0
        beqd      L473
	nop
        ldieq     264,ir0
        ldieq     0,r0
;*      Branch Occurs to L473 
        bu        L534
;*      Branch Occurs to L534 
L530:        
        cmpi      16,r0
        beqd      L489
	nop
        ldieq     264,ir0
        ldieq     0,r0
;*      Branch Occurs to L489 
        cmpi      18,r0
        beqd      L491
	nop
        ldieq     264,ir0
        ldieq     0,r0
;*      Branch Occurs to L491 
        cmpi      20,r0
        beqd      L497
	nop
        ldieq     264,ir0
        ldieq     0,r0
;*      Branch Occurs to L497 
        cmpi      22,r0
        beqd      L499
	nop
        ldieq     264,ir0
        ldieq     0,r0
;*      Branch Occurs to L499 
L534:        
	.line	380
;----------------------------------------------------------------------
; 1360 | if(nTxPos)                                                             
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldi       *+fp(ir0),r0
        beq       L547
;*      Branch Occurs to L547 
	.line	382
;----------------------------------------------------------------------
; 1362 | if(m_nDbgTxPos == 0xFFFFFFFF)                                          
;----------------------------------------------------------------------
        ldiu      @_m_nDbgTxPos+0,r0
        cmpi      @CL84,r0
        bned      L547
	nop
        ldieq     393,ir0
        ldieq     0,r0
;*      Branch Occurs to L547 
	.line	384
;----------------------------------------------------------------------
; 1364 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        sti       r0,*+fp(ir0)
	.line	385
;----------------------------------------------------------------------
; 1365 | sprintf(szBuf2,"[TX:%02d] ",nTxPos); strcat(szBuf,szBuf2);             
;----------------------------------------------------------------------
        ldiu      905,r1
        ldiu      264,ir0
        addi      fp,r1
        ldiu      *+fp(ir0),r2
        ldiu      @CL82,r0
        push      r2
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	386
;----------------------------------------------------------------------
; 1366 | for(i=0;i<nTxPos;i++) {sprintf(szBuf2,"%02X ",WORD_L(btTxBuf[i])); strc
;     | at(szBuf,szBuf2);}                                                     
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        ldiu      264,ir0
        cmpi3     *+fp(ir0),r0
        bged      L538
	nop
        ldiu      265,ar4
        ldiu      255,r4
;*      Branch Occurs to L538 
L537:        
        ldiu      *+fp(1),ir0
        ldiu      905,r0
        addi      fp,ir0
        ldiu      @CL83,r1
        and3      r4,*+ar4(ir0),r2
        push      r2
        addi      fp,r0
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        ldiu      264,ir0
        cmpi3     *+fp(ir0),r0
        blt       L537
;*      Branch Occurs to L537 
L538:        
	.line	387
;----------------------------------------------------------------------
; 1367 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL28,r1
        ldiu      393,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	388
;----------------------------------------------------------------------
; 1368 | user_DebugPrint(szBuf);                                                
;----------------------------------------------------------------------
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	392
;----------------------------------------------------------------------
; 1372 | break;                                                                 
;----------------------------------------------------------------------
        bu        L547
;*      Branch Occurs to L547 
L540:        
	.line	21
        ldiu      *+fp(6),r0
        cmpi      1,r0
        beq       L408
;*      Branch Occurs to L408 
        cmpi      2,r0
        beq       L408
;*      Branch Occurs to L408 
        cmpi      3,r0
        beq       L408
;*      Branch Occurs to L408 
        cmpi      4,r0
        beq       L408
;*      Branch Occurs to L408 
        cmpi      5,r0
        beq       L408
;*      Branch Occurs to L408 
        cmpi      6,r0
        beq       L408
;*      Branch Occurs to L408 
        cmpi      7,r0
        beqd      L457
	nop
        ldieq     fp,r0
        ldieq     7,r1
;*      Branch Occurs to L457 
L547:        
	.line	394
        pop       ar4
        ldiu      *-fp(1),bk
        pop       r4
        ldiu      *fp,fp
        subi      970,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1374,000001010h,968


	.sect	 ".text"

	.global	_BitSwap
	.sym	_BitSwap,_BitSwap,44,2,0
	.func	1379
;******************************************************************************
;* FUNCTION NAME: _BitSwap                                                    *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,st                                               *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 1 Parm + 1 Auto + 0 SOE = 4 words          *
;******************************************************************************
_BitSwap:
	.sym	_btDat,-2,12,9,32
	.sym	_btBuf,1,12,1,32
	.line	1
;----------------------------------------------------------------------
; 1379 | UCHAR BitSwap(UCHAR btDat)                                             
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      1,sp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 1381 | UCHAR btBuf = 0x00;                                                    
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
	.line	5
;----------------------------------------------------------------------
; 1383 | btBuf |= MASKBIT(btDat&0x01?1:0,7);                                    
;----------------------------------------------------------------------
        ldiu      1,r0
        tstb      *-fp(2),r0
        beq       L551
;*      Branch Occurs to L551 
        bu        L552
;*      Branch Occurs to L552 
L551:        
        ldiu      0,r0
L552:        
        and       1,r0
        ash       7,r0
        or        *+fp(1),r0
        sti       r0,*+fp(1)
	.line	6
;----------------------------------------------------------------------
; 1384 | btBuf |= MASKBIT(btDat&0x02?1:0,6);                                    
;----------------------------------------------------------------------
        ldiu      2,r0
        tstb      *-fp(2),r0
        beq       L554
;*      Branch Occurs to L554 
        bud       L555
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L555 
L554:        
        ldiu      0,r0
L555:        
        and       1,r0
        ash       6,r0
        or        *+fp(1),r0
        sti       r0,*+fp(1)
	.line	7
;----------------------------------------------------------------------
; 1385 | btBuf |= MASKBIT(btDat&0x04?1:0,5);                                    
;----------------------------------------------------------------------
        ldiu      4,r0
        tstb      *-fp(2),r0
        beq       L557
;*      Branch Occurs to L557 
        bud       L558
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L558 
L557:        
        ldiu      0,r0
L558:        
        and       1,r0
        ash       5,r0
        or        *+fp(1),r0
        sti       r0,*+fp(1)
	.line	8
;----------------------------------------------------------------------
; 1386 | btBuf |= MASKBIT(btDat&0x08?1:0,4);                                    
;----------------------------------------------------------------------
        ldiu      8,r0
        tstb      *-fp(2),r0
        beq       L560
;*      Branch Occurs to L560 
        bud       L561
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L561 
L560:        
        ldiu      0,r0
L561:        
        and       1,r0
        ash       4,r0
        or        *+fp(1),r0
        sti       r0,*+fp(1)
	.line	9
;----------------------------------------------------------------------
; 1387 | btBuf |= MASKBIT(btDat&0x10?1:0,3);                                    
;----------------------------------------------------------------------
        ldiu      16,r0
        tstb      *-fp(2),r0
        beq       L563
;*      Branch Occurs to L563 
        bud       L564
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L564 
L563:        
        ldiu      0,r0
L564:        
        and       1,r0
        ash       3,r0
        or        *+fp(1),r0
        sti       r0,*+fp(1)
	.line	10
;----------------------------------------------------------------------
; 1388 | btBuf |= MASKBIT(btDat&0x20?1:0,2);                                    
;----------------------------------------------------------------------
        ldiu      32,r0
        tstb      *-fp(2),r0
        beq       L566
;*      Branch Occurs to L566 
        bud       L567
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L567 
L566:        
        ldiu      0,r0
L567:        
        and       1,r0
        ash       2,r0
        or        *+fp(1),r0
        sti       r0,*+fp(1)
	.line	11
;----------------------------------------------------------------------
; 1389 | btBuf |= MASKBIT(btDat&0x40?1:0,1);                                    
;----------------------------------------------------------------------
        ldiu      64,r0
        tstb      *-fp(2),r0
        beq       L569
;*      Branch Occurs to L569 
        bud       L570
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L570 
L569:        
        ldiu      0,r0
L570:        
        and       1,r0
        ash       1,r0
        or        *+fp(1),r0
        sti       r0,*+fp(1)
	.line	12
;----------------------------------------------------------------------
; 1390 | btBuf |= MASKBIT(btDat&0x80?1:0,0);                                    
;----------------------------------------------------------------------
        ldiu      128,r0
        tstb      *-fp(2),r0
        beq       L572
;*      Branch Occurs to L572 
        bud       L573
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L573 
L572:        
        ldiu      0,r0
L573:        
        and       1,r0
        or        *+fp(1),r0
        sti       r0,*+fp(1)
	.line	14
;----------------------------------------------------------------------
; 1392 | return btBuf;                                                          
;----------------------------------------------------------------------
	.line	15
        ldiu      *-fp(1),r1
        ldiu      *fp,fp
        subi      3,sp
        bu        r1
;*      Branch Occurs to r1 
	.endfunc	1393,000000000h,1


	.sect	 ".text"

	.global	_user_LonWorkRx
	.sym	_user_LonWorkRx,_user_LonWorkRx,44,2,0
	.func	1395
;******************************************************************************
;* FUNCTION NAME: _user_LonWorkRx                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,ar0,ar1,fp,ir0,ir1,sp,st                      *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 4 Auto + 0 SOE = 8 words          *
;******************************************************************************
_user_LonWorkRx:
	.sym	_nRxPos,-2,4,9,32
	.sym	_pRxBuf,-3,28,9,32
	.sym	_i,1,4,1,32
	.sym	_nRxLen,2,12,1,32
	.sym	_pBuf,3,28,1,32
	.sym	_pLnWkDp,4,24,1,32,.fake13
	.line	1
;----------------------------------------------------------------------
; 1395 | UCHAR user_LonWorkRx(int nRxPos, UCHAR *pRxBuf)                        
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      4,sp
	.line	2
;----------------------------------------------------------------------
; 1397 | int i;                                                                 
; 1398 | UCHAR nRxLen;                                                          
; 1399 | UCHAR *pBuf;                                                           
;----------------------------------------------------------------------
	.line	6
;----------------------------------------------------------------------
; 1400 | PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;                                
;----------------------------------------------------------------------
        ldiu      @CL14,r0
        sti       r0,*+fp(4)
	.line	8
;----------------------------------------------------------------------
; 1402 | if(nRxPos >= 1 && nRxPos <= 6)                                         
;----------------------------------------------------------------------
        ldi       *-fp(2),r0
        ble       L592
;*      Branch Occurs to L592 
        cmpi      6,r0
        bgt       L592
;*      Branch Occurs to L592 
	.line	10
;----------------------------------------------------------------------
; 1404 | nRxLen = MIN(sizeof(LNWKFTPIT)-1,WORD_L(pLnWkDp->lfBuf[nRxPos-1].btLen)
;     | +6);                                                                   
;----------------------------------------------------------------------
        ldiu      1,ar0
        subri     *-fp(2),ar0
        ldiu      255,r0
        mpyi      200,ar0
        addi      *+fp(4),ar0           ; Unsigned
        ldiu      199,r1
        and       *+ar0(19),r0
        addi      6,r0                  ; Unsigned
        cmpi3     r0,r1
        bhs       L580
;*      Branch Occurs to L580 
        bud       L581
	nop
	nop
        ldiu      199,r0
;*      Branch Occurs to L581 
L580:        
        ldiu      1,ar0
        subri     *-fp(2),ar0
        mpyi      200,ar0
        addi      *+fp(4),ar0           ; Unsigned
        ldiu      255,r0
        and       *+ar0(19),r0
        addi      6,r0                  ; Unsigned
L581:        
        sti       r0,*+fp(2)
	.line	11
;----------------------------------------------------------------------
; 1405 | if(nRxLen > 6)                                                         
;----------------------------------------------------------------------
        cmpi      6,r0
        bls       L590
;*      Branch Occurs to L590 
	.line	13
;----------------------------------------------------------------------
; 1407 | pBuf = &pLnWkDp->lfBuf[nRxPos-1].btStx;                                
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     *-fp(2),r0
        mpyi      200,r0
        addi      *+fp(4),r0            ; Unsigned
        addi      16,r0                 ; Unsigned
        sti       r0,*+fp(3)
	.line	14
;----------------------------------------------------------------------
; 1408 | for(i=0;i<nRxLen;i++) pRxBuf[i] = WORD_L(pBuf[i]);                     
; 1410 | //MyPrintf("[Len:%d,Pos:%d->",nRxLen,nRxPos);                          
; 1411 | //for(i=0;i<nRxLen;i++) MyPrintf("%02X ",pRxBuf[i]);                   
; 1412 | //MyPrintf("]\r\n");                                                   
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(2),r0
        ldiu      255,r1
        bhs       L584
;*      Branch Occurs to L584 
L583:        
        ldiu      *+fp(1),ar1
        ldiu      *+fp(3),ir0
        ldiu      *-fp(3),ir1
        ldiu      ar1,ar0
        and3      r1,*+ar1(ir0),r0
        sti       r0,*+ar0(ir1)
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(2),r0
        blo       L583
;*      Branch Occurs to L583 
L584:        
	.line	20
;----------------------------------------------------------------------
; 1414 | if(pRxBuf[0] == STX && pRxBuf[nRxLen-1] == ETX)                        
;----------------------------------------------------------------------
        ldiu      *-fp(3),ar0
        ldiu      *ar0,r0
        cmpi      2,r0
        bne       L588
;*      Branch Occurs to L588 
        ldiu      *+fp(2),ar0
        addi      *-fp(3),ar0           ; Unsigned
        ldiu      *-ar0(1),r0
        cmpi      3,r0
        bne       L588
;*      Branch Occurs to L588 
	.line	22
;----------------------------------------------------------------------
; 1416 | return nRxLen;                                                         
; 1418 | else                                                                   
;----------------------------------------------------------------------
        bud       L610
	nop
	nop
        ldiu      *+fp(2),r0
;*      Branch Occurs to L610 
L588:        
	.line	26
;----------------------------------------------------------------------
; 1420 | return 0;                                                              
; 1423 | else                                                                   
;----------------------------------------------------------------------
        bud       L610
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L610 
L590:        
	.line	31
;----------------------------------------------------------------------
; 1425 | return 0;                                                              
; 1428 | else                                                                   
;----------------------------------------------------------------------
        bud       L610
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L610 
L592:        
	.line	35
;----------------------------------------------------------------------
; 1429 | if(nRxPos == 7)                                                        
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        cmpi      7,r0
        bned      L608
        ldieq     255,r0
        ldieq     *+fp(4),ir0
        ldieq     1219,ar0
;*      Branch Occurs to L608 
	.line	37
;----------------------------------------------------------------------
; 1431 | nRxLen = MIN(sizeof(LNWKGERIT),WORD_L(pLnWkDp->lgRxBuf.btLen)+6);      
;----------------------------------------------------------------------
        ldiu      200,r1
        and3      r0,*+ar0(ir0),r0
        addi      6,r0                  ; Unsigned
        cmpi3     r0,r1
        bhsd      L595
        ldihs     *+fp(4),ir0
        ldihs     1219,ar0
        ldihs     255,r0
;*      Branch Occurs to L595 
        bud       L596
	nop
	nop
        ldiu      200,r0
;*      Branch Occurs to L596 
L595:        
        and3      r0,*+ar0(ir0),r0
        addi      6,r0                  ; Unsigned
L596:        
        sti       r0,*+fp(2)
	.line	38
;----------------------------------------------------------------------
; 1432 | if(nRxLen > 5)                                                         
;----------------------------------------------------------------------
        cmpi      5,r0
        bls       L606
;*      Branch Occurs to L606 
	.line	40
;----------------------------------------------------------------------
; 1434 | pBuf = &pLnWkDp->lfBuf[nRxPos-1].btStx;                                
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     *-fp(2),r0
        mpyi      200,r0
        addi      *+fp(4),r0            ; Unsigned
        addi      16,r0                 ; Unsigned
        sti       r0,*+fp(3)
	.line	41
;----------------------------------------------------------------------
; 1435 | for(i=0;i<nRxLen;i++) pRxBuf[i] = WORD_L(pBuf[i]);                     
; 1437 | //MyPrintf("[Len:%d,Pos:%d->",nRxLen,nRxPos);                          
; 1438 | //for(i=0;i<nRxLen;i++) MyPrintf("%02X ",pRxBuf[i]);                   
; 1439 | //MyPrintf("]\r\n");                                                   
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(2),r0
        ldiu      255,r1
        bhs       L599
;*      Branch Occurs to L599 
L598:        
        ldiu      *+fp(1),ar1
        ldiu      *+fp(3),ir0
        ldiu      *-fp(3),ir1
        ldiu      ar1,ar0
        and3      r1,*+ar1(ir0),r0
        sti       r0,*+ar0(ir1)
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(2),r0
        blo       L598
;*      Branch Occurs to L598 
L599:        
	.line	47
;----------------------------------------------------------------------
; 1441 | if(pRxBuf[0] == STX && pRxBuf[nRxLen-1] == ETX && !Make1ByteBcc(&pRxBuf
;     | [1],nRxLen-2))                                                         
;----------------------------------------------------------------------
        ldiu      *-fp(3),ar0
        ldiu      *ar0,r0
        cmpi      2,r0
        bne       L604
;*      Branch Occurs to L604 
        ldiu      *+fp(2),ar0
        addi      *-fp(3),ar0           ; Unsigned
        ldiu      *-ar0(1),r0
        cmpi      3,r0
        bned      L604
	nop
        ldieq     1,r1
        ldieq     2,r0
;*      Branch Occurs to L604 
        addi      *-fp(3),r1            ; Unsigned
        subri     *+fp(2),r0            ; Unsigned
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        cmpi      0,r0
        subi      2,sp
        bne       L604
;*      Branch Occurs to L604 
	.line	49
;----------------------------------------------------------------------
; 1443 | return nRxLen;                                                         
; 1445 | else                                                                   
;----------------------------------------------------------------------
        bud       L610
	nop
	nop
        ldiu      *+fp(2),r0
;*      Branch Occurs to L610 
L604:        
	.line	53
;----------------------------------------------------------------------
; 1447 | return 0;                                                              
; 1450 | else                                                                   
;----------------------------------------------------------------------
        bud       L610
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L610 
L606:        
	.line	58
;----------------------------------------------------------------------
; 1452 | return 0;                                                              
; 1455 | else                                                                   
;----------------------------------------------------------------------
        bud       L610
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L610 
L608:        
	.line	63
;----------------------------------------------------------------------
; 1457 | return 0;                                                              
;----------------------------------------------------------------------
        bud       L610
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L610 
	.line	66
;----------------------------------------------------------------------
; 1460 | return 0;                                                              
;----------------------------------------------------------------------
L610:        
	.line	67
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      6,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1461,000000000h,4


	.sect	 ".text"

	.global	_user_LonWorkTx
	.sym	_user_LonWorkTx,_user_LonWorkTx,32,2,0
	.func	1463
;******************************************************************************
;* FUNCTION NAME: _user_LonWorkTx                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,ar0,ar1,fp,ir0,ir1,sp                         *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 579 Auto + 0 SOE = 583 words      *
;******************************************************************************
_user_LonWorkTx:
	.sym	_pTxBuf,-2,28,9,32
	.sym	_nLen,-3,12,9,32
	.sym	_i,1,4,1,32
	.sym	_szBuf,2,50,1,16384,,512
	.sym	_szBuf2,514,50,1,2048,,64
	.sym	_pBuf,578,28,1,32
	.sym	_pLnWkDp,579,24,1,32,.fake13
	.line	1
;----------------------------------------------------------------------
; 1463 | void user_LonWorkTx(UCHAR *pTxBuf,UCHAR nLen)                          
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      579,sp
	.line	2
;----------------------------------------------------------------------
; 1465 | int i;                                                                 
; 1466 | char szBuf[512];                                                       
; 1467 | char szBuf2[64];                                                       
; 1469 | UCHAR *pBuf;                                                           
;----------------------------------------------------------------------
	.line	8
;----------------------------------------------------------------------
; 1470 | PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;                                
;----------------------------------------------------------------------
        ldiu      579,ir0
        ldiu      @CL14,r0
        sti       r0,*+fp(ir0)
	.line	10
;----------------------------------------------------------------------
; 1472 | pBuf = &pLnWkDp->lgTxBuf.btStx;                                        
;----------------------------------------------------------------------
        ldiu      579,ir1
        ldiu      1416,r0
        ldiu      578,ir0
        addi3     r0,*+fp(ir1),r0       ; Unsigned
        sti       r0,*+fp(ir0)
	.line	12
;----------------------------------------------------------------------
; 1474 | memcpy(pBuf,pTxBuf,(int)nLen);                                         
;----------------------------------------------------------------------
        ldiu      *-fp(3),r1
        ldiu      *+fp(ir0),r0
        push      r1
        ldiu      *-fp(2),r1
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	13
;----------------------------------------------------------------------
; 1475 | LNWK_TXINTREQ();                                                       
;----------------------------------------------------------------------
        ldiu      @CL96,ar0
        ldiu      1,r0
        ldiu      @CL96,ar1
        andn3     *ar0,r0,r0
        sti       r0,*ar1
	.line	14
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      581,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1476,000000000h,579



	.sect	".cinit"
	.field  	1,32
	.field  	_nRxPos$10+0,32
	.field  	0,32		; _nRxPos$10 @ 0

	.sect	".text"

	.sect	".cinit"
	.field  	1,32
	.field  	_nOldUart2RxOneByteGapDelayTime$11+0,32
	.field  	0,32		; _nOldUart2RxOneByteGapDelayTime$11 @ 0

	.sect	".text"

	.sect	".cinit"
	.field  	1,32
	.field  	_nTimeSendCnt$14+0,32
	.field  	0,32		; _nTimeSendCnt$14 @ 0

	.sect	".text"
	.sect	 ".text"

	.global	_user_WithCncsRs232Loop
	.sym	_user_WithCncsRs232Loop,_user_WithCncsRs232Loop,32,2,0
	.func	1481
;******************************************************************************
;* FUNCTION NAME: _user_WithCncsRs232Loop                                     *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,r3,r4,r5,ar0,ar1,fp,ir0,ir1,sp,st          *
;*   Regs Saved         : r4,r5                                               *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 284 Auto + 2 SOE = 288 words      *
;******************************************************************************
_user_WithCncsRs232Loop:
	.bss	_nRxPos$10,1
	.sym	_nRxPos,_nRxPos$10,4,3,32
	.bss	_nOldUart2RxOneByteGapDelayTime$11,1
	.sym	_nOldUart2RxOneByteGapDelayTime,_nOldUart2RxOneByteGapDelayTime$11,12,3,32
	.bss	_btRx2chBuf$12,512
	.sym	_btRx2chBuf,_btRx2chBuf$12,60,3,16384,,512
	.bss	_btTx2chBuf$13,512
	.sym	_btTx2chBuf,_btTx2chBuf$13,60,3,16384,,512
	.bss	_nTimeSendCnt$14,1
	.sym	_nTimeSendCnt,_nTimeSendCnt$14,4,3,32
	.sym	_i,1,4,1,32
	.sym	_nRxLen,2,4,1,32
	.sym	_btBuf,3,60,1,8192,,256
	.sym	_sTimeBuf,259,60,1,320,,10
	.sym	_sPotoLen,269,4,1,32
	.sym	_sBcc,270,12,1,32
	.sym	_LL,271,12,1,32
	.sym	_LH,272,12,1,32
	.sym	_HL,273,12,1,32
	.sym	_HH,274,12,1,32
	.sym	_nBlkSize,275,4,1,32
	.sym	_nTempBlkEnd,276,4,1,32
	.sym	_sTxDataSize,277,4,1,32
	.sym	_pNvsram,278,28,1,32
	.sym	_pLicVerDp,279,24,1,32,.fake46
	.sym	_pLic_Cncs,280,24,1,32,.fake44
	.sym	_pCncsLicSd,281,24,1,32,.fake48
	.sym	_pCnsc_Lic_T_F,282,24,1,32,.fake49
	.sym	_pCncs_Lic_T_F_C,283,24,1,32,.fake50
	.sym	_pInfo,284,24,1,32,.fake74
	.line	1
;----------------------------------------------------------------------
; 1481 | void user_WithCncsRs232Loop()                                          
; 1483 | int i;                                                                 
; 1484 | int nRxLen;                                                            
; 1485 | UCHAR btBuf[256]; //���� ������Ʈ���� �о� ���� ����                   
; 1486 | UCHAR sTimeBuf[10];//�ð� ���� ����.                                   
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      284,sp
        push      r4
        push      r5
	.line	7
;----------------------------------------------------------------------
; 1487 | int sPotoLen = 0; //���� ��Ŷ Index.                                   
;----------------------------------------------------------------------
        ldiu      269,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	8
;----------------------------------------------------------------------
; 1488 | UCHAR sBcc = 0;                                                        
; 1489 | static int nRxPos = 0; //���� ī����.                                  
; 1490 | static UCHAR nOldUart2RxOneByteGapDelayTime = 0; //10ms �̻� ������ �ʵ
;     | Ǹ� ���� ó�� �Ѵ�.                                                    
; 1491 | static UCHAR btRx2chBuf[512]; //���� ����                              
; 1492 | static UCHAR btTx2chBuf[512]; //���� ����.                             
; 1493 | static int nTimeSendCnt = 0;                                           
; 1494 | UCHAR LL,LH,HL,HH;                                                     
;----------------------------------------------------------------------
        ldiu      270,ir0
        sti       r0,*+fp(ir0)
	.line	16
;----------------------------------------------------------------------
; 1496 | int nBlkSize = 0;                                                      
;----------------------------------------------------------------------
        ldiu      275,ir0
        sti       r0,*+fp(ir0)
	.line	17
;----------------------------------------------------------------------
; 1497 | int nTempBlkEnd = 0;                                                   
;----------------------------------------------------------------------
        ldiu      276,ir0
        sti       r0,*+fp(ir0)
	.line	18
;----------------------------------------------------------------------
; 1498 | int sTxDataSize = 0; //���ž� ����Ÿ size�� ��� �Ͽ� 128�̸� �߰� ����
;     | �� ������ ������ �̴�.                                                 
;----------------------------------------------------------------------
        ldiu      277,ir0
        sti       r0,*+fp(ir0)
	.line	20
;----------------------------------------------------------------------
; 1500 | UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;                                 
;----------------------------------------------------------------------
        ldiu      278,ir0
        ldiu      @CL81,r0
        sti       r0,*+fp(ir0)
	.line	22
;----------------------------------------------------------------------
; 1502 | PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó�
;     | ��� ���� ���Ƿ� �������.                                              
; 1503 | PLIC_CNCS_HD pLic_Cncs;                                                
; 1504 | PCNCS_LIC_SD pCncsLicSd;                                               
; 1506 | PCNCS_LIC_T_F pCnsc_Lic_T_F;                                           
;----------------------------------------------------------------------
        ldiu      279,ir0
        ldiu      @CL2,r0
        sti       r0,*+fp(ir0)
	.line	27
;----------------------------------------------------------------------
; 1507 | PCNCS_LIC_T_F_C pCncs_Lic_T_F_C = (CNCS_LIC_T_F_C *) btRx2chBuf;
;     |                          // ���� ��Ŷ ���� �Ϸ� Ȯ�� �������� �߰�(Y.J 
;     | 2011-05-10)                                                            
; 1509 | // Fault Block Information;                                            
;----------------------------------------------------------------------
        ldiu      283,ir0
        ldiu      @CL97,r0
        sti       r0,*+fp(ir0)
	.line	30
;----------------------------------------------------------------------
; 1510 | PFAULT_INFO pInfo = NULL;                                              
; 1512 | // ����                                                                
;----------------------------------------------------------------------
        ldiu      284,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	33
;----------------------------------------------------------------------
; 1513 | nRxLen = user_CncsRx(btBuf,128);                                       
;----------------------------------------------------------------------
        ldiu      128,r1
        ldiu      fp,r0
        push      r1
        addi      3,r0
        push      r0
        call      _user_CncsRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(2)
	.line	34
;----------------------------------------------------------------------
; 1514 | if(nRxLen)                                                             
;----------------------------------------------------------------------
        cmpi      0,r0
        beq       L620
;*      Branch Occurs to L620 
	.line	36
;----------------------------------------------------------------------
; 1516 | if(!m_nUart2RxOneByteGapDelayTime) nRxPos = 0;                         
;----------------------------------------------------------------------
        ldi       @_m_nUart2RxOneByteGapDelayTime+0,r0
        bne       L618
;*      Branch Occurs to L618 
        ldiu      0,r0
        sti       r0,@_nRxPos$10+0
L618:        
	.line	37
;----------------------------------------------------------------------
; 1517 | m_nUart2RxOneByteGapDelayTime = 10;                                    
;----------------------------------------------------------------------
        ldiu      10,r0
        sti       r0,@_m_nUart2RxOneByteGapDelayTime+0
	.line	39
;----------------------------------------------------------------------
; 1519 | if(nRxPos + nRxLen < 511)                                              
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        addi      @_nRxPos$10+0,r0
        cmpi      511,r0
        bged      L620
        ldilt     @CL97,r0
        ldilt     fp,r1
        ldilt     *+fp(2),r2
;*      Branch Occurs to L620 
	.line	41
;----------------------------------------------------------------------
; 1521 | memcpy(&btRx2chBuf[nRxPos],btBuf,nRxLen);                              
;----------------------------------------------------------------------
        addi      @_nRxPos$10+0,r0      ; Unsigned
        addi      3,r1
        push      r2
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	42
;----------------------------------------------------------------------
; 1522 | nRxPos += nRxLen;                                                      
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        addi      @_nRxPos$10+0,r0
        sti       r0,@_nRxPos$10+0
L620:        
	.line	46
;----------------------------------------------------------------------
; 1526 | if(nOldUart2RxOneByteGapDelayTime && !m_nUart2RxOneByteGapDelayTime)   
;----------------------------------------------------------------------
        ldi       @_nOldUart2RxOneByteGapDelayTime$11+0,r0
        beq       L657
;*      Branch Occurs to L657 
        ldi       @_m_nUart2RxOneByteGapDelayTime+0,r0
        bne       L657
;*      Branch Occurs to L657 
	.line	48
;----------------------------------------------------------------------
; 1528 | pCncsLicSd = (CNCS_LIC_SD *)btRx2chBuf;                                
;----------------------------------------------------------------------
        ldiu      281,ir0
        ldiu      @CL97,r0
        sti       r0,*+fp(ir0)
	.line	50
;----------------------------------------------------------------------
; 1530 | pCnsc_Lic_T_F = (CNCS_LIC_T_F *) btRx2chBuf;                           
;----------------------------------------------------------------------
        ldiu      282,ir0
        sti       r0,*+fp(ir0)
	.line	52
;----------------------------------------------------------------------
; 1532 | if(pCncsLicSd->phHdBuf.btSoh == SOH &&                                 
; 1533 |    pCncsLicSd->btEot == EOT &&                                         
; 1534 |    sizeof(CNCS_LIC_SD) == nRxPos &&                                    
; 1535 |    (TWOBYTE_ASC2HEX(pCncsLicSd->phHdBuf.chDestDev) == m_chCarKindNum) &
;     | &                                                                      
; 1536 |    (TWOBYTE_ASC2HEX(pCncsLicSd->sCommand) == 0x09) &&  //CNCS�� �ð� ��
;     | ��                                                                     
; 1537 |    !((Make1ByteBcc(&pCncsLicSd->phHdBuf.chSrcDev[0],nRxPos-4)^(TWOBYTE_
;     | ASC2HEX(pCncsLicSd->chChkSum)))))                                      
;----------------------------------------------------------------------
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *ar0,r0
        cmpi      1,r0
        bne       L637
;*      Branch Occurs to L637 
        ldiu      *+fp(ir0),ir0
        ldiu      363,ar0
        ldiu      *+ar0(ir0),r0
        cmpi      4,r0
        bne       L637
;*      Branch Occurs to L637 
        ldiu      364,r0
        cmpi      @_nRxPos$10+0,r0
        bne       L637
;*      Branch Occurs to L637 
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(4),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      @_m_chCarKindNum+0,r0
        subi      1,sp
        bne       L637
;*      Branch Occurs to L637 
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(15),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(16),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      9,r0
        subi      1,sp
        bne       L637
;*      Branch Occurs to L637 
        ldiu      1,r1
        ldiu      281,ir0
        ldiu      4,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$10+0,r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        ldiu      281,ir0
        subi      2,sp
        ldiu      361,ar0
        ldiu      *+fp(ir0),ir0
        ldiu      *+ar0(ir0),r1
        ldiu      r0,r5
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      281,ir0
        ldiu      362,ar0
        ldiu      *+fp(ir0),ir0
        ldiu      *+ar0(ir0),r1
        ldiu      r0,r4
        ash       4,r4
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        xor3      r5,r0,r0
        subi      1,sp
        bne       L637
;*      Branch Occurs to L637 
	.line	59
;----------------------------------------------------------------------
; 1539 | for(i=0;i<VER_BDD_MAX_CNT;i++)                                         
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      32,r0
        bge       L633
;*      Branch Occurs to L633 
L629:        
	.line	61
;----------------------------------------------------------------------
; 1541 | if(!MAKE_DWORD(0x00,m_tmUtcTime.year,m_tmUtcTime.month,m_tmUtcTime.day)
;     | )                                                                      
;----------------------------------------------------------------------
        ldiu      255,r1
        ldiu      255,r0
        ldiu      255,r2
        and       @_m_tmUtcTime+5,r1
        and       @_m_tmUtcTime+4,r0
        and       @_m_tmUtcTime+3,r2
        ash       16,r1
        ash       8,r0
        or3       r1,r0,r0
        or3       r0,r2,r0
        bne       L632
;*      Branch Occurs to L632 
	.line	63
;----------------------------------------------------------------------
; 1543 | pLicVerDp->VerCnt = FALSE;                                             
;----------------------------------------------------------------------
        ldiu      279,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      0,r0
        sti       r0,*ar0
	.line	64
;----------------------------------------------------------------------
; 1544 | memset(pLicVerDp->cvbBuf[i].chVer,'0',4);                              
;----------------------------------------------------------------------
        ldiu      4,r2
        ldiu      48,r1
        ldiu      *+fp(1),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),r0       ; Unsigned
        push      r2
        addi      1,r0                  ; Unsigned
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	65
;----------------------------------------------------------------------
; 1545 | memset(pLicVerDp->cvbBuf[i].chBuildDate,'0',6);                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        ldiu      279,ir0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),r0       ; Unsigned
        ldiu      6,r2
        push      r2
        addi      5,r0                  ; Unsigned
        ldiu      48,r1
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	66
;----------------------------------------------------------------------
; 1546 | break;                                                                 
; 1548 | else                                                                   
;----------------------------------------------------------------------
        bu        L633
;*      Branch Occurs to L633 
L632:        
	.line	70
;----------------------------------------------------------------------
; 1550 | pLicVerDp->VerCnt = TRUE;                                              
; 1552 | // ���� �Է�                                                           
;----------------------------------------------------------------------
        ldiu      279,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      1,r0
        sti       r0,*ar0
	.line	73
;----------------------------------------------------------------------
; 1553 | pLicVerDp->cvbBuf[i].chVer[0] = pCncsLicSd->cvbBuf[i].chVer[0];        
;----------------------------------------------------------------------
        ldiu      281,ir1
        ldiu      *+fp(1),r1
        ldiu      r1,r0
        mpyi      10,r0
        mpyi      10,r1
        addi3     r0,*+fp(ir1),ar1      ; Unsigned
        addi3     r1,*+fp(ir0),ar0      ; Unsigned
        ldiu      *+ar1(41),r0
        sti       r0,*+ar0(1)
	.line	74
;----------------------------------------------------------------------
; 1554 | pLicVerDp->cvbBuf[i].chVer[1] = pCncsLicSd->cvbBuf[i].chVer[1];        
;----------------------------------------------------------------------
        ldiu      279,ir1
        ldiu      281,ir0
        ldiu      *+fp(1),r0
        ldiu      r0,r1
        mpyi      10,r0
        mpyi      10,r1
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        addi3     r0,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+ar1(42),r0
        sti       r0,*+ar0(2)
	.line	75
;----------------------------------------------------------------------
; 1555 | pLicVerDp->cvbBuf[i].chVer[2] = pCncsLicSd->cvbBuf[i].chVer[2];        
;----------------------------------------------------------------------
        ldiu      *+fp(1),r1
        ldiu      r1,r0
        mpyi      10,r0
        mpyi      10,r1
        addi3     r0,*+fp(ir0),ar1      ; Unsigned
        addi3     r1,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+ar1(43),r0
        sti       r0,*+ar0(3)
	.line	76
;----------------------------------------------------------------------
; 1556 | pLicVerDp->cvbBuf[i].chVer[3] = pCncsLicSd->cvbBuf[i].chVer[3];        
; 1558 | // ������� ��¥ �Է�                                                  
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        ldiu      r0,r1
        mpyi      10,r1
        mpyi      10,r0
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        addi3     r0,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+ar1(44),r0
        sti       r0,*+ar0(4)
	.line	79
;----------------------------------------------------------------------
; 1559 | pLicVerDp->cvbBuf[i].chBuildDate[0] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [0];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r1
        ldiu      r1,r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar1      ; Unsigned
        mpyi      10,r1
        addi3     r1,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+ar1(45),r0
        sti       r0,*+ar0(5)
	.line	80
;----------------------------------------------------------------------
; 1560 | pLicVerDp->cvbBuf[i].chBuildDate[1] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [1];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        ldiu      r0,r1
        mpyi      10,r1
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        mpyi      10,r0
        addi3     r0,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+ar1(46),r0
        sti       r0,*+ar0(6)
	.line	81
;----------------------------------------------------------------------
; 1561 | pLicVerDp->cvbBuf[i].chBuildDate[2] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [2];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        ldiu      r0,r1
        mpyi      10,r1
        ldiu      281,ir1
        ldiu      279,ir0
        mpyi      10,r0
        addi3     r1,*+fp(ir1),ar0      ; Unsigned
        addi3     r0,*+fp(ir0),ar1      ; Unsigned
        ldiu      *+ar0(47),r0
        sti       r0,*+ar1(7)
	.line	82
;----------------------------------------------------------------------
; 1562 | pLicVerDp->cvbBuf[i].chBuildDate[3] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [3];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r1
        ldiu      r1,r0
        mpyi      10,r1
        mpyi      10,r0
        addi3     r0,*+fp(ir1),ar0      ; Unsigned
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        ldiu      *+ar0(48),r0
        sti       r0,*+ar1(8)
	.line	83
;----------------------------------------------------------------------
; 1563 | pLicVerDp->cvbBuf[i].chBuildDate[4] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [4];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r1
        mpyi      10,r1
        addi3     r1,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+fp(1),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar1      ; Unsigned
        ldiu      *+ar0(49),r0
        sti       r0,*+ar1(9)
	.line	84
;----------------------------------------------------------------------
; 1564 | pLicVerDp->cvbBuf[i].chBuildDate[5] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [5];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r1
        ldiu      r1,r0
        mpyi      10,r1
        mpyi      10,r0
        ldiu      281,ir0
        ldiu      279,ir1
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        addi3     r1,*+fp(ir1),ar1      ; Unsigned
        ldiu      *+ar0(50),r0
        sti       r0,*+ar1(10)
	.line	59
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      32,r0
        blt       L629
;*      Branch Occurs to L629 
L633:        
	.line	88
;----------------------------------------------------------------------
; 1568 | if(TWOBYTE_ASC2HEX(pCncsLicSd->sWaySide) == 0x01 && !m_LIC_CNCS_Tx_Flag
;     | ) // wayside on �˸�                                                   
;----------------------------------------------------------------------
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(29),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(30),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      1,r0
        subi      1,sp
        bne       L674
;*      Branch Occurs to L674 
        ldi       @_m_LIC_CNCS_Tx_Flag+0,r0
        bne       L674
;*      Branch Occurs to L674 
	.line	90
;----------------------------------------------------------------------
; 1570 | m_nCDT_FaultDataStFlag = 1;                                            
; 1572 | //2011_03_03 ����                                                      
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_nCDT_FaultDataStFlag+0
	.line	93
;----------------------------------------------------------------------
; 1573 | m_nFaultCnt = 0;                                                // ����
;     |  ������ 0���� �ʱ�ȭ.(Y.J �߰�);                                       
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nFaultCnt+0
	.line	94
;----------------------------------------------------------------------
; 1574 | memset((UCHAR *)NVSRAM_BASE,0x00,1024); // ���� ������ "0" ���� �ʽ�ȭ
;     | �Ѵ�. �ʱ� ��ġ 0���� 1024������ �ʱ�ȭ �Ѵ�.                          
;----------------------------------------------------------------------
        ldiu      1024,r2
        ldiu      @CL98,r1
        push      r2
        push      r0
        push      r1
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	95
;----------------------------------------------------------------------
; 1575 | ClearFltBlkInfo();                                              // ����
;     |  ������ Clear�ϴ� �κ�.                                                
; 1577 | //memset(aaa_FaultBlkList, 0xFF, 1024);                                
;----------------------------------------------------------------------
        call      _ClearFltBlkInfo
                                        ; Call Occurs
	.line	99
;----------------------------------------------------------------------
; 1579 | m_nNvsramPos = 0;       //��ü ��� ���� ��ġ�� ó������               
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nNvsramPos+0
	.line	100
;----------------------------------------------------------------------
; 1580 | nRecving_Posi = 0;      //���� ���� ������ ��ġ�� ó������             
;----------------------------------------------------------------------
        sti       r0,@_nRecving_Posi+0
	.line	101
;----------------------------------------------------------------------
; 1581 | m_nLnWkTxFlag = 0;      //���� �ڵ� ������ 0���� �ʱ�ȭ                
;----------------------------------------------------------------------
        sti       r0,@_m_nLnWkTxFlag+0
	.line	103
;----------------------------------------------------------------------
; 1583 | m_nLnWkTxFlag = TWOBYTE_ASC2HEX(pCncsLicSd->sDaType);                  
; 1585 | // ���� �ð� ��û WORD -> DWORD�� ����.(2011.05.08)                    
;----------------------------------------------------------------------
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(31),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(32),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        subi      1,sp
        sti       r0,@_m_nLnWkTxFlag+0
	.line	106
;----------------------------------------------------------------------
; 1586 | m_nDateTime2SecondCnt = MAKE_DWORD( MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->s
;     | FaultTime[0]),ConvAsc2Hex(pCncsLicSd->sFaultTime[1])),                 
; 1587 | 
;     |  MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->sFaultTime[2]),ConvAsc2Hex(pCncsLicS
;     | d->sFaultTime[3])),                                                    
; 1588 | 
;     |  MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->sFaultTime[4]),ConvAsc2Hex(pCncsLicS
;     | d->sFaultTime[5])),                                                    
; 1589 | 
;     |  MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->sFaultTime[6]),ConvAsc2Hex(pCncsLicS
;     | d->sFaultTime[7])));                                                   
;----------------------------------------------------------------------
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(33),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(34),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        and       15,r0
        ldiu      *+fp(ir0),ar0
        or3       r4,r0,r5
        ldiu      *+ar0(35),r0
        and       255,r5
        push      r0
        ash       24,r5
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(36),r0
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        and       15,r0
        or3       r4,r0,r1
        subi      1,sp
        and       255,r1
        ldiu      *+fp(ir0),ar0
        ash       16,r1
        ldiu      *+ar0(37),r0
        or3       r5,r1,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r5
        ldiu      *+ar0(38),r0
        ash       4,r5
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        and       15,r0
        or3       r5,r0,r1
        ldiu      *+fp(ir0),ar0
        and       255,r1
        ldiu      *+ar0(39),r0
        ash       8,r1
        or3       r4,r1,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r5
        ldiu      *+ar0(40),r0
        ash       4,r5
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r5,r0,r0
        and       255,r0
        or3       r4,r0,r0
        sti       r0,@_m_nDateTime2SecondCnt+0
        subi      1,sp
        bu        L674
;*      Branch Occurs to L674 
L637:        
	.line	112
;----------------------------------------------------------------------
; 1592 | else if(pCncs_Lic_T_F_C->phHdBuf.btSoh == SOH &&
;     |                                                                        
;     |                                           		// ���� �ð� ��û WORD -> D
;     | WORD�� ����.(2011.05.11)                                               
; 1593 |         pCncs_Lic_T_F_C->btEot == EOT &&                               
; 1594 |         sizeof(CNCS_LIC_T_F_C) == nRxPos &&                            
; 1595 |    (TWOBYTE_ASC2HEX(pCncs_Lic_T_F_C->phHdBuf.chDestDev) == m_chCarKindN
;     | um) &&                                                                 
; 1596 |    (TWOBYTE_ASC2HEX(pCncsLicSd->sCommand) == 0x07) &&  //���� ���� Ȯ��
;     |  ����(CNCS-> LIC)                                                      
; 1597 |    !((Make1ByteBcc(&pCncs_Lic_T_F_C->phHdBuf.chSrcDev[0],nRxPos-4)^(TWO
;     | BYTE_ASC2HEX(pCncs_Lic_T_F_C->chChkSum)))))                            
; 1599 |         // Y.J 2011-05-10 ��û�� ���� Index�� ����Ͽ�, �����ϵ��� ����
;     | .                                                                      
;----------------------------------------------------------------------
        ldiu      283,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *ar0,r0
        cmpi      1,r0
        bne       L674
;*      Branch Occurs to L674 
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(23),r0
        cmpi      4,r0
        bne       L674
;*      Branch Occurs to L674 
        ldiu      24,r0
        cmpi      @_nRxPos$10+0,r0
        bne       L674
;*      Branch Occurs to L674 
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      283,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(4),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      @_m_chCarKindNum+0,r0
        subi      1,sp
        bne       L674
;*      Branch Occurs to L674 
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(15),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(16),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      7,r0
        subi      1,sp
        bne       L674
;*      Branch Occurs to L674 
        ldiu      1,r1
        ldiu      283,ir0
        ldiu      4,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$10+0,r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        ldiu      283,ir0
        subi      2,sp
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(21),r1
        ldiu      r0,r5
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      283,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(22),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        xor3      r5,r0,r0
        subi      1,sp
        bne       L674
;*      Branch Occurs to L674 
	.line	120
;----------------------------------------------------------------------
; 1600 | sPotoLen = MAKE_WORD(MAKE_BYTE(ConvAsc2Hex(pCnsc_Lic_T_F->sTEXT[0]),Con
;     | vAsc2Hex(pCnsc_Lic_T_F->sTEXT[1])),                                    
; 1601 |                      MAKE_BYTE(ConvAsc2Hex(pCnsc_Lic_T_F->sTEXT[2]),Con
;     | vAsc2Hex(pCnsc_Lic_T_F->sTEXT[3])));                                   
;----------------------------------------------------------------------
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(17),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(18),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      282,ir0
        and       15,r0
        subi      1,sp
        or3       r4,r0,r5
        ldiu      *+fp(ir0),ar0
        and       255,r5
        ldiu      *+ar0(19),r0
        ash       8,r5
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(20),r0
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      269,ir0
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        or3       r5,r0,r0
        subi      1,sp
        and       65535,r0
        sti       r0,*+fp(ir0)
	.line	122
;----------------------------------------------------------------------
; 1602 | if(sPotoLen)                                                           
; 1604 |         // �������� ���� ���� ������ ����.                             
;----------------------------------------------------------------------
        ldi       *+fp(ir0),r0
        beq       L656
;*      Branch Occurs to L656 
	.line	125
;----------------------------------------------------------------------
; 1605 | pInfo = GetFltBlkInfo(m_chCarKind);                                    
;----------------------------------------------------------------------
        ldiu      @_m_chCarKind+0,r0
        push      r0
        call      _GetFltBlkInfo
                                        ; Call Occurs
        subi      1,sp
        ldiu      284,ir0
        sti       r0,*+fp(ir0)
	.line	127
;----------------------------------------------------------------------
; 1607 | if(pInfo != NULL)                                                      
; 1609 |         // ������ ���� ��ġ�� �̵�.                                    
;----------------------------------------------------------------------
        ldi       *+fp(ir0),r0
        beq       L655
;*      Branch Occurs to L655 
	.line	130
;----------------------------------------------------------------------
; 1610 | nRecving_Posi = pInfo->nStPosi + ((sPotoLen-1) * 128);                 
; 1612 | // ������ ���� ũ�⸦ ���ϴ� �κ�.                                     
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      269,ir0
        ldiu      284,ir1
        subi3     r0,*+fp(ir0),r0
        ldiu      *+fp(ir1),ar0
        mpyi      128,r0
        addi      *+ar0(1),r0
        sti       r0,@_nRecving_Posi+0
	.line	133
;----------------------------------------------------------------------
; 1613 | if(sPotoLen < pInfo->nTCnt) //  (sPotoLen*128) <= nTempBlkEnd)         
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        cmpi3     *ar0,*+fp(ir0)
        bged      L648
	nop
        ldige     284,ir1
        ldige     269,ir0
;*      Branch Occurs to L648 
	.line	135
;----------------------------------------------------------------------
; 1615 | nBlkSize = 128;                                                        
;----------------------------------------------------------------------
        ldiu      275,ir0
        ldiu      128,r0
        sti       r0,*+fp(ir0)
        bu        L652
;*      Branch Occurs to L652 
	.line	137
;----------------------------------------------------------------------
; 1617 | else if(sPotoLen == pInfo->nTCnt)                                      
;----------------------------------------------------------------------
L648:        
        ldiu      *+fp(ir1),ar0
        cmpi3     *ar0,*+fp(ir0)
        bned      L651
	nop
        ldine     275,ir0
        ldine     0,r0
;*      Branch Occurs to L651 
	.line	139
;----------------------------------------------------------------------
; 1619 | nBlkSize = (pInfo->nEdPosi - pInfo->nStPosi) % 128; // - ((sPotoLen - 1
;     | ) * 128);                                                              
; 1621 | else                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar1
        ldiu      284,ir0
        ldiu      2,ar0
        ldiu      *+fp(ir0),ir1
        subi3     *+ar1,*+ar0(ir1),r1
        ldiu      r1,r0
        ldiu      275,ir0
        ash       -6,r0
        lsh       @CL99,r0
        addi3     r0,r1,r0
        andn      127,r0
        subri     r1,r0
        sti       r0,*+fp(ir0)
        bu        L652
;*      Branch Occurs to L652 
	.line	143
;----------------------------------------------------------------------
; 1623 | nBlkSize = 0;                                                          
;----------------------------------------------------------------------
L651:        
        sti       r0,*+fp(ir0)
L652:        
	.line	146
;----------------------------------------------------------------------
; 1626 | if(nBlkSize < 0) nBlkSize = 0;                                         
; 1628 | // ������ ������ ��ġ�� ����.                                          
;----------------------------------------------------------------------
        ldiu      275,ir0
        ldi       *+fp(ir0),r0
        bge       L654
;*      Branch Occurs to L654 
        ldiu      0,r0
        sti       r0,*+fp(ir0)
L654:        
	.line	149
;----------------------------------------------------------------------
; 1629 | nTempBlkEnd = pInfo->nEdPosi;                                          
;----------------------------------------------------------------------
        ldiu      284,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      276,ir0
        ldiu      *+ar0(2),r0
        sti       r0,*+fp(ir0)
L655:        
	.line	152
;----------------------------------------------------------------------
; 1632 | sTxDataSize = nBlkSize + 2;                                            
; 1634 | // ���� �����͸� �����ϴ� �κ�.                                        
;----------------------------------------------------------------------
        ldiu      2,r0
        ldiu      275,ir1
        ldiu      277,ir0
        addi3     r0,*+fp(ir1),r0
        sti       r0,*+fp(ir0)
	.line	155
;----------------------------------------------------------------------
; 1635 | user_FaultDataTx(btTx2chBuf,sTxDataSize,TRUE,sPotoLen);                
;----------------------------------------------------------------------
        ldiu      269,ir1
        ldiu      1,r3
        ldiu      @CL100,r2

        ldiu      *+fp(ir1),r0
||      ldiu      *+fp(ir0),r1

        push      r0
        push      r3
        push      r1
        push      r2
        call      _user_FaultDataTx
                                        ; Call Occurs
        subi      4,sp
	.line	156
;----------------------------------------------------------------------
; 1636 | user_CncsTx(btTx2chBuf,(sTxDataSize*2)+18);                            
; 1638 | // ���� ��, ���� ��ġ�� ������ ��ġ�� ����.                            
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      2,r1
        mpyi3     r1,*+fp(ir0),r1
        addi      18,r1
        ldiu      @CL100,r0
        push      r1
        push      r0
        call      _user_CncsTx
                                        ; Call Occurs
        subi      2,sp
	.line	159
;----------------------------------------------------------------------
; 1639 | nRecving_Posi = nTempBlkEnd;                                           
; 1641 | else                                                                   
; 1642 | //�ٷ� ���� �ڵ尡 ���� �ɼ� �ִ�.                                     
;----------------------------------------------------------------------
        ldiu      276,ir0
        ldiu      *+fp(ir0),r0
        sti       r0,@_nRecving_Posi+0
        bu        L674
;*      Branch Occurs to L674 
L656:        
	.line	164
;----------------------------------------------------------------------
; 1644 | user_FtpEnd_CarNumFun();                                               
; 1648 | else // ����Ÿ ����                                                    
;----------------------------------------------------------------------
        call      _user_FtpEnd_CarNumFun
                                        ; Call Occurs
        bu        L674
;*      Branch Occurs to L674 
L657:        
	.line	170
;----------------------------------------------------------------------
; 1650 | if(m_nTxDbg1msTimer > 150)                                             
; 1652 |         //���� ���� ����.                                              
;----------------------------------------------------------------------
        ldiu      @_m_nTxDbg1msTimer+0,r0
        cmpi      150,r0
        bls       L674
;*      Branch Occurs to L674 
	.line	173
;----------------------------------------------------------------------
; 1653 | if(m_LIC_CNCS_Tx_Flag)                                                 
;----------------------------------------------------------------------
        ldi       @_m_LIC_CNCS_Tx_Flag+0,r0
        beq       L670
;*      Branch Occurs to L670 
	.line	175
;----------------------------------------------------------------------
; 1655 | m_nTxDbg1msTimer = 0;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nTxDbg1msTimer+0
	.line	177
;----------------------------------------------------------------------
; 1657 | m_LIC_CNCS_TX_DelyTime++;                                              
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_LIC_CNCS_TX_DelyTime+0,r0
        sti       r0,@_m_LIC_CNCS_TX_DelyTime+0
	.line	179
;----------------------------------------------------------------------
; 1659 | if(m_LIC_CNCS_TX_DelyTime > 50){m_bLnWkFtpEndFlag = TRUE;}             
;----------------------------------------------------------------------
        cmpi      50,r0
        ble       L661
;*      Branch Occurs to L661 
        ldiu      1,r0
        sti       r0,@_m_bLnWkFtpEndFlag+0
L661:        
	.line	181
;----------------------------------------------------------------------
; 1661 | if((m_nNvsramPos !=  (nRecving_Posi)) && (m_nNvsramPos >= (nRecving_Pos
;     | i+128)))                                                               
;----------------------------------------------------------------------
        ldiu      @_m_nNvsramPos+0,r0
        cmpi      @_nRecving_Posi+0,r0
        beqd      L666
	nop
        ldine     128,r0
        ldine     @_m_nNvsramPos+0,r1
;*      Branch Occurs to L666 
        addi      @_nRecving_Posi+0,r0  ; Unsigned
        cmpi3     r0,r1
        blo       L666
;*      Branch Occurs to L666 
	.line	183
;----------------------------------------------------------------------
; 1663 | m_nFaultCnt++;                                                         
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nFaultCnt+0,r0
        sti       r0,@_m_nFaultCnt+0
	.line	184
;----------------------------------------------------------------------
; 1664 | if(m_nFaultCnt == 1)                                                   
;----------------------------------------------------------------------
        cmpi      1,r0
        bne       L665
;*      Branch Occurs to L665 
	.line	185
;----------------------------------------------------------------------
; 1665 | SetFltBlkStPos(m_chCarKind, nRecving_Posi);
;     |                                          // ù��° ������ ���, ���� ��
;     | ���� ���� ��ġ�� ���.                                                 
;----------------------------------------------------------------------
        ldiu      @_nRecving_Posi+0,r0
        push      r0
        ldiu      @_m_chCarKind+0,r0
        push      r0
        call      _SetFltBlkStPos
                                        ; Call Occurs
        subi      2,sp
L665:        
	.line	187
;----------------------------------------------------------------------
; 1667 | sTxDataSize = 128 + 2;                                                 
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      130,r0
        sti       r0,*+fp(ir0)
	.line	189
;----------------------------------------------------------------------
; 1669 | user_FaultDataTx(btTx2chBuf,sTxDataSize,FALSE,0);                      
;----------------------------------------------------------------------
        ldiu      0,r1
        ldiu      @CL100,r2
        ldiu      *+fp(ir0),r3
        ldiu      0,r0
        push      r1
        push      r0
        push      r3
        push      r2
        call      _user_FaultDataTx
                                        ; Call Occurs
        subi      4,sp
	.line	191
;----------------------------------------------------------------------
; 1671 | nRecving_Posi += 128;                                                  
;----------------------------------------------------------------------
        ldiu      128,r0
        addi      @_nRecving_Posi+0,r0
        sti       r0,@_nRecving_Posi+0
	.line	193
;----------------------------------------------------------------------
; 1673 | user_CncsTx(btTx2chBuf,(sTxDataSize*2)+18);                            
; 1675 | else                                                                   
; 1676 | //�ٷ� ���� �ڵ尡 ���� �ɼ� �ִ�.                                     
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      2,r0
        mpyi3     r0,*+fp(ir0),r0
        addi      18,r0
        push      r0
        ldiu      @CL100,r1
        push      r1
        call      _user_CncsTx
                                        ; Call Occurs
        subi      2,sp
        bu        L674
;*      Branch Occurs to L674 
L666:        
	.line	197
;----------------------------------------------------------------------
; 1677 | if(m_bLnWkFtpEndFlag)                                                  
;----------------------------------------------------------------------
        ldi       @_m_bLnWkFtpEndFlag+0,r0
        beq       L674
;*      Branch Occurs to L674 
	.line	199
;----------------------------------------------------------------------
; 1679 | m_nFaultCnt++;                                                         
; 1680 | //aaa_CarAFautlCnt = m_nFaultCnt;                                      
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nFaultCnt+0,r0
        sti       r0,@_m_nFaultCnt+0
	.line	202
;----------------------------------------------------------------------
; 1682 | if(m_nFaultCnt == 1)                                                   
;----------------------------------------------------------------------
        cmpi      1,r0
        bne       L669
;*      Branch Occurs to L669 
	.line	203
;----------------------------------------------------------------------
; 1683 | SetFltBlkStPos(m_chCarKind, nRecving_Posi);
;     |                                          // ù��° ������ ���, ���� ��
;     | ���� ���� ��ġ�� ���.                                                 
; 1685 | // ���� ������ �����ϴ� �κ�.                                          
;----------------------------------------------------------------------
        ldiu      @_nRecving_Posi+0,r0
        push      r0
        ldiu      @_m_chCarKind+0,r0
        push      r0
        call      _SetFltBlkStPos
                                        ; Call Occurs
        subi      2,sp
L669:        
	.line	206
;----------------------------------------------------------------------
; 1686 | SetFltBlkEdInfo(m_chCarKind, m_nNvsramPos, m_nFaultCnt);               
;----------------------------------------------------------------------
        ldiu      @_m_nFaultCnt+0,r0
        ldiu      @_m_nNvsramPos+0,r1
        push      r0
        push      r1
        ldiu      @_m_chCarKind+0,r0
        push      r0
        call      _SetFltBlkEdInfo
                                        ; Call Occurs
        subi      3,sp
	.line	208
;----------------------------------------------------------------------
; 1688 | sTxDataSize = (m_nNvsramPos - nRecving_Posi) + 2;                      
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      @_nRecving_Posi+0,r0
        subri     @_m_nNvsramPos+0,r0   ; Unsigned
        addi      2,r0                  ; Unsigned
        sti       r0,*+fp(ir0)
	.line	209
;----------------------------------------------------------------------
; 1689 | user_FaultDataTx(btTx2chBuf,sTxDataSize,TRUE,0);                       
;----------------------------------------------------------------------
        ldiu      0,r1
        ldiu      @CL100,r2
        ldiu      *+fp(ir0),r3
        push      r1
        ldiu      1,r0
        push      r0
        push      r3
        push      r2
        call      _user_FaultDataTx
                                        ; Call Occurs
        subi      4,sp
	.line	210
;----------------------------------------------------------------------
; 1690 | nRecving_Posi += (sTxDataSize-2);                                      
; 1692 | // user_FtpEnd_CarNumFun();                                            
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      *+fp(ir0),r0
        addi      @_nRecving_Posi+0,r0
        subi      2,r0
        sti       r0,@_nRecving_Posi+0
	.line	214
;----------------------------------------------------------------------
; 1694 | user_CncsTx(btTx2chBuf,(sTxDataSize*2)+18);                            
;----------------------------------------------------------------------
        ldiu      2,r1
        mpyi3     r1,*+fp(ir0),r1
        addi      18,r1
        push      r1
        ldiu      @CL100,r0
        push      r0
        call      _user_CncsTx
                                        ; Call Occurs
        subi      2,sp
	.line	216
;----------------------------------------------------------------------
; 1696 | m_LIC_CNCS_Tx_Flag = FALSE;                                            
; 1699 | else                                                                   
; 1700 | //�ð� ���� ��û.                                                      
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_LIC_CNCS_Tx_Flag+0
        bu        L674
;*      Branch Occurs to L674 
L670:        
	.line	221
;----------------------------------------------------------------------
; 1701 | if(m_nTxDbg1msTimer > 1000)                                            
;----------------------------------------------------------------------
        ldiu      @_m_nTxDbg1msTimer+0,r0
        cmpi      1000,r0
        bls       L674
;*      Branch Occurs to L674 
	.line	223
;----------------------------------------------------------------------
; 1703 | m_nTxDbg1msTimer = 0;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nTxDbg1msTimer+0
	.line	225
;----------------------------------------------------------------------
; 1705 | nTimeSendCnt++;                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_nTimeSendCnt$14+0,r0
        sti       r0,@_nTimeSendCnt$14+0
	.line	226
;----------------------------------------------------------------------
; 1706 | nTimeSendCnt = nTimeSendCnt%255;                                       
;----------------------------------------------------------------------
        ldiu      255,r1
        call      MOD_I30
                                        ; Call Occurs
        sti       r0,@_nTimeSendCnt$14+0
	.line	228
;----------------------------------------------------------------------
; 1708 | pCnsc_Lic_T_F = (CNCS_LIC_T_F *) btTx2chBuf;                           
;----------------------------------------------------------------------
        ldiu      282,ir0
        ldiu      @CL100,r0
        sti       r0,*+fp(ir0)
	.line	230
;----------------------------------------------------------------------
; 1710 | sTxDataSize = 4;                                                       
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      4,r0
        sti       r0,*+fp(ir0)
	.line	232
;----------------------------------------------------------------------
; 1712 | pCnsc_Lic_T_F->phHdBuf.btSoh =  0x01;                                  
;----------------------------------------------------------------------
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      1,r0
        sti       r0,*ar0
	.line	233
;----------------------------------------------------------------------
; 1713 | pCnsc_Lic_T_F->phHdBuf.chSrcDev[0] =  ConvHex2Asc(BYTE_H(0x11));       
;----------------------------------------------------------------------
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(1)
	.line	234
;----------------------------------------------------------------------
; 1714 | pCnsc_Lic_T_F->phHdBuf.chSrcDev[1] =  ConvHex2Asc(BYTE_L(0x11));       
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(2)
	.line	235
;----------------------------------------------------------------------
; 1715 | pCnsc_Lic_T_F->phHdBuf.chDestDev[0] =  ConvHex2Asc(BYTE_H(0x15));      
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(3)
	.line	236
;----------------------------------------------------------------------
; 1716 | pCnsc_Lic_T_F->phHdBuf.chDestDev[1] =  ConvHex2Asc(BYTE_L(0x15));      
;----------------------------------------------------------------------
        ldiu      5,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(4)
	.line	238
;----------------------------------------------------------------------
; 1718 | pCnsc_Lic_T_F->phHdBuf.chMsgCnt[0] = ConvHex2Asc(BYTE_H(WORD_H(nTimeSen
;     | dCnt)));                                                               
;----------------------------------------------------------------------
        ldiu      @_nTimeSendCnt$14+0,r0
        ash       -8,r0
        and       255,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(5)
	.line	239
;----------------------------------------------------------------------
; 1719 | pCnsc_Lic_T_F->phHdBuf.chMsgCnt[1] = ConvHex2Asc(BYTE_L(WORD_H(nTimeSen
;     | dCnt)));                                                               
;----------------------------------------------------------------------
        ldiu      @_nTimeSendCnt$14+0,r0
        ash       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(6)
	.line	240
;----------------------------------------------------------------------
; 1720 | pCnsc_Lic_T_F->phHdBuf.chMsgCnt[2] = ConvHex2Asc(BYTE_H(WORD_L(nTimeSen
;     | dCnt)));                                                               
;----------------------------------------------------------------------
        ldiu      255,r0
        and       @_nTimeSendCnt$14+0,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(7)
	.line	241
;----------------------------------------------------------------------
; 1721 | pCnsc_Lic_T_F->phHdBuf.chMsgCnt[3] = ConvHex2Asc(BYTE_L(WORD_L(nTimeSen
;     | dCnt)));                                                               
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_nTimeSendCnt$14+0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(8)
	.line	243
;----------------------------------------------------------------------
; 1723 | pCnsc_Lic_T_F->phHdBuf.chCmdCode[0] = ConvHex2Asc(BYTE_H(0x10));       
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(9)
	.line	244
;----------------------------------------------------------------------
; 1724 | pCnsc_Lic_T_F->phHdBuf.chCmdCode[1] = ConvHex2Asc(BYTE_L(0x10));       
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(10)
	.line	246
;----------------------------------------------------------------------
; 1726 | pCnsc_Lic_T_F->phHdBuf.chDataLen[0] = ConvHex2Asc(BYTE_H(WORD_H(sTxData
;     | Size))); // ����                                                       
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      -8,r0
        ash3      r0,*+fp(ir0),r0
        and       255,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(11)
	.line	247
;----------------------------------------------------------------------
; 1727 | pCnsc_Lic_T_F->phHdBuf.chDataLen[1] = ConvHex2Asc(BYTE_L(WORD_H(sTxData
;     | Size))); // ����                                                       
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      -8,r0
        ash3      r0,*+fp(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(12)
	.line	248
;----------------------------------------------------------------------
; 1728 | pCnsc_Lic_T_F->phHdBuf.chDataLen[2] = ConvHex2Asc(BYTE_H(WORD_L(sTxData
;     | Size))); // ����                                                       
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      255,r0
        and3      r0,*+fp(ir0),r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(13)
	.line	249
;----------------------------------------------------------------------
; 1729 | pCnsc_Lic_T_F->phHdBuf.chDataLen[3] = ConvHex2Asc(BYTE_L(WORD_L(sTxData
;     | Size))); // ����                                                       
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      15,r0
        and3      r0,*+fp(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(14)
	.line	251
;----------------------------------------------------------------------
; 1731 | pCnsc_Lic_T_F->sCommand[0] = ConvHex2Asc(BYTE_H(0x08));                
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(15)
	.line	252
;----------------------------------------------------------------------
; 1732 | pCnsc_Lic_T_F->sCommand[1] = ConvHex2Asc(BYTE_L(0x08));                
;----------------------------------------------------------------------
        ldiu      8,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(16)
	.line	254
;----------------------------------------------------------------------
; 1734 | pCnsc_Lic_T_F->sTEXT[0] = ConvHex2Asc(BYTE_H(WORD_H(m_nCarNo)));  //���
;     | � ��ȣ ����                                                            
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+0,r0
        lsh       -8,r0
        and       255,r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(17)
	.line	255
;----------------------------------------------------------------------
; 1735 | pCnsc_Lic_T_F->sTEXT[1] = ConvHex2Asc(BYTE_L(WORD_H(m_nCarNo)));  //���
;     | � ��ȣ ����                                                            
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+0,r0
        lsh       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(18)
	.line	256
;----------------------------------------------------------------------
; 1736 | pCnsc_Lic_T_F->sTEXT[2] = ConvHex2Asc(BYTE_H(WORD_L(m_nCarNo)));  //���
;     | � ��ȣ ����                                                            
;----------------------------------------------------------------------
        ldiu      255,r0
        and       @_m_nCarNo+0,r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(19)
	.line	257
;----------------------------------------------------------------------
; 1737 | pCnsc_Lic_T_F->sTEXT[3] = ConvHex2Asc(BYTE_L(WORD_L(m_nCarNo)));  //���
;     | � ��ȣ ����                                                            
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_m_nCarNo+0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(20)
	.line	259
;----------------------------------------------------------------------
; 1739 | pCnsc_Lic_T_F->chContactSignalBuf[0] = ConvHex2Asc(BYTE_H(m_btCttSignal
;     | A | m_btCttSignalB));                                                  
;----------------------------------------------------------------------
        ldiu      @_m_btCttSignalB+0,r0
        or        @_m_btCttSignalA+0,r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(21)
	.line	260
;----------------------------------------------------------------------
; 1740 | pCnsc_Lic_T_F->chContactSignalBuf[1] = ConvHex2Asc(BYTE_L(m_btCttSignal
;     | A | m_btCttSignalB));                                                  
;----------------------------------------------------------------------
        ldiu      @_m_btCttSignalB+0,r0
        or        @_m_btCttSignalA+0,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(22)
	.line	262
;----------------------------------------------------------------------
; 1742 | sBcc = Make1ByteBcc(&pCnsc_Lic_T_F->phHdBuf.chSrcDev[0],(sTxDataSize*2)
;     | +14);                                                                  
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      2,r0
        ldiu      277,ir1
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        mpyi3     r0,*+fp(ir1),r0
        addi      14,r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        ldiu      270,ir0
        subi      2,sp
        sti       r0,*+fp(ir0)
	.line	264
;----------------------------------------------------------------------
; 1744 | pCnsc_Lic_T_F->chChkSum[0] = ConvHex2Asc(BYTE_H(sBcc));                
;----------------------------------------------------------------------
        ldiu      -4,r0
        lsh3      r0,*+fp(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(23)
	.line	265
;----------------------------------------------------------------------
; 1745 | pCnsc_Lic_T_F->chChkSum[1] = ConvHex2Asc(BYTE_L(sBcc));                
;----------------------------------------------------------------------
        ldiu      270,ir0
        ldiu      15,r0
        and3      r0,*+fp(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(24)
	.line	267
;----------------------------------------------------------------------
; 1747 | pCnsc_Lic_T_F->btEot = 0x04;                                           
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      4,r0
        sti       r0,*+ar0(25)
	.line	269
;----------------------------------------------------------------------
; 1749 | user_CncsTx(&pCnsc_Lic_T_F->phHdBuf.btSoh,(sTxDataSize*2)+18);         
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      2,r0
        mpyi3     r0,*+fp(ir0),r0
        addi      18,r0
        ldiu      282,ir1
        push      r0
        ldiu      *+fp(ir1),r0
        push      r0
        call      _user_CncsTx
                                        ; Call Occurs
        subi      2,sp
L674:        
	.line	274
;----------------------------------------------------------------------
; 1754 | nOldUart2RxOneByteGapDelayTime = m_nUart2RxOneByteGapDelayTime;        
;----------------------------------------------------------------------
        ldiu      @_m_nUart2RxOneByteGapDelayTime+0,r0
        sti       r0,@_nOldUart2RxOneByteGapDelayTime$11+0
	.line	275
        pop       r5
        ldiu      *-fp(1),bk
        pop       r4
        ldiu      *fp,fp
        subi      286,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1755,000000030h,284


	.sect	 ".text"

	.global	_ClearFltBlkInfo
	.sym	_ClearFltBlkInfo,_ClearFltBlkInfo,32,2,0
	.func	1758
;******************************************************************************
;* FUNCTION NAME: _ClearFltBlkInfo                                            *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,fp,sp                                      *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 0 Auto + 0 SOE = 2 words          *
;******************************************************************************
_ClearFltBlkInfo:
	.line	1
;----------------------------------------------------------------------
; 1758 | void ClearFltBlkInfo()                                                 
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	3
;----------------------------------------------------------------------
; 1760 | memset(&m_tFaultInfo, 0x00, sizeof(m_tFaultInfo));
;     |  // ���� ���� ����.                                                    
;----------------------------------------------------------------------
        ldiu      6,r2
        ldiu      0,r0
        ldiu      @CL101,r1
        push      r2
        push      r0
        push      r1
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1761,000000000h,0


	.sect	 ".text"

	.global	_SetFltBlkStPos
	.sym	_SetFltBlkStPos,_SetFltBlkStPos,32,2,0
	.func	1764
;******************************************************************************
;* FUNCTION NAME: _SetFltBlkStPos                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,ar0,fp,sp,st                                     *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 1 Auto + 0 SOE = 5 words          *
;******************************************************************************
_SetFltBlkStPos:
	.sym	_chCarKind,-2,2,9,32
	.sym	_nStPosi,-3,4,9,32
	.sym	_pInfo,1,24,1,32,.fake74
	.line	1
;----------------------------------------------------------------------
; 1764 | void SetFltBlkStPos(char chCarKind, int nStPosi)                       
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      1,sp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 1766 | PFAULT_INFO pInfo = GetFltBlkInfo(chCarKind);                          
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        push      r0
        call      _GetFltBlkInfo
                                        ; Call Occurs
        subi      1,sp
        sti       r0,*+fp(1)
	.line	5
;----------------------------------------------------------------------
; 1768 | if(pInfo != NULL)                                                      
;----------------------------------------------------------------------
        cmpi      0,r0
        beq       L682
;*      Branch Occurs to L682 
	.line	6
;----------------------------------------------------------------------
; 1769 | pInfo->nStPosi = nStPosi;
;     |                  // ���� ���� ��ġ�� ����.                             
;----------------------------------------------------------------------
        ldiu      r0,ar0
        ldiu      *-fp(3),r0
        sti       r0,*+ar0(1)
L682:        
	.line	7
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      3,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1770,000000000h,1


	.sect	 ".text"

	.global	_SetFltBlkEdInfo
	.sym	_SetFltBlkEdInfo,_SetFltBlkEdInfo,32,2,0
	.func	1773
;******************************************************************************
;* FUNCTION NAME: _SetFltBlkEdInfo                                            *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,ar0,fp,sp,st                                     *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 3 Parm + 1 Auto + 0 SOE = 6 words          *
;******************************************************************************
_SetFltBlkEdInfo:
	.sym	_chCarKind,-2,2,9,32
	.sym	_nEndPosi,-3,4,9,32
	.sym	_nFltTCnt,-4,4,9,32
	.sym	_pInfo,1,24,1,32,.fake74
	.line	1
;----------------------------------------------------------------------
; 1773 | void SetFltBlkEdInfo(char chCarKind, int nEndPosi, int nFltTCnt)       
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      1,sp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 1775 | PFAULT_INFO pInfo = GetFltBlkInfo(chCarKind);                          
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        push      r0
        call      _GetFltBlkInfo
                                        ; Call Occurs
        subi      1,sp
        sti       r0,*+fp(1)
	.line	5
;----------------------------------------------------------------------
; 1777 | if(pInfo != NULL)                                                      
;----------------------------------------------------------------------
        cmpi      0,r0
        beq       L686
;*      Branch Occurs to L686 
	.line	7
;----------------------------------------------------------------------
; 1779 | pInfo->nTCnt = nFltTCnt;
;     |                          // ���� ��ü ������ ���.                     
;----------------------------------------------------------------------
        ldiu      r0,ar0
        ldiu      *-fp(4),r0
        sti       r0,*ar0
	.line	8
;----------------------------------------------------------------------
; 1780 | pInfo->nEdPosi = nEndPosi;
;     |                          // ���� ������ ��ġ�� ����.                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        ldiu      *-fp(3),r0
        sti       r0,*+ar0(2)
L686:        
	.line	10
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      3,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1782,000000000h,1


	.sect	 ".text"

	.global	_GetFltBlkInfo
	.sym	_GetFltBlkInfo,_GetFltBlkInfo,104,2,0,.fake74
	.func	1785
;******************************************************************************
;* FUNCTION NAME: _GetFltBlkInfo                                              *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,st                                               *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 1 Parm + 1 Auto + 0 SOE = 4 words          *
;******************************************************************************
_GetFltBlkInfo:
	.sym	_chCarKind,-2,2,9,32
	.sym	_nIdx,1,4,1,32
	.line	1
;----------------------------------------------------------------------
; 1785 | PFAULT_INFO GetFltBlkInfo(char chCarKind)                              
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      1,sp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 1787 | int nIdx = chCarKind - 'A';                                            
;----------------------------------------------------------------------
        ldiu      65,r0
        subri     *-fp(2),r0
        sti       r0,*+fp(1)
	.line	5
;----------------------------------------------------------------------
; 1789 | if(nIdx < eCDT_MAXIMUM)                                                
;----------------------------------------------------------------------
        cmpi      2,r0
        bge       L690
;*      Branch Occurs to L690 
	.line	6
;----------------------------------------------------------------------
; 1790 | return &m_tFaultInfo[nIdx];                                            
;----------------------------------------------------------------------
        bud       L691
	nop
        mpyi      3,r0
        addi      @CL101,r0             ; Unsigned
;*      Branch Occurs to L691 
L690:        
	.line	8
;----------------------------------------------------------------------
; 1792 | return NULL;                                                           
;----------------------------------------------------------------------
        ldiu      0,r0
L691:        
	.line	9
        ldiu      *-fp(1),r1
        ldiu      *fp,fp
        subi      3,sp
        bu        r1
;*      Branch Occurs to r1 
	.endfunc	1793,000000000h,1


	.sect	 ".text"

	.global	_GetFltBlkStPos
	.sym	_GetFltBlkStPos,_GetFltBlkStPos,36,2,0
	.func	1796
;******************************************************************************
;* FUNCTION NAME: _GetFltBlkStPos                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,ar0,fp,sp,st                                     *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 1 Parm + 2 Auto + 0 SOE = 5 words          *
;******************************************************************************
_GetFltBlkStPos:
	.sym	_chCarKind,-2,2,9,32
	.sym	_nStPos,1,4,1,32
	.sym	_pInfo,2,24,1,32,.fake74
	.line	1
;----------------------------------------------------------------------
; 1796 | int GetFltBlkStPos(char chCarKind)                                     
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      2,sp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 1798 | int nStPos = -1;                                                       
;----------------------------------------------------------------------
        ldiu      -1,r0
        sti       r0,*+fp(1)
	.line	4
;----------------------------------------------------------------------
; 1799 | PFAULT_INFO pInfo = GetFltBlkInfo(chCarKind);                          
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        push      r0
        call      _GetFltBlkInfo
                                        ; Call Occurs
        subi      1,sp
        sti       r0,*+fp(2)
	.line	6
;----------------------------------------------------------------------
; 1801 | if(pInfo != NULL)                                                      
;----------------------------------------------------------------------
        cmpi      0,r0
        beq       L695
;*      Branch Occurs to L695 
	.line	7
;----------------------------------------------------------------------
; 1802 | nStPos = pInfo->nStPosi;                                               
;----------------------------------------------------------------------
        ldiu      r0,ar0
        ldiu      *+ar0(1),r0
        sti       r0,*+fp(1)
L695:        
	.line	9
;----------------------------------------------------------------------
; 1804 | return nStPos;                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
	.line	10
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      4,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1805,000000000h,2


	.sect	 ".text"

	.global	_user_FaultDataTx
	.sym	_user_FaultDataTx,_user_FaultDataTx,32,2,0
	.func	1807
;******************************************************************************
;* FUNCTION NAME: _user_FaultDataTx                                           *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,ar0,fp,sp,st                               *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 4 Parm + 3 Auto + 0 SOE = 9 words          *
;******************************************************************************
_user_FaultDataTx:
	.sym	_pTxBuf,-2,28,9,32
	.sym	_nLen,-3,12,9,32
	.sym	_nEndFlag,-4,12,9,32
	.sym	_nFltIdx,-5,4,9,32
	.sym	_sTempData,1,12,1,32
	.sym	_pLic_Cncs,2,24,1,32,.fake44
	.sym	_pNvsram,3,28,1,32
	.line	1
;----------------------------------------------------------------------
; 1807 | void user_FaultDataTx(UCHAR *pTxBuf,UCHAR nLen,UCHAR nEndFlag,int nFltI
;     | dx)                                                                    
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      3,sp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 1809 | UCHAR sTempData = 0;                                                   
; 1810 | PLIC_CNCS_HD pLic_Cncs;                                                
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
	.line	5
;----------------------------------------------------------------------
; 1811 | UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;                                 
;----------------------------------------------------------------------
        ldiu      @CL81,r0
        sti       r0,*+fp(3)
	.line	7
;----------------------------------------------------------------------
; 1813 | pLic_Cncs =(LIC_CNCS_HD *) pTxBuf;                                     
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        sti       r0,*+fp(2)
	.line	9
;----------------------------------------------------------------------
; 1815 | pLic_Cncs->phHdBuf.btSoh = 0x01;                                       
;----------------------------------------------------------------------
        ldiu      r0,ar0
        ldiu      1,r0
        sti       r0,*ar0
	.line	10
;----------------------------------------------------------------------
; 1816 | pLic_Cncs->phHdBuf.chSrcDev[0] =  ConvHex2Asc(BYTE_H(0x11));           
;----------------------------------------------------------------------
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(1)
	.line	11
;----------------------------------------------------------------------
; 1817 | pLic_Cncs->phHdBuf.chSrcDev[1] =  ConvHex2Asc(BYTE_L(0x11));           
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(2)
	.line	12
;----------------------------------------------------------------------
; 1818 | pLic_Cncs->phHdBuf.chDestDev[0] =  ConvHex2Asc(BYTE_H(0x15));          
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(3)
	.line	13
;----------------------------------------------------------------------
; 1819 | pLic_Cncs->phHdBuf.chDestDev[1] =  ConvHex2Asc(BYTE_L(0x15));          
; 1821 | // ���� �ε����� �űԷ� ����(Y.J ����)                                 
;----------------------------------------------------------------------
        ldiu      5,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(4)
	.line	16
;----------------------------------------------------------------------
; 1822 | if(!nFltIdx) nFltIdx = m_nFaultCnt;                                    
;----------------------------------------------------------------------
        ldi       *-fp(5),r0
        bne       L700
;*      Branch Occurs to L700 
        ldiu      @_m_nFaultCnt+0,r0
        sti       r0,*-fp(5)
L700:        
	.line	18
;----------------------------------------------------------------------
; 1824 | pLic_Cncs->phHdBuf.chMsgCnt[0] = ConvHex2Asc(BYTE_H(WORD_H(nFltIdx))); 
;----------------------------------------------------------------------
        ldiu      *-fp(5),r0
        ash       -8,r0
        and       255,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(5)
	.line	19
;----------------------------------------------------------------------
; 1825 | pLic_Cncs->phHdBuf.chMsgCnt[1] = ConvHex2Asc(BYTE_L(WORD_H(nFltIdx))); 
;----------------------------------------------------------------------
        ldiu      *-fp(5),r0
        ash       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(6)
	.line	20
;----------------------------------------------------------------------
; 1826 | pLic_Cncs->phHdBuf.chMsgCnt[2] = ConvHex2Asc(BYTE_H(WORD_L(nFltIdx))); 
;----------------------------------------------------------------------
        ldiu      255,r0
        and       *-fp(5),r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(7)
	.line	21
;----------------------------------------------------------------------
; 1827 | pLic_Cncs->phHdBuf.chMsgCnt[3] = ConvHex2Asc(BYTE_L(WORD_L(nFltIdx))); 
;----------------------------------------------------------------------
        ldiu      15,r0
        and       *-fp(5),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(8)
	.line	23
;----------------------------------------------------------------------
; 1829 | pLic_Cncs->phHdBuf.chCmdCode[0] = ConvHex2Asc(BYTE_H(0x10));           
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(9)
	.line	24
;----------------------------------------------------------------------
; 1830 | pLic_Cncs->phHdBuf.chCmdCode[1] = ConvHex2Asc(BYTE_L(0x10));           
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(10)
	.line	26
;----------------------------------------------------------------------
; 1832 | pLic_Cncs->phHdBuf.chDataLen[0] = ConvHex2Asc(BYTE_H(WORD_H(nLen)));   
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        lsh       -8,r0
        and       255,r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(11)
	.line	27
;----------------------------------------------------------------------
; 1833 | pLic_Cncs->phHdBuf.chDataLen[1] = ConvHex2Asc(BYTE_L(WORD_H(nLen)));   
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        lsh       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(12)
	.line	28
;----------------------------------------------------------------------
; 1834 | pLic_Cncs->phHdBuf.chDataLen[2] = ConvHex2Asc(BYTE_H(WORD_L(nLen)));   
;----------------------------------------------------------------------
        ldiu      255,r0
        and       *-fp(3),r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(13)
	.line	29
;----------------------------------------------------------------------
; 1835 | pLic_Cncs->phHdBuf.chDataLen[3] = ConvHex2Asc(BYTE_L(WORD_L(nLen)));   
;----------------------------------------------------------------------
        ldiu      15,r0
        and       *-fp(3),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(14)
	.line	31
;----------------------------------------------------------------------
; 1837 | if(nEndFlag)                                                           
;----------------------------------------------------------------------
        ldi       *-fp(4),r0
        beq       L702
;*      Branch Occurs to L702 
	.line	33
;----------------------------------------------------------------------
; 1839 | pLic_Cncs->sCommand[0] = ConvHex2Asc(BYTE_H(0x06));//���� ���� ���� ��.
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(15)
	.line	34
;----------------------------------------------------------------------
; 1840 | pLic_Cncs->sCommand[1] = ConvHex2Asc(BYTE_L(0x06));//���� ���� ���� ��.
; 1842 | else                                                                   
;----------------------------------------------------------------------
        ldiu      6,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(16)
        bu        L703
;*      Branch Occurs to L703 
L702:        
	.line	38
;----------------------------------------------------------------------
; 1844 | pLic_Cncs->sCommand[0] = ConvHex2Asc(BYTE_H(0x04));//���� ���� ���� ��.
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(15)
	.line	39
;----------------------------------------------------------------------
; 1845 | pLic_Cncs->sCommand[1] = ConvHex2Asc(BYTE_L(0x04));//���� ���� ���� ��.
;----------------------------------------------------------------------
        ldiu      4,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(16)
L703:        
	.line	42
;----------------------------------------------------------------------
; 1848 | pLic_Cncs->sCarKind[0] = ConvHex2Asc(BYTE_H(m_chCarKind));             
;----------------------------------------------------------------------
        ldiu      @_m_chCarKind+0,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(17)
	.line	43
;----------------------------------------------------------------------
; 1849 | pLic_Cncs->sCarKind[1] = ConvHex2Asc(BYTE_L(m_chCarKind));             
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_m_chCarKind+0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(18)
	.line	45
;----------------------------------------------------------------------
; 1851 | FunConvHexAsc(&pNvsram[nRecving_Posi],(char *)pLic_Cncs->sTextDataAsc,(
;     | nLen-2));                                                              
;----------------------------------------------------------------------
        ldiu      19,r2
        ldiu      @_nRecving_Posi+0,r1
        addi      *+fp(3),r1            ; Unsigned
        ldiu      2,r0
        addi      *+fp(2),r2            ; Unsigned
        subri     *-fp(3),r0            ; Unsigned
        push      r0
        push      r2
        push      r1
        call      _FunConvHexAsc
                                        ; Call Occurs
        subi      3,sp
	.line	47
;----------------------------------------------------------------------
; 1853 | sTempData = Make1ByteBcc(&pLic_Cncs->phHdBuf.chSrcDev[0],(nLen*2)+14); 
;----------------------------------------------------------------------
        ldiu      1,r1
        addi      *+fp(2),r1            ; Unsigned
        ldiu      *-fp(3),r0
        mpyi      2,r0
        addi      14,r0                 ; Unsigned
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(1)
	.line	49
;----------------------------------------------------------------------
; 1855 | pLic_Cncs->sTextDataAsc[((nLen-2)*2)] = ConvHex2Asc(BYTE_H(sTempData));
;----------------------------------------------------------------------
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      2,ar0
        subri     *-fp(3),ar0           ; Unsigned
        mpyi      2,ar0
        addi      *+fp(2),ar0           ; Unsigned
        sti       r0,*+ar0(19)
	.line	50
;----------------------------------------------------------------------
; 1856 | pLic_Cncs->sTextDataAsc[((nLen-2)*2)+1] = ConvHex2Asc(BYTE_L(sTempData)
;     | );                                                                     
;----------------------------------------------------------------------
        ldiu      15,r0
        and       *+fp(1),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      2,ar0
        subri     *-fp(3),ar0           ; Unsigned
        mpyi      2,ar0
        addi      *+fp(2),ar0           ; Unsigned
        sti       r0,*+ar0(20)
	.line	52
;----------------------------------------------------------------------
; 1858 | pLic_Cncs->sTextDataAsc[((nLen-2)*2)+2] = 0x04;                        
;----------------------------------------------------------------------
        ldiu      2,ar0
        subri     *-fp(3),ar0           ; Unsigned
        mpyi      2,ar0
        addi      *+fp(2),ar0           ; Unsigned
        ldiu      4,r0
        sti       r0,*+ar0(21)
	.line	54
;----------------------------------------------------------------------
; 1860 | m_LIC_CNCS_TX_DelyTime = 0;                                            
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_LIC_CNCS_TX_DelyTime+0
	.line	55
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      5,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1861,000000000h,3


	.sect	 ".text"

	.global	_user_FtpEnd_CarNumFun
	.sym	_user_FtpEnd_CarNumFun,_user_FtpEnd_CarNumFun,32,2,0
	.func	1866
;******************************************************************************
;* FUNCTION NAME: _user_FtpEnd_CarNumFun                                      *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0                                                  *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 0 Auto + 0 SOE = 2 words          *
;******************************************************************************
_user_FtpEnd_CarNumFun:
	.line	1
;----------------------------------------------------------------------
; 1866 | void user_FtpEnd_CarNumFun()                                           
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	3
;----------------------------------------------------------------------
; 1868 | m_bLnWkFtpEndFlag = FALSE;                                             
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_bLnWkFtpEndFlag+0
	.line	5
;----------------------------------------------------------------------
; 1870 | m_LIC_CNCS_Tx_Flag = FALSE; //���� ���� ������ ���� �̹Ƿ� ���� ��.    
;----------------------------------------------------------------------
        sti       r0,@_m_LIC_CNCS_Tx_Flag+0
	.line	6
;----------------------------------------------------------------------
; 1871 | m_nNvsramPos = 0;                                                      
;----------------------------------------------------------------------
        sti       r0,@_m_nNvsramPos+0
	.line	7
;----------------------------------------------------------------------
; 1872 | nRecving_Posi = 0;                                                     
;----------------------------------------------------------------------
        sti       r0,@_nRecving_Posi+0
	.line	8
;----------------------------------------------------------------------
; 1873 | m_nLnWkWaySideOnRxOk = 0;                                              
;----------------------------------------------------------------------
        sti       r0,@_m_nLnWkWaySideOnRxOk+0
	.line	9
;----------------------------------------------------------------------
; 1874 | m_nFaultCnt = 0;                                                       
; 1875 | //m_chCarKind = 'A';                                                   
;----------------------------------------------------------------------
        sti       r0,@_m_nFaultCnt+0
	.line	11
;----------------------------------------------------------------------
; 1876 | m_nLnWkTxFlag = 0;                                                     
;----------------------------------------------------------------------
        sti       r0,@_m_nLnWkTxFlag+0
	.line	52
        ldiu      *-fp(1),r1
        ldiu      *fp,fp
        subi      2,sp
        bu        r1
;*      Branch Occurs to r1 
	.endfunc	1917,000000000h,0



	.sect	".cinit"
	.field  	1,32
	.field  	_d_CI_Fault+0,32
	.field  	0,32		; _d_CI_Fault @ 0

	.sect	".text"

	.global	_d_CI_Fault
	.bss	_d_CI_Fault,1
	.sym	_d_CI_Fault,_d_CI_Fault,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_CI_Index+0,32
	.field  	0,32		; _d_CI_Index @ 0

	.sect	".text"

	.global	_d_CI_Index
	.bss	_d_CI_Index,1
	.sym	_d_CI_Index,_d_CI_Index,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_nRxPos$15+0,32
	.field  	0,32		; _nRxPos$15 @ 0

	.sect	".text"

	.sect	".cinit"
	.field  	1,32
	.field  	_nOldUart3RxOneByteGapDelayTime$16+0,32
	.field  	0,32		; _nOldUart3RxOneByteGapDelayTime$16 @ 0

	.sect	".text"
	.sect	 ".text"

	.global	_user_WithPacRs485Loop
	.sym	_user_WithPacRs485Loop,_user_WithPacRs485Loop,32,2,0
	.func	1924
;******************************************************************************
;* FUNCTION NAME: _user_WithPacRs485Loop                                      *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,r4,ar0,ar1,fp,ir0,ir1,sp,st,rs,re,rc       *
;*   Regs Saved         : r4                                                  *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 391 Auto + 1 SOE = 394 words      *
;******************************************************************************
_user_WithPacRs485Loop:
	.bss	_nRxPos$15,1
	.sym	_nRxPos,_nRxPos$15,4,3,32
	.bss	_nOldUart3RxOneByteGapDelayTime$16,1
	.sym	_nOldUart3RxOneByteGapDelayTime,_nOldUart3RxOneByteGapDelayTime$16,12,3,32
	.bss	_btRx3chBuf$17,256
	.sym	_btRx3chBuf,_btRx3chBuf$17,60,3,8192,,256
	.sym	_i,1,4,1,32
	.sym	_nRxLen,2,4,1,32
	.sym	_nCciCnt,3,4,1,32
	.sym	_btTmp,4,12,1,32
	.sym	_btTmpBuf,5,60,1,3200,,100
	.sym	_btBuf,105,60,1,8192,,256
	.sym	_pLnWkDp,361,24,1,32,.fake13
	.sym	_pPaSdrBuf,362,24,1,32,.fake16
	.sym	_lsLicSdBuf,363,8,1,768,.fake38
	.sym	_pPa_PaBuf,387,24,1,32,.fake36
	.sym	_pCcp_Pac,388,24,1,32,.fake37
	.sym	_pPac_Pac_Sta,389,24,1,32,.fake17
	.sym	_pCommStatus,390,24,1,32,.fake52
	.sym	_pCommStatus_Lic,391,24,1,32,.fake60
	.line	1
;----------------------------------------------------------------------
; 1924 | void user_WithPacRs485Loop()                                           
; 1926 | int i;                                                                 
; 1927 | int nRxLen;                                                            
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      391,sp
        push      r4
	.line	5
;----------------------------------------------------------------------
; 1928 | int nCciCnt = 0;                                                       
; 1929 | UCHAR btTmp;                                                           
; 1930 | UCHAR btTmpBuf[100];                                                   
; 1931 | UCHAR btBuf[256];                                                      
; 1932 | static int nRxPos = 0;                                                 
; 1933 | static UCHAR nOldUart3RxOneByteGapDelayTime = 0;                       
; 1934 | static UCHAR btRx3chBuf[256];                                          
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(3)
	.line	12
;----------------------------------------------------------------------
; 1935 | PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;                                
; 1937 | PPACSDR pPaSdrBuf;                                                     
; 1938 | LICSD lsLicSdBuf;                                                      
; 1939 | PPAC_PAC pPa_PaBuf;                                                    
; 1941 | PCCP_PAC pCcp_Pac;                                                     
; 1943 | PCRA_STATION pPac_Pac_Sta;                                             
; 1945 | PCOMMSTATUS_PA pCommStatus;                                            
; 1946 | PCOMMSTATUS_LIC pCommStatus_Lic;                                       
; 1948 | // ����                                                                
;----------------------------------------------------------------------
        ldiu      361,ir0
        ldiu      @CL14,r0
        sti       r0,*+fp(ir0)
	.line	26
;----------------------------------------------------------------------
; 1949 | nRxLen = user_PacRx(btBuf,128);                                        
;----------------------------------------------------------------------
        ldiu      128,r1
        ldiu      fp,r0
        push      r1
        addi      105,r0
        push      r0
        call      _user_PacRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(2)
	.line	27
;----------------------------------------------------------------------
; 1950 | if(nRxLen)                                                             
;----------------------------------------------------------------------
        cmpi      0,r0
        beq       L714
;*      Branch Occurs to L714 
	.line	29
;----------------------------------------------------------------------
; 1952 | if(!m_nUart3RxOneByteGapDelayTime) nRxPos = 0;                         
;----------------------------------------------------------------------
        ldi       @_m_nUart3RxOneByteGapDelayTime+0,r0
        bne       L712
;*      Branch Occurs to L712 
        ldiu      0,r0
        sti       r0,@_nRxPos$15+0
L712:        
	.line	30
;----------------------------------------------------------------------
; 1953 | m_nUart3RxOneByteGapDelayTime = 3;                                     
;----------------------------------------------------------------------
        ldiu      3,r0
        sti       r0,@_m_nUart3RxOneByteGapDelayTime+0
	.line	32
;----------------------------------------------------------------------
; 1955 | if(nRxPos + nRxLen < 250)                                              
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        addi      @_nRxPos$15+0,r0
        cmpi      250,r0
        bged      L714
        ldilt     @CL102,r0
        ldilt     fp,r1
        ldilt     *+fp(2),r2
;*      Branch Occurs to L714 
	.line	34
;----------------------------------------------------------------------
; 1957 | memcpy(&btRx3chBuf[nRxPos],btBuf,nRxLen);                              
;----------------------------------------------------------------------
        addi      @_nRxPos$15+0,r0      ; Unsigned
        addi      105,r1
        push      r2
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	35
;----------------------------------------------------------------------
; 1958 | nRxPos += nRxLen;                                                      
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        addi      @_nRxPos$15+0,r0
        sti       r0,@_nRxPos$15+0
L714:        
	.line	39
;----------------------------------------------------------------------
; 1962 | if(nOldUart3RxOneByteGapDelayTime && !m_nUart3RxOneByteGapDelayTime)   
;----------------------------------------------------------------------
        ldi       @_nOldUart3RxOneByteGapDelayTime$16+0,r0
        beq       L763
;*      Branch Occurs to L763 
        ldi       @_m_nUart3RxOneByteGapDelayTime+0,r0
        bne       L763
;*      Branch Occurs to L763 
	.line	42
;----------------------------------------------------------------------
; 1965 | if(nRxPos >= 10)                                                       
;----------------------------------------------------------------------
        ldiu      @_nRxPos$15+0,r0
        cmpi      10,r0
        blt       L763
;*      Branch Occurs to L763 
	.line	44
;----------------------------------------------------------------------
; 1967 | pPaSdrBuf = (PACSDR *)btRx3chBuf;                                      
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      @CL102,r0
        sti       r0,*+fp(ir0)
	.line	46
;----------------------------------------------------------------------
; 1969 | pPa_PaBuf = (PAC_PAC *)btRx3chBuf;                                     
;----------------------------------------------------------------------
        ldiu      387,ir0
        sti       r0,*+fp(ir0)
	.line	49
;----------------------------------------------------------------------
; 1972 | pCcp_Pac = (CCP_PAC *)btRx3chBuf;                                      
; 1974 | //PAC -> LIC �κ� ���������� �и� �Ѵ�.                                
; 1975 | if(                                                                    
;----------------------------------------------------------------------
        ldiu      388,ir0
        sti       r0,*+fp(ir0)
	.line	53
;----------------------------------------------------------------------
; 1976 | WORD_L(pPaSdrBuf->phHdBuf.btSoh) == SOH &&                             
; 1977 | WORD_L(pPaSdrBuf->btEot) == EOT &&                                     
; 1978 | sizeof(PACSDR) == nRxPos &&                                            
; 1979 | (TWOBYTE_ASC2HEX(pPaSdrBuf->phHdBuf.chDestDev) == m_chCarKindNum)&&    
; 1981 | ConvAsc2Hex(pPaSdrBuf->nCRC[0]) == BYTE_H(WORD_H(crc16_ccitt(&pPaSdrBuf
;     | ->phHdBuf.chSrcDev[0],nRxPos-6)))&&                                    
; 1982 | ConvAsc2Hex(pPaSdrBuf->nCRC[1]) == BYTE_L(WORD_H(crc16_ccitt(&pPaSdrBuf
;     | ->phHdBuf.chSrcDev[0],nRxPos-6)))&&                                    
; 1983 | ConvAsc2Hex(pPaSdrBuf->nCRC[2]) == BYTE_H(WORD_L(crc16_ccitt(&pPaSdrBuf
;     | ->phHdBuf.chSrcDev[0],nRxPos-6)))&&                                    
; 1984 | ConvAsc2Hex(pPaSdrBuf->nCRC[3]) == BYTE_L(WORD_L(crc16_ccitt(&pPaSdrBuf
;     | ->phHdBuf.chSrcDev[0],nRxPos-6))))                                     
; 1986 | switch(TWOBYTE_ASC2HEX(pPaSdrBuf->phHdBuf.chCmdCode))                  
; 1988 | case REQ_CMD: //PAC -> LIC                                             
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        cmpi      1,r0
        bne       L733
;*      Branch Occurs to L733 
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and       *+ar0(17),r0
        cmpi      4,r0
        bne       L733
;*      Branch Occurs to L733 
        ldiu      18,r0
        cmpi      @_nRxPos$15+0,r0
        bne       L733
;*      Branch Occurs to L733 
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      362,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(4),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      @_m_chCarKindNum+0,r0
        subi      1,sp
        bne       L733
;*      Branch Occurs to L733 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      362,ir0
        ldiu      r0,r4
        subi      2,sp
        lsh       -8,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(13),r0
        lsh       -4,r4
        and       15,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L733
;*      Branch Occurs to L733 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        subi      2,sp
        ldiu      362,ir0
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(14),r0
        lsh       -8,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L733
;*      Branch Occurs to L733 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      362,ir0
        subi      2,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(15),r0
        lsh       -4,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L733
;*      Branch Occurs to L733 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      362,ir0
        subi      2,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(16),r0
        and       15,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L733
;*      Branch Occurs to L733 
        bud       L730
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(7),r0
;*      Branch Occurs to L730 
	.line	67
;----------------------------------------------------------------------
; 1990 | lsLicSdBuf.phHdBuf.btSoh = SOH;                                        
;----------------------------------------------------------------------
L727:        
        sti       r0,*+fp(ir0)
	.line	68
;----------------------------------------------------------------------
; 1991 | lsLicSdBuf.phHdBuf.chSrcDev[0] = ConvHex2Asc(BYTE_H(m_chCarKindNum));  
;----------------------------------------------------------------------
        ldiu      @_m_chCarKindNum+0,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      364,ir0
        sti       r0,*+fp(ir0)
	.line	69
;----------------------------------------------------------------------
; 1992 | lsLicSdBuf.phHdBuf.chSrcDev[1] = ConvHex2Asc(BYTE_L(m_chCarKindNum));  
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_m_chCarKindNum+0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      365,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	70
;----------------------------------------------------------------------
; 1993 | lsLicSdBuf.phHdBuf.chDestDev[0] = pPaSdrBuf->phHdBuf.chSrcDev[0];      
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      366,ir0
        ldiu      *+ar0(1),r0
        sti       r0,*+fp(ir0)
	.line	71
;----------------------------------------------------------------------
; 1994 | lsLicSdBuf.phHdBuf.chDestDev[1] = pPaSdrBuf->phHdBuf.chSrcDev[1];      
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      367,ir0
        ldiu      *+ar0(2),r0
        sti       r0,*+fp(ir0)
	.line	72
;----------------------------------------------------------------------
; 1995 | lsLicSdBuf.phHdBuf.chMsgCnt[0] = pPaSdrBuf->phHdBuf.chMsgCnt[0];       
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      368,ir0
        ldiu      *+ar0(5),r0
        sti       r0,*+fp(ir0)
	.line	73
;----------------------------------------------------------------------
; 1996 | lsLicSdBuf.phHdBuf.chMsgCnt[1] = pPaSdrBuf->phHdBuf.chMsgCnt[1];       
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      369,ir0
        ldiu      *+ar0(6),r0
        sti       r0,*+fp(ir0)
	.line	74
;----------------------------------------------------------------------
; 1997 | lsLicSdBuf.phHdBuf.chCmdCode[0] = ConvHex2Asc(BYTE_H(RPY_CMD));        
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      370,ir0
        sti       r0,*+fp(ir0)
	.line	75
;----------------------------------------------------------------------
; 1998 | lsLicSdBuf.phHdBuf.chCmdCode[1] = ConvHex2Asc(BYTE_L(RPY_CMD));        
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      371,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	76
;----------------------------------------------------------------------
; 1999 | lsLicSdBuf.phHdBuf.chDataLen[0] = ConvHex2Asc(BYTE_H(((sizeof(LICSD)-16
;     | )/2)));                                                                
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      372,ir0
        sti       r0,*+fp(ir0)
	.line	77
;----------------------------------------------------------------------
; 2000 | lsLicSdBuf.phHdBuf.chDataLen[1] = ConvHex2Asc(BYTE_L(((sizeof(LICSD)-16
;     | )/2)));                                                                
;----------------------------------------------------------------------
        ldiu      4,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      373,ir0
        sti       r0,*+fp(ir0)
	.line	79
;----------------------------------------------------------------------
; 2002 | lsLicSdBuf.DATA1.BIT.All_Doors_Closed = 0;                             
;----------------------------------------------------------------------
        ldiu      375,ir0
        ldiu      *+fp(ir0),r0
        ldiu      375,ir1
        andn      1,r0
        sti       r0,*+fp(ir1)
	.line	80
;----------------------------------------------------------------------
; 2003 | lsLicSdBuf.DATA1.BIT.EP_Mode = 0;                                      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),r0
        andn      2,r0
        sti       r0,*+fp(ir1)
	.line	81
;----------------------------------------------------------------------
; 2004 | lsLicSdBuf.DATA1.BIT.Traction = 0;                                     
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),r0
        andn      4,r0
        sti       r0,*+fp(ir1)
	.line	82
;----------------------------------------------------------------------
; 2005 | lsLicSdBuf.DATA1.BIT.Atcive_Cab = 0;                                   
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),r0
        andn      8,r0
        sti       r0,*+fp(ir1)
	.line	84
;----------------------------------------------------------------------
; 2007 | lsLicSdBuf.DATA2.BIT.CI_Fault = d_CI_Fault;                            
;----------------------------------------------------------------------
        ldiu      374,ir0
        ldiu      *+fp(ir0),r1
        andn      4,r1
        ldiu      1,r0
        and       @_d_CI_Fault+0,r0
        ash       2,r0
        ldiu      374,ir1
        or3       r1,r0,r0
        sti       r0,*+fp(ir1)
	.line	85
;----------------------------------------------------------------------
; 2008 | lsLicSdBuf.DATA2.BIT.DST = 0;                                          
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),r0
        andn      8,r0
        sti       r0,*+fp(ir1)
	.line	87
;----------------------------------------------------------------------
; 2010 | lsLicSdBuf.DATA1.BYTE = ConvHex2Asc(BYTE_L(lsLicSdBuf.DATA1.BYTE));    
;----------------------------------------------------------------------
        ldiu      375,ir0
        ldiu      15,r0
        and3      r0,*+fp(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      375,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	89
;----------------------------------------------------------------------
; 2012 | lsLicSdBuf.DATA2.BYTE = ConvHex2Asc(BYTE_L(lsLicSdBuf.DATA2.BYTE));    
;----------------------------------------------------------------------
        ldiu      374,ir0
        ldiu      15,r0
        and3      r0,*+fp(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      374,ir0
        sti       r0,*+fp(ir0)
	.line	91
;----------------------------------------------------------------------
; 2014 | lsLicSdBuf.CI_Index_Num[0] = ConvHex2Asc(BYTE_H(d_CI_Index));          
;----------------------------------------------------------------------
        ldiu      @_d_CI_Index+0,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      376,ir0
        sti       r0,*+fp(ir0)
	.line	92
;----------------------------------------------------------------------
; 2015 | lsLicSdBuf.CI_Index_Num[1] = ConvHex2Asc(BYTE_L(d_CI_Index));          
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_d_CI_Index+0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      377,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	94
;----------------------------------------------------------------------
; 2017 | lsLicSdBuf.chCarn[0][0] = ConvHex2Asc(BYTE_H(WORD_H(m_nCarNo))); // Car
;     |  Number(-.���ڸ�)                                                      
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+0,r0
        lsh       -8,r0
        and       255,r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      378,ir0
        sti       r0,*+fp(ir0)
	.line	95
;----------------------------------------------------------------------
; 2018 | lsLicSdBuf.chCarn[0][1] = ConvHex2Asc(BYTE_L(WORD_H(m_nCarNo)));       
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+0,r0
        lsh       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      379,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	96
;----------------------------------------------------------------------
; 2019 | lsLicSdBuf.chCarn[1][0] = ConvHex2Asc(BYTE_H(m_nCarNo)); // Car Number(
;     | ���ڸ�,���ڸ�)                                                         
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+0,r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      380,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	97
;----------------------------------------------------------------------
; 2020 | lsLicSdBuf.chCarn[1][1] = ConvHex2Asc(BYTE_L(m_nCarNo));               
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_m_nCarNo+0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      381,ir0
        sti       r0,*+fp(ir0)
	.line	99
;----------------------------------------------------------------------
; 2022 | btTmp = crc16_ccitt(&lsLicSdBuf.phHdBuf.chSrcDev[0],sizeof(LICSD)-6);  
;----------------------------------------------------------------------
        ldiu      18,r1
        ldiu      364,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _crc16_ccitt
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(4)
	.line	100
;----------------------------------------------------------------------
; 2023 | lsLicSdBuf.nCRC[0] = ConvHex2Asc(BYTE_H(WORD_H(btTmp)));               
;----------------------------------------------------------------------
        lsh       -8,r0
        and       255,r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      382,ir0
        sti       r0,*+fp(ir0)
	.line	101
;----------------------------------------------------------------------
; 2024 | lsLicSdBuf.nCRC[1] = ConvHex2Asc(BYTE_L(WORD_H(btTmp)));               
;----------------------------------------------------------------------
        ldiu      *+fp(4),r0
        lsh       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      383,ir0
        sti       r0,*+fp(ir0)
	.line	102
;----------------------------------------------------------------------
; 2025 | lsLicSdBuf.nCRC[2] = ConvHex2Asc(BYTE_H(WORD_L(btTmp)));               
;----------------------------------------------------------------------
        ldiu      255,r0
        and       *+fp(4),r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      384,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	103
;----------------------------------------------------------------------
; 2026 | lsLicSdBuf.nCRC[3] = ConvHex2Asc(BYTE_L(WORD_L(btTmp)));               
;----------------------------------------------------------------------
        ldiu      15,r0
        and       *+fp(4),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      385,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	104
;----------------------------------------------------------------------
; 2027 | lsLicSdBuf.btEot = EOT;                                                
;----------------------------------------------------------------------
        ldiu      386,ir0
        ldiu      4,r0
        sti       r0,*+fp(ir0)
	.line	106
;----------------------------------------------------------------------
; 2029 | user_PacTx((UCHAR *)&lsLicSdBuf,sizeof(LICSD));                        
;----------------------------------------------------------------------
        ldiu      24,r0
        push      r0
        ldiu      363,r0
        addi      fp,r0
        push      r0
        call      _user_PacTx
                                        ; Call Occurs
        subi      2,sp
	.line	107
;----------------------------------------------------------------------
; 2030 | break;                                                                 
; 2031 | default:                                                               
;----------------------------------------------------------------------
        bu        L763
;*      Branch Occurs to L763 
	.line	109
;----------------------------------------------------------------------
; 2032 | break;                                                                 
; 2036 | else                                                                   
;----------------------------------------------------------------------
	.line	63
L730:        
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      362,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(8),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      16,r0
        beqd      L727
        subi      1,sp
        ldieq     363,ir0
        ldieq     1,r0
;*      Branch Occurs to L727 
        bu        L763
;*      Branch Occurs to L763 
L733:        
	.line	114
;----------------------------------------------------------------------
; 2037 | if(WORD_L(pPa_PaBuf->phHdBuf.btSoh) == SOH &&  // PAC <-> PAC ���� ����
;     |  ������ �����Ѵ�.                                                      
; 2038 |             WORD_L(pPa_PaBuf->btEot) == EOT &&                         
; 2039 |             sizeof(PAC_PAC) == nRxPos &&                               
; 2040 |                 (TWOBYTE_ASC2HEX(pPa_PaBuf->phHdBuf.chSrcDev) == PAC_DE
;     | V_NO) &&                                                               
; 2041 |             (TWOBYTE_ASC2HEX(pPa_PaBuf->phHdBuf.chDestDev) == PAC_BAKDE
;     | V_NO)&&                                                                
; 2043 |             ConvAsc2Hex(pPa_PaBuf->nCRC[0]) == BYTE_H(WORD_H(crc16_ccit
;     | t(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&                        
; 2044 |                 ConvAsc2Hex(pPa_PaBuf->nCRC[1]) == BYTE_L(WORD_H(crc16_
;     | ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&                    
; 2045 |                 ConvAsc2Hex(pPa_PaBuf->nCRC[2]) == BYTE_H(WORD_L(crc16_
;     | ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&                    
; 2046 |                 ConvAsc2Hex(pPa_PaBuf->nCRC[3]) == BYTE_L(WORD_L(crc16_
;     | ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))                      
; 2047 |             )                                                          
;----------------------------------------------------------------------
        ldiu      387,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        cmpi      1,r0
        bne       L752
;*      Branch Occurs to L752 
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and       *+ar0(253),r0
        cmpi      4,r0
        bne       L752
;*      Branch Occurs to L752 
        ldiu      254,r0
        cmpi      @_nRxPos$15+0,r0
        bne       L752
;*      Branch Occurs to L752 
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      387,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(2),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      33,r0
        subi      1,sp
        bne       L752
;*      Branch Occurs to L752 
        ldiu      387,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      387,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(4),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      37,r0
        subi      1,sp
        bne       L752
;*      Branch Occurs to L752 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      387,ir0
        ldiu      r0,r4
        subi      2,sp
        lsh       -8,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(249),r0
        lsh       -4,r4
        and       15,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L752
;*      Branch Occurs to L752 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      387,ir0
        subi      2,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(250),r0
        lsh       -8,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L752
;*      Branch Occurs to L752 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      387,ir0
        subi      2,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(251),r0
        lsh       -4,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L752
;*      Branch Occurs to L752 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      387,ir0
        subi      2,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(252),r0
        and       15,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L752
;*      Branch Occurs to L752 
	.line	126
;----------------------------------------------------------------------
; 2049 | memset(m_btCommSt,0x00,sizeof(m_btCommSt));                            
;----------------------------------------------------------------------
        ldiu      8,r2
        ldiu      0,r1
        ldiu      @CL3,r0
        push      r2
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	128
;----------------------------------------------------------------------
; 2051 | pCommStatus_Lic = (COMMSTATUS_LIC *)m_btCommSt;                        
;----------------------------------------------------------------------
        ldiu      391,ir0
        ldiu      @CL3,r0
        sti       r0,*+fp(ir0)
	.line	130
;----------------------------------------------------------------------
; 2053 | for(i=0;i<4;i++)                                                       
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      4,r0
        bge       L763
;*      Branch Occurs to L763 
L743:        
	.line	132
;----------------------------------------------------------------------
; 2055 | FunConvAscHex((char *)&pPa_PaBuf->phCRA_Sta[i][0][0] ,btTmpBuf,22);    
;----------------------------------------------------------------------
        ldiu      *+fp(1),r2
        ldiu      387,ir0
        ldiu      22,r1
        ldiu      fp,r0
        mpyi      22,r2
        addi3     r2,*+fp(ir0),r2       ; Unsigned
        addi      161,r2                ; Unsigned
        push      r1
        addi      5,r0
        push      r0
        push      r2
        call      _FunConvAscHex
                                        ; Call Occurs
        subi      3,sp
	.line	134
;----------------------------------------------------------------------
; 2057 | pPac_Pac_Sta = (CRA_STATION *) btTmpBuf;                               
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      fp,r0
        addi      5,r0
        sti       r0,*+fp(ir0)
	.line	136
;----------------------------------------------------------------------
; 2059 | if(m_chCarKind == 'A')                                                 
;----------------------------------------------------------------------
        ldiu      @_m_chCarKind+0,r0
        cmpi      65,r0
        bne       L747
;*      Branch Occurs to L747 
	.line	138
;----------------------------------------------------------------------
; 2061 | if(DWORD_L(m_nCarNo) == MAKE_WORD(pPac_Pac_Sta->CarNum_H,pPac_Pac_Sta->
;     | CarNum_L))                                                             
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      389,ir1
        ldiu      255,r1
        ldiu      *+ar0(9),r2
        ldiu      @_m_nCarNo+0,r0
        ldiu      *+fp(ir1),ar0
        ash       8,r2
        and       *+ar0(10),r1
        and       65535,r0
        or3       r2,r1,r1
        and       65535,r1
        cmpi3     r1,r0
        bne       L750
;*      Branch Occurs to L750 
	.line	140
;----------------------------------------------------------------------
; 2063 | pCommStatus_Lic->BYTE_1.BIT.nCcp = pPac_Pac_Sta->CRA_2.BIT.sACCP1;     
;----------------------------------------------------------------------
        ldiu      391,ir1
        ldiu      128,r0
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        and       *+ar1(1),r0
        ldiu      *ar0,r1
        lsh       -7,r0
        andn      128,r1
        and       1,r0
        ash       7,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	141
;----------------------------------------------------------------------
; 2064 | pCommStatus_Lic->BYTE_1.BIT.nCncs = pPac_Pac_Sta->CRA_3.BIT.sACNCS;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      16,r0
        ldiu      *+fp(ir1),ar0
        and       *+ar1(2),r0
        ldiu      *ar0,r1
        lsh       -4,r0
        andn      1,r1
        and       1,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	142
;----------------------------------------------------------------------
; 2065 | pCommStatus_Lic->BYTE_1.BIT.nGps = pPac_Pac_Sta->CRA_2.BIT.sAGPS;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      32,r0
        ldiu      *+fp(ir1),ar0
        and       *+ar1(1),r0
        ldiu      *ar0,r1
        lsh       -5,r0
        andn      32,r1
        and       1,r0
        ash       5,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	143
;----------------------------------------------------------------------
; 2066 | pCommStatus_Lic->BYTE_1.BIT.nLic = pPac_Pac_Sta->CRA_3.BIT.sALIC;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      *ar0,r1
        ldiu      64,r0
        ldiu      *+fp(ir0),ar1
        andn      4,r1
        and       *+ar1(2),r0
        lsh       -6,r0
        and       1,r0
        ash       2,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	144
;----------------------------------------------------------------------
; 2067 | pCommStatus_Lic->BYTE_1.BIT.nPac = pPac_Pac_Sta->CRA_3.BIT.sAPAC;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      128,r0
        and       *+ar0(2),r0
        lsh       -7,r0
        ldiu      *+fp(ir0),ar0
        and       1,r0
        ldiu      *ar0,r1
        andn      8,r1
        ash       3,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	145
;----------------------------------------------------------------------
; 2068 | pCommStatus_Lic->BYTE_1.BIT.nVoip = pPac_Pac_Sta->CRA_2.BIT.sAVOIP;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      64,r0
        ldiu      391,ir0
        and       *+ar0(1),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *ar0,r1
        andn      64,r1
        lsh       -6,r0
        and       1,r0
        ash       6,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	146
;----------------------------------------------------------------------
; 2069 | pCommStatus_Lic->BYTE_1.BIT.nVtx = pPac_Pac_Sta->CRA_3.BIT.sAVTX;      
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      32,r0
        ldiu      *+fp(ir1),ar0
        and       *+ar1(2),r0
        ldiu      *ar0,r1
        andn      2,r1
        lsh       -5,r0
        and       1,r0
        ash       1,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	147
;----------------------------------------------------------------------
; 2070 | pCommStatus_Lic->BYTE_1.BIT.nWlr = pPac_Pac_Sta->CRA_2.BIT.sAWLR;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      16,r0
        and       *+ar0(1),r0
        ldiu      391,ir0
        lsh       -4,r0
        ldiu      *+fp(ir0),ar0
        and       1,r0
        ash       4,r0
        ldiu      *ar0,r1
        andn      16,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	150
;----------------------------------------------------------------------
; 2073 | pCommStatus_Lic->BYTE_2.BIT.nFdi = pPac_Pac_Sta->CRA_4.BIT.sAFDI;      
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      64,r0
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        and       *+ar1(3),r0
        lsh       -6,r0
        and       1,r0
        ldiu      *+ar0(1),r1
        ash       6,r0
        andn      64,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	151
;----------------------------------------------------------------------
; 2074 | pCommStatus_Lic->BYTE_2.BIT.nPii1 = pPac_Pac_Sta->CRA_4.BIT.sAPII1;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      32,r0
        and       *+ar0(3),r0
        lsh       -5,r0
        ldiu      391,ir0
        and       1,r0
        ldiu      *+fp(ir0),ar0
        ash       5,r0
        ldiu      *+ar0(1),r1
        andn      32,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	152
;----------------------------------------------------------------------
; 2075 | pCommStatus_Lic->BYTE_2.BIT.nPii2 = pPac_Pac_Sta->CRA_4.BIT.sAPII2;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      16,r0
        and       *+ar0(3),r0
        ldiu      391,ir0
        lsh       -4,r0
        ldiu      *+fp(ir0),ar0
        and       1,r0
        ldiu      *+ar0(1),r1
        andn      16,r1
        ash       4,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	153
;----------------------------------------------------------------------
; 2076 | pCommStatus_Lic->BYTE_2.BIT.nSdi1 = pPac_Pac_Sta->CRA_5.BIT.sASDI1;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      128,r0
        and       *+ar0(4),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r1
        lsh       -7,r0
        and       1,r0
        ash       3,r0
        andn      8,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	154
;----------------------------------------------------------------------
; 2077 | pCommStatus_Lic->BYTE_2.BIT.nSdi2 = pPac_Pac_Sta->CRA_5.BIT.sASDI2;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      64,r0
        and       *+ar0(4),r0
        ldiu      391,ir0
        lsh       -6,r0
        and       1,r0
        ldiu      *+fp(ir0),ar0
        ash       2,r0
        ldiu      *+ar0(1),r1
        andn      4,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	155
;----------------------------------------------------------------------
; 2078 | pCommStatus_Lic->BYTE_2.BIT.nSdi3 = pPac_Pac_Sta->CRA_5.BIT.sASDI3;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      32,r0
        and       *+ar1(4),r0
        ldiu      *+fp(ir1),ar0
        lsh       -5,r0
        and       1,r0
        ldiu      *+ar0(1),r1
        ash       1,r0
        andn      2,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	156
;----------------------------------------------------------------------
; 2079 | pCommStatus_Lic->BYTE_2.BIT.nSdi4 = pPac_Pac_Sta->CRA_5.BIT.sASDI4;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      16,r0
        ldiu      *+ar0(1),r1
        ldiu      *+fp(ir0),ar1
        andn      1,r1
        and       *+ar1(4),r0
        lsh       -4,r0
        and       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	158
;----------------------------------------------------------------------
; 2081 | pCommStatus_Lic->BYTE_3.BIT.nPid1_1 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_1;
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      128,r0
        ldiu      391,ir0
        and       *+ar0(5),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(2),r1
        lsh       -7,r0
        and       1,r0
        andn      16,r1
        ash       4,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	159
;----------------------------------------------------------------------
; 2082 | pCommStatus_Lic->BYTE_3.BIT.nPid1_2 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_2;
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      64,r0
        ldiu      391,ir0
        and       *+ar0(5),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(2),r1
        lsh       -6,r0
        andn      8,r1
        and       1,r0
        ash       3,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	160
;----------------------------------------------------------------------
; 2083 | pCommStatus_Lic->BYTE_3.BIT.nPid1_3 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_3;
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      32,r0
        ldiu      391,ir0
        and       *+ar0(5),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(2),r1
        lsh       -5,r0
        and       1,r0
        andn      4,r1
        ash       2,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	161
;----------------------------------------------------------------------
; 2084 | pCommStatus_Lic->BYTE_3.BIT.nPid1_4 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_4;
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      16,r0
        and       *+ar1(5),r0
        lsh       -4,r0
        ldiu      *+fp(ir1),ar0
        and       1,r0
        ldiu      *+ar0(2),r1
        andn      2,r1
        ash       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	162
;----------------------------------------------------------------------
; 2085 | pCommStatus_Lic->BYTE_3.BIT.nPid2_1 = pPac_Pac_Sta->CRA_7.BIT.sAPID2_1;
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        ldiu      128,r1
        ldiu      *+ar0(2),r0
        and       *+ar1(6),r1
        andn      1,r0
        lsh       -7,r1
        and       1,r1
        or3       r0,r1,r0
        sti       r0,*+ar0(2)
	.line	164
;----------------------------------------------------------------------
; 2087 | pCommStatus_Lic->BYTE_4.BIT.nDph = pPac_Pac_Sta->CRA_9.BIT.sADPH;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      128,r0
        and       *+ar1(8),r0
        lsh       -7,r0
        and       1,r0
        ldiu      *+fp(ir1),ar0
        ash       7,r0
        ldiu      *+ar0(3),r1
        andn      128,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	165
;----------------------------------------------------------------------
; 2088 | pCommStatus_Lic->BYTE_4.BIT.nDpo = pPac_Pac_Sta->CRA_9.BIT.sADPO;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      16,r0
        and       *+ar0(8),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r1
        andn      16,r1
        lsh       -4,r0
        and       1,r0
        ash       4,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	166
;----------------------------------------------------------------------
; 2089 | pCommStatus_Lic->BYTE_4.BIT.nPei1 = pPac_Pac_Sta->CRA_7.BIT.sAPEI1;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      16,r0
        and       *+ar1(6),r0
        ldiu      *+fp(ir1),ar0
        lsh       -4,r0
        ldiu      *+ar0(3),r1
        and       1,r0
        andn      1,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	167
;----------------------------------------------------------------------
; 2090 | pCommStatus_Lic->BYTE_4.BIT.nPei2 = pPac_Pac_Sta->CRA_7.BIT.sAPEI2;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      32,r0
        and       *+ar0(6),r0
        ldiu      *+fp(ir0),ar0
        lsh       -5,r0
        and       1,r0
        ldiu      *+ar0(3),r1
        ash       1,r0
        andn      2,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	169
;----------------------------------------------------------------------
; 2092 | break;                                                                 
;----------------------------------------------------------------------
        bu        L763
;*      Branch Occurs to L763 
L747:        
	.line	172
;----------------------------------------------------------------------
; 2095 | else if(m_chCarKind == 'B') //�������ݿ��� MA ���� ��ȣ�� �����Ƿ� MB��
;     |  ������ �ν� �ؾ� �Ѵ�.                                                
;----------------------------------------------------------------------
        ldiu      @_m_chCarKind+0,r0
        cmpi      66,r0
        bne       L750
;*      Branch Occurs to L750 
	.line	174
;----------------------------------------------------------------------
; 2097 | if(DWORD_L(m_nCarNo) == (MAKE_WORD(pPac_Pac_Sta->CarNum_H,pPac_Pac_Sta-
;     | >CarNum_L)+1))                                                         
;----------------------------------------------------------------------
        ldiu      389,ir1
        ldiu      389,ir0
        ldiu      255,r0
        ldiu      *+fp(ir1),ar0
        ldiu      @_m_nCarNo+0,r1
        ldiu      *+ar0(9),r2
        ldiu      *+fp(ir0),ar0
        ash       8,r2
        and       *+ar0(10),r0
        and       65535,r1
        or3       r2,r0,r0
        and       65535,r0
        addi      1,r0                  ; Unsigned
        cmpi3     r0,r1
        bne       L750
;*      Branch Occurs to L750 
	.line	176
;----------------------------------------------------------------------
; 2099 | pCommStatus_Lic->BYTE_1.BIT.nCcp = pPac_Pac_Sta->CRA_2.BIT.sBCCP1;     
;----------------------------------------------------------------------
        ldiu      391,ir1
        ldiu      8,r0
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        and       *+ar1(1),r0
        ldiu      *ar0,r1
        lsh       -3,r0
        andn      128,r1
        and       1,r0
        ash       7,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	177
;----------------------------------------------------------------------
; 2100 | pCommStatus_Lic->BYTE_1.BIT.nCncs = pPac_Pac_Sta->CRA_3.BIT.sBCNCS;    
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(ir1),ar0
        ldiu      *+fp(ir0),ar1
        ldiu      *ar0,r0
        and       *+ar1(2),r1
        andn      1,r0
        or3       r0,r1,r0
        sti       r0,*ar0
	.line	178
;----------------------------------------------------------------------
; 2101 | pCommStatus_Lic->BYTE_1.BIT.nGps = pPac_Pac_Sta->CRA_2.BIT.sBGPS;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      2,r0
        and       *+ar1(1),r0
        lsh       -1,r0
        and       1,r0
        ldiu      *+fp(ir1),ar0
        ash       5,r0
        ldiu      *ar0,r1
        andn      32,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	179
;----------------------------------------------------------------------
; 2102 | pCommStatus_Lic->BYTE_1.BIT.nLic = pPac_Pac_Sta->CRA_3.BIT.sBLIC;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      4,r0
        and       *+ar0(2),r0
        lsh       -2,r0
        ldiu      *+fp(ir1),ar1
        and       1,r0
        ldiu      *ar1,r1
        ash       2,r0
        andn      4,r1
        or3       r1,r0,r0
        sti       r0,*ar1
	.line	180
;----------------------------------------------------------------------
; 2103 | pCommStatus_Lic->BYTE_1.BIT.nPac = pPac_Pac_Sta->CRA_3.BIT.sBPAC;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      8,r0
        and       *+ar0(2),r0
        ldiu      391,ir0
        lsh       -3,r0
        ldiu      *+fp(ir0),ar0
        and       1,r0
        ldiu      *ar0,r1
        ash       3,r0
        andn      8,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	181
;----------------------------------------------------------------------
; 2104 | pCommStatus_Lic->BYTE_1.BIT.nVoip = pPac_Pac_Sta->CRA_2.BIT.sBVOIP;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      4,r0
        and       *+ar0(1),r0
        lsh       -2,r0
        and       1,r0
        ldiu      *+fp(ir0),ar0
        ash       6,r0
        ldiu      *ar0,r1
        andn      64,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	182
;----------------------------------------------------------------------
; 2105 | pCommStatus_Lic->BYTE_1.BIT.nVtx = pPac_Pac_Sta->CRA_3.BIT.sBVTX;      
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      2,r0
        and       *+ar1(2),r0
        lsh       -1,r0
        and       1,r0
        ldiu      *+fp(ir1),ar0
        ash       1,r0
        ldiu      *ar0,r1
        andn      2,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	183
;----------------------------------------------------------------------
; 2106 | pCommStatus_Lic->BYTE_1.BIT.nWlr = pPac_Pac_Sta->CRA_2.BIT.sBWLR;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      1,r0
        and       *+ar1(1),r0
        ldiu      *+fp(ir1),ar0
        ash       4,r0
        ldiu      *ar0,r1
        andn      16,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	186
;----------------------------------------------------------------------
; 2109 | pCommStatus_Lic->BYTE_2.BIT.nFdi = pPac_Pac_Sta->CRA_4.BIT.sBFDI;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      4,r0
        and       *+ar0(3),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r1
        andn      64,r1
        lsh       -2,r0
        and       1,r0
        ash       6,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	187
;----------------------------------------------------------------------
; 2110 | pCommStatus_Lic->BYTE_2.BIT.nPii1 = pPac_Pac_Sta->CRA_4.BIT.sBPII1;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      2,r0
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        and       *+ar0(3),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r1
        lsh       -1,r0
        andn      32,r1
        and       1,r0
        ash       5,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	188
;----------------------------------------------------------------------
; 2111 | pCommStatus_Lic->BYTE_2.BIT.nPii2 = pPac_Pac_Sta->CRA_4.BIT.sBPII2;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      1,r0
        and       *+ar1(3),r0
        ldiu      *+fp(ir1),ar0
        ash       4,r0
        ldiu      *+ar0(1),r1
        andn      16,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	189
;----------------------------------------------------------------------
; 2112 | pCommStatus_Lic->BYTE_2.BIT.nSdi1 = pPac_Pac_Sta->CRA_5.BIT.sBSDI1;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      8,r0
        and       *+ar0(4),r0
        ldiu      391,ir0
        lsh       -3,r0
        ldiu      *+fp(ir0),ar0
        and       1,r0
        ldiu      *+ar0(1),r1
        ash       3,r0
        andn      8,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	190
;----------------------------------------------------------------------
; 2113 | pCommStatus_Lic->BYTE_2.BIT.nSdi2 = pPac_Pac_Sta->CRA_5.BIT.sBSDI2;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      4,r0
        ldiu      391,ir0
        and       *+ar0(4),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r1
        lsh       -2,r0
        and       1,r0
        andn      4,r1
        ash       2,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	191
;----------------------------------------------------------------------
; 2114 | pCommStatus_Lic->BYTE_2.BIT.nSdi3 = pPac_Pac_Sta->CRA_5.BIT.sBSDI3;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      2,r0
        and       *+ar1(4),r0
        ldiu      *+fp(ir1),ar0
        lsh       -1,r0
        ldiu      *+ar0(1),r1
        and       1,r0
        andn      2,r1
        ash       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	192
;----------------------------------------------------------------------
; 2115 | pCommStatus_Lic->BYTE_2.BIT.nSdi4 = pPac_Pac_Sta->CRA_5.BIT.sBSDI4;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      *+fp(ir0),ar1
        ldiu      *+ar0(1),r1
        andn      1,r1
        ldiu      1,r0
        and       *+ar1(4),r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	194
;----------------------------------------------------------------------
; 2117 | pCommStatus_Lic->BYTE_3.BIT.nPid1_1 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_1;
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      *+ar0(2),r1
        ldiu      8,r0
        ldiu      *+fp(ir0),ar1
        andn      16,r1
        and       *+ar1(5),r0
        lsh       -3,r0
        and       1,r0
        ash       4,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	195
;----------------------------------------------------------------------
; 2118 | pCommStatus_Lic->BYTE_3.BIT.nPid1_2 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_2;
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        ldiu      4,r0
        and       *+ar1(5),r0
        lsh       -2,r0
        and       1,r0
        ash       3,r0
        ldiu      *+ar0(2),r1
        andn      8,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	196
;----------------------------------------------------------------------
; 2119 | pCommStatus_Lic->BYTE_3.BIT.nPid1_3 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_3;
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      *+ar0(2),r1
        andn      4,r1
        ldiu      *+fp(ir0),ar1
        ldiu      2,r0
        and       *+ar1(5),r0
        lsh       -1,r0
        and       1,r0
        ash       2,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	197
;----------------------------------------------------------------------
; 2120 | pCommStatus_Lic->BYTE_3.BIT.nPid1_4 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_4;
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      *+ar0(2),r1
        ldiu      1,r0
        ldiu      *+fp(ir0),ar1
        andn      2,r1
        and       *+ar1(5),r0
        ash       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	198
;----------------------------------------------------------------------
; 2121 | pCommStatus_Lic->BYTE_3.BIT.nPid2_1 = pPac_Pac_Sta->CRA_7.BIT.sBPID2_1;
;----------------------------------------------------------------------
        ldiu      391,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      389,ir1
        ldiu      *+ar0(2),r1
        ldiu      *+fp(ir1),ar1
        ldiu      8,r0
        and       *+ar1(6),r0
        lsh       -3,r0
        and       1,r0
        andn      1,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	200
;----------------------------------------------------------------------
; 2123 | pCommStatus_Lic->BYTE_4.BIT.nDph = pPac_Pac_Sta->CRA_9.BIT.sBDPH;      
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      8,r0
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        and       *+ar0(8),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r1
        andn      128,r1
        lsh       -3,r0
        and       1,r0
        ash       7,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	201
;----------------------------------------------------------------------
; 2124 | pCommStatus_Lic->BYTE_4.BIT.nDpo = pPac_Pac_Sta->CRA_9.BIT.sBDPO;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar1
        ldiu      1,r1
        ldiu      *+fp(ir0),ar0
        and       *+ar1(8),r1
        ldiu      *+ar0(3),r0
        ash       4,r1
        andn      16,r0
        or3       r0,r1,r0
        sti       r0,*+ar0(3)
	.line	202
;----------------------------------------------------------------------
; 2125 | pCommStatus_Lic->BYTE_4.BIT.nPei1 = pPac_Pac_Sta->CRA_7.BIT.sBPEI1;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      1,r0
        ldiu      *+ar0(3),r1
        ldiu      *+fp(ir1),ar1
        andn      1,r1
        and       *+ar1(6),r0
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	203
;----------------------------------------------------------------------
; 2126 | pCommStatus_Lic->BYTE_4.BIT.nPei2 = pPac_Pac_Sta->CRA_7.BIT.sBPEI2;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      2,r0
        and       *+ar0(6),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r1
        lsh       -1,r0
        andn      2,r1
        and       1,r0
        ash       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	204
;----------------------------------------------------------------------
; 2127 | break;                                                                 
; 2134 | else                                                                   
;----------------------------------------------------------------------
        bu        L763
;*      Branch Occurs to L763 
L750:        
	.line	130
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      4,r0
        blt       L743
;*      Branch Occurs to L743 
        bu        L763
;*      Branch Occurs to L763 
L752:        
	.line	212
;----------------------------------------------------------------------
; 2135 | if(WORD_L(pCcp_Pac->phHdBuf.btSoh) == SOH &&  // CCP -> PAC ���� ���� �
;     | ����� �����Ѵ�.                                                        
; 2136 |         WORD_L(pCcp_Pac->btEot) == EOT &&                              
; 2137 |         sizeof(CCP_PAC) == nRxPos &&                                   
; 2138 |         (TWOBYTE_ASC2HEX(pCcp_Pac->phHdBuf.chSrcDev) == CCP_DEV_NO) && 
; 2139 |         (TWOBYTE_ASC2HEX(pCcp_Pac->phHdBuf.chDestDev) == PAC_DEV_NO)&& 
; 2141 |         ConvAsc2Hex(pCcp_Pac->nCRC[0]) == BYTE_H(WORD_H(crc16_ccitt(&pC
;     | cp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))&&                              
; 2142 |         ConvAsc2Hex(pCcp_Pac->nCRC[1]) == BYTE_L(WORD_H(crc16_ccitt(&pC
;     | cp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))&&                              
; 2143 |         ConvAsc2Hex(pCcp_Pac->nCRC[2]) == BYTE_H(WORD_L(crc16_ccitt(&pC
;     | cp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))&&                              
; 2144 |         ConvAsc2Hex(pCcp_Pac->nCRC[3]) == BYTE_L(WORD_L(crc16_ccitt(&pC
;     | cp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))                                
; 2145 |         )                                                              
;----------------------------------------------------------------------
        ldiu      388,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        cmpi      1,r0
        bne       L763
;*      Branch Occurs to L763 
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and       *+ar0(155),r0
        cmpi      4,r0
        bne       L763
;*      Branch Occurs to L763 
        ldiu      156,r0
        cmpi      @_nRxPos$15+0,r0
        bne       L763
;*      Branch Occurs to L763 
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      388,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(2),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      17,r0
        subi      1,sp
        bne       L763
;*      Branch Occurs to L763 
        ldiu      388,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      388,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(4),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      33,r0
        subi      1,sp
        bne       L763
;*      Branch Occurs to L763 
        ldiu      1,r1
        ldiu      388,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      388,ir0
        ldiu      r0,r4
        subi      2,sp
        lsh       -8,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(151),r0
        lsh       -4,r4
        and       15,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L763
;*      Branch Occurs to L763 
        ldiu      1,r1
        ldiu      388,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        subi      2,sp
        ldiu      388,ir0
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(152),r0
        lsh       -8,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L763
;*      Branch Occurs to L763 
        ldiu      1,r1
        ldiu      388,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      388,ir0
        subi      2,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(153),r0
        lsh       -4,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L763
;*      Branch Occurs to L763 
        ldiu      1,r1
        ldiu      388,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$15+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      388,ir0
        subi      2,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(154),r1
        and       15,r4
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L763
;*      Branch Occurs to L763 
	.line	224
;----------------------------------------------------------------------
; 2147 | d_CI_Index = MAKE_BYTE(ConvAsc2Hex(pCcp_Pac->sCI_Index[0][0]),ConvAsc2H
;     | ex(pCcp_Pac->sCI_Index[0][1]) );                                       
;----------------------------------------------------------------------
        ldiu      388,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(123),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      388,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(124),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        sti       r0,@_d_CI_Index+0
        subi      1,sp
	.line	226
;----------------------------------------------------------------------
; 2149 | FunConvAscHex((char *)&pCcp_Pac->sCCP_Date[0][0],btTmpBuf,12);         
;----------------------------------------------------------------------
        ldiu      388,ir0
        ldiu      139,r2
        ldiu      fp,r0
        addi3     r2,*+fp(ir0),r2       ; Unsigned
        addi      5,r0
        ldiu      12,r1
        push      r1
        push      r0
        push      r2
        call      _FunConvAscHex
                                        ; Call Occurs
        subi      3,sp
	.line	228
;----------------------------------------------------------------------
; 2151 | memcpy(&m_tmCurTime.second,btTmpBuf,6);                                
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      5,ar0
        ldiu      @CL19,ar1
        ldiu      *ar0++(1),r0
        rpts      4                     ; Fast MEMCPY(#12)
        sti       r0,*ar1++(1)
||      ldi       *ar0++(1),r0
        sti       r0,*ar1++(1)
	.line	237
;----------------------------------------------------------------------
; 2160 | memset(&m_tmUtcTime, 0x00, sizeof(DATE_TIME_TYPE));                    
;----------------------------------------------------------------------
        ldiu      7,r2
        push      r2
        ldiu      0,r0
        push      r0
        ldiu      @CL18,r1
        push      r1
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	239
;----------------------------------------------------------------------
; 2162 | if(m_LIC_CNCS_TimSetFlag = GetLocalTimeToUTC(&m_tmCurTime, -5, &m_tmUtc
;     | Time))                                                                 
;----------------------------------------------------------------------
        ldiu      @CL18,r1
        ldiu      @CL19,r0
        push      r1
        ldiu      -5,r2
        push      r2
        push      r0
        call      _GetLocalTimeToUTC
                                        ; Call Occurs
        cmpi      0,r0
        beqd      L763
	nop
        subi      3,sp
        sti       r0,@_m_LIC_CNCS_TimSetFlag+0
;*      Branch Occurs to L763 
	.line	241
;----------------------------------------------------------------------
; 2164 | m_tmUtcTime.year        = ConvDec2Hex(m_tmUtcTime.year  );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+5,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+5
        subi      1,sp
	.line	242
;----------------------------------------------------------------------
; 2165 | m_tmUtcTime.month       = ConvDec2Hex(m_tmUtcTime.month );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+4,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+4
        subi      1,sp
	.line	243
;----------------------------------------------------------------------
; 2166 | m_tmUtcTime.day         = ConvDec2Hex(m_tmUtcTime.day   );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+3,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+3
        subi      1,sp
	.line	244
;----------------------------------------------------------------------
; 2167 | m_tmUtcTime.hour        = ConvDec2Hex(m_tmUtcTime.hour  );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+2,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+2
        subi      1,sp
	.line	245
;----------------------------------------------------------------------
; 2168 | m_tmUtcTime.minute      = ConvDec2Hex(m_tmUtcTime.minute);             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+1,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+1
        subi      1,sp
	.line	246
;----------------------------------------------------------------------
; 2169 | m_tmUtcTime.second      = ConvDec2Hex(m_tmUtcTime.second);             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+0,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+0
        subi      1,sp
	.line	248
;----------------------------------------------------------------------
; 2171 | m_nCncsRxCheck1msTimer = 2000;                                         
;----------------------------------------------------------------------
        ldiu      2000,r0
        sti       r0,@_m_nCncsRxCheck1msTimer+0
L763:        
	.line	258
;----------------------------------------------------------------------
; 2181 | nOldUart3RxOneByteGapDelayTime = m_nUart3RxOneByteGapDelayTime;        
;----------------------------------------------------------------------
        ldiu      @_m_nUart3RxOneByteGapDelayTime+0,r0
        sti       r0,@_nOldUart3RxOneByteGapDelayTime$16+0
	.line	259
        ldiu      *-fp(1),bk
        pop       r4
        ldiu      *fp,fp
        subi      393,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	2182,000000010h,391


	.sect	 ".text"

	.global	_GetLocalTimeToUTC
	.sym	_GetLocalTimeToUTC,_GetLocalTimeToUTC,36,2,0
	.func	2187
;******************************************************************************
;* FUNCTION NAME: _GetLocalTimeToUTC                                          *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r4,ar0,ar1,fp,sp,st                           *
;*   Regs Saved         : r4                                                  *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 3 Parm + 5 Auto + 1 SOE = 11 words         *
;******************************************************************************
_GetLocalTimeToUTC:
	.sym	_pLocal,-2,24,9,32,.fake5
	.sym	_nHour,-3,4,9,32
	.sym	_pUTC,-4,24,9,32,.fake5
	.sym	_nHourT,1,4,1,32
	.sym	_nDayT,2,4,1,32
	.sym	_nLastDays,3,4,1,32
	.sym	_nMonthT,4,4,1,32
	.sym	_nYearT,5,4,1,32
	.line	1
;----------------------------------------------------------------------
; 2187 | BOOL GetLocalTimeToUTC( DATE_TIME_PTR pLocal, int nHour, DATE_TIME_PTR
;     | pUTC )                                                                 
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      5,sp
        push      r4
	.line	2
;----------------------------------------------------------------------
; 2189 | // �ð��� ����ϴ� �κ�.                                               
;----------------------------------------------------------------------
	.line	4
;----------------------------------------------------------------------
; 2190 | int nHourT = pLocal->hour - nHour;                                     
;----------------------------------------------------------------------
        ldiu      *-fp(2),ar0
        ldiu      *-fp(3),r0
        subri     *+ar0(2),r0           ; Unsigned
        sti       r0,*+fp(1)
	.line	5
;----------------------------------------------------------------------
; 2191 | int nDayT = pLocal->day;                                               
;----------------------------------------------------------------------
        ldiu      *+ar0(3),r0
        sti       r0,*+fp(2)
	.line	6
;----------------------------------------------------------------------
; 2192 | int nLastDays = GetDaysOfMonth( pLocal->month, pLocal->year );
;     |                                                                        
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      ar0,ar1
        ldiu      *+ar0(4),r1
        ldiu      *+ar1(5),r0
        push      r0
        push      r1
        call      _GetDaysOfMonth
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(3)
	.line	7
;----------------------------------------------------------------------
; 2193 | int nMonthT = pLocal->month;                                           
;----------------------------------------------------------------------
        ldiu      *-fp(2),ar0
        ldiu      *+ar0(4),r0
        sti       r0,*+fp(4)
	.line	8
;----------------------------------------------------------------------
; 2194 | int nYearT = 2000 + pLocal->year;                                      
; 2196 | // �ð� ������ ���ϴ� �κ�.                                            
;----------------------------------------------------------------------
        ldiu      2000,r0
        addi      *+ar0(5),r0           ; Unsigned
        sti       r0,*+fp(5)
	.line	11
;----------------------------------------------------------------------
; 2197 | if(nHourT < 0 ) {                                                      
;----------------------------------------------------------------------
        ldi       *+fp(1),r0
        bge       L768
;*      Branch Occurs to L768 
	.line	12
;----------------------------------------------------------------------
; 2198 | nHourT += 24;                                                          
;----------------------------------------------------------------------
        ldiu      24,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
	.line	13
;----------------------------------------------------------------------
; 2199 | nDayT += -1;                                                           
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     *+fp(2),r0
        sti       r0,*+fp(2)
        bu        L770
;*      Branch Occurs to L770 
L768:        
	.line	15
;----------------------------------------------------------------------
; 2201 | else if( 24 <= nHourT ) {                                              
;----------------------------------------------------------------------
        ldiu      24,r0
        cmpi      *+fp(1),r0
        bgt       L770
;*      Branch Occurs to L770 
	.line	16
;----------------------------------------------------------------------
; 2202 | nHourT -= 24;                                                          
;----------------------------------------------------------------------
        subri     *+fp(1),r0
        sti       r0,*+fp(1)
	.line	17
;----------------------------------------------------------------------
; 2203 | nDayT += 1;                                                            
; 2206 | // ���ڸ� ���ϴ� �κ�.                                                 
; 2207 | // �ð��� ����Ͽ� ���ڸ� �����ؾ��ϴ� ���.                           
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      *+fp(2),r0
        sti       r0,*+fp(2)
L770:        
	.line	22
;----------------------------------------------------------------------
; 2208 | if(nDayT < 1)
;     |                                                                        
;     |                                                                        
;     |                                                                        
;----------------------------------------------------------------------
        ldi       *+fp(2),r0
        bgt       L773
;*      Branch Occurs to L773 
	.line	24
;----------------------------------------------------------------------
; 2210 | nDayT = GetDaysOfMonth( nMonthT, nYearT );                             
;----------------------------------------------------------------------
        ldiu      *+fp(5),r0
        push      r0
        ldiu      *+fp(4),r0
        push      r0
        call      _GetDaysOfMonth
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(2)
	.line	26
;----------------------------------------------------------------------
; 2212 | if(--nMonthT < 1)                                                      
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     *+fp(4),r0
        bgtd      L776
        sti       r0,*+fp(4)
	nop
        ldile     1,r0
;*      Branch Occurs to L776 
	.line	28
;----------------------------------------------------------------------
; 2214 | nYearT--;                                                              
;----------------------------------------------------------------------
        subri     *+fp(5),r0
        sti       r0,*+fp(5)
	.line	29
;----------------------------------------------------------------------
; 2215 | nMonthT = 12;                                                          
;----------------------------------------------------------------------
        ldiu      12,r0
        sti       r0,*+fp(4)
        bu        L776
;*      Branch Occurs to L776 
L773:        
	.line	32
;----------------------------------------------------------------------
; 2218 | else if(nLastDays < nDayT)                                             
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        cmpi      *+fp(2),r0
        bge       L776
;*      Branch Occurs to L776 
	.line	34
;----------------------------------------------------------------------
; 2220 | nDayT = 1;                                                             
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,*+fp(2)
	.line	36
;----------------------------------------------------------------------
; 2222 | if(12 < ++nMonthT)                                                     
;----------------------------------------------------------------------
        ldiu      12,r1
        addi      *+fp(4),r0
        cmpi3     r0,r1
        bged      L776
        sti       r0,*+fp(4)
	nop
        ldilt     1,r0
;*      Branch Occurs to L776 
	.line	38
;----------------------------------------------------------------------
; 2224 | nYearT++;                                                              
;----------------------------------------------------------------------
        addi      *+fp(5),r0
        sti       r0,*+fp(5)
	.line	39
;----------------------------------------------------------------------
; 2225 | nMonthT = 1;                                                           
; 2229 | // ���� �ú��� ������ UTC �ð����� �̵���Ű�� �κ�.                  
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,*+fp(4)
L776:        
	.line	44
;----------------------------------------------------------------------
; 2230 | pUTC->second = pLocal->second;                                         
;----------------------------------------------------------------------
        ldiu      *-fp(2),ar0
        ldiu      *-fp(4),ar1
        ldiu      *ar0,r0
        sti       r0,*ar1
	.line	45
;----------------------------------------------------------------------
; 2231 | pUTC->minute = pLocal->minute;                                         
;----------------------------------------------------------------------
        ldiu      *-fp(2),ar1
        ldiu      *-fp(4),ar0
        ldiu      *+ar1(1),r0
        sti       r0,*+ar0(1)
	.line	46
;----------------------------------------------------------------------
; 2232 | pUTC->hour = nHourT;                                                   
;----------------------------------------------------------------------
        ldiu      *-fp(4),ar0
        ldiu      *+fp(1),r0
        sti       r0,*+ar0(2)
	.line	47
;----------------------------------------------------------------------
; 2233 | pUTC->day = nDayT;                                                     
;----------------------------------------------------------------------
        ldiu      *-fp(4),ar0
        ldiu      *+fp(2),r0
        sti       r0,*+ar0(3)
	.line	48
;----------------------------------------------------------------------
; 2234 | pUTC->month = nMonthT;                                                 
;----------------------------------------------------------------------
        ldiu      *-fp(4),ar0
        ldiu      *+fp(4),r0
        sti       r0,*+ar0(4)
	.line	49
;----------------------------------------------------------------------
; 2235 | pUTC->year = nYearT - 2000;                                            
; 2237 | return      (( 10 <= pUTC->year ) &&
;     |                                                                        
;     |                                   // 10�� �̻�                         
; 2238 |                         (( 1 <= pUTC->month ) && ( pUTC->month <= 12 ))
;     |  &&                                                                    
;     |                   // ��                                                
; 2239 |                         (( 1 <= pUTC->day )   && ( pUTC->day <= GetDays
;     | OfMonth(nMonthT, nYearT) )) &&                           // ��         
; 2240 |                         (( 0 <= pUTC->hour )  && ( pUTC->hour < 24 ))
;     |  &&                                                                    
;     |                   // ��                                                
; 2241 |                         (( 0 <= pUTC->minute) && ( pUTC->minute < 60 ))
;     |  &&                                                                    
;     |                   // ��                                                
;----------------------------------------------------------------------
        ldiu      2000,r0
        ldiu      *-fp(4),ar0
        subri     *+fp(5),r0            ; Unsigned
        sti       r0,*+ar0(5)
	.line	56
;----------------------------------------------------------------------
; 2242 | (( 0 <= pUTC->second) && ( pUTC->second < 60 )));
;     |                                                                  // �� 
;----------------------------------------------------------------------
        ldiu      *-fp(4),ar0
        ldiu      10,r0
        cmpi      *+ar0(5),r0
        ldiu      0,r4
        bhi       L787
;*      Branch Occurs to L787 
        ldiu      1,r0
        cmpi      *+ar0(4),r0
        bhi       L787
;*      Branch Occurs to L787 
        ldiu      *+ar0(4),r0
        cmpi      12,r0
        bhi       L787
;*      Branch Occurs to L787 
        ldiu      1,r0
        cmpi      *+ar0(3),r0
        bhi       L787
;*      Branch Occurs to L787 
        ldiu      *+fp(5),r0
        push      r0
        ldiu      *+fp(4),r0
        push      r0
        call      _GetDaysOfMonth
                                        ; Call Occurs
        subi      2,sp
        ldiu      *-fp(4),ar0
        ldiu      *+ar0(3),r1
        cmpi3     r0,r1
        bhi       L787
;*      Branch Occurs to L787 
        ldiu      0,r0
        cmpi      *+ar0(2),r0
        bhi       L787
;*      Branch Occurs to L787 
        ldiu      *+ar0(2),r0
        cmpi      24,r0
        bhs       L787
;*      Branch Occurs to L787 
        ldiu      0,r0
        cmpi3     *+ar0,r0
        bhi       L787
;*      Branch Occurs to L787 
        ldiu      *+ar0(1),r0
        cmpi      60,r0
        bhs       L787
;*      Branch Occurs to L787 
        ldiu      0,r0
        cmpi3     *ar0,r0
        bhi       L787
;*      Branch Occurs to L787 
        ldiu      *ar0,r0
        cmpi      60,r0
        ldilo     1,r4
L787:        
	.line	57
        ldiu      r4,r0
        ldiu      *-fp(1),bk
        pop       r4
        ldiu      *fp,fp
        subi      7,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	2243,000000010h,5


	.sect	 ".text"

	.global	_IsLeapYear
	.sym	_IsLeapYear,_IsLeapYear,36,2,0
	.func	2248
;******************************************************************************
;* FUNCTION NAME: _IsLeapYear                                                 *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,st                                            *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 1 Parm + 0 Auto + 0 SOE = 3 words          *
;******************************************************************************
_IsLeapYear:
	.sym	_nYear,-2,4,9,32
	.line	1
;----------------------------------------------------------------------
; 2248 | int IsLeapYear( int nYear )
;     |                  // ���� ������ ���ϴ� �κ�.                           
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 2250 | if( nYear % 400 == 0 )                                                 
;----------------------------------------------------------------------
        ldiu      400,r1
        ldiu      *-fp(2),r0
        call      MOD_I30
                                        ; Call Occurs
        cmpi      0,r0
        bne       L792
;*      Branch Occurs to L792 
	.line	4
;----------------------------------------------------------------------
; 2251 | return 1;                                                              
;----------------------------------------------------------------------
        bud       L797
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L797 
L792:        
	.line	6
;----------------------------------------------------------------------
; 2253 | if( nYear % 100 == 0 )                                                 
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        ldiu      100,r1
        call      MOD_I30
                                        ; Call Occurs
        cmpi      0,r0
        bne       L794
;*      Branch Occurs to L794 
	.line	7
;----------------------------------------------------------------------
; 2254 | return 0;                                                              
;----------------------------------------------------------------------
        bud       L797
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L797 
L794:        
	.line	9
;----------------------------------------------------------------------
; 2256 | if( nYear % 4 == 0 )                                                   
;----------------------------------------------------------------------
        ldiu      *-fp(2),r1
        ldiu      r1,r0
        ash       -1,r0
        lsh       @CL103,r0
        addi3     r0,r1,r0
        andn      3,r0
        subri     r1,r0
        bne       L796
;*      Branch Occurs to L796 
	.line	10
;----------------------------------------------------------------------
; 2257 | return 1;                                                              
;----------------------------------------------------------------------
        bud       L797
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L797 
L796:        
	.line	12
;----------------------------------------------------------------------
; 2259 | return 0;                                                              
;----------------------------------------------------------------------
        ldiu      0,r0
L797:        
	.line	13
        ldiu      *-fp(1),ar1
        ldiu      *fp,fp
        subi      2,sp
        bu        ar1
;*      Branch Occurs to ar1 
	.endfunc	2260,000000000h,0


	.sect	 ".text"

	.global	_GetDaysOfMonth
	.sym	_GetDaysOfMonth,_GetDaysOfMonth,36,2,0
	.func	2262
;******************************************************************************
;* FUNCTION NAME: _GetDaysOfMonth                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,ar0,fp,ir0,sp,st                                 *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 1 Auto + 0 SOE = 5 words          *
;******************************************************************************
_GetDaysOfMonth:
	.sym	_nMonth,-2,4,9,32
	.sym	_nYear,-3,4,9,32
	.sym	_nDays,1,4,1,32
	.line	1
;----------------------------------------------------------------------
; 2262 | int GetDaysOfMonth( int nMonth, int nYear )
;     |  // ���� ������ ���ڸ� ���ϴ� �κ�.                                    
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	4
;----------------------------------------------------------------------
; 2265 | int nDays = 0;                                                         
; 2267 | switch( nMonth )                                                       
; 2269 | case 1 :
;     |                                  // 31�� ������ ����                   
; 2270 | case 3 :                                                               
; 2271 | case 5 :                                                               
; 2272 | case 7 :                                                               
; 2273 | case 8 :                                                               
; 2274 | case 10 :                                                              
; 2275 | case 12 :                                                              
;----------------------------------------------------------------------
        bud       L805
        addi      1,sp
        ldiu      0,r0
        sti       r0,*+fp(1)
;*      Branch Occurs to L805 
L800:        
	.line	15
;----------------------------------------------------------------------
; 2276 | nDays = 31;                                                            
;----------------------------------------------------------------------
        ldiu      31,r0
        sti       r0,*+fp(1)
	.line	16
;----------------------------------------------------------------------
; 2277 | break;                                                                 
; 2278 | case 2 :                                                               
;----------------------------------------------------------------------
        bu        L807
;*      Branch Occurs to L807 
L801:        
	.line	18
;----------------------------------------------------------------------
; 2279 | nDays = 28;                                                            
;----------------------------------------------------------------------
        ldiu      28,r0
        sti       r0,*+fp(1)
	.line	19
;----------------------------------------------------------------------
; 2280 | if( IsLeapYear( nYear ) )
;     |          // ������ ����Ͽ�, ������ ���, +1                           
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        push      r0
        call      _IsLeapYear
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L807
;*      Branch Occurs to L807 
	.line	20
;----------------------------------------------------------------------
; 2281 | nDays += 1;                                                            
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
	.line	21
;----------------------------------------------------------------------
; 2282 | break;                                                                 
; 2283 | case 4 :
;     |                                  // 30�� ������ ����                   
; 2284 | case 6 :                                                               
; 2285 | case 9 :                                                               
; 2286 | case 11 :                                                              
;----------------------------------------------------------------------
        bu        L807
;*      Branch Occurs to L807 
L803:        
	.line	26
;----------------------------------------------------------------------
; 2287 | nDays = 30;                                                            
;----------------------------------------------------------------------
        ldiu      30,r0
        sti       r0,*+fp(1)
	.line	27
;----------------------------------------------------------------------
; 2288 | break;                                                                 
;----------------------------------------------------------------------
        bu        L807
;*      Branch Occurs to L807 
L805:        
	.line	6
        ldiu      1,r0
        ldiu      *-fp(2),ir0
        subri     ir0,r0
        cmpi      11,r0
        bhi       L807
;*      Branch Occurs to L807 
        subi      1,ir0
        ldiu      @CL104,ar0
        ldiu      *+ar0(ir0),r0
        bu        r0

	.sect	".text"
SW0:	.word	L800	; 1
	.word	L801	; 2
	.word	L800	; 3
	.word	L803	; 4
	.word	L800	; 5
	.word	L803	; 6
	.word	L800	; 7
	.word	L800	; 8
	.word	L803	; 9
	.word	L800	; 10
	.word	L803	; 11
	.word	L800	; 12
	.sect	".text"
;*      Branch Occurs to r0 
L807:        
	.line	30
;----------------------------------------------------------------------
; 2291 | return nDays;                                                          
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
	.line	31
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      3,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	2292,000000000h,1


	.sect	 ".text"

	.global	_user_CarNoForCarKindToLon
	.sym	_user_CarNoForCarKindToLon,_user_CarNoForCarKindToLon,32,2,0
	.func	2298
;******************************************************************************
;* FUNCTION NAME: _user_CarNoForCarKindToLon                                  *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0                                                  *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 0 Auto + 0 SOE = 2 words          *
;******************************************************************************
_user_CarNoForCarKindToLon:
	.line	1
;----------------------------------------------------------------------
; 2298 | void user_CarNoForCarKindToLon()                                       
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	3
;----------------------------------------------------------------------
; 2300 | m_nCarKindToLonCnt = 0;                                                
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nCarKindToLonCnt+0
	.line	4
        ldiu      *-fp(1),r1
        ldiu      *fp,fp
        subi      2,sp
        bu        r1
;*      Branch Occurs to r1 
	.endfunc	2301,000000000h,0



	.sect	".cinit"
	.field  	1,32
	.field  	_nDelayCnt$18+0,32
	.field  	0,32		; _nDelayCnt$18 @ 0

	.sect	".text"
	.sect	 ".text"

	.global	_user_1msLoop
	.sym	_user_1msLoop,_user_1msLoop,32,2,0
	.func	2306
;******************************************************************************
;* FUNCTION NAME: _user_1msLoop                                               *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r4,ar0,fp,ir0,sp,st                           *
;*   Regs Saved         : r4                                                  *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 34 Auto + 1 SOE = 37 words        *
;******************************************************************************
_user_1msLoop:
	.bss	_nDelayCnt$18,1
	.sym	_nDelayCnt,_nDelayCnt$18,14,3,32
	.sym	_i,1,4,1,32
	.sym	_nTxPos,2,4,1,32
	.sym	_btTxBuf,3,60,1,1024,,32
	.line	1
;----------------------------------------------------------------------
; 2306 | void user_1msLoop()                                                    
; 2308 | int i;                                                                 
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      34,sp
        push      r4
	.line	4
;----------------------------------------------------------------------
; 2309 | int nTxPos = 0;                                                        
; 2310 | UCHAR btTxBuf[32];                                                     
; 2311 | static UINT nDelayCnt = 0;                                             
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(2)
	.line	8
;----------------------------------------------------------------------
; 2313 | m_nTxDbg1msTimer++;                                                    
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nTxDbg1msTimer+0,r0 ; Unsigned
        sti       r0,@_m_nTxDbg1msTimer+0
	.line	9
;----------------------------------------------------------------------
; 2314 | m_nUserDebug1msTimer++;                                                
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nUserDebug1msTimer+0,r0 ; Unsigned
        sti       r0,@_m_nUserDebug1msTimer+0
	.line	10
;----------------------------------------------------------------------
; 2315 | m_nSingleOrMarriedCarUpdate1msTimer++;                                 
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nSingleOrMarriedCarUpdate1msTimer+0,r0 ; Unsigned
        sti       r0,@_m_nSingleOrMarriedCarUpdate1msTimer+0
	.line	11
;----------------------------------------------------------------------
; 2316 | m_nTest1msTimer++;                                                     
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nTest1msTimer+0,r0 ; Unsigned
        sti       r0,@_m_nTest1msTimer+0
	.line	13
;----------------------------------------------------------------------
; 2318 | if(!(m_nUserDebug1msTimer%100)) //A�� ���� �ϰ� 1�� �ִٰ� B�� ���� �ϱ
;     | � ���Ͽ� �ð��� ������ �Ѵ�.                                           
;----------------------------------------------------------------------
        ldiu      100,r1
        ldiu      @_m_nUserDebug1msTimer+0,r0
        call      MOD_U30
                                        ; Call Occurs
        cmpi      0,r0
        bne       L816
;*      Branch Occurs to L816 
	.line	15
;----------------------------------------------------------------------
; 2320 | if(m_nCDT_FaultDataStFlag) m_nCDT_FaultDataStFlag--;                   
;----------------------------------------------------------------------
        ldi       @_m_nCDT_FaultDataStFlag+0,r0
        beq       L816
;*      Branch Occurs to L816 
        ldiu      1,r0
        subri     @_m_nCDT_FaultDataStFlag+0,r0
        sti       r0,@_m_nCDT_FaultDataStFlag+0
L816:        
	.line	18
;----------------------------------------------------------------------
; 2323 | if(m_nUart1RxOneByteGapDelayTime) m_nUart1RxOneByteGapDelayTime--;     
;----------------------------------------------------------------------
        ldi       @_m_nUart1RxOneByteGapDelayTime+0,r0
        beq       L818
;*      Branch Occurs to L818 
        ldiu      1,r0
        subri     @_m_nUart1RxOneByteGapDelayTime+0,r0 ; Unsigned
        sti       r0,@_m_nUart1RxOneByteGapDelayTime+0
L818:        
	.line	19
;----------------------------------------------------------------------
; 2324 | if(m_nUart2RxOneByteGapDelayTime) m_nUart2RxOneByteGapDelayTime--;     
;----------------------------------------------------------------------
        ldi       @_m_nUart2RxOneByteGapDelayTime+0,r0
        beq       L820
;*      Branch Occurs to L820 
        ldiu      1,r0
        subri     @_m_nUart2RxOneByteGapDelayTime+0,r0 ; Unsigned
        sti       r0,@_m_nUart2RxOneByteGapDelayTime+0
L820:        
	.line	20
;----------------------------------------------------------------------
; 2325 | if(m_nUart3RxOneByteGapDelayTime) m_nUart3RxOneByteGapDelayTime--;     
;----------------------------------------------------------------------
        ldi       @_m_nUart3RxOneByteGapDelayTime+0,r0
        beq       L822
;*      Branch Occurs to L822 
        ldiu      1,r0
        subri     @_m_nUart3RxOneByteGapDelayTime+0,r0 ; Unsigned
        sti       r0,@_m_nUart3RxOneByteGapDelayTime+0
L822:        
	.line	22
;----------------------------------------------------------------------
; 2327 | if(m_nGiaRxCheck1msTimer) m_nGiaRxCheck1msTimer--;                     
;----------------------------------------------------------------------
        ldi       @_m_nGiaRxCheck1msTimer+0,r0
        beq       L824
;*      Branch Occurs to L824 
        ldiu      1,r0
        subri     @_m_nGiaRxCheck1msTimer+0,r0 ; Unsigned
        sti       r0,@_m_nGiaRxCheck1msTimer+0
L824:        
	.line	24
;----------------------------------------------------------------------
; 2329 | if(m_nCncsRxCheck1msTimer) m_nCncsRxCheck1msTimer--;                   
;----------------------------------------------------------------------
        ldi       @_m_nCncsRxCheck1msTimer+0,r0
        beq       L826
;*      Branch Occurs to L826 
        ldiu      1,r0
        subri     @_m_nCncsRxCheck1msTimer+0,r0 ; Unsigned
        sti       r0,@_m_nCncsRxCheck1msTimer+0
L826:        
	.line	26
;----------------------------------------------------------------------
; 2331 | if(m_nCarKindToLonCnt < 6 && !(nDelayCnt%2000))                        
;----------------------------------------------------------------------
        ldiu      @_m_nCarKindToLonCnt+0,r0
        cmpi      6,r0
        bge       L831
;*      Branch Occurs to L831 
        ldiu      @_nDelayCnt$18+0,r0
        ldiu      2000,r1
        call      MOD_U30
                                        ; Call Occurs
        cmpi      0,r0
        bne       L831
;*      Branch Occurs to L831 
	.line	28
;----------------------------------------------------------------------
; 2333 | m_nCarKindToLonCnt++;                                                  
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nCarKindToLonCnt+0,r0
        sti       r0,@_m_nCarKindToLonCnt+0
	.line	30
;----------------------------------------------------------------------
; 2335 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(2)
	.line	31
;----------------------------------------------------------------------
; 2336 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        addi      3,ar0
        ldiu      r0,ir0
        addi      ir0,r1
        ldiu      2,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	32
;----------------------------------------------------------------------
; 2337 | btTxBuf[nTxPos++] = 0xF0; // Command Code                              
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r1
        ldiu      240,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	33
;----------------------------------------------------------------------
; 2338 | btTxBuf[nTxPos++] = 0x00; // Message Code                              
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(2),ir0
        addi      ir0,r0
        ldiu      fp,ar0
        sti       r0,*+fp(2)
        addi      3,ar0
        ldiu      0,r1
        sti       r1,*+ar0(ir0)
	.line	34
;----------------------------------------------------------------------
; 2339 | btTxBuf[nTxPos++] = 0x02; // ����                                      
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        ldiu      fp,ar0
        ldiu      2,r0
        addi      ir0,r1
        addi      3,ar0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	35
;----------------------------------------------------------------------
; 2340 | btTxBuf[nTxPos++] = WORD_H(m_nCarNo); // ������ȣ ����                 
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        ldiu      @_m_nCarNo+0,r0
        sti       r1,*+fp(2)
        ldiu      fp,ar0
        lsh       -8,r0
        addi      3,ar0
        and       255,r0
        sti       r0,*+ar0(ir0)
	.line	36
;----------------------------------------------------------------------
; 2341 | btTxBuf[nTxPos++] = WORD_L(m_nCarNo); // ������ȣ ����                 
;----------------------------------------------------------------------
        ldiu      *+fp(2),ir0
        ldiu      1,r1
        addi      ir0,r1
        ldiu      fp,ar0
        ldiu      255,r0
        addi      3,ar0
        and       @_m_nCarNo+0,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	37
;----------------------------------------------------------------------
; 2342 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      4,r0
        ldiu      1,r1
        subri     *+fp(2),r1
        push      r1
        push      r0
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      fp,ar0
        addi      3,ar0
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	38
;----------------------------------------------------------------------
; 2343 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      3,ar0
        ldiu      *+fp(2),ir0
        ldiu      1,r1
        ldiu      3,r0
        addi      ir0,r1
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	39
;----------------------------------------------------------------------
; 2344 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      *+fp(2),r1
        push      r1
        ldiu      fp,r0
        addi      3,r0
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	41
;----------------------------------------------------------------------
; 2346 | MyPrintf("[TX:%02d] ",nTxPos);                                         
;----------------------------------------------------------------------
        ldiu      *+fp(2),r1
        push      r1
        ldiu      @CL82,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      2,sp
	.line	42
;----------------------------------------------------------------------
; 2347 | for(i=0;i<nTxPos;i++) MyPrintf("%02X ",WORD_L(btTxBuf[i]));            
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        ldiu      255,r4
        cmpi      *+fp(2),r0
        bge       L830
;*      Branch Occurs to L830 
L829:        
        ldiu      fp,ar0
        ldiu      *+fp(1),ir0
        addi      3,ar0
        ldiu      @CL83,r1
        and3      r4,*+ar0(ir0),r0
        push      r0
        push      r1
        call      _MyPrintf
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        blt       L829
;*      Branch Occurs to L829 
L830:        
	.line	43
;----------------------------------------------------------------------
; 2348 | MyPrintf("\r\n");                                                      
;----------------------------------------------------------------------
        ldiu      @CL28,r0
        push      r0
        call      _MyPrintf
                                        ; Call Occurs
        subi      1,sp
L831:        
	.line	46
;----------------------------------------------------------------------
; 2351 | nDelayCnt++;                                                           
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_nDelayCnt$18+0,r0   ; Unsigned
        sti       r0,@_nDelayCnt$18+0
	.line	47
        ldiu      *-fp(1),bk
        pop       r4
        ldiu      *fp,fp
        subi      36,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	2352,000000010h,34



	.global	_m_tFaultInfo
	.bss	_m_tFaultInfo,6
	.sym	_m_tFaultInfo,_m_tFaultInfo,56,2,192,.fake74,2

	.global	_m_btOldCommSt
	.bss	_m_btOldCommSt,8
	.sym	_m_btOldCommSt,_m_btOldCommSt,60,2,256,,8

	.global	_m_btExVersionTbl
	.bss	_m_btExVersionTbl,36
	.sym	_m_btExVersionTbl,_m_btExVersionTbl,61,2,1152,,36

	.global	_m_tmUtcTime
	.bss	_m_tmUtcTime,7
	.sym	_m_tmUtcTime,_m_tmUtcTime,8,2,224,.fake5

	.global	_m_btSenseCommStBuf
	.bss	_m_btSenseCommStBuf,8
	.sym	_m_btSenseCommStBuf,_m_btSenseCommStBuf,60,2,256,,8

	.global	_m_btCommSt
	.bss	_m_btCommSt,8
	.sym	_m_btCommSt,_m_btCommSt,60,2,256,,8

	.global	_m_btExVersion_DAYTbl
	.bss	_m_btExVersion_DAYTbl,36
	.sym	_m_btExVersion_DAYTbl,_m_btExVersion_DAYTbl,61,2,1152,,36

	.global	_m_bExVersionEnableTbl
	.bss	_m_bExVersionEnableTbl,36
	.sym	_m_bExVersionEnableTbl,_m_bExVersionEnableTbl,52,2,1152,,36

	.global	_mRackDi
	.bss	_mRackDi,1
	.sym	_mRackDi,_mRackDi,8,2,32,.fake71

	.global	_m_tmCurTime
	.bss	_m_tmCurTime,7
	.sym	_m_tmCurTime,_m_tmCurTime,8,2,224,.fake5
;******************************************************************************
;* STRINGS                                                                    *
;******************************************************************************
	.sect	".const"
SL1:	.byte	"Lonwork Monitor Program, Version:%d.%d%d%d",13,10,0
SL2:	.byte	"->",13,10,0
SL3:	.byte	"Time",0
SL4:	.byte	"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%"
	.byte	"02X[minute],%02X[second] ",13,10,0
SL5:	.byte	"Not Date&time format ",13,10,0
SL6:	.byte	"t",0
SL7:	.byte	"Version",0
SL8:	.byte	"LIC-MPU Version:%d.%d%d%d,Build Date:20%06d, LIC-LON Versio"
	.byte	"n:%d.%d%d%d,Build Date:%08X",13,10,0
SL9:	.byte	":",0
SL10:	.byte	13,10,0
SL11:	.byte	13,10,13,10,0
SL12:	.byte	"Recent",0
SL13:	.byte	"Recent fault read start send ",13,10,0
SL14:	.byte	"Historical",0
SL15:	.byte	"Historical read start send, Historical start time : %08XH, "
	.byte	"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%"
	.byte	"02X[minute],%02X[second] ",13,10,0
SL16:	.byte	"Rxinfo",0
SL17:	.byte	"Total byte : %d, Packet count : %d, window count : %d, rema"
	.byte	"ind packet : %d, m_nLnWkWaySideOnRxOk : %d, m_bLnWkFtpEndFl"
	.byte	"ag : %d, Historical start time : %08XH ",13,10,0
SL18:	.byte	"LnWayClr",0
SL19:	.byte	"'m_nLnWkWaySideOnRxOk' Clear OK ",13,10,0
SL20:	.byte	"LnFtpClr",0
SL21:	.byte	"'m_bLnWkFtpEndFlag' Clear OK ",13,10,0
SL22:	.byte	"HisStTm",0
SL23:	.byte	"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%"
	.byte	"02X[minute],%02X[second], Setting OK ",13,10,0
SL24:	.byte	"No format ",13,10,0
SL25:	.byte	"CarNoSet",0
SL26:	.byte	"Car Number = %d,%c Car ",13,10,0
SL27:	.byte	"Invalid syntax",13,10,0
SL28:	.byte	"WaySideON",0
SL29:	.byte	"Recently",0
SL30:	.byte	"m_nCDT_FaultDataStFlag  = %d,%s, Date&Time : 20%02X[year],%"
	.byte	"02X[month],%02X[day],%02X[hour],%02X[minute],%02X[second]",13
	.byte	10,0
SL31:	.byte	"CommStSet",0
SL32:	.byte	"CommStSet =  %02X-%02X-%02X-%02X ",13,10,0
SL33:	.byte	"TrainConf",0
SL34:	.byte	"TrainConf value = %02X ",13,10,0
SL35:	.byte	"CarPosSet",0
SL36:	.byte	"CarPosVal = %02X ",13,10,0
SL37:	.byte	"Invalid syntax [%d]",13,10,0
SL38:	.byte	"CiFaultSet",0
SL39:	.byte	"CiFault Val = %02X ",13,10,0
SL40:	.byte	"VerSet",0
SL41:	.byte	"Syntax error",13,10,0
SL42:	.byte	"?",0
SL43:	.byte	"[ENTER]      : Move next line after out '->' ",13,10,0
SL44:	.byte	"'?'          : Help ",13,10,0
SL45:	.byte	"'Time'       : Date&time setting , 'Time=YYMMDDHHMNSS', 'EX"
	.byte	")Time=120102030405' ",13,10,0
SL46:	.byte	"'t'          : Date&time read ",13,10,0
SL47:	.byte	"'Version     : Version ",13,10,0
SL48:	.byte	"'Recent'     : Recently faults start ",13,10,0
SL49:	.byte	"'Historical' : Historical data start ",13,10,0
SL50:	.byte	"'Rxinfo'     : Recieve info ",13,10,0
SL51:	.byte	"'LnWayClr'   : 'm_nLnWkWaySideOnRxOk' variable clear ",13,10
	.byte	0
SL52:	.byte	"'LnFtpClr'   : 'm_bLnWkFtpEndFlag' variable clear ",13,10,0
SL53:	.byte	"'HisStTm'    : Historical data start time set(2000/1/1 0:0:"
	.byte	"0 ~ total second), HisStTm=XXXXXXXX, 'EX)HisStTm=0000000F' "
	.byte	13,10,0
SL54:	.byte	"'CarNoSet'   : Car number set. CarNoSet=XXXX, EX)CarNoSet=4"
	.byte	"001 -> [%d[0x%X],%c CAR]",13,10,0
SL55:	.byte	"'TrainConf'  : Train Configuration. TrainConf=X(X : 0~3[2,4"
	.byte	",6,8Car]) => [%d]",13,10,0
SL56:	.byte	"'CarPosSet'  : Car index position. CarPosSet=X(X:1~8) 'EX)C"
	.byte	"arPosSet=1' => [%d]",13,10,0
SL57:	.byte	"'CiFaultSet' : Other C/I Fault. CiFaultSet=XX 'EX)CiFaultSe"
	.byte	"t=00' => [0x%02X]",13,10,0
SL58:	.byte	"'WaySideON'  : WaySide_ON ",13,10,0
SL59:	.byte	"'CommStSet'  : Comm Status. CommStSet=XXXXXXXX  'EX) CommSt"
	.byte	"Set=FF7F1F53' => [0x%02X,0x%02X,0x%02X,0x%02X]",13,10,0
SL60:	.byte	"'VerSet'     : Each unit version set. VerSet=XX(incdex):XXX"
	.byte	"X(Ver):XXXXXX(BuildDate) ",13,10,0
SL61:	.byte	"[TX:%02d] ",0
SL62:	.byte	"%02X ",0
SL63:	.byte	"[%d,%3d,%c]",0
SL64:	.byte	"%02X",0
SL65:	.byte	"..",0
SL66:	.byte	"***FTP File receive... ^^;;***",13,10,0
SL67:	.byte	"***FTP data buffer full..",13,10,0
SL68:	.byte	"***FTP File receive End ^..^ ***",13,10,0
SL69:	.byte	"[RX:%02d] ",0
;******************************************************************************
;* CONSTANT TABLE                                                             *
;******************************************************************************
	.sect	".const"
	.bss	CL1,1
	.bss	CL2,1
	.bss	CL3,1
	.bss	CL4,1
	.bss	CL5,1
	.bss	CL6,1
	.bss	CL7,1
	.bss	CL8,1
	.bss	CL9,1
	.bss	CL10,1
	.bss	CL11,1
	.bss	CL12,1
	.bss	CL13,1
	.bss	CL14,1
	.bss	CL15,1
	.bss	CL16,1
	.bss	CL17,1
	.bss	CL18,1
	.bss	CL19,1
	.bss	CL20,1
	.bss	CL21,1
	.bss	CL22,1
	.bss	CL23,1
	.bss	CL24,1
	.bss	CL25,1
	.bss	CL26,1
	.bss	CL27,1
	.bss	CL28,1
	.bss	CL29,1
	.bss	CL30,1
	.bss	CL31,1
	.bss	CL32,1
	.bss	CL33,1
	.bss	CL34,1
	.bss	CL35,1
	.bss	CL36,1
	.bss	CL37,1
	.bss	CL38,1
	.bss	CL39,1
	.bss	CL40,1
	.bss	CL41,1
	.bss	CL42,1
	.bss	CL43,1
	.bss	CL44,1
	.bss	CL45,1
	.bss	CL46,1
	.bss	CL47,1
	.bss	CL48,1
	.bss	CL49,1
	.bss	CL50,1
	.bss	CL51,1
	.bss	CL52,1
	.bss	CL53,1
	.bss	CL54,1
	.bss	CL55,1
	.bss	CL56,1
	.bss	CL57,1
	.bss	CL58,1
	.bss	CL59,1
	.bss	CL60,1
	.bss	CL61,1
	.bss	CL62,1
	.bss	CL63,1
	.bss	CL64,1
	.bss	CL65,1
	.bss	CL66,1
	.bss	CL67,1
	.bss	CL68,1
	.bss	CL69,1
	.bss	CL70,1
	.bss	CL71,1
	.bss	CL72,1
	.bss	CL73,1
	.bss	CL74,1
	.bss	CL75,1
	.bss	CL76,1
	.bss	CL77,1
	.bss	CL78,1
	.bss	CL79,1
	.bss	CL80,1
	.bss	CL81,1
	.bss	CL82,1
	.bss	CL83,1
	.bss	CL84,1
	.bss	CL85,1
	.bss	CL86,1
	.bss	CL87,1
	.bss	CL88,1
	.bss	CL89,1
	.bss	CL90,1
	.bss	CL91,1
	.bss	CL92,1
	.bss	CL93,1
	.bss	CL94,1
	.bss	CL95,1
	.bss	CL96,1
	.bss	CL97,1
	.bss	CL98,1
	.bss	CL99,1
	.bss	CL100,1
	.bss	CL101,1
	.bss	CL102,1
	.bss	CL103,1
	.bss	CL104,1

	.sect	".cinit"
	.field  	104,32
	.field  	CL1+0,32
	.field  	11534336,32
	.field  	16776716,32
	.field  	_m_btCommSt,32
	.field  	_m_btOldCommSt,32
	.field  	_m_btSenseCommStBuf,32
	.field  	_m_btExVersionTbl,32
	.field  	_m_btExVersion_DAYTbl,32
	.field  	100000,32
	.field  	536870912,32
	.field  	SL1,32
	.field  	2097153,32
	.field  	16777215,32
	.field  	_btRx3chBuf$3,32
	.field  	11534336,32
	.field  	_btRxBuf$6,32
	.field  	SL2,32
	.field  	SL3,32
	.field  	_m_tmUtcTime,32
	.field  	_m_tmCurTime,32
	.field  	100000,32
	.field  	SL4,32
	.field  	SL5,32
	.field  	SL6,32
	.field  	SL7,32
	.field  	SL8,32
	.field  	_LIC_VerList,32
	.field  	SL9,32
	.field  	SL10,32
	.field  	SL11,32
	.field  	SL12,32
	.field  	SL13,32
	.field  	SL14,32
	.field  	SL15,32
	.field  	SL16,32
	.field  	SL17,32
	.field  	SL18,32
	.field  	SL19,32
	.field  	SL20,32
	.field  	SL21,32
	.field  	SL22,32
	.field  	SL23,32
	.field  	SL24,32
	.field  	SL25,32
	.field  	SL26,32
	.field  	SL27,32
	.field  	SL28,32
	.field  	SL29,32
	.field  	SL30,32
	.field  	SL31,32
	.field  	_btRxBuf$6+10,32
	.field  	SL32,32
	.field  	SL33,32
	.field  	SL34,32
	.field  	SL35,32
	.field  	SL36,32
	.field  	SL37,32
	.field  	SL38,32
	.field  	SL39,32
	.field  	SL40,32
	.field  	SL41,32
	.field  	SL42,32
	.field  	SL43,32
	.field  	SL44,32
	.field  	SL45,32
	.field  	SL46,32
	.field  	SL47,32
	.field  	SL48,32
	.field  	SL49,32
	.field  	SL50,32
	.field  	SL51,32
	.field  	SL52,32
	.field  	SL53,32
	.field  	SL54,32
	.field  	SL55,32
	.field  	SL56,32
	.field  	SL57,32
	.field  	SL58,32
	.field  	SL59,32
	.field  	SL60,32
	.field  	_m_bExVersionEnableTbl,32
	.field  	12582912,32
	.field  	SL61,32
	.field  	SL62,32
	.field  	-1,32
	.field  	_btFtpOneRecRxBuf$9,32
	.field  	SL63,32
	.field  	SL64,32
	.field  	SL65,32
	.field  	4128768,32
	.field  	SL66,32
	.field  	SL67,32
	.field  	SL68,32
	.field  	SL69,32
	.field  	32768,32
	.field  	32768,32
	.field  	10485760,32
	.field  	_btRx2chBuf$12,32
	.field  	12582912,32
	.field  	-25,32
	.field  	_btTx2chBuf$13,32
	.field  	_m_tFaultInfo,32
	.field  	_btRx3chBuf$17,32
	.field  	-30,32
	.field  	SW0,32

	.sect	".text"
;******************************************************************************
;* UNDEFINED EXTERNAL REFERENCES                                              *
;******************************************************************************

	.global	_memset

	.global	_strcat

	.global	_strlen

	.global	_strncmp

	.global	_strncpy

	.global	_IsNumAsc

	.global	_ConvAsc2Dec

	.global	_ConvHex2Asc

	.global	_ConvAsc2Hex

	.global	_GetFirmwareVersion

	.global	_Make1ByteBcc

	.global	_gm_SysTimeToRtc

	.global	_MyPrintf

	.global	_FunConvAscHex

	.global	_FunConvHexAsc

	.global	_crc16_ccitt

	.global	_xr16l784_GetRxBuffer1Ch

	.global	_xr16l784_GetRxBuffer2Ch

	.global	_xr16l784_GetRxBuffer3Ch

	.global	_xr16l784_Send

	.global	_xr16l784_RtsDelayStartSend
	.global	MOD_I30
	.global	DIV_I30
	.global	_sprintf
	.global	_memcpy
	.global	_ConvDec2Hex
	.global	DIV_U30
	.global	MOD_U30
