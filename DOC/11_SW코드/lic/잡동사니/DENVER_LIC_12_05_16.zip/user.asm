;******************************************************************************
;* TMS320C3x/4x ANSI C Code Generator                            Version 5.11 *
;* Date/Time created: Wed May 16 08:22:13 2012                                *
;******************************************************************************
	.regalias	; enable floating point register aliases
fp	.set	ar3
FP	.set	ar3
;******************************************************************************
;* GLOBAL FILE PARAMETERS                                                     *
;*                                                                            *
;*   Optimization       : Always Choose Smaller Code Size                     *
;*   Memory             : Small Memory Model                                  *
;*   Float-to-Int       : Normal Conversions (round toward zero)              *
;*   Multiply           : in Hardware (24 bits max)                           *
;*   Memory Info        : Unmapped Memory Exists                              *
;*   Repeat Loops       : Use RPTS and/or RPTB                                *
;*   Calls              : Normal Library ASM calls                            *
;*   Debug Info         : Optimized TI Debug Information                      *
;******************************************************************************
;	c:\lang\tms320c3x\511\bin\ac30.exe user.c C:\Users\JDS_SSD\AppData\Local\Temp\user.if 
	.file	"user.c"
	.file	"string.h"
	.sym	_size_t,0,14,13,32
	.file	"def.h"
	.sym	_WORD,0,13,13,32
	.sym	_USHORT,0,13,13,32
	.sym	_BYTE,0,12,13,32
	.sym	_UCHAR,0,12,13,32
	.sym	_UINT,0,14,13,32
	.sym	_BOOL,0,4,13,32
	.sym	_DWORD,0,15,13,32
	.file	"ds1647.h"
	.stag	.fake1,32
	.member	_R,6,4,18,1
	.member	_W,7,4,18,1
	.eos
	.stag	.fake2,32
	.member	_Sec,0,4,18,7
	.member	_Osc,7,4,18,1
	.eos
	.stag	.fake3,32
	.member	_Day,0,4,18,3
	.member	_SPare2,3,4,18,3
	.member	_FT,6,4,18,1
	.member	_Spare1,7,4,18,1
	.eos
	.utag	.fake0,32
	.member	_CtrlBit,0,8,11,32,.fake1
	.member	_SecBit,0,8,11,32,.fake2
	.member	_DayBit,0,8,11,32,.fake3
	.member	_B8,0,12,11,32
	.eos
	.sym	_DS1647ONELTP,0,9,13,32,.fake0
	.sym	_PDS1647ONELTP,0,25,13,32,.fake0
	.stag	.fake4,256
	.member	_Ctrl,0,9,8,32,.fake0
	.member	_Second,32,9,8,32,.fake0
	.member	_Minute,64,9,8,32,.fake0
	.member	_Hour,96,9,8,32,.fake0
	.member	_Day,128,9,8,32,.fake0
	.member	_Date,160,9,8,32,.fake0
	.member	_Month,192,9,8,32,.fake0
	.member	_Year,224,9,8,32,.fake0
	.eos
	.sym	_DS1647BDY,0,8,13,256,.fake4
	.sym	_PDS1647BDY,0,24,13,32,.fake4
	.stag	.fake5,224
	.member	_second,0,12,8,32
	.member	_minute,32,12,8,32
	.member	_hour,64,12,8,32
	.member	_day,96,12,8,32
	.member	_month,128,12,8,32
	.member	_year,160,12,8,32
	.member	_weekday,192,12,8,32
	.eos
	.sym	_DATE_TIME_TYPE,0,8,13,224,.fake5
	.sym	_DATE_TIME_PTR,0,24,13,32,.fake5
	.file	"main.h"
	.file	"xr16l784.h"
	.utag	.fake7,32
	.member	_btRxd,0,12,11,32
	.member	_btTxd,0,12,11,32
	.member	_btDll,0,12,11,32
	.eos
	.utag	.fake8,32
	.member	_btDlm,0,12,11,32
	.member	_btIer,0,12,11,32
	.eos
	.utag	.fake9,32
	.member	_btIir,0,12,11,32
	.member	_btFcr,0,12,11,32
	.eos
	.stag	.fake6,512
	.member	_CREG1,0,9,8,32,.fake7
	.member	_CREG2,32,9,8,32,.fake8
	.member	_CREG3,64,9,8,32,.fake9
	.member	_btLcr,96,12,8,32
	.member	_btMcr,128,12,8,32
	.member	_btLsr,160,12,8,32
	.member	_btMsr_U,192,12,8,32
	.member	_btScr,224,12,8,32
	.member	_btSp,256,60,8,256,,8
	.eos
	.sym	_XR16L784ST,0,8,13,512,.fake6
	.sym	_PXR16L784ST,0,24,13,32,.fake6
	.stag	.fake10,2048
	.member	_xr16Reg,0,56,8,2048,.fake6,4
	.eos
	.sym	_XR16L784BDY,0,8,13,2048,.fake10
	.sym	_PXR16L784BDY,0,24,13,32,.fake10
	.file	"user.h"
	.stag	.fake11,6400
	.member	_btStx,0,12,8,32
	.member	_btCmd,32,12,8,32
	.member	_btMessCode,64,12,8,32
	.member	_btLen,96,12,8,32
	.member	_btDat,128,60,8,6272,,196
	.eos
	.sym	_LNWKFTPIT,0,8,13,6400,.fake11
	.sym	_PLNWKFTPIT,0,24,13,32,.fake11
	.stag	.fake12,6400
	.member	_btStx,0,12,8,32
	.member	_btCmd,32,12,8,32
	.member	_btMessCode,64,12,8,32
	.member	_btLen,96,12,8,32
	.member	_btDat,128,60,8,6272,,196
	.eos
	.sym	_LNWKGERIT,0,8,13,6400,.fake12
	.sym	_PLNWKGERIT,0,24,13,32,.fake12
	.stag	.fake13,51712
	.member	_btKind,0,12,8,32
	.member	_btVerH,32,12,8,32
	.member	_btVerL,64,12,8,32
	.member	_btBuildDateHH,96,12,8,32
	.member	_btBuildDateHL,128,12,8,32
	.member	_btBuildDateLH,160,12,8,32
	.member	_btBuildDateLL,192,12,8,32
	.member	_btSpare,224,60,8,288,,9
	.member	_lfBuf,512,56,8,38400,.fake11,6
	.member	_lgRxBuf,38912,8,8,6400,.fake12
	.member	_lgTxBuf,45312,8,8,6400,.fake12
	.eos
	.sym	_LNWKDP,0,8,13,51712,.fake13
	.sym	_PLNWKDP,0,24,13,32,.fake13
	.stag	.fake14,352
	.member	_btSoh,0,12,8,32
	.member	_chSrcDev,32,60,8,64,,2
	.member	_chDestDev,96,60,8,64,,2
	.member	_chMsgCnt,160,60,8,64,,2
	.member	_chCmdCode,224,60,8,64,,2
	.member	_chDataLen,288,60,8,64,,2
	.eos
	.sym	_PTCHD,0,8,13,352,.fake14
	.sym	_PPTCHD,0,24,13,32,.fake14
	.stag	.fake15,768
	.member	_chPacT,0,60,8,64,,2
	.member	_chCcpM,64,60,8,64,,2
	.member	_chCncsT,128,60,8,64,,2
	.member	_chD0,192,60,8,64,,2
	.member	_chD1,256,60,8,64,,2
	.member	_chTran,320,252,8,192,,3,2
	.member	_chCid,512,252,8,192,,3,2
	.member	_chDs,704,60,8,64,,2
	.eos
	.sym	_PROTOCOL_1,0,8,13,768,.fake15
	.stag	.fake16,576
	.member	_phHdBuf,0,8,8,352,.fake14
	.member	_nDdata,352,60,8,64,,2
	.member	_nCRC,416,60,8,128,,4
	.member	_btEot,544,12,8,32
	.eos
	.sym	_PACSDR,0,8,13,576,.fake16
	.sym	_PPACSDR,0,24,13,32,.fake16
	.stag	.fake19,32
	.member	_sBCab_ON,0,14,18,1
	.member	_sBSp_1,1,14,18,1
	.member	_sBSp_2,2,14,18,1
	.member	_sBHead_Bit,3,14,18,1
	.member	_sACab_ON,4,14,18,1
	.member	_sASp_1,5,14,18,1
	.member	_sASp_2,6,14,18,1
	.member	_sAHead_Bit,7,14,18,1
	.eos
	.utag	.fake18,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake19
	.eos
	.stag	.fake21,32
	.member	_sBWLR,0,14,18,1
	.member	_sBGPS,1,14,18,1
	.member	_sBVOIP,2,14,18,1
	.member	_sBCCP1,3,14,18,1
	.member	_sAWLR,4,14,18,1
	.member	_sAGPS,5,14,18,1
	.member	_sAVOIP,6,14,18,1
	.member	_sACCP1,7,14,18,1
	.eos
	.utag	.fake20,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake21
	.eos
	.stag	.fake23,32
	.member	_sBCNCS,0,14,18,1
	.member	_sBVTX,1,14,18,1
	.member	_sBLIC,2,14,18,1
	.member	_sBPAC,3,14,18,1
	.member	_sACNCS,4,14,18,1
	.member	_sAVTX,5,14,18,1
	.member	_sALIC,6,14,18,1
	.member	_sAPAC,7,14,18,1
	.eos
	.utag	.fake22,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake23
	.eos
	.stag	.fake25,32
	.member	_sBPII2,0,14,18,1
	.member	_sBPII1,1,14,18,1
	.member	_sBFDI,2,14,18,1
	.member	_sBSp_3,3,14,18,1
	.member	_sAPII2,4,14,18,1
	.member	_sAPII1,5,14,18,1
	.member	_sAFDI,6,14,18,1
	.member	_sASp_3,7,14,18,1
	.eos
	.utag	.fake24,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake25
	.eos
	.stag	.fake27,32
	.member	_sBSDI4,0,14,18,1
	.member	_sBSDI3,1,14,18,1
	.member	_sBSDI2,2,14,18,1
	.member	_sBSDI1,3,14,18,1
	.member	_sASDI4,4,14,18,1
	.member	_sASDI3,5,14,18,1
	.member	_sASDI2,6,14,18,1
	.member	_sASDI1,7,14,18,1
	.eos
	.utag	.fake26,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake27
	.eos
	.stag	.fake29,32
	.member	_sBPID1_4,0,14,18,1
	.member	_sBPID1_3,1,14,18,1
	.member	_sBPID1_2,2,14,18,1
	.member	_sBPID1_1,3,14,18,1
	.member	_sAPID1_4,4,14,18,1
	.member	_sAPID1_3,5,14,18,1
	.member	_sAPID1_2,6,14,18,1
	.member	_sAPID1_1,7,14,18,1
	.eos
	.utag	.fake28,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake29
	.eos
	.stag	.fake31,32
	.member	_sBPEI1,0,14,18,1
	.member	_sBPEI2,1,14,18,1
	.member	_sBSp_3,2,14,18,1
	.member	_sBPID2_1,3,14,18,1
	.member	_sAPEI1,4,14,18,1
	.member	_sAPEI2,5,14,18,1
	.member	_sASp_3,6,14,18,1
	.member	_sAPID2_1,7,14,18,1
	.eos
	.utag	.fake30,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake31
	.eos
	.stag	.fake33,32
	.member	_sBPEI1_Call,0,14,18,1
	.member	_sBPEI2_Call,1,14,18,1
	.member	_sBSp_2,2,14,18,1
	.member	_sBSp_3,3,14,18,1
	.member	_sAPEI1_Call,4,14,18,1
	.member	_sAPEI2_Call,5,14,18,1
	.member	_sASp_2,6,14,18,1
	.member	_sASp_3,7,14,18,1
	.eos
	.utag	.fake32,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake33
	.eos
	.stag	.fake35,32
	.member	_sBDPO,0,14,18,1
	.member	_sBSp_2,1,14,18,1
	.member	_sBSp_3,2,14,18,1
	.member	_sBDPH,3,14,18,1
	.member	_sADPO,4,14,18,1
	.member	_sASp_2,5,14,18,1
	.member	_sASp_3,6,14,18,1
	.member	_sADPH,7,14,18,1
	.eos
	.utag	.fake34,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake35
	.eos
	.stag	.fake17,352
	.member	_CRA_1,0,9,8,32,.fake18
	.member	_CRA_2,32,9,8,32,.fake20
	.member	_CRA_3,64,9,8,32,.fake22
	.member	_CRA_4,96,9,8,32,.fake24
	.member	_CRA_5,128,9,8,32,.fake26
	.member	_CRA_6,160,9,8,32,.fake28
	.member	_CRA_7,192,9,8,32,.fake30
	.member	_CRA_8,224,9,8,32,.fake32
	.member	_CRA_9,256,9,8,32,.fake34
	.member	_CarNum_H,288,12,8,32
	.member	_CarNum_L,320,12,8,32
	.eos
	.sym	_CRA_STATION,0,8,13,352,.fake17
	.sym	_PCRA_STATION,0,24,13,32,.fake17
	.stag	.fake36,8128
	.member	_phHdBuf,0,8,8,352,.fake14
	.member	_sPAC_T,352,252,8,128,,2,2
	.member	_sC_ID,480,60,8,64,,2
	.member	_sDO,544,60,8,64,,2
	.member	_sD1,608,60,8,64,,2
	.member	_sODM,672,252,8,256,,4,2
	.member	_sANS,928,60,8,64,,2
	.member	_sTRAN_NO,992,252,8,192,,3,2
	.member	_sCRAW_ID,1184,252,8,192,,3,2
	.member	_sTRIP,1376,252,8,192,,3,2
	.member	_sD2,1568,60,8,64,,2
	.member	_sSTST,1632,252,8,128,,2,2
	.member	_sNOST,1760,252,8,128,,2,2
	.member	_sNEST,1888,252,8,128,,2,2
	.member	_sDEST,2016,252,8,128,,2,2
	.member	_sSPK,2144,252,8,256,,4,2
	.member	_sD3,2400,252,8,128,,2,2
	.member	_sD4,2528,252,8,128,,2,2
	.member	_sPR,2656,60,8,64,,2
	.member	_sPRVector,2720,252,8,128,,2,2
	.member	_sPACVector,2848,252,8,128,,2,2
	.member	_sFDI_SDI_Color,2976,252,8,128,,2,2
	.member	_sFDI_SDI_Vector1,3104,252,8,128,,2,2
	.member	_sFDI_SDI_Vector2,3232,252,8,128,,2,2
	.member	_sPII_Vector,3360,252,8,128,,2,2
	.member	_sPP_Line_Vector,3488,252,8,128,,2,2
	.member	_sPP_Vector,3616,252,8,128,,2,2
	.member	_sSP_Vector,3744,252,8,128,,2,2
	.member	_sROUTE_SKIP,3872,252,8,640,,10,2
	.member	_sCI_Index,4512,252,8,512,,8,2
	.member	_sCI_Fault,5024,60,8,64,,2
	.member	_sCCI,5088,60,8,64,,2
	.member	_phCRA_Sta,5152,1020,8,2816,,4,11,2
	.member	_nCRC,7968,60,8,128,,4
	.member	_btEot,8096,12,8,32
	.eos
	.sym	_PAC_PAC,0,8,13,8128,.fake36
	.sym	_PPAC_PAC,0,24,13,32,.fake36
	.stag	.fake37,4992
	.member	_phHdBuf,0,8,8,352,.fake14
	.member	_sDO,352,60,8,64,,2
	.member	_sTRAN_NO,416,252,8,192,,3,2
	.member	_sCRAW_ID,608,252,8,192,,3,2
	.member	_sTRIP,800,252,8,192,,3,2
	.member	_sD1,992,60,8,64,,2
	.member	_sSTST,1056,252,8,128,,2,2
	.member	_sNOST,1184,252,8,128,,2,2
	.member	_sNEST,1312,252,8,128,,2,2
	.member	_sDEST,1440,252,8,128,,2,2
	.member	_sSPK,1568,252,8,256,,4,2
	.member	_sD2,1824,252,8,128,,2,2
	.member	_sD3,1952,252,8,128,,2,2
	.member	_sPR,2080,60,8,64,,2
	.member	_sPRVector,2144,252,8,128,,2,2
	.member	_sPACVector,2272,252,8,128,,2,2
	.member	_sFDI_SDI_Color,2400,252,8,128,,2,2
	.member	_sFDI_SDI_Vector1,2528,252,8,128,,2,2
	.member	_sFDI_SDI_Vector2,2656,252,8,128,,2,2
	.member	_sPII_Vector,2784,252,8,128,,2,2
	.member	_sPP_Line_Vector,2912,252,8,128,,2,2
	.member	_sPP_Vector,3040,252,8,128,,2,2
	.member	_sSP_Vector,3168,252,8,128,,2,2
	.member	_sROUTE_SKIP,3296,252,8,640,,10,2
	.member	_sCI_Index,3936,252,8,512,,8,2
	.member	_sCCP_Date,4448,252,8,384,,6,2
	.member	_nCRC,4832,60,8,128,,4
	.member	_btEot,4960,12,8,32
	.eos
	.sym	_CCP_PAC,0,8,13,4992,.fake37
	.sym	_PCCP_PAC,0,24,13,32,.fake37
	.stag	.fake40,32
	.member	_Sp_0,0,14,18,1
	.member	_Sp_1,1,14,18,1
	.member	_CI_Fault,2,14,18,1
	.member	_DST,3,14,18,1
	.member	_Sp_4,4,14,18,1
	.member	_Sp_5,5,14,18,1
	.member	_Sp_6,6,14,18,1
	.member	_Sp_7,7,14,18,1
	.eos
	.utag	.fake39,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake40
	.eos
	.stag	.fake42,32
	.member	_All_Doors_Closed,0,14,18,1
	.member	_EP_Mode,1,14,18,1
	.member	_Traction,2,14,18,1
	.member	_Atcive_Cab,3,14,18,1
	.member	_Sp_4,4,14,18,1
	.member	_Sp_5,5,14,18,1
	.member	_Sp_6,6,14,18,1
	.member	_Sp_7,7,14,18,1
	.eos
	.utag	.fake41,32
	.member	_BYTE,0,14,11,32
	.member	_BIT,0,8,11,32,.fake42
	.eos
	.stag	.fake38,768
	.member	_phHdBuf,0,8,8,352,.fake14
	.member	_DATA2,352,9,8,32,.fake39
	.member	_DATA1,384,9,8,32,.fake41
	.member	_CI_Index_Num,416,60,8,64,,2
	.member	_chCarn,480,252,8,128,,2,2
	.member	_nCRC,608,60,8,128,,4
	.member	_btEot,736,12,8,32
	.eos
	.sym	_LICSD,0,8,13,768,.fake38
	.sym	_PLICSDR,0,24,13,32,.fake38
	.stag	.fake43,480
	.member	_btSoh,0,12,8,32
	.member	_chSrcDev,32,60,8,64,,2
	.member	_chDestDev,96,60,8,64,,2
	.member	_chMsgCnt,160,60,8,128,,4
	.member	_chCmdCode,288,60,8,64,,2
	.member	_chDataLen,352,60,8,128,,4
	.eos
	.sym	_CNCSHD,0,8,13,480,.fake43
	.sym	_PCNCSHD,0,24,13,32,.fake43
	.stag	.fake44,10208
	.member	_phHdBuf,0,8,8,480,.fake43
	.member	_sCommand,480,60,8,64,,2
	.member	_sCarKind,544,60,8,64,,2
	.member	_sTextDataAsc,608,60,8,9600,,300
	.eos
	.sym	_LIC_CNCS_HD,0,8,13,10208,.fake44
	.sym	_PLIC_CNCS_HD,0,24,13,32,.fake44
	.stag	.fake45,320
	.member	_chVer,0,50,8,128,,4
	.member	_chBuildDate,128,50,8,192,,6
	.eos
	.sym	_CNCS_LIC_VERBDD_SD,0,8,13,320,.fake45
	.sym	_PCNCS_LIC_VERBDD_SD,0,24,13,32,.fake45
	.stag	.fake46,7776
	.member	_VerCnt,0,13,8,32
	.member	_cvbBuf,32,56,8,7680,.fake45,24
	.member	_CarNum,7712,61,8,64,,2
	.eos
	.sym	_LIC_DPRAM_Ver,0,8,13,7776,.fake46
	.sym	_PLIC_DPRAM_Ver,0,24,13,32,.fake46
	.stag	.fake47,4096
	.member	_s1TRIC,0,252,8,256,,2,4
	.member	_s2CCP,256,252,8,256,,2,4
	.member	_s3LIC_LON,512,252,8,256,,2,4
	.member	_s4GIA,768,252,8,256,,2,4
	.member	_s5VTX,1024,252,8,256,,2,4
	.member	_s6PAC,1280,252,8,256,,2,4
	.member	_s7FDI,1536,252,8,256,,2,4
	.member	_s8SDI,1792,252,8,256,,2,4
	.member	_s9PII,2048,252,8,256,,2,4
	.member	_s10VRX,2304,252,8,256,,2,4
	.member	_s11CN_MAIN,2560,252,8,256,,2,4
	.member	_s12CN_LAVN,2816,252,8,256,,2,4
	.member	_s13CN_VP,3072,252,8,256,,2,4
	.member	_s14CN_PPLOY,3328,252,8,256,,2,4
	.member	_s15CN_SPLAY,3584,252,8,256,,2,4
	.member	_s16CN_PTU,3840,252,8,256,,2,4
	.eos
	.sym	_LIC_VER_LIST,0,8,13,4096,.fake47
	.sym	_PLIC_VER_LIST,0,24,13,32,.fake47
	.stag	.fake48,9088
	.member	_phHdBuf,0,8,8,480,.fake43
	.member	_sCommand,480,60,8,64,,2
	.member	_sYear,544,60,8,64,,2
	.member	_sMonth,608,60,8,64,,2
	.member	_sDay,672,60,8,64,,2
	.member	_sHour,736,60,8,64,,2
	.member	_sMinute,800,60,8,64,,2
	.member	_sSecond,864,60,8,64,,2
	.member	_sWaySide,928,60,8,64,,2
	.member	_sDaType,992,60,8,64,,2
	.member	_sFaultTime,1056,60,8,256,,8
	.member	_cvbBuf,1312,56,8,7680,.fake45,24
	.member	_chChkSum,8992,60,8,64,,2
	.member	_btEot,9056,12,8,32
	.eos
	.sym	_CNCS_LIC_SD,0,8,13,9088,.fake48
	.sym	_PCNCS_LIC_SD,0,24,13,32,.fake48
	.stag	.fake49,832
	.member	_phHdBuf,0,8,8,480,.fake43
	.member	_sCommand,480,60,8,64,,2
	.member	_sTEXT,544,60,8,128,,4
	.member	_chContactSignalBuf,672,60,8,64,,2
	.member	_chChkSum,736,60,8,64,,2
	.member	_btEot,800,12,8,32
	.eos
	.sym	_CNCS_LIC_T_F,0,8,13,832,.fake49
	.sym	_PCNCS_LIC_T_F,0,24,13,32,.fake49
	.stag	.fake50,768
	.member	_phHdBuf,0,8,8,480,.fake43
	.member	_sCommand,480,60,8,64,,2
	.member	_sTEXT,544,60,8,128,,4
	.member	_chChkSum,672,60,8,64,,2
	.member	_btEot,736,12,8,32
	.eos
	.sym	_CNCS_LIC_T_F_C,0,8,13,768,.fake50
	.sym	_PCNCS_LIC_T_F_C,0,24,13,32,.fake50
	.stag	.fake51,96
	.member	_sChSum,0,60,8,64,,2
	.member	_sETX,64,12,8,32
	.eos
	.sym	_LIC_CNCS_ED,0,8,13,96,.fake51
	.sym	_PLIC_CNCS_ED,0,24,13,32,.fake51
	.stag	.fake53,32
	.member	_n1VTX,0,14,18,1
	.member	_n2CNCS,1,14,18,1
	.member	_n3PAC2,2,14,18,1
	.member	_n4LIC,3,14,18,1
	.member	_n5WLAN,4,14,18,1
	.member	_n6GPS,5,14,18,1
	.member	_n7PAC1,6,14,18,1
	.member	_n8sp,7,14,18,1
	.eos
	.stag	.fake54,32
	.member	_n1DPO1,0,14,18,1
	.member	_n2DPO2,1,14,18,1
	.member	_n3CCP1,2,14,18,1
	.member	_n4CCP2,3,14,18,1
	.member	_n5TRIC1,4,14,18,1
	.member	_n6TRIC2,5,14,18,1
	.member	_n7TR1,6,14,18,1
	.member	_n8TR2,7,14,18,1
	.eos
	.stag	.fake55,32
	.member	_n1Sp,0,14,18,1
	.member	_n2Sp,1,14,18,1
	.member	_n3CPO1,2,14,18,1
	.member	_n4CPO2,3,14,18,1
	.member	_n5CPO3,4,14,18,1
	.member	_n6CPO4,5,14,18,1
	.member	_n7Sp,6,14,18,1
	.member	_n8Sp,7,14,18,1
	.eos
	.stag	.fake56,32
	.member	_n1PEI1,0,14,18,1
	.member	_n2PEI2,1,14,18,1
	.member	_n3PEI3,2,14,18,1
	.member	_n4PEI4,3,14,18,1
	.member	_n5PEI5,4,14,18,1
	.member	_n6PEI6,5,14,18,1
	.member	_n7FDI1,6,14,18,1
	.member	_n8FDI2,7,14,18,1
	.eos
	.stag	.fake57,32
	.member	_n1SDI1,0,14,18,1
	.member	_n2SDI2,1,14,18,1
	.member	_n3SDI3,2,14,18,1
	.member	_n4SDI4,3,14,18,1
	.member	_n5SDI5,4,14,18,1
	.member	_n6SDI6,5,14,18,1
	.member	_n7SDI7,6,14,18,1
	.member	_n8SDI8,7,14,18,1
	.eos
	.stag	.fake58,32
	.member	_n1PID1_1,0,14,18,1
	.member	_n2PID1_2,1,14,18,1
	.member	_n3PID1_3,2,14,18,1
	.member	_n4PID1_4,3,14,18,1
	.member	_n5PID1_5,4,14,18,1
	.member	_n6PID1_6,5,14,18,1
	.member	_n7PID1_7,6,14,18,1
	.member	_n8PID1_8,7,14,18,1
	.eos
	.stag	.fake59,32
	.member	_n1PID2_1,0,14,18,1
	.member	_n2PID2_2,1,14,18,1
	.member	_n3PID2_3,2,14,18,1
	.member	_n4PID2_4,3,14,18,1
	.member	_n5PII1,4,14,18,1
	.member	_n6PII2,5,14,18,1
	.member	_n7PII3,6,14,18,1
	.member	_n8PII4,7,14,18,1
	.eos
	.stag	.fake52,256
	.member	_BYTE_1,0,8,8,32,.fake53
	.member	_BYTE_2,32,8,8,32,.fake54
	.member	_BYTE_3,64,8,8,32,.fake55
	.member	_BYTE_4,96,8,8,32,.fake56
	.member	_BYTE_5,128,12,8,32
	.member	_BYTE_6,160,8,8,32,.fake57
	.member	_BYTE_7,192,8,8,32,.fake58
	.member	_BYTE_8,224,8,8,32,.fake59
	.eos
	.sym	_COMMSTATUS_PA,0,8,13,256,.fake52
	.sym	_PCOMMSTATUS_PA,0,24,13,32,.fake52
	.stag	.fake62,32
	.member	_nCncs,0,14,18,1
	.member	_nVtx,1,14,18,1
	.member	_nLic,2,14,18,1
	.member	_nPac,3,14,18,1
	.member	_nWlr,4,14,18,1
	.member	_nGps,5,14,18,1
	.member	_nVoip,6,14,18,1
	.member	_nCcp,7,14,18,1
	.eos
	.utag	.fake61,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake62
	.eos
	.stag	.fake64,32
	.member	_nSdi4,0,14,18,1
	.member	_nSdi3,1,14,18,1
	.member	_nSdi2,2,14,18,1
	.member	_nSdi1,3,14,18,1
	.member	_nPii2,4,14,18,1
	.member	_nPii1,5,14,18,1
	.member	_nFdi,6,14,18,1
	.member	_sp_7,7,14,18,1
	.eos
	.utag	.fake63,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake64
	.eos
	.stag	.fake66,32
	.member	_nPid2_1,0,14,18,1
	.member	_nPid1_4,1,14,18,1
	.member	_nPid1_3,2,14,18,1
	.member	_nPid1_2,3,14,18,1
	.member	_nPid1_1,4,14,18,1
	.member	_sp_5,5,14,18,1
	.member	_sp_4,6,14,18,1
	.member	_sp_7,7,14,18,1
	.eos
	.utag	.fake65,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake66
	.eos
	.stag	.fake68,32
	.member	_nPei1,0,14,18,1
	.member	_nPei2,1,14,18,1
	.member	_sp_2,2,14,18,1
	.member	_sp_3,3,14,18,1
	.member	_nDpo,4,14,18,1
	.member	_sp_5,5,14,18,1
	.member	_sp_6,6,14,18,1
	.member	_nDph,7,14,18,1
	.eos
	.utag	.fake67,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake68
	.eos
	.stag	.fake70,32
	.member	_sp_0,0,14,18,1
	.member	_sp_1,1,14,18,1
	.member	_sp_2,2,14,18,1
	.member	_sp_3,3,14,18,1
	.member	_sp_4,4,14,18,1
	.member	_sp_5,5,14,18,1
	.member	_sp_6,6,14,18,1
	.member	_sp_7,7,14,18,1
	.eos
	.utag	.fake69,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake70
	.eos
	.stag	.fake60,160
	.member	_BYTE_1,0,9,8,32,.fake61
	.member	_BYTE_2,32,9,8,32,.fake63
	.member	_BYTE_3,64,9,8,32,.fake65
	.member	_BYTE_4,96,9,8,32,.fake67
	.member	_BYTE_5,128,9,8,32,.fake69
	.eos
	.sym	_COMMSTATUS_LIC,0,8,13,160,.fake60
	.sym	_PCOMMSTATUS_LIC,0,24,13,32,.fake60
	.stag	.fake73,32
	.member	_n1Reverse,0,14,18,1
	.member	_n2ForWard,1,14,18,1
	.member	_n3Uncouple,2,14,18,1
	.member	_n4Simulation,3,14,18,1
	.member	_n5Pattern,4,14,18,1
	.member	_n6A_CabOn,5,14,18,1
	.member	_n7B_CabOn,6,14,18,1
	.member	_n8sp,7,14,18,1
	.eos
	.utag	.fake72,32
	.member	_BYTE,0,12,11,32
	.member	_BIT,0,8,11,32,.fake73
	.eos
	.stag	.fake71,32
	.member	_n1DATA,0,9,8,32,.fake72
	.eos
	.sym	_RACK_DI,0,8,13,32,.fake71
	.sym	_PRACK_DI,0,24,13,32,.fake71
	.etag	_eCDT_TYPE,32
	.member	_eCDT_A,0,4,16,32
	.member	_eCDT_B,1,4,16,32
	.member	_eCDT_MAXIMUM,2,4,16,32
	.eos
	.stag	.fake74,96
	.member	_nTCnt,0,4,8,32
	.member	_nStPosi,32,4,8,32
	.member	_nEdPosi,64,4,8,32
	.eos
	.sym	_T_FAULT_INFO,0,8,13,96,.fake74
	.sym	_PFAULT_INFO,0,24,13,32,.fake74
	.file	"user.c"

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nUserDebug1msTimer+0,32
	.field  	0,32		; _m_nUserDebug1msTimer @ 0

	.sect	".text"

	.global	_m_nUserDebug1msTimer
	.bss	_m_nUserDebug1msTimer,1
	.sym	_m_nUserDebug1msTimer,_m_nUserDebug1msTimer,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nUart1RxOneByteGapDelayTime+0,32
	.field  	0,32		; _m_nUart1RxOneByteGapDelayTime @ 0

	.sect	".text"

	.global	_m_nUart1RxOneByteGapDelayTime
	.bss	_m_nUart1RxOneByteGapDelayTime,1
	.sym	_m_nUart1RxOneByteGapDelayTime,_m_nUart1RxOneByteGapDelayTime,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nUart2RxOneByteGapDelayTime+0,32
	.field  	0,32		; _m_nUart2RxOneByteGapDelayTime @ 0

	.sect	".text"

	.global	_m_nUart2RxOneByteGapDelayTime
	.bss	_m_nUart2RxOneByteGapDelayTime,1
	.sym	_m_nUart2RxOneByteGapDelayTime,_m_nUart2RxOneByteGapDelayTime,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nUart3RxOneByteGapDelayTime+0,32
	.field  	0,32		; _m_nUart3RxOneByteGapDelayTime @ 0

	.sect	".text"

	.global	_m_nUart3RxOneByteGapDelayTime
	.bss	_m_nUart3RxOneByteGapDelayTime,1
	.sym	_m_nUart3RxOneByteGapDelayTime,_m_nUart3RxOneByteGapDelayTime,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_LIC_CNCS_Tx_Flag+0,32
	.field  	0,32		; _m_LIC_CNCS_Tx_Flag @ 0

	.sect	".text"

	.global	_m_LIC_CNCS_Tx_Flag
	.bss	_m_LIC_CNCS_Tx_Flag,1
	.sym	_m_LIC_CNCS_Tx_Flag,_m_LIC_CNCS_Tx_Flag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_LIC_CNCS_TX_DelyTime+0,32
	.field  	0,32		; _m_LIC_CNCS_TX_DelyTime @ 0

	.sect	".text"

	.global	_m_LIC_CNCS_TX_DelyTime
	.bss	_m_LIC_CNCS_TX_DelyTime,1
	.sym	_m_LIC_CNCS_TX_DelyTime,_m_LIC_CNCS_TX_DelyTime,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nLnWkTxFlag+0,32
	.field  	0,32		; _m_nLnWkTxFlag @ 0

	.sect	".text"

	.global	_m_nLnWkTxFlag
	.bss	_m_nLnWkTxFlag,1
	.sym	_m_nLnWkTxFlag,_m_nLnWkTxFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_chCarKind+0,32
	.field  	65,32		; _m_chCarKind @ 0

	.sect	".text"

	.global	_m_chCarKind
	.bss	_m_chCarKind,1
	.sym	_m_chCarKind,_m_chCarKind,2,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nFaultCnt+0,32
	.field  	0,32		; _m_nFaultCnt @ 0

	.sect	".text"

	.global	_m_nFaultCnt
	.bss	_m_nFaultCnt,1
	.sym	_m_nFaultCnt,_m_nFaultCnt,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_nRecving_Posi+0,32
	.field  	0,32		; _nRecving_Posi @ 0

	.sect	".text"

	.global	_nRecving_Posi
	.bss	_nRecving_Posi,1
	.sym	_nRecving_Posi,_nRecving_Posi,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nCDT_FaultDataStFlag+0,32
	.field  	0,32		; _m_nCDT_FaultDataStFlag @ 0

	.sect	".text"

	.global	_m_nCDT_FaultDataStFlag
	.bss	_m_nCDT_FaultDataStFlag,1
	.sym	_m_nCDT_FaultDataStFlag,_m_nCDT_FaultDataStFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_TrainCof_Flag+0,32
	.field  	0,32		; _m_TrainCof_Flag @ 0

	.sect	".text"

	.global	_m_TrainCof_Flag
	.bss	_m_TrainCof_Flag,1
	.sym	_m_TrainCof_Flag,_m_TrainCof_Flag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_TrainCof_Val+0,32
	.field  	0,32		; _m_TrainCof_Val @ 0

	.sect	".text"

	.global	_m_TrainCof_Val
	.bss	_m_TrainCof_Val,1
	.sym	_m_TrainCof_Val,_m_TrainCof_Val,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_CiPosi_Flag+0,32
	.field  	0,32		; _m_CiPosi_Flag @ 0

	.sect	".text"

	.global	_m_CiPosi_Flag
	.bss	_m_CiPosi_Flag,1
	.sym	_m_CiPosi_Flag,_m_CiPosi_Flag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_CiPosi_Val+0,32
	.field  	0,32		; _m_CiPosi_Val @ 0

	.sect	".text"

	.global	_m_CiPosi_Val
	.bss	_m_CiPosi_Val,1
	.sym	_m_CiPosi_Val,_m_CiPosi_Val,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_CiFault_Flag+0,32
	.field  	0,32		; _m_CiFault_Flag @ 0

	.sect	".text"

	.global	_m_CiFault_Flag
	.bss	_m_CiFault_Flag,1
	.sym	_m_CiFault_Flag,_m_CiFault_Flag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_CiFault_Val+0,32
	.field  	0,32		; _m_CiFault_Val @ 0

	.sect	".text"

	.global	_m_CiFault_Val
	.bss	_m_CiFault_Val,1
	.sym	_m_CiFault_Val,_m_CiFault_Val,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_DIAdd_Flag+0,32
	.field  	0,32		; _m_DIAdd_Flag @ 0

	.sect	".text"

	.global	_m_DIAdd_Flag
	.bss	_m_DIAdd_Flag,1
	.sym	_m_DIAdd_Flag,_m_DIAdd_Flag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_DIAdd_Val+0,32
	.field  	0,32		; _m_DIAdd_Val @ 0

	.sect	".text"

	.global	_m_DIAdd_Val
	.bss	_m_DIAdd_Val,1
	.sym	_m_DIAdd_Val,_m_DIAdd_Val,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_wCarNo+0,32
	.field  	16385,32		; _m_wCarNo @ 0

	.sect	".text"

	.global	_m_wCarNo
	.bss	_m_wCarNo,1
	.sym	_m_wCarNo,_m_wCarNo,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_bLnWkDbgTxFlag+0,32
	.field  	0,32		; _m_bLnWkDbgTxFlag @ 0

	.sect	".text"

	.global	_m_bLnWkDbgTxFlag
	.bss	_m_bLnWkDbgTxFlag,1
	.sym	_m_bLnWkDbgTxFlag,_m_bLnWkDbgTxFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nLnWkWaySideOnRxOk+0,32
	.field  	0,32		; _m_nLnWkWaySideOnRxOk @ 0

	.sect	".text"

	.global	_m_nLnWkWaySideOnRxOk
	.bss	_m_nLnWkWaySideOnRxOk,1
	.sym	_m_nLnWkWaySideOnRxOk,_m_nLnWkWaySideOnRxOk,12,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nCarCnt+0,32
	.field  	0,32		; _m_nCarCnt @ 0

	.sect	".text"

	.global	_m_nCarCnt
	.bss	_m_nCarCnt,1
	.sym	_m_nCarCnt,_m_nCarCnt,12,2,32

	.sect	".cinit"
	.field  	IR_1,32
	.field  	_m_nCarNo+0,32
	.field  	0,32		; _m_nCarNo[0] @ 0
	.field  	0,32		; _m_nCarNo[1] @ 32
IR_1:	.set	2

	.sect	".text"

	.global	_m_nCarNo
	.bss	_m_nCarNo,2
	.sym	_m_nCarNo,_m_nCarNo,61,2,64,,2

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nNvsramPos+0,32
	.field  	0,32		; _m_nNvsramPos @ 0

	.sect	".text"

	.global	_m_nNvsramPos
	.bss	_m_nNvsramPos,1
	.sym	_m_nNvsramPos,_m_nNvsramPos,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_bLnWkFtpEndFlag+0,32
	.field  	0,32		; _m_bLnWkFtpEndFlag @ 0

	.sect	".text"

	.global	_m_bLnWkFtpEndFlag
	.bss	_m_bLnWkFtpEndFlag,1
	.sym	_m_bLnWkFtpEndFlag,_m_bLnWkFtpEndFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nDateTime2SecondCnt+0,32
	.field  	0,32		; _m_nDateTime2SecondCnt @ 0

	.sect	".text"

	.global	_m_nDateTime2SecondCnt
	.bss	_m_nDateTime2SecondCnt,1
	.sym	_m_nDateTime2SecondCnt,_m_nDateTime2SecondCnt,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nTxDbg1msTimer+0,32
	.field  	0,32		; _m_nTxDbg1msTimer @ 0

	.sect	".text"

	.global	_m_nTxDbg1msTimer
	.bss	_m_nTxDbg1msTimer,1
	.sym	_m_nTxDbg1msTimer,_m_nTxDbg1msTimer,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nDbgTxPos+0,32
	.field  	-1,32		; _m_nDbgTxPos @ 0

	.sect	".text"

	.global	_m_nDbgTxPos
	.bss	_m_nDbgTxPos,1
	.sym	_m_nDbgTxPos,_m_nDbgTxPos,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nSingleOrMarriedCarUpdate1msTimer+0,32
	.field  	0,32		; _m_nSingleOrMarriedCarUpdate1msTimer @ 0

	.sect	".text"

	.global	_m_nSingleOrMarriedCarUpdate1msTimer
	.bss	_m_nSingleOrMarriedCarUpdate1msTimer,1
	.sym	_m_nSingleOrMarriedCarUpdate1msTimer,_m_nSingleOrMarriedCarUpdate1msTimer,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_btCttSignalA+0,32
	.field  	0,32		; _m_btCttSignalA @ 0

	.sect	".text"

	.global	_m_btCttSignalA
	.bss	_m_btCttSignalA,1
	.sym	_m_btCttSignalA,_m_btCttSignalA,12,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_btCttSignalB+0,32
	.field  	0,32		; _m_btCttSignalB @ 0

	.sect	".text"

	.global	_m_btCttSignalB
	.bss	_m_btCttSignalB,1
	.sym	_m_btCttSignalB,_m_btCttSignalB,12,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_LIC_CNCS_TimSetFlag+0,32
	.field  	0,32		; _m_LIC_CNCS_TimSetFlag @ 0

	.sect	".text"

	.global	_m_LIC_CNCS_TimSetFlag
	.bss	_m_LIC_CNCS_TimSetFlag,1
	.sym	_m_LIC_CNCS_TimSetFlag,_m_LIC_CNCS_TimSetFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_LIC_GIA_TimSetFlag+0,32
	.field  	0,32		; _m_LIC_GIA_TimSetFlag @ 0

	.sect	".text"

	.global	_m_LIC_GIA_TimSetFlag
	.bss	_m_LIC_GIA_TimSetFlag,1
	.sym	_m_LIC_GIA_TimSetFlag,_m_LIC_GIA_TimSetFlag,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nCncsRxCheck1msTimer+0,32
	.field  	0,32		; _m_nCncsRxCheck1msTimer @ 0

	.sect	".text"

	.global	_m_nCncsRxCheck1msTimer
	.bss	_m_nCncsRxCheck1msTimer,1
	.sym	_m_nCncsRxCheck1msTimer,_m_nCncsRxCheck1msTimer,14,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_m_nGiaRxCheck1msTimer+0,32
	.field  	0,32		; _m_nGiaRxCheck1msTimer @ 0

	.sect	".text"

	.global	_m_nGiaRxCheck1msTimer
	.bss	_m_nGiaRxCheck1msTimer,1
	.sym	_m_nGiaRxCheck1msTimer,_m_nGiaRxCheck1msTimer,14,2,32

	.sect	".cinit"
	.field  	IR_2,32
	.field  	_LIC_VerList+0,32
	.field  	67,32		; _LIC_VerList[0] @ 0
	.field  	67,32		; _LIC_VerList[1] @ 32
	.field  	80,32		; _LIC_VerList[2] @ 64
	.field  	0,32		; _LIC_VerList[3] @ 96
IR_2:	.set	4

	.sect	".text"

	.sect	".cinit"
	.field  	IR_3,32
	.field  	_LIC_VerList+9,32
	.field  	76,32		; _LIC_VerList[9] @ 288
	.field  	73,32		; _LIC_VerList[10] @ 320
	.field  	67,32		; _LIC_VerList[11] @ 352
	.field  	95,32		; _LIC_VerList[12] @ 384
	.field  	76,32		; _LIC_VerList[13] @ 416
	.field  	79,32		; _LIC_VerList[14] @ 448
	.field  	78,32		; _LIC_VerList[15] @ 480
	.field  	0,32		; _LIC_VerList[16] @ 512
	.field  	0,32
	.field  	86,32		; _LIC_VerList[18] @ 576
	.field  	84,32		; _LIC_VerList[19] @ 608
	.field  	88,32		; _LIC_VerList[20] @ 640
	.field  	0,32		; _LIC_VerList[21] @ 672
IR_3:	.set	13

	.sect	".text"

	.sect	".cinit"
	.field  	IR_4,32
	.field  	_LIC_VerList+27,32
	.field  	80,32		; _LIC_VerList[27] @ 864
	.field  	65,32		; _LIC_VerList[28] @ 896
	.field  	45,32		; _LIC_VerList[29] @ 928
	.field  	86,32		; _LIC_VerList[30] @ 960
	.field  	79,32		; _LIC_VerList[31] @ 992
	.field  	73,32		; _LIC_VerList[32] @ 1024
	.field  	80,32		; _LIC_VerList[33] @ 1056
	.field  	0,32		; _LIC_VerList[34] @ 1088
	.field  	0,32
	.field  	80,32		; _LIC_VerList[36] @ 1152
	.field  	65,32		; _LIC_VerList[37] @ 1184
	.field  	67,32		; _LIC_VerList[38] @ 1216
	.field  	45,32		; _LIC_VerList[39] @ 1248
	.field  	77,32		; _LIC_VerList[40] @ 1280
	.field  	67,32		; _LIC_VerList[41] @ 1312
	.field  	85,32		; _LIC_VerList[42] @ 1344
	.field  	0,32		; _LIC_VerList[43] @ 1376
	.field  	0,32
	.field  	70,32		; _LIC_VerList[45] @ 1440
	.field  	68,32		; _LIC_VerList[46] @ 1472
	.field  	73,32		; _LIC_VerList[47] @ 1504
	.field  	49,32		; _LIC_VerList[48] @ 1536
	.field  	0,32		; _LIC_VerList[49] @ 1568
	.space	4
	.field  	83,32		; _LIC_VerList[54] @ 1728
	.field  	68,32		; _LIC_VerList[55] @ 1760
	.field  	73,32		; _LIC_VerList[56] @ 1792
	.field  	49,32		; _LIC_VerList[57] @ 1824
	.field  	0,32		; _LIC_VerList[58] @ 1856
	.space	4
	.field  	83,32		; _LIC_VerList[63] @ 2016
	.field  	68,32		; _LIC_VerList[64] @ 2048
	.field  	73,32		; _LIC_VerList[65] @ 2080
	.field  	50,32		; _LIC_VerList[66] @ 2112
	.field  	0,32		; _LIC_VerList[67] @ 2144
	.space	4
	.field  	83,32		; _LIC_VerList[72] @ 2304
	.field  	68,32		; _LIC_VerList[73] @ 2336
	.field  	73,32		; _LIC_VerList[74] @ 2368
	.field  	51,32		; _LIC_VerList[75] @ 2400
	.field  	0,32		; _LIC_VerList[76] @ 2432
	.space	4
	.field  	83,32		; _LIC_VerList[81] @ 2592
	.field  	68,32		; _LIC_VerList[82] @ 2624
	.field  	73,32		; _LIC_VerList[83] @ 2656
	.field  	52,32		; _LIC_VerList[84] @ 2688
	.field  	0,32		; _LIC_VerList[85] @ 2720
	.space	4
	.field  	80,32		; _LIC_VerList[90] @ 2880
	.field  	73,32		; _LIC_VerList[91] @ 2912
	.field  	73,32		; _LIC_VerList[92] @ 2944
	.field  	49,32		; _LIC_VerList[93] @ 2976
	.field  	0,32		; _LIC_VerList[94] @ 3008
	.space	4
	.field  	80,32		; _LIC_VerList[99] @ 3168
	.field  	73,32		; _LIC_VerList[100] @ 3200
	.field  	73,32		; _LIC_VerList[101] @ 3232
	.field  	50,32		; _LIC_VerList[102] @ 3264
	.field  	0,32		; _LIC_VerList[103] @ 3296
	.space	4
	.field  	80,32		; _LIC_VerList[108] @ 3456
	.field  	73,32		; _LIC_VerList[109] @ 3488
	.field  	68,32		; _LIC_VerList[110] @ 3520
	.field  	49,32		; _LIC_VerList[111] @ 3552
	.field  	0,32		; _LIC_VerList[112] @ 3584
	.space	4
	.field  	80,32		; _LIC_VerList[117] @ 3744
	.field  	73,32		; _LIC_VerList[118] @ 3776
	.field  	68,32		; _LIC_VerList[119] @ 3808
	.field  	50,32		; _LIC_VerList[120] @ 3840
	.field  	0,32		; _LIC_VerList[121] @ 3872
	.space	4
	.field  	80,32		; _LIC_VerList[126] @ 4032
	.field  	73,32		; _LIC_VerList[127] @ 4064
	.field  	68,32		; _LIC_VerList[128] @ 4096
	.field  	51,32		; _LIC_VerList[129] @ 4128
	.field  	0,32		; _LIC_VerList[130] @ 4160
	.space	4
	.field  	80,32		; _LIC_VerList[135] @ 4320
	.field  	73,32		; _LIC_VerList[136] @ 4352
	.field  	68,32		; _LIC_VerList[137] @ 4384
	.field  	52,32		; _LIC_VerList[138] @ 4416
	.field  	0,32		; _LIC_VerList[139] @ 4448
	.space	4
	.field  	80,32		; _LIC_VerList[144] @ 4608
	.field  	73,32		; _LIC_VerList[145] @ 4640
	.field  	68,32		; _LIC_VerList[146] @ 4672
	.field  	50,32		; _LIC_VerList[147] @ 4704
	.field  	45,32		; _LIC_VerList[148] @ 4736
	.field  	49,32		; _LIC_VerList[149] @ 4768
	.field  	0,32		; _LIC_VerList[150] @ 4800
	.space	2
	.field  	67,32		; _LIC_VerList[153] @ 4896
	.field  	82,32		; _LIC_VerList[154] @ 4928
	.field  	65,32		; _LIC_VerList[155] @ 4960
	.field  	45,32		; _LIC_VerList[156] @ 4992
	.field  	77,32		; _LIC_VerList[157] @ 5024
	.field  	65,32		; _LIC_VerList[158] @ 5056
	.field  	73,32		; _LIC_VerList[159] @ 5088
	.field  	78,32		; _LIC_VerList[160] @ 5120
	.field  	0,32		; _LIC_VerList[161] @ 5152
	.field  	67,32		; _LIC_VerList[162] @ 5184
	.field  	82,32		; _LIC_VerList[163] @ 5216
	.field  	65,32		; _LIC_VerList[164] @ 5248
	.field  	45,32		; _LIC_VerList[165] @ 5280
	.field  	76,32		; _LIC_VerList[166] @ 5312
	.field  	65,32		; _LIC_VerList[167] @ 5344
	.field  	85,32		; _LIC_VerList[168] @ 5376
	.field  	78,32		; _LIC_VerList[169] @ 5408
	.field  	0,32		; _LIC_VerList[170] @ 5440
	.field  	67,32		; _LIC_VerList[171] @ 5472
	.field  	82,32		; _LIC_VerList[172] @ 5504
	.field  	65,32		; _LIC_VerList[173] @ 5536
	.field  	45,32		; _LIC_VerList[174] @ 5568
	.field  	85,32		; _LIC_VerList[175] @ 5600
	.field  	80,32		; _LIC_VerList[176] @ 5632
	.field  	0,32		; _LIC_VerList[177] @ 5664
	.space	2
	.field  	67,32		; _LIC_VerList[180] @ 5760
	.field  	82,32		; _LIC_VerList[181] @ 5792
	.field  	65,32		; _LIC_VerList[182] @ 5824
	.field  	45,32		; _LIC_VerList[183] @ 5856
	.field  	80,32		; _LIC_VerList[184] @ 5888
	.field  	80,32		; _LIC_VerList[185] @ 5920
	.field  	0,32		; _LIC_VerList[186] @ 5952
	.space	2
	.field  	67,32		; _LIC_VerList[189] @ 6048
	.field  	82,32		; _LIC_VerList[190] @ 6080
	.field  	65,32		; _LIC_VerList[191] @ 6112
	.field  	45,32		; _LIC_VerList[192] @ 6144
	.field  	83,32		; _LIC_VerList[193] @ 6176
	.field  	80,32		; _LIC_VerList[194] @ 6208
	.field  	0,32		; _LIC_VerList[195] @ 6240
	.space	2
	.field  	67,32		; _LIC_VerList[198] @ 6336
	.field  	82,32		; _LIC_VerList[199] @ 6368
	.field  	65,32		; _LIC_VerList[200] @ 6400
	.field  	45,32		; _LIC_VerList[201] @ 6432
	.field  	70,32		; _LIC_VerList[202] @ 6464
	.field  	84,32		; _LIC_VerList[203] @ 6496
	.field  	80,32		; _LIC_VerList[204] @ 6528
	.field  	0,32		; _LIC_VerList[205] @ 6560
	.field  	0,32
	.field  	67,32		; _LIC_VerList[207] @ 6624
	.field  	82,32		; _LIC_VerList[208] @ 6656
	.field  	65,32		; _LIC_VerList[209] @ 6688
	.field  	45,32		; _LIC_VerList[210] @ 6720
	.field  	67,32		; _LIC_VerList[211] @ 6752
	.field  	68,32		; _LIC_VerList[212] @ 6784
	.field  	84,32		; _LIC_VerList[213] @ 6816
	.field  	0,32		; _LIC_VerList[214] @ 6848
IR_4:	.set	188

	.sect	".text"

	.global	_LIC_VerList
	.bss	_LIC_VerList,450
	.sym	_LIC_VerList,_LIC_VerList,252,2,14400,,50,9
	.sect	 ".text"

	.global	_user_Init
	.sym	_user_Init,_user_Init,32,2,0
	.func	90
;******************************************************************************
;* FUNCTION NAME: _user_Init                                                  *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,r3,r4,r5,ar0,ar1,fp,ir0,bk,sp,st           *
;*   Regs Saved         : r4,r5                                               *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 136 Auto + 2 SOE = 140 words      *
;******************************************************************************
_user_Init:
	.sym	_i,1,4,1,32
	.sym	_wCarNo,2,4,1,32
	.sym	_LL,3,12,1,32
	.sym	_LH,4,12,1,32
	.sym	_HL,5,12,1,32
	.sym	_HH,6,12,1,32
	.sym	_szBuf,7,50,1,4096,,128
	.sym	_pDpram,135,28,1,32
	.sym	_pLicVerDp,136,24,1,32,.fake46
	.line	1
;----------------------------------------------------------------------
;  90 | void user_Init()                                                       
;  92 | int i;                                                                 
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      136,sp
        push      r4
        push      r5
	.line	4
;----------------------------------------------------------------------
;  93 | int wCarNo = 0;                                                        
;  94 | UCHAR LL,LH,HL,HH;                                                     
;  95 | char szBuf[128];                                                       
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(2)
	.line	7
;----------------------------------------------------------------------
;  96 | UCHAR *pDpram = (UCHAR *)DPRAM_BASE;                                   
;----------------------------------------------------------------------
        ldiu      @CL1,r0
        sti       r0,*+fp(135)
	.line	9
;----------------------------------------------------------------------
;  98 | PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó�
;     | ��� ���� ���Ƿ� �������.                                              
; 100 | // �ʱ�ȭ�ϱ�                                                          
; 101 | //timeGet(&m_tmCurTime);                                               
;----------------------------------------------------------------------
        ldiu      @CL2,r0
        sti       r0,*+fp(136)
	.line	13
;----------------------------------------------------------------------
; 102 | memset(m_btCommSt,0x00,sizeof(m_btCommSt)); //���� ����Ÿ ���� ����    
;----------------------------------------------------------------------
        ldiu      7,r2
        ldiu      0,r1
        push      r2
        ldiu      @CL3,r0
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	15
;----------------------------------------------------------------------
; 104 | memset(m_btExVersionTbl,0x0000,sizeof(m_btExVersionTbl));              
;----------------------------------------------------------------------
        ldiu      0,r0
        ldiu      28,r1
        push      r1
        push      r0
        ldiu      @CL4,r2
        push      r2
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	16
;----------------------------------------------------------------------
; 105 | memset(m_btExVersion_DAYTbl,0x0000,sizeof(m_btExVersion_DAYTbl));      
;----------------------------------------------------------------------
        ldiu      0,r0
        ldiu      28,r1
        push      r1
        push      r0
        ldiu      @CL5,r2
        push      r2
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	19
;----------------------------------------------------------------------
; 108 | for(i=0;i<VER_BDD_MAX_CNT;i++)                                         
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      24,r0
        bge       L19
;*      Branch Occurs to L19 
L2:        
	.line	21
;----------------------------------------------------------------------
; 110 | if(WORD_L(pLicVerDp->VerCnt) == TRUE)                                  
; 112 |         if(                                                            
;----------------------------------------------------------------------
        ldiu      *+fp(136),ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        cmpi      1,r0
        bned      L17
	nop
        ldine     *+fp(136),ar0
        ldine     1,r0
;*      Branch Occurs to L17 
	.line	24
;----------------------------------------------------------------------
; 113 | !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chVer[0])) || !IsNumAsc(WORD_L(pL
;     | icVerDp->cvbBuf[i].chVer[1])) ||                                       
; 114 | !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chVer[2])) || !IsNumAsc(WORD_L(pL
;     | icVerDp->cvbBuf[i].chVer[3])) ||                                       
; 116 | !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[0])) || !IsNumAsc(WOR
;     | D_L(pLicVerDp->cvbBuf[i].chBuildDate[1])) ||                           
; 117 | !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[2])) || !IsNumAsc(WOR
;     | D_L(pLicVerDp->cvbBuf[i].chBuildDate[3])) ||                           
; 118 | !IsNumAsc(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[4])) || !IsNumAsc(WOR
;     | D_L(pLicVerDp->cvbBuf[i].chBuildDate[5]))                              
; 119 | )                                                                      
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(1),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(2),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(3),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(4),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(5),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(6),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(7),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(8),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(9),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L13
;*      Branch Occurs to L13 
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(10),r0
        push      r0
        call      _IsNumAsc
                                        ; Call Occurs
        cmpi      0,r0
        bned      L15
        subi      1,sp
	nop
        ldine     *+fp(1),ar0
;*      Branch Occurs to L15 
L13:        
	.line	32
;----------------------------------------------------------------------
; 121 | memset(pLicVerDp->cvbBuf[i].chVer,'0',4);                              
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        ldiu      4,r2
        ldiu      48,r1
        mpyi      10,r0
        addi      *+fp(136),r0          ; Unsigned
        push      r2
        addi      1,r0                  ; Unsigned
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	33
;----------------------------------------------------------------------
; 122 | memset(pLicVerDp->cvbBuf[i].chBuildDate,'0',6);                        
; 124 | else                                                                   
;----------------------------------------------------------------------
        ldiu      6,r2
        ldiu      *+fp(1),r0
        ldiu      48,r1
        mpyi      10,r0
        addi      *+fp(136),r0          ; Unsigned
        push      r2
        push      r1
        addi      5,r0                  ; Unsigned
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
        bu        L18
;*      Branch Occurs to L18 
	.line	37
;----------------------------------------------------------------------
; 126 | LH = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[0])),ConvA
;     | sc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[1])));                        
;----------------------------------------------------------------------
L15:        
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(1),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      255,r1
        ldiu      *+fp(1),ar0
        ldiu      r0,r4
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ash       4,r4
        and       *+ar0(2),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(4)
	.line	38
;----------------------------------------------------------------------
; 127 | LL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[2])),ConvA
;     | sc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chVer[3])));                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        ldiu      255,r1
        addi      *+fp(136),ar0         ; Unsigned
        ash       4,r4
        and       *+ar0(4),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(3)
	.line	39
;----------------------------------------------------------------------
; 128 | m_btExVersionTbl[i] = MAKE_WORD(LH,LL);                                
;----------------------------------------------------------------------
        ldiu      255,r0
        ldiu      *+fp(4),r1
        and       *+fp(3),r0
        ash       8,r1
        or3       r1,r0,r0
        ldiu      @CL4,ar0
        ldiu      *+fp(1),ir0
        and       65535,r0
        sti       r0,*+ar0(ir0)
	.line	40
;----------------------------------------------------------------------
; 129 | HH = 0x20;                                                             
;----------------------------------------------------------------------
        ldiu      32,r0
        sti       r0,*+fp(6)
	.line	41
;----------------------------------------------------------------------
; 130 | HL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[0]))
;     | ,ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[1])));            
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(5),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r1
        ldiu      r0,r4
        ash       4,r4
        and       *+ar0(6),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        subi      1,sp
        or3       r4,r0,r0
        and       255,r0
        sti       r0,*+fp(5)
	.line	42
;----------------------------------------------------------------------
; 131 | LH = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[2]))
;     | ,ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[3])));            
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(7),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        ldiu      255,r0
        subi      1,sp
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ash       4,r4
        and       *+ar0(8),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        sti       r0,*+fp(4)
	.line	43
;----------------------------------------------------------------------
; 132 | LL = MAKE_BYTE(ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[4]))
;     | ,ConvAsc2Hex(WORD_L(pLicVerDp->cvbBuf[i].chBuildDate[5])));            
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        mpyi      10,ar0
        addi      *+fp(136),ar0         ; Unsigned
        ldiu      255,r0
        and       *+ar0(9),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(1),ar0
        ldiu      255,r1
        mpyi      10,ar0
        ldiu      r0,r4
        addi      *+fp(136),ar0         ; Unsigned
        ash       4,r4
        and       *+ar0(10),r1
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(3)
	.line	44
;----------------------------------------------------------------------
; 133 | m_btExVersion_DAYTbl[i] = MAKE_DWORD(HH,HL,LH,LL);                     
; 136 | else //�ѹ��� ���� ���� �Է��� �������� ��� 0 ���� �ʱ�ȭ �Ѵ�.       
;----------------------------------------------------------------------
        ldiu      255,r0
        ldiu      *+fp(6),r3
        and       *+fp(5),r0
        ash       24,r3
        ash       16,r0
        or3       r3,r0,r0
        ldiu      255,r1
        and       *+fp(4),r1
        ldiu      255,r2
        ash       8,r1
        and       *+fp(3),r2
        ldiu      @CL5,ar0
        or3       r0,r1,r0
        ldiu      *+fp(1),ir0
        or3       r0,r2,r0
        sti       r0,*+ar0(ir0)
        bu        L18
;*      Branch Occurs to L18 
	.line	49
;----------------------------------------------------------------------
; 138 | pLicVerDp->VerCnt = TRUE;                                              
;----------------------------------------------------------------------
L17:        
        sti       r0,*ar0
	.line	50
;----------------------------------------------------------------------
; 139 | memset(pLicVerDp->cvbBuf[i].chVer,'0',4);                              
;----------------------------------------------------------------------
        ldiu      4,r2
        ldiu      48,r1
        ldiu      *+fp(1),r0
        mpyi      10,r0
        addi      *+fp(136),r0          ; Unsigned
        push      r2
        addi      1,r0                  ; Unsigned
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	51
;----------------------------------------------------------------------
; 140 | memset(pLicVerDp->cvbBuf[i].chBuildDate,'0',6);                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        mpyi      10,r0
        addi      *+fp(136),r0          ; Unsigned
        ldiu      6,r2
        push      r2
        ldiu      48,r1
        push      r1
        addi      5,r0                  ; Unsigned
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
L18:        
	.line	19
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      24,r0
        blt       L2
;*      Branch Occurs to L2 
L19:        
	.line	55
;----------------------------------------------------------------------
; 144 | if(MAKE_WORD(pLicVerDp->CarNum[0],pLicVerDp->CarNum[1]) != 0xFFFF)     
;----------------------------------------------------------------------
        ldiu      *+fp(136),ar0
        ldiu      255,r0
        ldiu      ar0,ar1
        ldiu      *+ar0(241),r1
        and       *+ar1(242),r0
        ash       8,r1
        or3       r1,r0,r0
        and       65535,r0
        cmpi      @CL6,r0
        beq       L21
;*      Branch Occurs to L21 
	.line	57
;----------------------------------------------------------------------
; 146 | m_wCarNo = MAKE_WORD(pLicVerDp->CarNum[0],pLicVerDp->CarNum[1]);       
; 149 | // LIC-MPU����� ���� & ���嵥��Ʈ                                     
;----------------------------------------------------------------------
        ldiu      255,r0
        ldiu      *+ar1(241),r1
        and       *+ar0(242),r0
        ash       8,r1
        or3       r1,r0,r0
        and       65535,r0
        sti       r0,@_m_wCarNo+0
L21:        
	.line	61
;----------------------------------------------------------------------
; 150 | m_btExVersionTbl[5] = MAKE_WORD(                                       
; 151 |                                                         MAKE_BYTE(ConvH
;     | ex2Asc(GetFirmwareVersion(1)/1000%10),ConvHex2Asc(GetFirmwareVersion(1)
;     | /100%10)),                                                             
; 152 |                                                         MAKE_BYTE(ConvH
;     | ex2Asc(GetFirmwareVersion(1)/10%10),ConvHex2Asc(GetFirmwareVersion(1)%1
;     | 0))                                                                    
; 153 |                                                         );             
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      1000,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      1,r1
        ldiu      r0,r4
        subi      1,sp
        push      r1
        ash       4,r4
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      100,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      1,r1
        and       15,r0
        or3       r4,r0,r5
        and       255,r5
        subi      1,sp
        ash       8,r5
        push      r1
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      10,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      1,r1
        ldiu      r0,r4
        push      r1
        ash       4,r4
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        or3       r5,r0,r0
        and       65535,r0
        sti       r0,@_m_btExVersionTbl+5
        subi      1,sp
	.line	66
;----------------------------------------------------------------------
; 155 | m_btExVersion_DAYTbl[5] = MAKE_DWORD(                                  
; 156 |                                                         0x20,          
; 157 |                                                         MAKE_BYTE(ConvH
;     | ex2Asc(GetFirmwareVersion(2)/100000%10),ConvHex2Asc(GetFirmwareVersion(
;     | 2)/10000%10)),                                                         
; 158 |                                                         MAKE_BYTE(ConvH
;     | ex2Asc(GetFirmwareVersion(2)/1000%10),ConvHex2Asc(GetFirmwareVersion(2)
;     | /100%10)),                                                             
; 159 |                                                         MAKE_BYTE(ConvH
;     | ex2Asc(GetFirmwareVersion(2)/10%10),ConvHex2Asc(GetFirmwareVersion(2)%1
;     | 0))                                                                    
; 160 |                                                         );             
;----------------------------------------------------------------------
        ldiu      2,r0
        push      r0
        call      _GetFirmwareVersion
                                        ; Call Occurs
        ldiu      @CL7,r1
        subi      1,sp
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      2,r1
        push      r1
        ldiu      r0,r4
        ash       4,r4
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      10000,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      2,r1
        and       15,r0
        subi      1,sp
        or3       r4,r0,r4
        push      r1
        and       255,r4
        ash       16,r4
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      1000,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      r0,r5
        ldiu      2,r1
        subi      1,sp
        push      r1
        ash       4,r5
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      100,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        and       15,r0
        ldiu      2,r1
        or3       r5,r0,r0
        and       255,r0
        ash       8,r0
        subi      1,sp
        or3       r4,r0,r5
        push      r1
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      10,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      2,r1
        ldiu      r0,r4
        push      r1
        ash       4,r4
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        or3       r5,r0,r0
        or        @CL8,r0
        sti       r0,@_m_btExVersion_DAYTbl+5
        subi      1,sp
	.line	73
;----------------------------------------------------------------------
; 162 | i = GetFirmwareVersion(1);                                             
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        sti       r0,*+fp(1)
	.line	74
;----------------------------------------------------------------------
; 163 | sprintf(szBuf,"Lonwork Monitor Program, Version:%d.%d%d%d\r\n",i/1000%1
;     | 0,i/100%10,i/10%10,i%10);                                              
;----------------------------------------------------------------------
        ldiu      1000,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      100,r1
        ldiu      r0,bk
        ldiu      *+fp(1),r0
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      r0,r3
        ldiu      10,r1
        ldiu      *+fp(1),r0
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      r0,ir0
        ldiu      10,r1
        ldiu      *+fp(1),r0
        call      MOD_I30
                                        ; Call Occurs
        ldiu      fp,r1
        ldiu      @CL9,r2
        push      r0
        push      ir0
        push      r3
        push      bk
        addi      7,r1
        push      r2
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      6,sp
	.line	75
;----------------------------------------------------------------------
; 164 | user_DebugPrint(szBuf);                                                
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      7,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	77
        pop       r5
        ldiu      *-fp(1),bk
        pop       r4
        ldiu      *fp,fp
        subi      138,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	166,000000030h,136


	.sect	 ".text"

	.global	_user_Loop
	.sym	_user_Loop,_user_Loop,32,2,0
	.func	171
;******************************************************************************
;* FUNCTION NAME: _user_Loop                                                  *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,ar0,st                                           *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 1 Auto + 0 SOE = 3 words          *
;******************************************************************************
_user_Loop:
	.sym	_i,1,4,1,32
	.line	1
;----------------------------------------------------------------------
; 171 | void user_Loop()                                                       
; 173 | int i;                                                                 
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      1,sp
	.line	5
;----------------------------------------------------------------------
; 175 | user_LonWorkLoop();                                                    
;----------------------------------------------------------------------
        call      _user_LonWorkLoop
                                        ; Call Occurs
	.line	7
;----------------------------------------------------------------------
; 177 | user_DebugLoop();                                                      
;----------------------------------------------------------------------
        call      _user_DebugLoop
                                        ; Call Occurs
	.line	9
;----------------------------------------------------------------------
; 179 | user_WithCncsRs232Loop();                                              
;----------------------------------------------------------------------
        call      _user_WithCncsRs232Loop
                                        ; Call Occurs
	.line	11
;----------------------------------------------------------------------
; 181 | user_WithPacRs485Loop();                                               
;----------------------------------------------------------------------
        call      _user_WithPacRs485Loop
                                        ; Call Occurs
	.line	13
;----------------------------------------------------------------------
; 183 | if(m_nSingleOrMarriedCarUpdate1msTimer > 500)                          
;----------------------------------------------------------------------
        ldiu      @_m_nSingleOrMarriedCarUpdate1msTimer+0,r0
        cmpi      500,r0
        bls       L31
;*      Branch Occurs to L31 
	.line	15
;----------------------------------------------------------------------
; 185 | m_nSingleOrMarriedCarUpdate1msTimer = 0;                               
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nSingleOrMarriedCarUpdate1msTimer+0
	.line	16
;----------------------------------------------------------------------
; 186 | if(user_IsSingleOrMarried()) SINGLE_OR_MARRIED_CAR = user_IsSingleOrMar
;     | ried();                                                                
;----------------------------------------------------------------------
        call      _user_IsSingleOrMarried
                                        ; Call Occurs
        cmpi      0,r0
        beq       L31
;*      Branch Occurs to L31 
        call      _user_IsSingleOrMarried
                                        ; Call Occurs
        ldiu      @CL10,ar0
        sti       r0,*ar0
L31:        
	.line	18
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      3,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	188,000000000h,1



	.sect	".cinit"
	.field  	1,32
	.field  	_nRxPos$1+0,32
	.field  	0,32		; _nRxPos$1 @ 0

	.sect	".text"

	.sect	".cinit"
	.field  	1,32
	.field  	_nOldUart1RxOneByteGapDelayTime$2+0,32
	.field  	0,32		; _nOldUart1RxOneByteGapDelayTime$2 @ 0

	.sect	".text"
	.sect	 ".text"

	.global	_user_DebugLoop
	.sym	_user_DebugLoop,_user_DebugLoop,32,2,0
	.func	193
;******************************************************************************
;* FUNCTION NAME: _user_DebugLoop                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,r3,r4,r5,ar0,ar1,ar2,fp,ar4,ar5,ir0,ir1,bk,*
;*                        sp,st,rs,re,rc                                      *
;*   Regs Saved         : r4,r5,ar4,ar5                                       *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 792 Auto + 4 SOE = 798 words      *
;******************************************************************************
_user_DebugLoop:
	.bss	_nRxPos$1,1
	.sym	_nRxPos,_nRxPos$1,4,3,32
	.bss	_nOldUart1RxOneByteGapDelayTime$2,1
	.sym	_nOldUart1RxOneByteGapDelayTime,_nOldUart1RxOneByteGapDelayTime$2,12,3,32
	.bss	_btRxBuf$3,256
	.sym	_btRxBuf,_btRxBuf$3,60,3,8192,,256
	.sym	_i,1,4,1,32
	.sym	_j,2,4,1,32
	.sym	_sIndex,3,4,1,32
	.sym	_szBuf1,4,50,1,8192,,256
	.sym	_szBuf2,260,50,1,8192,,256
	.sym	_btBuf,516,60,1,8192,,256
	.sym	_sTemp,772,60,1,320,,10
	.sym	_nRxLen,782,4,1,32
	.sym	_tmBuf,783,8,1,224,.fake5
	.sym	_pLnWkDp,790,24,1,32,.fake13
	.sym	_pLicVerDp,791,24,1,32,.fake46
	.sym	_pCommStatus_Lic,792,24,1,32,.fake60
	.line	1
;----------------------------------------------------------------------
; 193 | void user_DebugLoop()                                                  
; 195 | int i,j;                                                               
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      792,sp
        push      r4
        push      r5
        push      ar4
        push      ar5
	.line	4
;----------------------------------------------------------------------
; 196 | int sIndex = 0;                                                        
; 197 | char szBuf1[256];                                                      
; 198 | char szBuf2[256];                                                      
; 199 | UCHAR btBuf[256];                                                      
; 201 | UCHAR sTemp[10];                                                       
; 203 | int nRxLen;                                                            
; 204 | static int nRxPos = 0;                                                 
; 205 | static UCHAR nOldUart1RxOneByteGapDelayTime = 0;                       
; 206 | static UCHAR btRxBuf[256];                                             
; 207 | DATE_TIME_TYPE tmBuf;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(3)
	.line	16
;----------------------------------------------------------------------
; 208 | PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;                                
;----------------------------------------------------------------------
        ldiu      790,ir0
        ldiu      @CL11,r0
        sti       r0,*+fp(ir0)
	.line	17
;----------------------------------------------------------------------
; 209 | PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó�
;     | ��� ���� ���Ƿ� �������.                                              
; 210 | PCOMMSTATUS_LIC pCommStatus_Lic;  //��ġ Status                        
; 212 | // ����                                                                
;----------------------------------------------------------------------
        ldiu      791,ir0
        ldiu      @CL2,r0
        sti       r0,*+fp(ir0)
	.line	21
;----------------------------------------------------------------------
; 213 | nRxLen = user_DebugRx(btBuf,128);                                      
;----------------------------------------------------------------------
        ldiu      128,r1
        ldiu      516,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _user_DebugRx
                                        ; Call Occurs
        subi      2,sp
        ldiu      782,ir0
        sti       r0,*+fp(ir0)
	.line	22
;----------------------------------------------------------------------
; 214 | if(nRxLen)                                                             
;----------------------------------------------------------------------
        ldi       *+fp(ir0),r0
        beq       L38
;*      Branch Occurs to L38 
	.line	24
;----------------------------------------------------------------------
; 216 | if(!m_nUart1RxOneByteGapDelayTime) nRxPos = 0;                         
;----------------------------------------------------------------------
        ldi       @_m_nUart1RxOneByteGapDelayTime+0,r0
        bne       L36
;*      Branch Occurs to L36 
        ldiu      0,r0
        sti       r0,@_nRxPos$1+0
L36:        
	.line	25
;----------------------------------------------------------------------
; 217 | m_nUart1RxOneByteGapDelayTime = 10;                                    
;----------------------------------------------------------------------
        ldiu      10,r0
        sti       r0,@_m_nUart1RxOneByteGapDelayTime+0
	.line	27
;----------------------------------------------------------------------
; 219 | if(nRxPos + nRxLen < 250)                                              
;----------------------------------------------------------------------
        ldiu      782,ir0
        ldiu      *+fp(ir0),r0
        addi      @_nRxPos$1+0,r0
        cmpi      250,r0
        bge       L38
;*      Branch Occurs to L38 
	.line	29
;----------------------------------------------------------------------
; 221 | memcpy(&btRxBuf[nRxPos],btBuf,nRxLen);                                 
;----------------------------------------------------------------------
        ldiu      @CL12,r0
        ldiu      516,r1
        ldiu      *+fp(ir0),r2
        addi      @_nRxPos$1+0,r0       ; Unsigned
        addi      fp,r1
        push      r2
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	30
;----------------------------------------------------------------------
; 222 | nRxPos += nRxLen;                                                      
;----------------------------------------------------------------------
        ldiu      782,ir0
        ldiu      *+fp(ir0),r0
        addi      @_nRxPos$1+0,r0
        sti       r0,@_nRxPos$1+0
L38:        
	.line	34
;----------------------------------------------------------------------
; 226 | if(nOldUart1RxOneByteGapDelayTime && !m_nUart1RxOneByteGapDelayTime)   
;----------------------------------------------------------------------
        ldi       @_nOldUart1RxOneByteGapDelayTime$2+0,r0
        beq       L360
;*      Branch Occurs to L360 
        ldi       @_m_nUart1RxOneByteGapDelayTime+0,r0
        bne       L360
;*      Branch Occurs to L360 
	.line	36
;----------------------------------------------------------------------
; 228 | strncpy(szBuf1,(char *)btRxBuf,MIN(16,nRxPos));                        
;----------------------------------------------------------------------
        ldiu      16,r0
        cmpi      @_nRxPos$1+0,r0
        bge       L42
;*      Branch Occurs to L42 
        bu        L43
;*      Branch Occurs to L43 
L42:        
        ldiu      @_nRxPos$1+0,r0
L43:        
        ldiu      fp,r1
        push      r0
        ldiu      @CL12,r2
        addi      4,r1
        push      r2
        push      r1
        call      _strncpy
                                        ; Call Occurs
        subi      3,sp
	.line	37
;----------------------------------------------------------------------
; 229 | szBuf1[16] = NULL;                                                     
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      20,ar0
        ldiu      0,r0
        sti       r0,*ar0
	.line	38
;----------------------------------------------------------------------
; 230 | for(i=0;i<strlen(szBuf1);i++) if(!IS_ASCALPHABET(szBuf1[i]) && !IS_ASCS
;     | PEC(szBuf1[i])) {szBuf1[i] = NULL; break;}                             
;----------------------------------------------------------------------
        sti       r0,*+fp(1)
        ldiu      fp,r0
        addi      4,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(1),r1
        cmpi3     r0,r1
        bhs       L51
;*      Branch Occurs to L51 
L44:        
        ldiu      fp,ar0
        ldiu      *+fp(1),ir0
        addi      4,ar0
        ldiu      *+ar0(ir0),r0
        cmpi      65,r0
        blt       L46
;*      Branch Occurs to L46 
        ldiu      fp,ar0
        addi      4,ar0
        ldiu      *+ar0(ir0),r0
        cmpi      90,r0
        ble       L50
;*      Branch Occurs to L50 
L46:        
        ldiu      fp,ar0
        ldiu      *+fp(1),ir0
        addi      4,ar0
        ldiu      *+ar0(ir0),r0
        cmpi      97,r0
        blt       L48
;*      Branch Occurs to L48 
        ldiu      fp,ar0
        addi      4,ar0
        ldiu      *+ar0(ir0),r0
        cmpi      122,r0
        ble       L50
;*      Branch Occurs to L50 
L48:        
        ldiu      fp,ar0
        ldiu      *+fp(1),ir0
        addi      4,ar0
        ldiu      *+ar0(ir0),r0
        cmpi      63,r0
        beq       L50
;*      Branch Occurs to L50 
        ldiu      fp,ar0
        addi      4,ar0
        ldiu      0,r0
        sti       r0,*+ar0(ir0)
        bu        L51
;*      Branch Occurs to L51 
L50:        
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        ldiu      fp,r0
        addi      4,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(1),r1
        cmpi3     r0,r1
        blo       L44
;*      Branch Occurs to L44 
L51:        
	.line	40
;----------------------------------------------------------------------
; 232 | if(btRxBuf[0] == '\r' || btRxBuf[0] == '\n')                           
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+0,r0
        cmpi      13,r0
        beq       L53
;*      Branch Occurs to L53 
        cmpi      10,r0
        bned      L55
	nop
        ldine     @CL14,r1
        ldine     fp,r0
;*      Branch Occurs to L55 
L53:        
	.line	42
;----------------------------------------------------------------------
; 234 | user_DebugPrint((char *)"->\r\n");                                     
; 236 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL13,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	45
;----------------------------------------------------------------------
; 237 | if(!strcmp(szBuf1,"T"))                                                
;----------------------------------------------------------------------
L55:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L87
        subi      2,sp
        ldine     @CL20,r1
        ldine     fp,r0
;*      Branch Occurs to L87 
	.line	47
;----------------------------------------------------------------------
; 239 | if(IS_ASCNUMBER(btRxBuf[1]) && IS_ASCNUMBER(btRxBuf[2]) &&             
; 240 |         IS_ASCNUMBER(btRxBuf[3]) && IS_ASCNUMBER(btRxBuf[4]) &&        
; 241 |         IS_ASCNUMBER(btRxBuf[5]) && IS_ASCNUMBER(btRxBuf[6]) &&        
; 242 |         IS_ASCNUMBER(btRxBuf[7]) && IS_ASCNUMBER(btRxBuf[8]) &&        
; 243 |         IS_ASCNUMBER(btRxBuf[9]) && IS_ASCNUMBER(btRxBuf[10]) &&       
; 244 |         IS_ASCNUMBER(btRxBuf[11]) && IS_ASCNUMBER(btRxBuf[12]))        
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+1,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
        ldiu      @_btRxBuf$3+2,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
        ldiu      @_btRxBuf$3+3,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
        ldiu      @_btRxBuf$3+4,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
        ldiu      @_btRxBuf$3+5,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
        ldiu      @_btRxBuf$3+6,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
        ldiu      @_btRxBuf$3+7,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
        ldiu      @_btRxBuf$3+8,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
        ldiu      @_btRxBuf$3+9,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
        ldiu      @_btRxBuf$3+10,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
        ldiu      @_btRxBuf$3+11,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
        ldiu      @_btRxBuf$3+12,r0
        cmpi      48,r0
        blo       L85
;*      Branch Occurs to L85 
        cmpi      57,r0
        bhi       L85
;*      Branch Occurs to L85 
	.line	54
;----------------------------------------------------------------------
; 246 | tmBuf.second = MAKE_BYTE(ConvAsc2Hex(btRxBuf[11]),ConvAsc2Hex(btRxBuf[1
;     | 2]));                                                                  
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+11,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      r0,r4
        ldiu      @_btRxBuf$3+12,r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      783,ir0
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	55
;----------------------------------------------------------------------
; 247 | tmBuf.minute = MAKE_BYTE(ConvAsc2Hex(btRxBuf[9]),ConvAsc2Hex(btRxBuf[10
;     | ]));                                                                   
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+9,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      @_btRxBuf$3+10,r1
        push      r1
        ldiu      r0,r4
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      784,ir0
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	56
;----------------------------------------------------------------------
; 248 | tmBuf.hour = MAKE_BYTE(ConvAsc2Hex(btRxBuf[7]),ConvAsc2Hex(btRxBuf[8]))
;     | ;                                                                      
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+7,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      r0,r4
        ldiu      @_btRxBuf$3+8,r0
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      785,ir0
        and       15,r0
        subi      1,sp
        or3       r4,r0,r0
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	57
;----------------------------------------------------------------------
; 249 | tmBuf.day = MAKE_BYTE(ConvAsc2Hex(btRxBuf[5]),ConvAsc2Hex(btRxBuf[6]));
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+5,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        subi      1,sp
        ldiu      @_btRxBuf$3+6,r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      786,ir0
        subi      1,sp
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	58
;----------------------------------------------------------------------
; 250 | tmBuf.month = MAKE_BYTE(ConvAsc2Hex(btRxBuf[3]),ConvAsc2Hex(btRxBuf[4])
;     | );                                                                     
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+3,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        ldiu      @_btRxBuf$3+4,r0
        subi      1,sp
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      787,ir0
        and       15,r0
        or3       r4,r0,r0
        subi      1,sp
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	59
;----------------------------------------------------------------------
; 251 | tmBuf.year = MAKE_BYTE(ConvAsc2Hex(btRxBuf[1]),ConvAsc2Hex(btRxBuf[2]))
;     | ;                                                                      
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+1,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        subi      1,sp
        ldiu      @_btRxBuf$3+2,r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      788,ir0
        and       15,r0
        subi      1,sp
        or3       r4,r0,r0
        and       255,r0
        sti       r0,*+fp(ir0)
	.line	60
;----------------------------------------------------------------------
; 252 | tmBuf.weekday = 0;                                                     
;----------------------------------------------------------------------
        ldiu      789,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	62
;----------------------------------------------------------------------
; 254 | m_tmCurTime.second = HEXA2BIN(tmBuf.second);                           
;----------------------------------------------------------------------
        ldiu      -4,r1
        ldiu      783,ir0
        ldiu      783,ir1
        lsh3      r1,*+fp(ir0),r1
        mpyi      10,r1
        ldiu      15,r0
        and3      r0,*+fp(ir1),r0
        addi3     r0,r1,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+0
	.line	63
;----------------------------------------------------------------------
; 255 | m_tmCurTime.minute = HEXA2BIN(tmBuf.minute);                           
;----------------------------------------------------------------------
        ldiu      784,ir0
        ldiu      -4,r1
        ldiu      15,r0
        ldiu      784,ir1
        lsh3      r1,*+fp(ir0),r1
        and3      r0,*+fp(ir1),r0
        mpyi      10,r1
        addi3     r0,r1,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+1
	.line	64
;----------------------------------------------------------------------
; 256 | m_tmCurTime.hour = HEXA2BIN(tmBuf.hour);                               
;----------------------------------------------------------------------
        ldiu      785,ir0
        ldiu      -4,r1
        lsh3      r1,*+fp(ir0),r1
        ldiu      15,r0
        ldiu      785,ir1
        mpyi      10,r1
        and3      r0,*+fp(ir1),r0
        addi3     r0,r1,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+2
	.line	65
;----------------------------------------------------------------------
; 257 | m_tmCurTime.day = HEXA2BIN(tmBuf.day);                                 
;----------------------------------------------------------------------
        ldiu      786,ir0
        ldiu      -4,r0
        lsh3      r0,*+fp(ir0),r0
        ldiu      15,r1
        ldiu      786,ir1
        mpyi      10,r0
        and3      r1,*+fp(ir1),r1
        addi3     r1,r0,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+3
	.line	66
;----------------------------------------------------------------------
; 258 | m_tmCurTime.month = HEXA2BIN(tmBuf.month);                             
;----------------------------------------------------------------------
        ldiu      15,r1
        ldiu      787,ir1
        ldiu      787,ir0
        ldiu      -4,r0
        lsh3      r0,*+fp(ir0),r0
        and3      r1,*+fp(ir1),r1
        mpyi      10,r0
        addi3     r1,r0,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+4
	.line	67
;----------------------------------------------------------------------
; 259 | m_tmCurTime.year = HEXA2BIN(tmBuf.year);                               
;----------------------------------------------------------------------
        ldiu      788,ir0
        ldiu      -4,r0
        ldiu      788,ir1
        lsh3      r0,*+fp(ir0),r0
        ldiu      15,r1
        mpyi      10,r0
        and3      r1,*+fp(ir1),r1
        addi3     r1,r0,r0              ; Unsigned
        sti       r0,@_m_tmCurTime+5
	.line	69
;----------------------------------------------------------------------
; 261 | memset(&m_tmUtcTime, 0x00, sizeof(DATE_TIME_TYPE));                    
;----------------------------------------------------------------------
        ldiu      7,r2
        ldiu      0,r1
        push      r2
        push      r1
        ldiu      @CL15,r0
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	71
;----------------------------------------------------------------------
; 263 | if(m_LIC_CNCS_TimSetFlag = GetLocalTimeToUTC(&m_tmCurTime, -5, &m_tmUtc
;     | Time))                                                                 
;----------------------------------------------------------------------
        ldiu      @CL15,r2
        push      r2
        ldiu      -5,r1
        ldiu      @CL16,r0
        push      r1
        push      r0
        call      _GetLocalTimeToUTC
                                        ; Call Occurs
        cmpi      0,r0
        beqd      L83
	nop
        sti       r0,@_m_LIC_CNCS_TimSetFlag+0
        subi      3,sp
;*      Branch Occurs to L83 
	.line	73
;----------------------------------------------------------------------
; 265 | m_tmUtcTime.year        = ConvDec2Hex(m_tmUtcTime.year  );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+5,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+5
        subi      1,sp
	.line	74
;----------------------------------------------------------------------
; 266 | m_tmUtcTime.month       = ConvDec2Hex(m_tmUtcTime.month );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+4,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+4
        subi      1,sp
	.line	75
;----------------------------------------------------------------------
; 267 | m_tmUtcTime.day         = ConvDec2Hex(m_tmUtcTime.day   );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+3,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+3
        subi      1,sp
	.line	76
;----------------------------------------------------------------------
; 268 | m_tmUtcTime.hour        = ConvDec2Hex(m_tmUtcTime.hour  );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+2,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+2
        subi      1,sp
	.line	77
;----------------------------------------------------------------------
; 269 | m_tmUtcTime.minute      = ConvDec2Hex(m_tmUtcTime.minute);             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+1,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+1
        subi      1,sp
	.line	78
;----------------------------------------------------------------------
; 270 | m_tmUtcTime.second      = ConvDec2Hex(m_tmUtcTime.second);             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+0,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+0
        subi      1,sp
	.line	80
;----------------------------------------------------------------------
; 272 | m_nCncsRxCheck1msTimer = 100000;                                       
;----------------------------------------------------------------------
        ldiu      @CL17,r0
        sti       r0,@_m_nCncsRxCheck1msTimer+0
L83:        
	.line	84
;----------------------------------------------------------------------
; 276 | sprintf(btBuf,"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour
;     | ],%02X[minute],%02X[second] \r\n",                                     
; 278 |         BIN2HEXA(m_tmUtcTime.year),                                    
; 279 |         BIN2HEXA(m_tmUtcTime.month),                                   
; 280 |         BIN2HEXA(m_tmUtcTime.day),                                     
; 281 |         BIN2HEXA(m_tmUtcTime.hour),                                    
; 282 |         BIN2HEXA(m_tmUtcTime.minute),                                  
; 283 |         BIN2HEXA(m_tmUtcTime.second));                                 
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+5,r0
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      10,r1
        ash       4,r2
        ldiu      @_m_tmUtcTime+5,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,ir1
        ldiu      @_m_tmUtcTime+4,r0
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ash       4,r2
        ldiu      @_m_tmUtcTime+4,r0
        ldiu      10,r1
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,ar2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+3,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ash       4,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+3,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,bk
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+2,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+2,r0
        ash       4,r2
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        ldiu      @_m_tmUtcTime+1,r0
        or3       r2,r1,r3
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ash       4,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+1,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+0,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,ir0
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+0,r0
        call      MOD_U30
                                        ; Call Occurs
        ash       4,ir0
        or3       ir0,r0,r0
        ldiu      516,r1
        push      r0
        push      r2
        addi      fp,r1
        push      r3
        ldiu      @CL18,r0
        push      bk
        push      ar2
        push      ir1
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      8,sp
	.line	93
;----------------------------------------------------------------------
; 285 | user_DebugPrint((char *)btBuf);                                        
; 287 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
L85:        
	.line	97
;----------------------------------------------------------------------
; 289 | user_DebugPrint("Not Date&time format \r\n");                          
; 292 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL19,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	101
;----------------------------------------------------------------------
; 293 | if(!strcmp(szBuf1,"t"))                                                
;----------------------------------------------------------------------
L87:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L91
        subi      2,sp
        ldine     @CL21,r1
        ldine     fp,r0
;*      Branch Occurs to L91 
	.line	103
;----------------------------------------------------------------------
; 295 | sprintf(btBuf,"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour
;     | ],%02X[minute],%02X[second] \r\n",                                     
; 296 |         BIN2HEXA(m_tmUtcTime.year),                                    
; 297 |         BIN2HEXA(m_tmUtcTime.month),                                   
; 298 |         BIN2HEXA(m_tmUtcTime.day),                                     
; 299 |         BIN2HEXA(m_tmUtcTime.hour),                                    
; 300 |         BIN2HEXA(m_tmUtcTime.minute),                                  
; 301 |         BIN2HEXA(m_tmUtcTime.second));                                 
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+5,r0
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      10,r1
        ash       4,r2
        ldiu      @_m_tmUtcTime+5,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,ir1
        ldiu      @_m_tmUtcTime+4,r0
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ash       4,r2
        ldiu      @_m_tmUtcTime+4,r0
        ldiu      10,r1
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,ar2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+3,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ash       4,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+3,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,bk
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+2,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+2,r0
        ash       4,r2
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        ldiu      @_m_tmUtcTime+1,r0
        or3       r2,r1,r3
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ash       4,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+1,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r1
        or3       r2,r1,r2
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+0,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,ir0
        ldiu      10,r1
        ldiu      @_m_tmUtcTime+0,r0
        call      MOD_U30
                                        ; Call Occurs
        ash       4,ir0
        or3       ir0,r0,r0
        ldiu      516,r1
        push      r0
        push      r2
        addi      fp,r1
        push      r3
        ldiu      @CL18,r0
        push      bk
        push      ar2
        push      ir1
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      8,sp
	.line	110
;----------------------------------------------------------------------
; 302 | user_DebugPrint((char *)btBuf);                                        
; 304 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	113
;----------------------------------------------------------------------
; 305 | if(!strcmp(szBuf1,"V"))                                                
;----------------------------------------------------------------------
L91:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L98
        subi      2,sp
        ldine     @CL26,r1
        ldine     fp,r0
;*      Branch Occurs to L98 
	.line	115
;----------------------------------------------------------------------
; 307 | i = GetFirmwareVersion(1);                                             
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _GetFirmwareVersion
                                        ; Call Occurs
        subi      1,sp
        sti       r0,*+fp(1)
	.line	116
;----------------------------------------------------------------------
; 308 | j = MAKE_WORD(pLnWkDp->btVerH,pLnWkDp->btVerL);                        
;----------------------------------------------------------------------
        ldiu      790,ir0
        ldiu      790,ir1
        ldiu      8,r1
        ldiu      *+fp(ir0),ar0
        ldiu      *+fp(ir1),ar1
        ldiu      255,r0
        ash3      r1,*+ar0,r1
        and       *+ar1(2),r0
        or3       r1,r0,r0
        and       65535,r0
        sti       r0,*+fp(2)
	.line	117
;----------------------------------------------------------------------
; 309 | sprintf(btBuf,"LIC-MPU Version:%d.%d%d%d,Build Date:20%06d, LIC-LON Ver
;     | sion:%d.%d%d%d,Build Date:%08X\r\n",                                   
; 310 |         i/1000%10,                                                     
; 311 |         i/100%10,                                                      
; 312 |         i/10%10,                                                       
; 313 |         i%10,                                                          
; 314 |         GetFirmwareVersion(2),                                         
; 315 |         BYTE_H(WORD_H(j)),                                             
; 316 |         BYTE_L(WORD_H(j)),                                             
; 317 |         BYTE_H(WORD_L(j)),                                             
; 318 |         BYTE_L(WORD_L(j)),                                             
; 319 |         MAKE_DWORD(pLnWkDp->btBuildDateHH,pLnWkDp->btBuildDateHL,pLnWkD
;     | p->btBuildDateLH,pLnWkDp->btBuildDateLL));                             
;----------------------------------------------------------------------
        ldiu      1000,r1
        ldiu      *+fp(1),r0
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      r0,r5
        ldiu      100,r1
        ldiu      *+fp(1),r0
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      r0,r4
        ldiu      *+fp(1),r0
        ldiu      10,r1
        call      DIV_I30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      r0,ar4
        ldiu      *+fp(1),r0
        ldiu      10,r1
        call      MOD_I30
                                        ; Call Occurs
        ldiu      r0,ar5
        ldiu      2,r1
        push      r1
        call      _GetFirmwareVersion
                                        ; Call Occurs
        ldiu      790,ir1
        subi      1,sp
        ldiu      790,ir0
        ldiu      255,r1
        ldiu      255,r2
        ldiu      *+fp(ir1),ar0
        ldiu      *+fp(ir0),ar1
        and       *+ar1(4),r2
        ldiu      *+fp(ir0),ar1
        and       *+ar1(5),r1
        ash       16,r2
        ash       8,r1
        ldiu      *+ar0(3),rs
        ash       24,rs
        ldiu      *+fp(ir1),ar0
        or3       rs,r2,rs
        ldiu      255,re
        or3       rs,r1,r1
        and       *+ar0(6),re
        ldiu      255,r3
        or3       r1,re,r1
        and       *+fp(2),r3
        ldiu      *+fp(2),re
        ldiu      re,rs
        ash       -4,r3
        ldiu      15,r2
        and       15,r3
        and       *+fp(2),r2
        ash       -8,re
        and       255,re
        push      r1
        ash       -8,rs
        push      r2
        ash       -4,re
        and       15,rs
        push      r3
        push      rs
        and       15,re
        push      re
        push      r0
        ldiu      @CL22,r0
        push      ar5
        push      ar4
        push      r4
        push      r5
        push      r0
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      12,sp
	.line	129
;----------------------------------------------------------------------
; 321 | user_DebugPrint((char *)btBuf);                                        
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	131
;----------------------------------------------------------------------
; 323 | memset(btBuf,0x00,256);                                                
; 325 | //2011_03_03 ����                                                      
;----------------------------------------------------------------------
        ldiu      256,r0
        ldiu      0,r1
        push      r0
        ldiu      516,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	134
;----------------------------------------------------------------------
; 326 | for(i =0 ;i<24;i++) //CNCS�� ���� ���� ���� ���� ǥ�� �ϴ� �κ� �߰�   
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      24,r0
        bge       L263
;*      Branch Occurs to L263 
L94:        
	.line	136
;----------------------------------------------------------------------
; 328 | memset(btBuf,0x00,256);                                                
;----------------------------------------------------------------------
        ldiu      256,r1
        ldiu      516,r2
        ldiu      0,r0
        push      r1
        addi      fp,r2
        push      r0
        push      r2
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	137
;----------------------------------------------------------------------
; 329 | memcpy(btBuf,&LIC_VerList[i][0],strlen((char*)&LIC_VerList[i][0]));    
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        mpyi      9,r0
        addi      @CL23,r0              ; Unsigned
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(1),r2
        push      r0
        ldiu      @CL23,r0
        ldiu      516,r1
        mpyi      9,r2
        addi      fp,r1
        addi      r2,r0
        push      r0
        push      r1
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	138
;----------------------------------------------------------------------
; 330 | sprintf(&btBuf[strlen((char*)&btBuf)],"---");                          
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      @CL24,r1
        push      r1
        addi3     r0,fp,r0              ; Unsigned
        addi      516,r0                ; Unsigned
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	139
;----------------------------------------------------------------------
; 331 | memcpy(&btBuf[strlen((char*)&btBuf)],&pLicVerDp->cvbBuf[i].chVer[0],4);
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(1),r1
        ldiu      791,ir0
        mpyi      10,r1
        addi3     r1,*+fp(ir0),ar0      ; Unsigned
        addi3     r0,fp,ar1             ; Unsigned
        addi      1,ar0                 ; Unsigned
        addi      516,ar1               ; Unsigned
        ldiu      *ar0,r0
        sti       r0,*ar1
        ldiu      *+ar0,r0
        sti       r0,*+ar1
        ldiu      *+ar0(2),r0
        sti       r0,*+ar1(2)
        ldiu      *+ar0(3),r0
        sti       r0,*+ar1(3)
	.line	140
;----------------------------------------------------------------------
; 332 | sprintf(&btBuf[strlen((char*)&btBuf)],"---");                          
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      @CL24,r1
        subi      1,sp
        addi3     r0,fp,r0              ; Unsigned
        addi      516,r0                ; Unsigned
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	141
;----------------------------------------------------------------------
; 333 | memcpy(&btBuf[strlen((char*)&btBuf)],&pLicVerDp->cvbBuf[i].chBuildDate[
;     | 0],8);                                                                 
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(1),r1
        ldiu      791,ir0
        mpyi      10,r1
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        addi      5,ar1                 ; Unsigned
        addi3     r0,fp,ar0             ; Unsigned
        addi      516,ar0               ; Unsigned
        ldiu      *ar1++(1),r0
        rpts      6                     ; Fast MEMCPY(#3)
        sti       r0,*ar0++(1)
||      ldi       *ar1++(1),r0
        sti       r0,*ar0++(1)
	.line	142
;----------------------------------------------------------------------
; 334 | sprintf(&btBuf[strlen((char*)&btBuf)],"\r\n");                         
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      @CL25,r1
        subi      1,sp
        addi3     r0,fp,r0              ; Unsigned
        addi      516,r0                ; Unsigned
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	144
;----------------------------------------------------------------------
; 336 | user_DebugPrint((char *)btBuf);                                        
; 339 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	134
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      24,r0
        blt       L94
;*      Branch Occurs to L94 
        bu        L263
;*      Branch Occurs to L263 
	.line	148
;----------------------------------------------------------------------
; 340 | if(!strcmp(szBuf1,"Recent"))                                           
;----------------------------------------------------------------------
L98:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L101
        subi      2,sp
        ldine     @CL28,r1
        ldine     fp,r0
;*      Branch Occurs to L101 
	.line	150
;----------------------------------------------------------------------
; 342 | m_nLnWkTxFlag = 1;                                                     
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_nLnWkTxFlag+0
	.line	151
;----------------------------------------------------------------------
; 343 | user_DebugPrint("Recent fault read start send \r\n");                  
; 345 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL27,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	154
;----------------------------------------------------------------------
; 346 | if(!strcmp(szBuf1,"Historical"))                                       
;----------------------------------------------------------------------
L101:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L104
        subi      2,sp
        ldine     @CL30,r1
        ldine     fp,r0
;*      Branch Occurs to L104 
	.line	156
;----------------------------------------------------------------------
; 348 | m_nLnWkTxFlag = 2;                                                     
;----------------------------------------------------------------------
        ldiu      2,r0
        sti       r0,@_m_nLnWkTxFlag+0
	.line	157
;----------------------------------------------------------------------
; 349 | gm_SysTimeToRtc(&tmBuf,m_nDateTime2SecondCnt);                         
;----------------------------------------------------------------------
        ldiu      @_m_nDateTime2SecondCnt+0,r1
        ldiu      783,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _gm_SysTimeToRtc
                                        ; Call Occurs
        subi      2,sp
	.line	158
;----------------------------------------------------------------------
; 350 | sprintf(btBuf,"Historical read start send, Historical start time : %08X
;     | H, Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%02X[minut
;     | e],%02X[second] \r\n",                                                 
; 351 |         m_nDateTime2SecondCnt,                                         
; 352 |         tmBuf.year,                                                    
; 353 |         tmBuf.month,                                                   
; 354 |         tmBuf.day,                                                     
; 355 |         tmBuf.hour,                                                    
; 356 |         tmBuf.minute,                                                  
; 357 |         tmBuf.second);                                                 
;----------------------------------------------------------------------
        ldiu      783,ir0
        ldiu      *+fp(ir0),r0
        ldiu      786,ir1
        ldiu      784,ir0
        push      r0
        ldiu      *+fp(ir0),r0
        ldiu      785,ir0
        push      r0
        ldiu      *+fp(ir0),r0
        push      r0
        ldiu      *+fp(ir1),r0
        ldiu      787,ir1
        push      r0
        ldiu      *+fp(ir1),r1
        push      r1
        ldiu      788,ir0
        ldiu      516,r2
        ldiu      *+fp(ir0),r1
        push      r1
        ldiu      @_m_nDateTime2SecondCnt+0,r1
        addi      fp,r2
        push      r1
        ldiu      @CL29,r0
        push      r0
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      9,sp
	.line	166
;----------------------------------------------------------------------
; 358 | user_DebugPrint((char *)btBuf);                                        
; 360 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	169
;----------------------------------------------------------------------
; 361 | if(!strcmp(szBuf1,"Rxinfo"))                                           
;----------------------------------------------------------------------
L104:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L110
        subi      2,sp
        ldine     @CL32,r1
        ldine     fp,r0
;*      Branch Occurs to L110 
	.line	171
;----------------------------------------------------------------------
; 363 | if(!m_nNvsramPos)                                                      
;----------------------------------------------------------------------
        ldi       @_m_nNvsramPos+0,r0
        bne       L107
;*      Branch Occurs to L107 
	.line	173
;----------------------------------------------------------------------
; 365 | sprintf(btBuf,"Total byte : %d, Packet count : %d, window count : %d, r
;     | emaind packet : %d, m_nLnWkWaySideOnRxOk : %d, m_bLnWkFtpEndFlag : %d, 
;     | Historical start time : %08XH \r\n",                                   
; 366 |         0,0,0,0,                                                       
; 367 |         m_nLnWkWaySideOnRxOk,                                          
; 368 |         m_bLnWkFtpEndFlag,                                             
; 369 |         m_nDateTime2SecondCnt);                                        
; 371 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @_m_nDateTime2SecondCnt+0,r0
        ldiu      0,r3
        ldiu      0,rs
        ldiu      0,re
        ldiu      0,rc
        push      r0
        ldiu      @CL31,r1
        ldiu      @_m_bLnWkFtpEndFlag+0,r0
        push      r0
        ldiu      @_m_nLnWkWaySideOnRxOk+0,r2
        ldiu      516,r0
        push      r2
        push      r3
        addi      fp,r0
        push      rs
        push      re
        push      rc
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      9,sp
        bu        L108
;*      Branch Occurs to L108 
L107:        
	.line	181
;----------------------------------------------------------------------
; 373 | sprintf(btBuf,"Total byte : %d, Packet count : %d, window count : %d, r
;     | emaind packet : %d, m_nLnWkWaySideOnRxOk : %d, m_bLnWkFtpEndFlag : %d, 
;     | Historical start time : %08XH \r\n",                                   
; 374 |         m_nNvsramPos,                                                  
; 375 |         ((m_nNvsramPos-1)/128)+1,                                      
; 376 |         ((m_nNvsramPos-1)/128/6)+1,                                    
; 377 |         m_nNvsramPos%128,                                              
; 378 |         m_nLnWkWaySideOnRxOk,                                          
; 379 |         m_bLnWkFtpEndFlag,                                             
; 380 |         m_nDateTime2SecondCnt);                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     @_m_nNvsramPos+0,r0   ; Unsigned
        ldiu      768,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      127,r2
        ldiu      @_m_nDateTime2SecondCnt+0,r3
        ldiu      1,r1
        and       @_m_nNvsramPos+0,r2
        subri     @_m_nNvsramPos+0,r1   ; Unsigned
        push      r3
        ldiu      @_m_bLnWkFtpEndFlag+0,r3
        addi      1,r0                  ; Unsigned
        push      r3
        ldiu      @_m_nLnWkWaySideOnRxOk+0,r3
        push      r3
        push      r2
        lsh       -7,r1
        push      r0
        addi      1,r1                  ; Unsigned
        ldiu      @CL31,rs
        push      r1
        ldiu      @_m_nNvsramPos+0,r0
        push      r0
        ldiu      516,r3
        addi      fp,r3
        push      rs
        push      r3
        call      _sprintf
                                        ; Call Occurs
        subi      9,sp
L108:        
	.line	190
;----------------------------------------------------------------------
; 382 | user_DebugPrint((char *)btBuf);                                        
; 384 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	193
;----------------------------------------------------------------------
; 385 | if(!strcmp(szBuf1,"LnWayClr"))                                         
;----------------------------------------------------------------------
L110:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L113
        subi      2,sp
        ldine     @CL34,r1
        ldine     fp,r0
;*      Branch Occurs to L113 
	.line	195
;----------------------------------------------------------------------
; 387 | m_nLnWkWaySideOnRxOk = 0;                                              
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nLnWkWaySideOnRxOk+0
	.line	196
;----------------------------------------------------------------------
; 388 | user_DebugPrint("'m_nLnWkWaySideOnRxOk' Clear OK \r\n");               
; 390 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL33,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	199
;----------------------------------------------------------------------
; 391 | if(!strcmp(szBuf1,"LnFtpClr"))                                         
;----------------------------------------------------------------------
L113:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L116
        subi      2,sp
        ldine     @CL36,r1
        ldine     fp,r0
;*      Branch Occurs to L116 
	.line	201
;----------------------------------------------------------------------
; 393 | m_bLnWkFtpEndFlag = FALSE;                                             
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_bLnWkFtpEndFlag+0
	.line	202
;----------------------------------------------------------------------
; 394 | user_DebugPrint("'m_bLnWkFtpEndFlag' Clear OK \r\n");                  
; 396 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL35,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	205
;----------------------------------------------------------------------
; 397 | if(!strcmp(szBuf1,"HisStTm"))                                          
;----------------------------------------------------------------------
L116:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L169
        subi      2,sp
        ldine     @CL39,r1
        ldine     fp,r0
;*      Branch Occurs to L169 
	.line	207
;----------------------------------------------------------------------
; 399 | if(IS_ASCHEX(btRxBuf[7]) && IS_ASCHEX(btRxBuf[8]) &&                   
; 400 |         IS_ASCHEX(btRxBuf[9]) && IS_ASCHEX(btRxBuf[10]) &&             
; 401 |         IS_ASCHEX(btRxBuf[11]) && IS_ASCHEX(btRxBuf[12]) &&            
; 402 |         IS_ASCHEX(btRxBuf[13]) && IS_ASCHEX(btRxBuf[14]))              
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+7,r0
        cmpi      48,r0
        blo       L119
;*      Branch Occurs to L119 
        cmpi      57,r0
        bls       L123
;*      Branch Occurs to L123 
L119:        
        ldiu      @_btRxBuf$3+7,r0
        cmpi      65,r0
        blo       L121
;*      Branch Occurs to L121 
        cmpi      70,r0
        bls       L123
;*      Branch Occurs to L123 
L121:        
        ldiu      @_btRxBuf$3+7,r0
        cmpi      97,r0
        blo       L167
;*      Branch Occurs to L167 
        cmpi      102,r0
        bhi       L167
;*      Branch Occurs to L167 
L123:        
        ldiu      @_btRxBuf$3+8,r0
        cmpi      48,r0
        blo       L125
;*      Branch Occurs to L125 
        cmpi      57,r0
        bls       L129
;*      Branch Occurs to L129 
L125:        
        ldiu      @_btRxBuf$3+8,r0
        cmpi      65,r0
        blo       L127
;*      Branch Occurs to L127 
        cmpi      70,r0
        bls       L129
;*      Branch Occurs to L129 
L127:        
        ldiu      @_btRxBuf$3+8,r0
        cmpi      97,r0
        blo       L167
;*      Branch Occurs to L167 
        cmpi      102,r0
        bhi       L167
;*      Branch Occurs to L167 
L129:        
        ldiu      @_btRxBuf$3+9,r0
        cmpi      48,r0
        blo       L131
;*      Branch Occurs to L131 
        cmpi      57,r0
        bls       L135
;*      Branch Occurs to L135 
L131:        
        ldiu      @_btRxBuf$3+9,r0
        cmpi      65,r0
        blo       L133
;*      Branch Occurs to L133 
        cmpi      70,r0
        bls       L135
;*      Branch Occurs to L135 
L133:        
        ldiu      @_btRxBuf$3+9,r0
        cmpi      97,r0
        blo       L167
;*      Branch Occurs to L167 
        cmpi      102,r0
        bhi       L167
;*      Branch Occurs to L167 
L135:        
        ldiu      @_btRxBuf$3+10,r0
        cmpi      48,r0
        blo       L137
;*      Branch Occurs to L137 
        cmpi      57,r0
        bls       L141
;*      Branch Occurs to L141 
L137:        
        ldiu      @_btRxBuf$3+10,r0
        cmpi      65,r0
        blo       L139
;*      Branch Occurs to L139 
        cmpi      70,r0
        bls       L141
;*      Branch Occurs to L141 
L139:        
        ldiu      @_btRxBuf$3+10,r0
        cmpi      97,r0
        blo       L167
;*      Branch Occurs to L167 
        cmpi      102,r0
        bhi       L167
;*      Branch Occurs to L167 
L141:        
        ldiu      @_btRxBuf$3+11,r0
        cmpi      48,r0
        blo       L143
;*      Branch Occurs to L143 
        cmpi      57,r0
        bls       L147
;*      Branch Occurs to L147 
L143:        
        ldiu      @_btRxBuf$3+11,r0
        cmpi      65,r0
        blo       L145
;*      Branch Occurs to L145 
        cmpi      70,r0
        bls       L147
;*      Branch Occurs to L147 
L145:        
        ldiu      @_btRxBuf$3+11,r0
        cmpi      97,r0
        blo       L167
;*      Branch Occurs to L167 
        cmpi      102,r0
        bhi       L167
;*      Branch Occurs to L167 
L147:        
        ldiu      @_btRxBuf$3+12,r0
        cmpi      48,r0
        blo       L149
;*      Branch Occurs to L149 
        cmpi      57,r0
        bls       L153
;*      Branch Occurs to L153 
L149:        
        ldiu      @_btRxBuf$3+12,r0
        cmpi      65,r0
        blo       L151
;*      Branch Occurs to L151 
        cmpi      70,r0
        bls       L153
;*      Branch Occurs to L153 
L151:        
        ldiu      @_btRxBuf$3+12,r0
        cmpi      97,r0
        blo       L167
;*      Branch Occurs to L167 
        cmpi      102,r0
        bhi       L167
;*      Branch Occurs to L167 
L153:        
        ldiu      @_btRxBuf$3+13,r0
        cmpi      48,r0
        blo       L155
;*      Branch Occurs to L155 
        cmpi      57,r0
        bls       L159
;*      Branch Occurs to L159 
L155:        
        ldiu      @_btRxBuf$3+13,r0
        cmpi      65,r0
        blo       L157
;*      Branch Occurs to L157 
        cmpi      70,r0
        bls       L159
;*      Branch Occurs to L159 
L157:        
        ldiu      @_btRxBuf$3+13,r0
        cmpi      97,r0
        blo       L167
;*      Branch Occurs to L167 
        cmpi      102,r0
        bhi       L167
;*      Branch Occurs to L167 
L159:        
        ldiu      @_btRxBuf$3+14,r0
        cmpi      48,r0
        blo       L161
;*      Branch Occurs to L161 
        cmpi      57,r0
        bls       L165
;*      Branch Occurs to L165 
L161:        
        ldiu      @_btRxBuf$3+14,r0
        cmpi      65,r0
        blo       L163
;*      Branch Occurs to L163 
        cmpi      70,r0
        bls       L165
;*      Branch Occurs to L165 
L163:        
        ldiu      @_btRxBuf$3+14,r0
        cmpi      97,r0
        blo       L167
;*      Branch Occurs to L167 
        cmpi      102,r0
        bhi       L167
;*      Branch Occurs to L167 
L165:        
	.line	212
;----------------------------------------------------------------------
; 404 | m_nDateTime2SecondCnt = MAKE_DWORD(                                    
; 405 |         MAKE_BYTE(ConvAsc2Hex(btRxBuf[7]),ConvAsc2Hex(btRxBuf[8])),    
; 406 |         MAKE_BYTE(ConvAsc2Hex(btRxBuf[9]),ConvAsc2Hex(btRxBuf[10])),   
; 407 |         MAKE_BYTE(ConvAsc2Hex(btRxBuf[11]),ConvAsc2Hex(btRxBuf[12])),  
; 408 |         MAKE_BYTE(ConvAsc2Hex(btRxBuf[13]),ConvAsc2Hex(btRxBuf[14]))); 
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+7,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      r0,r4
        ldiu      @_btRxBuf$3+8,r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      @_btRxBuf$3+9,r1
        push      r1
        and       15,r0
        or3       r4,r0,r5
        and       255,r5
        ash       24,r5
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        ldiu      @_btRxBuf$3+10,r0
        subi      1,sp
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r1
        and       255,r1
        ash       16,r1
        ldiu      @_btRxBuf$3+11,r0
        subi      1,sp
        or3       r5,r1,r5
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        ldiu      @_btRxBuf$3+12,r0
        subi      1,sp
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r1
        and       255,r1
        subi      1,sp
        ldiu      @_btRxBuf$3+13,r0
        ash       8,r1
        push      r0
        or3       r5,r1,r5
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      r0,r4
        ldiu      @_btRxBuf$3+14,r0
        subi      1,sp
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        or3       r5,r0,r0
        sti       r0,@_m_nDateTime2SecondCnt+0
        subi      1,sp
	.line	219
;----------------------------------------------------------------------
; 411 | gm_SysTimeToRtc(&tmBuf,m_nDateTime2SecondCnt);                         
;----------------------------------------------------------------------
        ldiu      r0,r1
        push      r1
        ldiu      783,r0
        addi      fp,r0
        push      r0
        call      _gm_SysTimeToRtc
                                        ; Call Occurs
        subi      2,sp
	.line	220
;----------------------------------------------------------------------
; 412 | sprintf(btBuf,"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour
;     | ],%02X[minute],%02X[second], Setting OK \r\n",                         
; 413 |         tmBuf.year,                                                    
; 414 |         tmBuf.month,                                                   
; 415 |         tmBuf.day,                                                     
; 416 |         tmBuf.hour,                                                    
; 417 |         tmBuf.minute,                                                  
; 418 |         tmBuf.second                                                   
; 419 |         );                                                             
;----------------------------------------------------------------------
        ldiu      783,ir1
        ldiu      *+fp(ir1),r0
        ldiu      784,ir1
        push      r0
        ldiu      *+fp(ir1),r0
        ldiu      785,ir0
        push      r0
        ldiu      *+fp(ir0),r0
        ldiu      787,ir1
        ldiu      786,ir0
        push      r0
        ldiu      *+fp(ir0),r1
        push      r1
        ldiu      *+fp(ir1),r1
        ldiu      788,ir0
        push      r1
        ldiu      *+fp(ir0),r1
        push      r1
        ldiu      @CL37,r0
        push      r0
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      8,sp
	.line	228
;----------------------------------------------------------------------
; 420 | user_DebugPrint((char *)btBuf);                                        
; 422 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
L167:        
	.line	232
;----------------------------------------------------------------------
; 424 | user_DebugPrint("No format \r\n");                                     
; 427 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL38,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	236
;----------------------------------------------------------------------
; 428 | if(!strcmp(szBuf1,"ViewCarNo"))                                        
;----------------------------------------------------------------------
L169:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L172
        subi      2,sp
        ldine     @CL41,r1
        ldine     fp,r0
;*      Branch Occurs to L172 
	.line	238
;----------------------------------------------------------------------
; 430 | sprintf(btBuf,"Car number 0 : %d, Car number 1 : %d \r\n",m_nCarNo[0],m
;     | _nCarNo[1]);                                                           
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+1,r1
        ldiu      @_m_nCarNo+0,r3
        ldiu      516,r0
        ldiu      @CL40,r2
        push      r1
        addi      fp,r0
        push      r3
        push      r2
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      4,sp
	.line	239
;----------------------------------------------------------------------
; 431 | user_DebugPrint((char *)btBuf);                                        
; 433 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	242
;----------------------------------------------------------------------
; 434 | if(!strcmp(szBuf1,"CarNoClr"))                                         
;----------------------------------------------------------------------
L172:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L175
        subi      2,sp
        ldine     @CL43,r1
        ldine     fp,r0
;*      Branch Occurs to L175 
	.line	244
;----------------------------------------------------------------------
; 436 | m_nCarNo[0] = 0x0000;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nCarNo+0
	.line	245
;----------------------------------------------------------------------
; 437 | m_nCarNo[1] = 0x0000;                                                  
;----------------------------------------------------------------------
        sti       r0,@_m_nCarNo+1
	.line	246
;----------------------------------------------------------------------
; 438 | user_DebugPrint("Car number clear OK \r\n");                           
; 440 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL42,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	249
;----------------------------------------------------------------------
; 441 | if(!strcmp(szBuf1,"WaySideON"))                                        
;----------------------------------------------------------------------
L175:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L178
        subi      2,sp
        ldine     @CL45,r1
        ldine     fp,r0
;*      Branch Occurs to L178 
	.line	251
;----------------------------------------------------------------------
; 443 | m_nCDT_FaultDataStFlag = 1;                                            
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_nCDT_FaultDataStFlag+0
	.line	252
;----------------------------------------------------------------------
; 444 | sprintf(btBuf,"m_nCDT_FaultDataStFlag  = %d \r\n",m_nCDT_FaultDataStFla
;     | g);                                                                    
;----------------------------------------------------------------------
        ldiu      @CL44,r2
        ldiu      r0,r1
        ldiu      516,r0
        push      r1
        addi      fp,r0
        push      r2
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
	.line	253
;----------------------------------------------------------------------
; 445 | user_DebugPrint((char *)btBuf);                                        
; 448 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	257
;----------------------------------------------------------------------
; 449 | if(!strcmp(szBuf1,"COMMST"))                                           
;----------------------------------------------------------------------
L178:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L230
        subi      2,sp
        ldine     @CL49,r1
        ldine     fp,r0
;*      Branch Occurs to L230 
	.line	259
;----------------------------------------------------------------------
; 451 | if( IS_ASCHEX(btRxBuf[7]) &&IS_ASCHEX(btRxBuf[8]) &&                   
; 452 |         IS_ASCHEX(btRxBuf[9]) &&IS_ASCHEX(btRxBuf[10]) &&              
; 453 |         IS_ASCHEX(btRxBuf[11]) &&IS_ASCHEX(btRxBuf[12]) &&             
; 454 |         IS_ASCHEX(btRxBuf[13]) &&IS_ASCHEX(btRxBuf[14]))               
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+7,r0
        cmpi      48,r0
        blo       L181
;*      Branch Occurs to L181 
        cmpi      57,r0
        bls       L185
;*      Branch Occurs to L185 
L181:        
        ldiu      @_btRxBuf$3+7,r0
        cmpi      65,r0
        blo       L183
;*      Branch Occurs to L183 
        cmpi      70,r0
        bls       L185
;*      Branch Occurs to L185 
L183:        
        ldiu      @_btRxBuf$3+7,r0
        cmpi      97,r0
        blo       L228
;*      Branch Occurs to L228 
        cmpi      102,r0
        bhi       L228
;*      Branch Occurs to L228 
L185:        
        ldiu      @_btRxBuf$3+8,r0
        cmpi      48,r0
        blo       L187
;*      Branch Occurs to L187 
        cmpi      57,r0
        bls       L191
;*      Branch Occurs to L191 
L187:        
        ldiu      @_btRxBuf$3+8,r0
        cmpi      65,r0
        blo       L189
;*      Branch Occurs to L189 
        cmpi      70,r0
        bls       L191
;*      Branch Occurs to L191 
L189:        
        ldiu      @_btRxBuf$3+8,r0
        cmpi      97,r0
        blo       L228
;*      Branch Occurs to L228 
        cmpi      102,r0
        bhi       L228
;*      Branch Occurs to L228 
L191:        
        ldiu      @_btRxBuf$3+9,r0
        cmpi      48,r0
        blo       L193
;*      Branch Occurs to L193 
        cmpi      57,r0
        bls       L197
;*      Branch Occurs to L197 
L193:        
        ldiu      @_btRxBuf$3+9,r0
        cmpi      65,r0
        blo       L195
;*      Branch Occurs to L195 
        cmpi      70,r0
        bls       L197
;*      Branch Occurs to L197 
L195:        
        ldiu      @_btRxBuf$3+9,r0
        cmpi      97,r0
        blo       L228
;*      Branch Occurs to L228 
        cmpi      102,r0
        bhi       L228
;*      Branch Occurs to L228 
L197:        
        ldiu      @_btRxBuf$3+10,r0
        cmpi      48,r0
        blo       L199
;*      Branch Occurs to L199 
        cmpi      57,r0
        bls       L203
;*      Branch Occurs to L203 
L199:        
        ldiu      @_btRxBuf$3+10,r0
        cmpi      65,r0
        blo       L201
;*      Branch Occurs to L201 
        cmpi      70,r0
        bls       L203
;*      Branch Occurs to L203 
L201:        
        ldiu      @_btRxBuf$3+10,r0
        cmpi      97,r0
        blo       L228
;*      Branch Occurs to L228 
        cmpi      102,r0
        bhi       L228
;*      Branch Occurs to L228 
L203:        
        ldiu      @_btRxBuf$3+11,r0
        cmpi      48,r0
        blo       L205
;*      Branch Occurs to L205 
        cmpi      57,r0
        bls       L209
;*      Branch Occurs to L209 
L205:        
        ldiu      @_btRxBuf$3+11,r0
        cmpi      65,r0
        blo       L207
;*      Branch Occurs to L207 
        cmpi      70,r0
        bls       L209
;*      Branch Occurs to L209 
L207:        
        ldiu      @_btRxBuf$3+11,r0
        cmpi      97,r0
        blo       L228
;*      Branch Occurs to L228 
        cmpi      102,r0
        bhi       L228
;*      Branch Occurs to L228 
L209:        
        ldiu      @_btRxBuf$3+12,r0
        cmpi      48,r0
        blo       L211
;*      Branch Occurs to L211 
        cmpi      57,r0
        bls       L215
;*      Branch Occurs to L215 
L211:        
        ldiu      @_btRxBuf$3+12,r0
        cmpi      65,r0
        blo       L213
;*      Branch Occurs to L213 
        cmpi      70,r0
        bls       L215
;*      Branch Occurs to L215 
L213:        
        ldiu      @_btRxBuf$3+12,r0
        cmpi      97,r0
        blo       L228
;*      Branch Occurs to L228 
        cmpi      102,r0
        bhi       L228
;*      Branch Occurs to L228 
L215:        
        ldiu      @_btRxBuf$3+13,r0
        cmpi      48,r0
        blo       L217
;*      Branch Occurs to L217 
        cmpi      57,r0
        bls       L221
;*      Branch Occurs to L221 
L217:        
        ldiu      @_btRxBuf$3+13,r0
        cmpi      65,r0
        blo       L219
;*      Branch Occurs to L219 
        cmpi      70,r0
        bls       L221
;*      Branch Occurs to L221 
L219:        
        ldiu      @_btRxBuf$3+13,r0
        cmpi      97,r0
        blo       L228
;*      Branch Occurs to L228 
        cmpi      102,r0
        bhi       L228
;*      Branch Occurs to L228 
L221:        
        ldiu      @_btRxBuf$3+14,r0
        cmpi      48,r0
        blo       L223
;*      Branch Occurs to L223 
        cmpi      57,r0
        bls       L227
;*      Branch Occurs to L227 
L223:        
        ldiu      @_btRxBuf$3+14,r0
        cmpi      65,r0
        blo       L225
;*      Branch Occurs to L225 
        cmpi      70,r0
        bls       L227
;*      Branch Occurs to L227 
L225:        
        ldiu      @_btRxBuf$3+14,r0
        cmpi      97,r0
        blo       L228
;*      Branch Occurs to L228 
        cmpi      102,r0
        bhi       L228
;*      Branch Occurs to L228 
L227:        
	.line	265
;----------------------------------------------------------------------
; 457 | FunConvAscHex((char *)&btRxBuf[7],sTemp,8);                            
;----------------------------------------------------------------------
        ldiu      8,r2
        ldiu      772,r1
        ldiu      @CL46,r0
        push      r2
        addi      fp,r1
        push      r1
        push      r0
        call      _FunConvAscHex
                                        ; Call Occurs
        subi      3,sp
	.line	267
;----------------------------------------------------------------------
; 459 | memset(m_btCommSt,0x00,sizeof(m_btCommSt));                            
;----------------------------------------------------------------------
        ldiu      7,r0
        ldiu      0,r1
        ldiu      @CL3,r2
        push      r0
        push      r1
        push      r2
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	268
;----------------------------------------------------------------------
; 460 | pCommStatus_Lic = (COMMSTATUS_LIC *)m_btCommSt;                        
;----------------------------------------------------------------------
        ldiu      792,ir0
        ldiu      @CL3,r0
        sti       r0,*+fp(ir0)
	.line	270
;----------------------------------------------------------------------
; 462 | pCommStatus_Lic->BYTE_1.BYTE = sTemp[0];                               
;----------------------------------------------------------------------
        ldiu      772,ir1
        ldiu      *+fp(ir0),ar0
        ldiu      *+fp(ir1),r0
        sti       r0,*ar0
	.line	271
;----------------------------------------------------------------------
; 463 | pCommStatus_Lic->BYTE_2.BYTE = sTemp[1];                               
;----------------------------------------------------------------------
        ldiu      773,ir1
        ldiu      *+fp(ir0),ar0
        ldiu      *+fp(ir1),r0
        sti       r0,*+ar0(1)
	.line	272
;----------------------------------------------------------------------
; 464 | pCommStatus_Lic->BYTE_3.BYTE = sTemp[2];                               
;----------------------------------------------------------------------
        ldiu      774,ir1
        ldiu      *+fp(ir0),ar0
        ldiu      *+fp(ir1),r0
        sti       r0,*+ar0(2)
	.line	273
;----------------------------------------------------------------------
; 465 | pCommStatus_Lic->BYTE_4.BYTE = sTemp[3];                               
;----------------------------------------------------------------------
        ldiu      775,ir1
        ldiu      *+fp(ir0),ar0
        ldiu      *+fp(ir1),r0
        sti       r0,*+ar0(3)
	.line	275
;----------------------------------------------------------------------
; 467 | sprintf(btBuf,"COMMST  %02X-%02X-%02X-%02X \r\n",                      
; 468 | m_btCommSt[0],                                                         
; 469 | m_btCommSt[1],                                                         
; 470 | m_btCommSt[2],                                                         
; 471 | m_btCommSt[3]);                                                        
;----------------------------------------------------------------------
        ldiu      @_m_btCommSt+2,r3
        ldiu      @_m_btCommSt+1,rs
        ldiu      @_m_btCommSt+3,r2
        ldiu      @_m_btCommSt+0,r0
        push      r2
        ldiu      516,r2
        push      r3
        push      rs
        ldiu      @CL47,r1
        push      r0
        addi      fp,r2
        push      r1
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      6,sp
	.line	281
;----------------------------------------------------------------------
; 473 | user_DebugPrint((char *)btBuf);                                        
; 476 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
L228:        
	.line	286
;----------------------------------------------------------------------
; 478 | user_DebugPrint("COMMST Syntax error\r\n");                            
; 481 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL48,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	290
;----------------------------------------------------------------------
; 482 | if(!strcmp(szBuf1,"TrainConf"))                                        
;----------------------------------------------------------------------
L230:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L239
        subi      2,sp
        ldine     @CL52,r1
        ldine     fp,r0
;*      Branch Occurs to L239 
	.line	292
;----------------------------------------------------------------------
; 484 | if( IS_ASCNUMBER(btRxBuf[9]))                                          
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+9,r0
        cmpi      48,r0
        blo       L237
;*      Branch Occurs to L237 
        cmpi      57,r0
        bhi       L237
;*      Branch Occurs to L237 
	.line	294
;----------------------------------------------------------------------
; 486 | m_TrainCof_Flag = TRUE;                                                
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_TrainCof_Flag+0
	.line	296
;----------------------------------------------------------------------
; 488 | m_TrainCof_Val = MIN(3,ConvAsc2Hex(btRxBuf[9]));                       
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+9,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      3,r1
        cmpi3     r0,r1
        bhsd      L235
        subi      1,sp
	nop
        ldihs     @_btRxBuf$3+9,r0
;*      Branch Occurs to L235 
        bud       L236
	nop
	nop
        ldiu      3,r0
;*      Branch Occurs to L236 
L235:        
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
L236:        
        sti       r0,@_m_TrainCof_Val+0
	.line	298
;----------------------------------------------------------------------
; 490 | sprintf(btBuf,"TrainConf Val = %02X \r\n",m_TrainCof_Val);             
;----------------------------------------------------------------------
        ldiu      @CL50,r1
        ldiu      516,r2
        push      r0
        addi      fp,r2
        push      r1
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
	.line	299
;----------------------------------------------------------------------
; 491 | user_DebugPrint((char *)btBuf);                                        
; 493 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
L237:        
	.line	303
;----------------------------------------------------------------------
; 495 | user_DebugPrint("TrainConf Syntax error\r\n");                         
; 499 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL51,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	308
;----------------------------------------------------------------------
; 500 | if(!strcmp(szBuf1,"CiPosi"))                                           
;----------------------------------------------------------------------
L239:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L247
        subi      2,sp
        ldine     @CL55,r1
        ldine     fp,r0
;*      Branch Occurs to L247 
	.line	310
;----------------------------------------------------------------------
; 502 | if( IS_ASCNUMBER(btRxBuf[6]) && IS_ASCNUMBER(btRxBuf[7]))              
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+6,r0
        cmpi      48,r0
        blo       L245
;*      Branch Occurs to L245 
        cmpi      57,r0
        bhi       L245
;*      Branch Occurs to L245 
        ldiu      @_btRxBuf$3+7,r0
        cmpi      48,r0
        blo       L245
;*      Branch Occurs to L245 
        cmpi      57,r0
        bhi       L245
;*      Branch Occurs to L245 
	.line	312
;----------------------------------------------------------------------
; 504 | m_CiPosi_Flag = TRUE;                                                  
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_CiPosi_Flag+0
	.line	314
;----------------------------------------------------------------------
; 506 | m_CiPosi_Val = MAKE_WORD(ConvAsc2Hex(btRxBuf[6]),ConvAsc2Hex(btRxBuf[7]
;     | ));                                                                    
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+6,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      @_btRxBuf$3+7,r1
        ldiu      r0,r4
        ash       8,r4
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       255,r0
        or3       r4,r0,r0
        and       65535,r0
        sti       r0,@_m_CiPosi_Val+0
        subi      1,sp
	.line	316
;----------------------------------------------------------------------
; 508 | sprintf(btBuf,"CiPosi Val = %02X \r\n",m_CiPosi_Val);                  
;----------------------------------------------------------------------
        ldiu      r0,r1
        push      r1
        ldiu      516,r1
        ldiu      @CL53,r0
        addi      fp,r1
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
	.line	317
;----------------------------------------------------------------------
; 509 | user_DebugPrint((char *)btBuf);                                        
; 511 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
L245:        
	.line	321
;----------------------------------------------------------------------
; 513 | user_DebugPrint("CiPosi Syntax error\r\n");                            
; 517 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL54,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	326
;----------------------------------------------------------------------
; 518 | if(!strcmp(szBuf1,"CiFault"))                                          
;----------------------------------------------------------------------
L247:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L255
        subi      2,sp
        ldine     @CL58,r1
        ldine     fp,r0
;*      Branch Occurs to L255 
	.line	328
;----------------------------------------------------------------------
; 520 | if( IS_ASCNUMBER(btRxBuf[7]) && IS_ASCNUMBER(btRxBuf[8]))              
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+7,r0
        cmpi      48,r0
        blo       L253
;*      Branch Occurs to L253 
        cmpi      57,r0
        bhi       L253
;*      Branch Occurs to L253 
        ldiu      @_btRxBuf$3+8,r0
        cmpi      48,r0
        blo       L253
;*      Branch Occurs to L253 
        cmpi      57,r0
        bhi       L253
;*      Branch Occurs to L253 
	.line	330
;----------------------------------------------------------------------
; 522 | m_CiFault_Flag = TRUE;                                                 
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_CiFault_Flag+0
	.line	332
;----------------------------------------------------------------------
; 524 | m_CiFault_Val = MAKE_WORD(ConvAsc2Hex(btRxBuf[7]),ConvAsc2Hex(btRxBuf[8
;     | ]));                                                                   
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+7,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      @_btRxBuf$3+8,r1
        ldiu      r0,r4
        ash       8,r4
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       255,r0
        or3       r4,r0,r0
        and       65535,r0
        sti       r0,@_m_CiFault_Val+0
        subi      1,sp
	.line	334
;----------------------------------------------------------------------
; 526 | sprintf(btBuf,"CiFault Val = %02X \r\n",m_CiFault_Val);                
;----------------------------------------------------------------------
        ldiu      r0,r1
        push      r1
        ldiu      516,r1
        ldiu      @CL56,r0
        addi      fp,r1
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
	.line	335
;----------------------------------------------------------------------
; 527 | user_DebugPrint((char *)btBuf);                                        
; 529 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
L253:        
	.line	339
;----------------------------------------------------------------------
; 531 | user_DebugPrint("CiFault Syntax error\r\n");                           
; 534 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL57,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
	.line	343
;----------------------------------------------------------------------
; 535 | if(!strcmp(szBuf1,"DIAdd"))                                            
;----------------------------------------------------------------------
L255:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        subi      2,sp
        bne       L263
;*      Branch Occurs to L263 
	.line	345
;----------------------------------------------------------------------
; 537 | if( IS_ASCNUMBER(btRxBuf[5]))                                          
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+5,r0
        cmpi      48,r0
        blo       L262
;*      Branch Occurs to L262 
        cmpi      57,r0
        bhi       L262
;*      Branch Occurs to L262 
	.line	347
;----------------------------------------------------------------------
; 539 | m_DIAdd_Flag = TRUE;                                                   
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_DIAdd_Flag+0
	.line	349
;----------------------------------------------------------------------
; 541 | m_DIAdd_Val = MIN(3,(ConvAsc2Hex(btRxBuf[5])));                        
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+5,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      3,r1
        cmpi3     r0,r1
        bhsd      L260
        subi      1,sp
	nop
        ldihs     @_btRxBuf$3+5,r0
;*      Branch Occurs to L260 
        bud       L261
	nop
	nop
        ldiu      3,r0
;*      Branch Occurs to L261 
L260:        
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
L261:        
        sti       r0,@_m_DIAdd_Val+0
	.line	351
;----------------------------------------------------------------------
; 543 | sprintf(btBuf,"DIAdd Val = %02X \r\n",m_DIAdd_Val);                    
;----------------------------------------------------------------------
        ldiu      516,r2
        ldiu      r0,r1
        ldiu      @CL59,r0
        addi      fp,r2
        push      r1
        push      r0
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
	.line	352
;----------------------------------------------------------------------
; 544 | user_DebugPrint((char *)btBuf);                                        
; 546 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L263
;*      Branch Occurs to L263 
L262:        
	.line	356
;----------------------------------------------------------------------
; 548 | user_DebugPrint("DIAdd Syntax error\r\n");                             
;----------------------------------------------------------------------
        ldiu      @CL60,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
L263:        
	.line	360
;----------------------------------------------------------------------
; 552 | if(!strcmp(szBuf1,"VerSet"))                                           
;----------------------------------------------------------------------
        ldiu      @CL61,r1
        ldiu      fp,r0
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L355
        subi      2,sp
        ldine     @CL64,r1
        ldine     fp,r0
;*      Branch Occurs to L355 
	.line	363
;----------------------------------------------------------------------
; 555 | if( IS_ASCHEX(btRxBuf[7]) &&IS_ASCHEX(btRxBuf[8]) &&                   
; 557 |         IS_ASCHEX(btRxBuf[10]) &&IS_ASCHEX(btRxBuf[11]) &&             
; 558 |         IS_ASCHEX(btRxBuf[12]) &&IS_ASCHEX(btRxBuf[13]) &&             
; 560 |         IS_ASCHEX(btRxBuf[15]) &&IS_ASCHEX(btRxBuf[16]) &&             
; 561 |         IS_ASCHEX(btRxBuf[17]) &&IS_ASCHEX(btRxBuf[18]) &&             
; 562 |         IS_ASCHEX(btRxBuf[19]) &&IS_ASCHEX(btRxBuf[20]) &&             
; 563 |         IS_ASCHEX(btRxBuf[21]) &&IS_ASCHEX(btRxBuf[22])                
; 564 |         )                                                              
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+7,r0
        cmpi      48,r0
        blo       L266
;*      Branch Occurs to L266 
        cmpi      57,r0
        bls       L270
;*      Branch Occurs to L270 
L266:        
        ldiu      @_btRxBuf$3+7,r0
        cmpi      65,r0
        blo       L268
;*      Branch Occurs to L268 
        cmpi      70,r0
        bls       L270
;*      Branch Occurs to L270 
L268:        
        ldiu      @_btRxBuf$3+7,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L270:        
        ldiu      @_btRxBuf$3+8,r0
        cmpi      48,r0
        blo       L272
;*      Branch Occurs to L272 
        cmpi      57,r0
        bls       L276
;*      Branch Occurs to L276 
L272:        
        ldiu      @_btRxBuf$3+8,r0
        cmpi      65,r0
        blo       L274
;*      Branch Occurs to L274 
        cmpi      70,r0
        bls       L276
;*      Branch Occurs to L276 
L274:        
        ldiu      @_btRxBuf$3+8,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L276:        
        ldiu      @_btRxBuf$3+10,r0
        cmpi      48,r0
        blo       L278
;*      Branch Occurs to L278 
        cmpi      57,r0
        bls       L282
;*      Branch Occurs to L282 
L278:        
        ldiu      @_btRxBuf$3+10,r0
        cmpi      65,r0
        blo       L280
;*      Branch Occurs to L280 
        cmpi      70,r0
        bls       L282
;*      Branch Occurs to L282 
L280:        
        ldiu      @_btRxBuf$3+10,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L282:        
        ldiu      @_btRxBuf$3+11,r0
        cmpi      48,r0
        blo       L284
;*      Branch Occurs to L284 
        cmpi      57,r0
        bls       L288
;*      Branch Occurs to L288 
L284:        
        ldiu      @_btRxBuf$3+11,r0
        cmpi      65,r0
        blo       L286
;*      Branch Occurs to L286 
        cmpi      70,r0
        bls       L288
;*      Branch Occurs to L288 
L286:        
        ldiu      @_btRxBuf$3+11,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L288:        
        ldiu      @_btRxBuf$3+12,r0
        cmpi      48,r0
        blo       L290
;*      Branch Occurs to L290 
        cmpi      57,r0
        bls       L294
;*      Branch Occurs to L294 
L290:        
        ldiu      @_btRxBuf$3+12,r0
        cmpi      65,r0
        blo       L292
;*      Branch Occurs to L292 
        cmpi      70,r0
        bls       L294
;*      Branch Occurs to L294 
L292:        
        ldiu      @_btRxBuf$3+12,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L294:        
        ldiu      @_btRxBuf$3+13,r0
        cmpi      48,r0
        blo       L296
;*      Branch Occurs to L296 
        cmpi      57,r0
        bls       L300
;*      Branch Occurs to L300 
L296:        
        ldiu      @_btRxBuf$3+13,r0
        cmpi      65,r0
        blo       L298
;*      Branch Occurs to L298 
        cmpi      70,r0
        bls       L300
;*      Branch Occurs to L300 
L298:        
        ldiu      @_btRxBuf$3+13,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L300:        
        ldiu      @_btRxBuf$3+15,r0
        cmpi      48,r0
        blo       L302
;*      Branch Occurs to L302 
        cmpi      57,r0
        bls       L306
;*      Branch Occurs to L306 
L302:        
        ldiu      @_btRxBuf$3+15,r0
        cmpi      65,r0
        blo       L304
;*      Branch Occurs to L304 
        cmpi      70,r0
        bls       L306
;*      Branch Occurs to L306 
L304:        
        ldiu      @_btRxBuf$3+15,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L306:        
        ldiu      @_btRxBuf$3+16,r0
        cmpi      48,r0
        blo       L308
;*      Branch Occurs to L308 
        cmpi      57,r0
        bls       L312
;*      Branch Occurs to L312 
L308:        
        ldiu      @_btRxBuf$3+16,r0
        cmpi      65,r0
        blo       L310
;*      Branch Occurs to L310 
        cmpi      70,r0
        bls       L312
;*      Branch Occurs to L312 
L310:        
        ldiu      @_btRxBuf$3+16,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L312:        
        ldiu      @_btRxBuf$3+17,r0
        cmpi      48,r0
        blo       L314
;*      Branch Occurs to L314 
        cmpi      57,r0
        bls       L318
;*      Branch Occurs to L318 
L314:        
        ldiu      @_btRxBuf$3+17,r0
        cmpi      65,r0
        blo       L316
;*      Branch Occurs to L316 
        cmpi      70,r0
        bls       L318
;*      Branch Occurs to L318 
L316:        
        ldiu      @_btRxBuf$3+17,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L318:        
        ldiu      @_btRxBuf$3+18,r0
        cmpi      48,r0
        blo       L320
;*      Branch Occurs to L320 
        cmpi      57,r0
        bls       L324
;*      Branch Occurs to L324 
L320:        
        ldiu      @_btRxBuf$3+18,r0
        cmpi      65,r0
        blo       L322
;*      Branch Occurs to L322 
        cmpi      70,r0
        bls       L324
;*      Branch Occurs to L324 
L322:        
        ldiu      @_btRxBuf$3+18,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L324:        
        ldiu      @_btRxBuf$3+19,r0
        cmpi      48,r0
        blo       L326
;*      Branch Occurs to L326 
        cmpi      57,r0
        bls       L330
;*      Branch Occurs to L330 
L326:        
        ldiu      @_btRxBuf$3+19,r0
        cmpi      65,r0
        blo       L328
;*      Branch Occurs to L328 
        cmpi      70,r0
        bls       L330
;*      Branch Occurs to L330 
L328:        
        ldiu      @_btRxBuf$3+19,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L330:        
        ldiu      @_btRxBuf$3+20,r0
        cmpi      48,r0
        blo       L332
;*      Branch Occurs to L332 
        cmpi      57,r0
        bls       L336
;*      Branch Occurs to L336 
L332:        
        ldiu      @_btRxBuf$3+20,r0
        cmpi      65,r0
        blo       L334
;*      Branch Occurs to L334 
        cmpi      70,r0
        bls       L336
;*      Branch Occurs to L336 
L334:        
        ldiu      @_btRxBuf$3+20,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L336:        
        ldiu      @_btRxBuf$3+21,r0
        cmpi      48,r0
        blo       L338
;*      Branch Occurs to L338 
        cmpi      57,r0
        bls       L342
;*      Branch Occurs to L342 
L338:        
        ldiu      @_btRxBuf$3+21,r0
        cmpi      65,r0
        blo       L340
;*      Branch Occurs to L340 
        cmpi      70,r0
        bls       L342
;*      Branch Occurs to L342 
L340:        
        ldiu      @_btRxBuf$3+21,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L342:        
        ldiu      @_btRxBuf$3+22,r0
        cmpi      48,r0
        blo       L344
;*      Branch Occurs to L344 
        cmpi      57,r0
        bls       L348
;*      Branch Occurs to L348 
L344:        
        ldiu      @_btRxBuf$3+22,r0
        cmpi      65,r0
        blo       L346
;*      Branch Occurs to L346 
        cmpi      70,r0
        bls       L348
;*      Branch Occurs to L348 
L346:        
        ldiu      @_btRxBuf$3+22,r0
        cmpi      97,r0
        blo       L353
;*      Branch Occurs to L353 
        cmpi      102,r0
        bhi       L353
;*      Branch Occurs to L353 
L348:        
	.line	374
;----------------------------------------------------------------------
; 566 | sIndex = MIN(VER_BDD_MAX_CNT,MAKE_BYTE(ConvAsc2Hex(btRxBuf[7]),ConvAsc2
;     | Hex(btRxBuf[8])));                                                     
;----------------------------------------------------------------------
        ldiu      @_btRxBuf$3+7,r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      r0,r4
        ldiu      @_btRxBuf$3+8,r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      24,r1
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi3     r0,r1
        bhsd      L350
        subi      1,sp
	nop
        ldihs     @_btRxBuf$3+7,r0
;*      Branch Occurs to L350 
        bud       L351
	nop
	nop
        ldiu      24,r0
;*      Branch Occurs to L351 
L350:        
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      @_btRxBuf$3+8,r1
        ldiu      r0,r4
        ash       4,r4
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        subi      1,sp
        or3       r4,r0,r0
        and       255,r0
L351:        
        sti       r0,*+fp(3)
	.line	376
;----------------------------------------------------------------------
; 568 | pLicVerDp->cvbBuf[sIndex].chVer[0] = btRxBuf[10];                      
;----------------------------------------------------------------------
        ldiu      791,ir0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$3+10,r0
        sti       r0,*+ar0(1)
	.line	377
;----------------------------------------------------------------------
; 569 | pLicVerDp->cvbBuf[sIndex].chVer[1] = btRxBuf[11];                      
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$3+11,r0
        sti       r0,*+ar0(2)
	.line	378
;----------------------------------------------------------------------
; 570 | pLicVerDp->cvbBuf[sIndex].chVer[2] = btRxBuf[12];                      
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$3+12,r0
        sti       r0,*+ar0(3)
	.line	379
;----------------------------------------------------------------------
; 571 | pLicVerDp->cvbBuf[sIndex].chVer[3] = btRxBuf[13];                      
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$3+13,r0
        sti       r0,*+ar0(4)
	.line	381
;----------------------------------------------------------------------
; 573 | pLicVerDp->cvbBuf[sIndex].chBuildDate[0]=btRxBuf[15];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$3+15,r0
        sti       r0,*+ar0(5)
	.line	382
;----------------------------------------------------------------------
; 574 | pLicVerDp->cvbBuf[sIndex].chBuildDate[1]=btRxBuf[16];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$3+16,r0
        sti       r0,*+ar0(6)
	.line	383
;----------------------------------------------------------------------
; 575 | pLicVerDp->cvbBuf[sIndex].chBuildDate[2]=btRxBuf[17];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$3+17,r0
        sti       r0,*+ar0(7)
	.line	384
;----------------------------------------------------------------------
; 576 | pLicVerDp->cvbBuf[sIndex].chBuildDate[3]=btRxBuf[18];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$3+18,r0
        sti       r0,*+ar0(8)
	.line	385
;----------------------------------------------------------------------
; 577 | pLicVerDp->cvbBuf[sIndex].chBuildDate[4]=btRxBuf[19];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$3+19,r0
        sti       r0,*+ar0(9)
	.line	386
;----------------------------------------------------------------------
; 578 | pLicVerDp->cvbBuf[sIndex].chBuildDate[5]=btRxBuf[20];                  
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        ldiu      @_btRxBuf$3+20,r0
        sti       r0,*+ar0(10)
	.line	388
;----------------------------------------------------------------------
; 580 | memset(btBuf,0x00,256);                                                
;----------------------------------------------------------------------
        ldiu      256,r2
        ldiu      516,r1
        ldiu      0,r0
        push      r2
        push      r0
        addi      fp,r1
        push      r1
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	389
;----------------------------------------------------------------------
; 581 | memcpy(btBuf,&LIC_VerList[sIndex][0],strlen((char*)&LIC_VerList[sIndex]
;     | [0]));                                                                 
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        mpyi      9,r0
        addi      @CL23,r0              ; Unsigned
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(3),r2
        mpyi      9,r2
        ldiu      516,r1
        push      r0
        ldiu      @CL23,r0
        addi      fp,r1
        addi      r2,r0
        push      r0
        push      r1
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	390
;----------------------------------------------------------------------
; 582 | sprintf(&btBuf[strlen((char*)&btBuf)],":");                            
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      @CL62,r1
        subi      1,sp
        push      r1
        addi3     r0,fp,r0              ; Unsigned
        addi      516,r0                ; Unsigned
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	391
;----------------------------------------------------------------------
; 583 | memcpy(&btBuf[strlen((char*)&btBuf)],&pLicVerDp->cvbBuf[sIndex].chVer[0
;     | ],4);                                                                  
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(3),r1
        mpyi      10,r1
        ldiu      791,ir0
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        addi3     r0,fp,ar0             ; Unsigned
        addi      1,ar1                 ; Unsigned
        addi      516,ar0               ; Unsigned
        ldiu      *ar1,r0
        sti       r0,*ar0
        ldiu      *+ar1,r0
        sti       r0,*+ar0
        ldiu      *+ar1(2),r0
        sti       r0,*+ar0(2)
        ldiu      *+ar1(3),r0
        sti       r0,*+ar0(3)
	.line	392
;----------------------------------------------------------------------
; 584 | sprintf(&btBuf[strlen((char*)&btBuf)],":");                            
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      @CL62,r1
        subi      1,sp
        addi3     r0,fp,r0              ; Unsigned
        addi      516,r0                ; Unsigned
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	393
;----------------------------------------------------------------------
; 585 | memcpy(&btBuf[strlen((char*)&btBuf)],&pLicVerDp->cvbBuf[sIndex].chBuild
;     | Date[0],8);                                                            
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      791,ir0
        ldiu      *+fp(3),r1
        mpyi      10,r1
        addi3     r0,fp,ar0             ; Unsigned
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        addi      516,ar0               ; Unsigned
        addi      5,ar1                 ; Unsigned
        ldiu      *ar1++(1),r0
        rpts      6                     ; Fast MEMCPY(#6)
        sti       r0,*ar0++(1)
||      ldi       *ar1++(1),r0
        sti       r0,*ar0++(1)
	.line	394
;----------------------------------------------------------------------
; 586 | sprintf(&btBuf[strlen((char*)&btBuf)],"\r\n");                         
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        subi      1,sp
        ldiu      @CL25,r1
        push      r1
        addi3     r0,fp,r0              ; Unsigned
        addi      516,r0                ; Unsigned
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      2,sp
	.line	396
;----------------------------------------------------------------------
; 588 | user_DebugPrint((char *)btBuf);                                        
; 591 | else                                                                   
;----------------------------------------------------------------------
        ldiu      516,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L360
;*      Branch Occurs to L360 
L353:        
	.line	401
;----------------------------------------------------------------------
; 593 | user_DebugPrint("VerSet Syntax error\r\n");                            
; 597 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL63,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L360
;*      Branch Occurs to L360 
	.line	406
;----------------------------------------------------------------------
; 598 | if(!strcmp(szBuf1,"?"))                                                
;----------------------------------------------------------------------
L355:        
        push      r1
        addi      4,r0
        push      r0
        call      _strcmp
                                        ; Call Occurs
        cmpi      0,r0
        bned      L359
        subi      2,sp
	nop
        ldine     @CL85,r0
;*      Branch Occurs to L359 
	.line	408
;----------------------------------------------------------------------
; 600 | user_DebugPrint("[ENTER]      : Move next line after out '->' \r\n");  
;----------------------------------------------------------------------
        ldiu      @CL65,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	409
;----------------------------------------------------------------------
; 601 | user_DebugPrint("'?'          : Help \r\n");                           
;----------------------------------------------------------------------
        ldiu      @CL66,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	410
;----------------------------------------------------------------------
; 602 | user_DebugPrint("'T'          : Date&time setting , 'TYYMMDDHHMNSS', 'E
;     | X)T100312154200' \r\n");                                               
;----------------------------------------------------------------------
        ldiu      @CL67,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	411
;----------------------------------------------------------------------
; 603 | user_DebugPrint("'t'          : Date&time read \r\n");                 
;----------------------------------------------------------------------
        ldiu      @CL68,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	412
;----------------------------------------------------------------------
; 604 | user_DebugPrint("'V'          : Version \r\n");                        
;----------------------------------------------------------------------
        ldiu      @CL69,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	413
;----------------------------------------------------------------------
; 605 | user_DebugPrint("'Recent'     : Recently faults start \r\n");          
;----------------------------------------------------------------------
        ldiu      @CL70,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	414
;----------------------------------------------------------------------
; 606 | user_DebugPrint("'Historical' : Historical data start \r\n");          
;----------------------------------------------------------------------
        ldiu      @CL71,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	415
;----------------------------------------------------------------------
; 607 | user_DebugPrint("'Rxinfo'     : Recieve info \r\n");                   
;----------------------------------------------------------------------
        ldiu      @CL72,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	416
;----------------------------------------------------------------------
; 608 | user_DebugPrint("'LnWayClr'   : 'm_nLnWkWaySideOnRxOk' variable clear \
;     | r\n");                                                                 
;----------------------------------------------------------------------
        ldiu      @CL73,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	417
;----------------------------------------------------------------------
; 609 | user_DebugPrint("'LnFtpClr'   : 'm_bLnWkFtpEndFlag' variable clear \r\n
;     | ");                                                                    
;----------------------------------------------------------------------
        ldiu      @CL74,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	418
;----------------------------------------------------------------------
; 610 | user_DebugPrint("'HisStTm'    : Historical data start time set(2000/1/1
;     |  0:0:0 ~ total second), HisStTmxxxxxxxx, 'EX)HisStTm0000000F' \r\n");  
;----------------------------------------------------------------------
        ldiu      @CL75,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	419
;----------------------------------------------------------------------
; 611 | user_DebugPrint("'ViewCarNo'  : View car number \r\n");                
;----------------------------------------------------------------------
        ldiu      @CL76,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	420
;----------------------------------------------------------------------
; 612 | user_DebugPrint("'CarNoClr'   : Car number clear \r\n");               
;----------------------------------------------------------------------
        ldiu      @CL77,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	421
;----------------------------------------------------------------------
; 613 | user_DebugPrint("'TrainConf'  : Train Configuration. TrainConfx(x : 1~2
;     | ) \r\n");                                                              
;----------------------------------------------------------------------
        ldiu      @CL78,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	422
;----------------------------------------------------------------------
; 614 | user_DebugPrint("'CiPosi'     : C_I Index Position. CiPosixx 'EX)CiPosi
;     | 00' \r\n");                                                            
;----------------------------------------------------------------------
        ldiu      @CL79,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	423
;----------------------------------------------------------------------
; 615 | user_DebugPrint("'CiFault'    : Other C/I Fault. CiFaultxx :  'EX)CiFau
;     | lt01' \r\n");                                                          
;----------------------------------------------------------------------
        ldiu      @CL80,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	424
;----------------------------------------------------------------------
; 616 | user_DebugPrint("'DIAdd'      : DI_Address_A/B  DIAdd1x(x : 1~2) 'EX)DI
;     | Add1' \r\n");                                                          
;----------------------------------------------------------------------
        ldiu      @CL81,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	425
;----------------------------------------------------------------------
; 617 | user_DebugPrint("'WaySideON'  : WaySide_ON \r\n");                     
;----------------------------------------------------------------------
        ldiu      @CL82,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	426
;----------------------------------------------------------------------
; 618 | user_DebugPrint("'COMMST'     : Comm Status. COMMST=XXXXXXXX  'EX) COMM
;     | ST=FF7F1F53' \r\n");                                                   
;----------------------------------------------------------------------
        ldiu      @CL83,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	427
;----------------------------------------------------------------------
; 619 | user_DebugPrint("'VerSet'     : Unit Ver Set. VerSet=XX(incdex):XXXX(Ve
;     | r):XXXXXX(BuildDate) \r\n");                                           
;----------------------------------------------------------------------
        ldiu      @CL84,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	428
;----------------------------------------------------------------------
; 620 | user_DebugPrint("\r\n");                                               
; 622 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @CL25,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L360
;*      Branch Occurs to L360 
	.line	432
;----------------------------------------------------------------------
; 624 | user_DebugPrint("Syntax error\r\n");                                   
;----------------------------------------------------------------------
L359:        
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
L360:        
	.line	435
;----------------------------------------------------------------------
; 627 | nOldUart1RxOneByteGapDelayTime = m_nUart1RxOneByteGapDelayTime;        
;----------------------------------------------------------------------
        ldiu      @_m_nUart1RxOneByteGapDelayTime+0,r0
        sti       r0,@_nOldUart1RxOneByteGapDelayTime$2+0
	.line	436
        pop       ar5
        ldiu      *-fp(1),bk
        pop       ar4
        pop       r5
        ldiu      *fp,fp
        pop       r4
        subi      794,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	628,000003030h,792


	.sect	 ".text"

	.global	_user_IsSingleOrMarried
	.sym	_user_IsSingleOrMarried,_user_IsSingleOrMarried,36,2,0
	.func	638
;******************************************************************************
;* FUNCTION NAME: _user_IsSingleOrMarried                                     *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,st                                               *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 0 Auto + 0 SOE = 2 words          *
;******************************************************************************
_user_IsSingleOrMarried:
	.line	1
;----------------------------------------------------------------------
; 638 | int user_IsSingleOrMarried()                                           
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	3
;----------------------------------------------------------------------
; 640 | if(m_nCarNo[0] && !m_nCarNo[1]) return 1;                              
; 641 | else                                                                   
;----------------------------------------------------------------------
        ldi       @_m_nCarNo+0,r0
        beq       L367
;*      Branch Occurs to L367 
        ldi       @_m_nCarNo+1,r0
        bne       L367
;*      Branch Occurs to L367 
        bud       L372
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L372 
L367:        
	.line	5
;----------------------------------------------------------------------
; 642 | if(m_nCarNo[0] && m_nCarNo[1]) return 2;                               
; 643 | else                                                                   
;----------------------------------------------------------------------
        ldi       @_m_nCarNo+0,r0
        beq       L371
;*      Branch Occurs to L371 
        ldi       @_m_nCarNo+1,r0
        beq       L371
;*      Branch Occurs to L371 
        bud       L372
	nop
	nop
        ldiu      2,r0
;*      Branch Occurs to L372 
L371:        
	.line	7
;----------------------------------------------------------------------
; 644 | return 0;                                                              
;----------------------------------------------------------------------
        ldiu      0,r0
L372:        
	.line	8
        ldiu      *-fp(1),r1
        ldiu      *fp,fp
        subi      2,sp
        bu        r1
;*      Branch Occurs to r1 
	.endfunc	645,000000000h,0


	.sect	 ".text"

	.global	_user_SetVersionEnableTbl
	.sym	_user_SetVersionEnableTbl,_user_SetVersionEnableTbl,32,2,0
	.func	650
;******************************************************************************
;* FUNCTION NAME: _user_SetVersionEnableTbl                                   *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,ar0,ir0,st                                    *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 1 Parm + 1 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_SetVersionEnableTbl:
	.sym	_nVal,-2,4,9,32
	.sym	_nPos,1,4,1,32
	.line	1
;----------------------------------------------------------------------
; 650 | void user_SetVersionEnableTbl(int nVal)                                
;----------------------------------------------------------------------
	.line	2
;----------------------------------------------------------------------
; 652 | int nPos;                                                              
; 654 | switch(nVal)                                                           
; 656 | // �̱�ī�� ���                                                       
; 657 | case 1:                                                                
;----------------------------------------------------------------------
        bud       L378
        push      fp
        ldiu      sp,fp
        addi      1,sp
;*      Branch Occurs to L378 
L375:        
	.line	9
;----------------------------------------------------------------------
; 658 | nPos = 0;                                                              
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
	.line	10
;----------------------------------------------------------------------
; 659 | m_bExVersionEnableTbl[nPos++] = TRUE;   //TRIC, A/F                    
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      @CL86,ar0
        ldiu      r0,ir0
        addi      ir0,r1
        ldiu      1,r0
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	11
;----------------------------------------------------------------------
; 660 | m_bExVersionEnableTbl[nPos++] = TRUE;   //TRIC, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	12
;----------------------------------------------------------------------
; 661 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CCP, F/A end
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	13
;----------------------------------------------------------------------
; 662 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CCP, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	14
;----------------------------------------------------------------------
; 663 | m_bExVersionEnableTbl[nPos++] = TRUE;   //LIC-LON
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	15
;----------------------------------------------------------------------
; 664 | m_bExVersionEnableTbl[nPos++] = TRUE;   //LIC-MPU
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	16
;----------------------------------------------------------------------
; 665 | m_bExVersionEnableTbl[nPos++] = TRUE;   //GIA
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	17
;----------------------------------------------------------------------
; 666 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VTX
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	18
;----------------------------------------------------------------------
; 667 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PAC, F/A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	19
;----------------------------------------------------------------------
; 668 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PAC, F/A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	20
;----------------------------------------------------------------------
; 669 | m_bExVersionEnableTbl[nPos++] = TRUE;   //FDI, F /A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	21
;----------------------------------------------------------------------
; 670 | m_bExVersionEnableTbl[nPos++] = TRUE;   //FDI, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	22
;----------------------------------------------------------------------
; 671 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	23
;----------------------------------------------------------------------
; 672 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	24
;----------------------------------------------------------------------
; 673 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	25
;----------------------------------------------------------------------
; 674 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	26
;----------------------------------------------------------------------
; 675 | m_bExVersionEnableTbl[nPos++] = FALSE;  //SDI 5
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        ldiu      0,r1
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	27
;----------------------------------------------------------------------
; 676 | m_bExVersionEnableTbl[nPos++] = FALSE;  //SDI 6
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	28
;----------------------------------------------------------------------
; 677 | m_bExVersionEnableTbl[nPos++] = FALSE;  //SDI 7
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	29
;----------------------------------------------------------------------
; 678 | m_bExVersionEnableTbl[nPos++] = FALSE;  //SDI 8
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	30
;----------------------------------------------------------------------
; 679 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        ldiu      1,r1
        sti       r1,*+ar0(ir0)
	.line	31
;----------------------------------------------------------------------
; 680 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	32
;----------------------------------------------------------------------
; 681 | m_bExVersionEnableTbl[nPos++] = FALSE;  //PII 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      0,r1
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	33
;----------------------------------------------------------------------
; 682 | m_bExVersionEnableTbl[nPos++] = FALSE;  //PII 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	34
;----------------------------------------------------------------------
; 683 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        ldiu      1,r1
        sti       r1,*+ar0(ir0)
	.line	35
;----------------------------------------------------------------------
; 684 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	36
;----------------------------------------------------------------------
; 685 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	37
;----------------------------------------------------------------------
; 686 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	38
;----------------------------------------------------------------------
; 687 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 5
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	39
;----------------------------------------------------------------------
; 688 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 6
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	40
;----------------------------------------------------------------------
; 689 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 7
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        ldiu      0,r1
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	41
;----------------------------------------------------------------------
; 690 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 8
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	42
;----------------------------------------------------------------------
; 691 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 9
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	43
;----------------------------------------------------------------------
; 692 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 10
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	44
;----------------------------------------------------------------------
; 693 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 11
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	45
;----------------------------------------------------------------------
; 694 | m_bExVersionEnableTbl[nPos++] = FALSE;  //VRX 12
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	46
;----------------------------------------------------------------------
; 695 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-MAIN
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	47
;----------------------------------------------------------------------
; 696 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-LAUN
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	48
;----------------------------------------------------------------------
; 697 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-UP
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	49
;----------------------------------------------------------------------
; 698 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-PPLAY
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	50
;----------------------------------------------------------------------
; 699 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-SPLAY
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	51
;----------------------------------------------------------------------
; 700 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-FTPDATA
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      *+fp(1),ir0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	52
;----------------------------------------------------------------------
; 701 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-CDTDATA
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r0
        addi      ir0,r0
        sti       r0,*+fp(1)
        sti       r1,*+ar0(ir0)
	.line	53
;----------------------------------------------------------------------
; 702 | break;                                                                 
; 704 | // �޸��� ī�� ���                                                    
; 705 | case 2:                                                                
;----------------------------------------------------------------------
        bu        L380
;*      Branch Occurs to L380 
L376:        
	.line	57
;----------------------------------------------------------------------
; 706 | nPos = 0;                                                              
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
	.line	58
;----------------------------------------------------------------------
; 707 | m_bExVersionEnableTbl[nPos++] = TRUE;   //TRIC, A/F                    
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      @CL86,ar0
        ldiu      r0,ir0
        addi      ir0,r1
        ldiu      1,r0
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	59
;----------------------------------------------------------------------
; 708 | m_bExVersionEnableTbl[nPos++] = TRUE;   //TRIC, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	60
;----------------------------------------------------------------------
; 709 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CCP, F/A end
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	61
;----------------------------------------------------------------------
; 710 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CCP, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	62
;----------------------------------------------------------------------
; 711 | m_bExVersionEnableTbl[nPos++] = TRUE;   //LIC-LON
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	63
;----------------------------------------------------------------------
; 712 | m_bExVersionEnableTbl[nPos++] = TRUE;   //LIC-MPU
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	64
;----------------------------------------------------------------------
; 713 | m_bExVersionEnableTbl[nPos++] = TRUE;   //GIA
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	65
;----------------------------------------------------------------------
; 714 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VTX
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	66
;----------------------------------------------------------------------
; 715 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PAC, F/A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	67
;----------------------------------------------------------------------
; 716 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PAC, F/A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	68
;----------------------------------------------------------------------
; 717 | m_bExVersionEnableTbl[nPos++] = TRUE;   //FDI, F /A
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	69
;----------------------------------------------------------------------
; 718 | m_bExVersionEnableTbl[nPos++] = TRUE;   //FDI, B
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	70
;----------------------------------------------------------------------
; 719 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	71
;----------------------------------------------------------------------
; 720 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	72
;----------------------------------------------------------------------
; 721 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	73
;----------------------------------------------------------------------
; 722 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	74
;----------------------------------------------------------------------
; 723 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 5
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	75
;----------------------------------------------------------------------
; 724 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 6
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	76
;----------------------------------------------------------------------
; 725 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 7
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	77
;----------------------------------------------------------------------
; 726 | m_bExVersionEnableTbl[nPos++] = TRUE;   //SDI 8
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	78
;----------------------------------------------------------------------
; 727 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	79
;----------------------------------------------------------------------
; 728 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	80
;----------------------------------------------------------------------
; 729 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	81
;----------------------------------------------------------------------
; 730 | m_bExVersionEnableTbl[nPos++] = TRUE;   //PII 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	82
;----------------------------------------------------------------------
; 731 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 1
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	83
;----------------------------------------------------------------------
; 732 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 2
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	84
;----------------------------------------------------------------------
; 733 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 3
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	85
;----------------------------------------------------------------------
; 734 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 4
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	86
;----------------------------------------------------------------------
; 735 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 5
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	87
;----------------------------------------------------------------------
; 736 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 6
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	88
;----------------------------------------------------------------------
; 737 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 7
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	89
;----------------------------------------------------------------------
; 738 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 8
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	90
;----------------------------------------------------------------------
; 739 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 9
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	91
;----------------------------------------------------------------------
; 740 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 10
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	92
;----------------------------------------------------------------------
; 741 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 11
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	93
;----------------------------------------------------------------------
; 742 | m_bExVersionEnableTbl[nPos++] = TRUE;   //VRX 12
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	94
;----------------------------------------------------------------------
; 743 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-MAIN
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	95
;----------------------------------------------------------------------
; 744 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-LAUN
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	96
;----------------------------------------------------------------------
; 745 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-UP
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	97
;----------------------------------------------------------------------
; 746 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-PPLAY
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	98
;----------------------------------------------------------------------
; 747 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-SPLAY
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	99
;----------------------------------------------------------------------
; 748 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-FTPDATA
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(1),ir0
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	100
;----------------------------------------------------------------------
; 749 | m_bExVersionEnableTbl[nPos++] = TRUE;   //CN-CDTDATA                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),ir0
        ldiu      1,r1
        addi      ir0,r1
        sti       r1,*+fp(1)
        sti       r0,*+ar0(ir0)
	.line	101
;----------------------------------------------------------------------
; 750 | break;                                                                 
;----------------------------------------------------------------------
        bu        L380
;*      Branch Occurs to L380 
L378:        
	.line	5
        ldiu      *-fp(2),r0
        cmpi      1,r0
        beq       L375
;*      Branch Occurs to L375 
        cmpi      2,r0
        beq       L376
;*      Branch Occurs to L376 
L380:        
	.line	103
        ldiu      *-fp(1),ir0
        ldiu      *fp,fp
        subi      3,sp
        bu        ir0
;*      Branch Occurs to ir0 
	.endfunc	752,000000000h,1


	.sect	 ".text"

	.global	_user_DebugRx
	.sym	_user_DebugRx,_user_DebugRx,36,2,0
	.func	757
;******************************************************************************
;* FUNCTION NAME: _user_DebugRx                                               *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,fp,sp                                            *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 0 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_DebugRx:
	.sym	_pBuf,-2,28,9,32
	.sym	_nRxBuffLen,-3,4,9,32
	.line	1
;----------------------------------------------------------------------
; 757 | int user_DebugRx(UCHAR *pBuf,int nRxBuffLen)                           
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 759 | return xr16l784_GetRxBuffer1Ch(pBuf,nRxBuffLen);                       
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        call      _xr16l784_GetRxBuffer1Ch
                                        ; Call Occurs
        subi      2,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	760,000000000h,0


	.sect	 ".text"

	.global	_user_DebugPrint
	.sym	_user_DebugPrint,_user_DebugPrint,32,2,0
	.func	762
;******************************************************************************
;* FUNCTION NAME: _user_DebugPrint                                            *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,fp,sp                                         *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 1 Parm + 0 Auto + 0 SOE = 3 words          *
;******************************************************************************
_user_DebugPrint:
	.sym	_pTxBuf,-2,18,9,32
	.line	1
;----------------------------------------------------------------------
; 762 | void user_DebugPrint(char *pTxBuf)                                     
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 764 | xr16l784_Send(XR16L784_1CHL,(UCHAR *)pTxBuf,strlen(pTxBuf));           
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      0,r1
        subi      1,sp
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        push      r1
        call      _xr16l784_Send
                                        ; Call Occurs
        subi      3,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	765,000000000h,0


	.sect	 ".text"

	.global	_user_CncsRx
	.sym	_user_CncsRx,_user_CncsRx,36,2,0
	.func	767
;******************************************************************************
;* FUNCTION NAME: _user_CncsRx                                                *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,fp,sp                                            *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 0 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_CncsRx:
	.sym	_pBuf,-2,28,9,32
	.sym	_nRxBuffLen,-3,4,9,32
	.line	1
;----------------------------------------------------------------------
; 767 | int user_CncsRx(UCHAR *pBuf,int nRxBuffLen)                            
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 769 | return xr16l784_GetRxBuffer2Ch(pBuf,nRxBuffLen);                       
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        call      _xr16l784_GetRxBuffer2Ch
                                        ; Call Occurs
        subi      2,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	770,000000000h,0


	.sect	 ".text"

	.global	_user_CncsTx
	.sym	_user_CncsTx,_user_CncsTx,32,2,0
	.func	772
;******************************************************************************
;* FUNCTION NAME: _user_CncsTx                                                *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,fp,sp                                         *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 0 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_CncsTx:
	.sym	_pTxBuf,-2,28,9,32
	.sym	_nTxLen,-3,4,9,32
	.line	1
;----------------------------------------------------------------------
; 772 | void user_CncsTx(UCHAR *pTxBuf,int nTxLen)                             
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 774 | xr16l784_RtsDelayStartSend(XR16L784_2CHL,(UCHAR *)pTxBuf,nTxLen,10);   
; 775 | //xr16l784_Send(XR16L784_2CHL,(UCHAR *)pTxBuf,nTxLen);                 
;----------------------------------------------------------------------
        ldiu      10,r0
        ldiu      1,r1
        push      r0
        ldiu      *-fp(3),r0
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        push      r1
        call      _xr16l784_RtsDelayStartSend
                                        ; Call Occurs
        subi      4,sp
	.line	5
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	776,000000000h,0


	.sect	 ".text"

	.global	_user_PacRx
	.sym	_user_PacRx,_user_PacRx,36,2,0
	.func	778
;******************************************************************************
;* FUNCTION NAME: _user_PacRx                                                 *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,fp,sp                                            *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 0 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_PacRx:
	.sym	_pBuf,-2,28,9,32
	.sym	_nRxBuffLen,-3,4,9,32
	.line	1
;----------------------------------------------------------------------
; 778 | int user_PacRx(UCHAR *pBuf,int nRxBuffLen)                             
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 780 | return xr16l784_GetRxBuffer3Ch(pBuf,nRxBuffLen);                       
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        call      _xr16l784_GetRxBuffer3Ch
                                        ; Call Occurs
        subi      2,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	781,000000000h,0


	.sect	 ".text"

	.global	_user_PacTx
	.sym	_user_PacTx,_user_PacTx,32,2,0
	.func	783
;******************************************************************************
;* FUNCTION NAME: _user_PacTx                                                 *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,fp,sp                                         *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 0 Auto + 0 SOE = 4 words          *
;******************************************************************************
_user_PacTx:
	.sym	_pTxBuf,-2,28,9,32
	.sym	_nTxLen,-3,4,9,32
	.line	1
;----------------------------------------------------------------------
; 783 | void user_PacTx(UCHAR *pTxBuf,int nTxLen)                              
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 785 | xr16l784_RtsDelayStartSend(XR16L784_3CHL,(UCHAR *)pTxBuf,nTxLen,10);   
;----------------------------------------------------------------------
        ldiu      10,r0
        ldiu      2,r1
        push      r0
        ldiu      *-fp(3),r0
        push      r0
        ldiu      *-fp(2),r0
        push      r0
        push      r1
        call      _xr16l784_RtsDelayStartSend
                                        ; Call Occurs
        subi      4,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	786,000000000h,0



	.sect	".cinit"
	.field  	1,32
	.field  	_d_CdtTxCnt+0,32
	.field  	0,32		; _d_CdtTxCnt @ 0

	.sect	".text"

	.global	_d_CdtTxCnt
	.bss	_d_CdtTxCnt,1
	.sym	_d_CdtTxCnt,_d_CdtTxCnt,4,2,32
	.sect	 ".text"

	.global	_user_LonWorkLoop
	.sym	_user_LonWorkLoop,_user_LonWorkLoop,32,2,0
	.func	792
;******************************************************************************
;* FUNCTION NAME: _user_LonWorkLoop                                           *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,ar0,fp,ir0,sp,st                           *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 707 Auto + 0 SOE = 709 words      *
;******************************************************************************
_user_LonWorkLoop:
	.sym	_i,1,4,1,32
	.sym	_nTxPos,2,4,1,32
	.sym	_btTxBuf,3,60,1,4096,,128
	.sym	_pNvsram,131,28,1,32
	.sym	_szBuf,132,50,1,16384,,512
	.sym	_szBuf2,644,50,1,2048,,64
	.line	1
;----------------------------------------------------------------------
; 792 | void user_LonWorkLoop()                                                
; 794 | int i;                                                                 
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      707,sp
	.line	4
;----------------------------------------------------------------------
; 795 | int nTxPos = 0;                                                        
; 796 | UCHAR btTxBuf[128];                                                    
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(2)
	.line	6
;----------------------------------------------------------------------
; 797 | UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;                                 
; 798 | char szBuf[512];                                                       
; 799 | char szBuf2[64];                                                       
;----------------------------------------------------------------------
        ldiu      @CL87,r0
        sti       r0,*+fp(131)
	.line	10
;----------------------------------------------------------------------
; 801 | if(m_nCDT_FaultDataStFlag == 1)                                        
;----------------------------------------------------------------------
        ldiu      @_m_nCDT_FaultDataStFlag+0,r0
        cmpi      1,r0
        bne       L405
;*      Branch Occurs to L405 
	.line	12
;----------------------------------------------------------------------
; 803 | m_nCDT_FaultDataStFlag = 0;                                            
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nCDT_FaultDataStFlag+0
	.line	14
;----------------------------------------------------------------------
; 805 | m_LIC_CNCS_Tx_Flag = TRUE;                                             
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_LIC_CNCS_Tx_Flag+0
	.line	15
;----------------------------------------------------------------------
; 806 | m_nTxDbg1msTimer = 0;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nTxDbg1msTimer+0
	.line	17
;----------------------------------------------------------------------
; 808 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        sti       r0,*+fp(2)
	.line	18
;----------------------------------------------------------------------
; 809 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        addi      3,ar0
        ldiu      r0,ir0
        addi      ir0,r1
        ldiu      2,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	19
;----------------------------------------------------------------------
; 810 | btTxBuf[nTxPos++] = LW_WAYSIDE_ON_REQ; // Command Code                 
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      fp,ar0
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r1
        ldiu      1,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	20
;----------------------------------------------------------------------
; 811 | btTxBuf[nTxPos++] = 0x00; // 0x00���� ����                             
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        sti       r1,*+fp(2)
        ldiu      fp,ar0
        addi      3,ar0
        ldiu      0,r0
        sti       r0,*+ar0(ir0)
	.line	21
;----------------------------------------------------------------------
; 812 | btTxBuf[nTxPos++] = 0x06; // ����                                      
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      fp,ar0
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        sti       r1,*+fp(2)
        addi      3,ar0
        ldiu      6,r0
        sti       r0,*+ar0(ir0)
	.line	22
;----------------------------------------------------------------------
; 813 | btTxBuf[nTxPos++] = 0x02;//m_nLnWkTxFlag; // �����̼�(Recently):0x01, �
;     | ���â(Historycal):0x02                                                 
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        sti       r1,*+fp(2)
        ldiu      fp,ar0
        addi      3,ar0
        ldiu      2,r0
        sti       r0,*+ar0(ir0)
	.line	23
;----------------------------------------------------------------------
; 814 | btTxBuf[nTxPos++] = BYTE_L(m_DIAdd_Val) == 1 ? 'A' : 'B'; // ; // 'A' :
;     |  Aī�κ��� ����, 'B' : Bī�κ��� ����                                  
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_m_DIAdd_Val+0,r0
        cmpi      1,r0
        bned      L404
        ldine     66,r0
        ldine     fp,ar0
        ldine     1,r1
;*      Branch Occurs to L404 
        ldiu      65,r0
        ldiu      fp,ar0
        ldiu      1,r1
L404:        
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r1
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	24
;----------------------------------------------------------------------
; 815 | btTxBuf[nTxPos++] = WORD_H(DWORD_H(m_nDateTime2SecondCnt)); // �ð�(HH)
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      @_m_nDateTime2SecondCnt+0,r0
        ldiu      *+fp(2),ir0
        addi      3,ar0
        lsh       -16,r0
        addi      ir0,r1
        and       65535,r0
        lsh       -8,r0
        sti       r1,*+fp(2)
        and       255,r0
        sti       r0,*+ar0(ir0)
	.line	25
;----------------------------------------------------------------------
; 816 | btTxBuf[nTxPos++] = WORD_L(DWORD_H(m_nDateTime2SecondCnt)); // �ð�(HL)
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      fp,ar0
        ldiu      *+fp(2),ir0
        addi      3,ar0
        ldiu      @_m_nDateTime2SecondCnt+0,r0
        addi      ir0,r1
        lsh       -16,r0
        sti       r1,*+fp(2)
        and       255,r0
        sti       r0,*+ar0(ir0)
	.line	26
;----------------------------------------------------------------------
; 817 | btTxBuf[nTxPos++] = WORD_H(DWORD_L(m_nDateTime2SecondCnt)); // �ð�(LH)
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        ldiu      @_m_nDateTime2SecondCnt+0,r0
        and       65535,r0
        lsh       -8,r0
        ldiu      fp,ar0
        sti       r1,*+fp(2)
        addi      3,ar0
        and       255,r0
        sti       r0,*+ar0(ir0)
	.line	27
;----------------------------------------------------------------------
; 818 | btTxBuf[nTxPos++] = WORD_L(DWORD_L(m_nDateTime2SecondCnt)); // �ð�(LL)
;----------------------------------------------------------------------
        ldiu      *+fp(2),ir0
        ldiu      1,r1
        addi      ir0,r1
        ldiu      fp,ar0
        ldiu      255,r0
        addi      3,ar0
        and       @_m_nDateTime2SecondCnt+0,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	28
;----------------------------------------------------------------------
; 819 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      4,r0
        ldiu      1,r1
        subri     *+fp(2),r1
        push      r1
        push      r0
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        addi      3,ar0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	29
;----------------------------------------------------------------------
; 820 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      *+fp(2),ir0
        ldiu      1,r1
        ldiu      fp,ar0
        addi      ir0,r1
        addi      3,ar0
        sti       r1,*+fp(2)
        ldiu      3,r0
        sti       r0,*+ar0(ir0)
	.line	30
;----------------------------------------------------------------------
; 821 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      *+fp(2),r1
        push      r1
        ldiu      fp,r0
        addi      3,r0
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	32
;----------------------------------------------------------------------
; 823 | d_CdtTxCnt++;                                                          
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_CdtTxCnt+0,r0
        sti       r0,@_d_CdtTxCnt+0
        bu        L416
;*      Branch Occurs to L416 
L405:        
	.line	34
;----------------------------------------------------------------------
; 825 | else if(m_TrainCof_Flag)                                               
;----------------------------------------------------------------------
        ldi       @_m_TrainCof_Flag+0,r0
        beq       L407
;*      Branch Occurs to L407 
	.line	36
;----------------------------------------------------------------------
; 827 | m_TrainCof_Flag = 0;                                                   
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_TrainCof_Flag+0
	.line	38
;----------------------------------------------------------------------
; 829 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        sti       r0,*+fp(2)
	.line	39
;----------------------------------------------------------------------
; 830 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      r0,ir0
        addi      3,ar0
        addi      ir0,r1
        ldiu      2,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	40
;----------------------------------------------------------------------
; 831 | btTxBuf[nTxPos++] = LW_TRAIN_CONFIG; // Command Code                   
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      15,r1
        ldiu      1,r0
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r0
        sti       r0,*+fp(2)
        sti       r1,*+ar0(ir0)
	.line	41
;----------------------------------------------------------------------
; 832 | btTxBuf[nTxPos++] = 0x10; // 0x00���� ����MPU-> LON 0x10               
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r0
        addi      3,ar0
        ldiu      *+fp(2),ir0
        ldiu      16,r1
        addi      ir0,r0
        sti       r0,*+fp(2)
        sti       r1,*+ar0(ir0)
	.line	42
;----------------------------------------------------------------------
; 833 | btTxBuf[nTxPos++] = 0x01; // ����                                      
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        ldiu      1,r0
        ldiu      fp,ar0
        addi      ir0,r0
        addi      3,ar0
        sti       r0,*+fp(2)
        sti       r1,*+ar0(ir0)
	.line	43
;----------------------------------------------------------------------
; 834 | btTxBuf[nTxPos++] = BYTE_L(m_TrainCof_Val); //                         
;----------------------------------------------------------------------
        ldiu      15,r0
        ldiu      fp,ar0
        addi      3,ar0
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        and       @_m_TrainCof_Val+0,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	44
;----------------------------------------------------------------------
; 835 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      4,r0
        ldiu      1,r1
        subri     *+fp(2),r1
        push      r1
        push      r0
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      *+fp(2),ir0
        ldiu      1,r1
        ldiu      fp,ar0
        addi      ir0,r1
        addi      3,ar0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	45
;----------------------------------------------------------------------
; 836 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        ldiu      fp,ar0
        addi      ir0,r1
        addi      3,ar0
        sti       r1,*+fp(2)
        ldiu      3,r0
        sti       r0,*+ar0(ir0)
	.line	46
;----------------------------------------------------------------------
; 837 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      3,r0
        ldiu      *+fp(2),r1
        push      r1
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
        bu        L416
;*      Branch Occurs to L416 
L407:        
	.line	49
;----------------------------------------------------------------------
; 840 | else if(m_CiPosi_Flag)                                                 
;----------------------------------------------------------------------
        ldi       @_m_CiPosi_Flag+0,r0
        beq       L409
;*      Branch Occurs to L409 
	.line	51
;----------------------------------------------------------------------
; 842 | m_CiPosi_Flag = 0;                                                     
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_CiPosi_Flag+0
	.line	53
;----------------------------------------------------------------------
; 844 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        sti       r0,*+fp(2)
	.line	54
;----------------------------------------------------------------------
; 845 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      r0,ir0
        addi      3,ar0
        addi      ir0,r1
        ldiu      2,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	55
;----------------------------------------------------------------------
; 846 | btTxBuf[nTxPos++] = LW_CI_POSITION; // Command Code                    
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      16,r1
        ldiu      1,r0
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r0
        sti       r0,*+fp(2)
        sti       r1,*+ar0(ir0)
	.line	56
;----------------------------------------------------------------------
; 847 | btTxBuf[nTxPos++] = 0x10; // 0x00���� ����MPU-> LON 0x10               
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r0
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r0
        sti       r0,*+fp(2)
        sti       r1,*+ar0(ir0)
	.line	57
;----------------------------------------------------------------------
; 848 | btTxBuf[nTxPos++] = 0x01; // ����                                      
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      3,ar0
        ldiu      *+fp(2),ir0
        ldiu      1,r0
        ldiu      1,r1
        addi      ir0,r0
        sti       r0,*+fp(2)
        sti       r1,*+ar0(ir0)
	.line	58
;----------------------------------------------------------------------
; 849 | btTxBuf[nTxPos++] = BYTE_L(m_CiPosi_Val); //                           
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      3,ar0
        ldiu      *+fp(2),ir0
        ldiu      15,r0
        addi      ir0,r1
        and       @_m_CiPosi_Val+0,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	59
;----------------------------------------------------------------------
; 850 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      fp,r0
        addi      4,r0
        subri     *+fp(2),r1
        push      r1
        push      r0
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        ldiu      fp,ar0
        addi      3,ar0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	60
;----------------------------------------------------------------------
; 851 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      *+fp(2),ir0
        ldiu      fp,ar0
        ldiu      1,r1
        addi      3,ar0
        addi      ir0,r1
        ldiu      3,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	61
;----------------------------------------------------------------------
; 852 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      *+fp(2),r1
        push      r1
        ldiu      fp,r0
        addi      3,r0
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
        bu        L416
;*      Branch Occurs to L416 
L409:        
	.line	64
;----------------------------------------------------------------------
; 855 | else if(m_CiFault_Flag)                                                
;----------------------------------------------------------------------
        ldi       @_m_CiFault_Flag+0,r0
        beq       L411
;*      Branch Occurs to L411 
	.line	66
;----------------------------------------------------------------------
; 857 | m_CiFault_Flag = 0;                                                    
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_CiFault_Flag+0
	.line	68
;----------------------------------------------------------------------
; 859 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        sti       r0,*+fp(2)
	.line	69
;----------------------------------------------------------------------
; 860 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      r0,ir0
        addi      3,ar0
        addi      ir0,r1
        ldiu      2,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	70
;----------------------------------------------------------------------
; 861 | btTxBuf[nTxPos++] = LW_TRAIN_CONFIG; // Command Code                   
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      15,r1
        ldiu      1,r0
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r0
        sti       r0,*+fp(2)
        sti       r1,*+ar0(ir0)
	.line	71
;----------------------------------------------------------------------
; 862 | btTxBuf[nTxPos++] = 0x10; // 0x00���� ����MPU-> LON 0x10               
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r0
        addi      3,ar0
        ldiu      *+fp(2),ir0
        ldiu      16,r1
        addi      ir0,r0
        sti       r0,*+fp(2)
        sti       r1,*+ar0(ir0)
	.line	72
;----------------------------------------------------------------------
; 863 | btTxBuf[nTxPos++] = 0x01; // ����                                      
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        ldiu      1,r0
        ldiu      fp,ar0
        addi      ir0,r0
        addi      3,ar0
        sti       r0,*+fp(2)
        sti       r1,*+ar0(ir0)
	.line	73
;----------------------------------------------------------------------
; 864 | btTxBuf[nTxPos++] = BYTE_L(m_CiFault_Val); //                          
;----------------------------------------------------------------------
        ldiu      15,r0
        ldiu      fp,ar0
        addi      3,ar0
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        and       @_m_CiFault_Val+0,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	74
;----------------------------------------------------------------------
; 865 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      fp,r1
        addi      4,r1
        subri     *+fp(2),r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      fp,ar0
        ldiu      *+fp(2),ir0
        ldiu      1,r1
        addi      ir0,r1
        addi      3,ar0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	75
;----------------------------------------------------------------------
; 866 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      *+fp(2),ir0
        ldiu      1,r1
        ldiu      fp,ar0
        addi      ir0,r1
        addi      3,ar0
        sti       r1,*+fp(2)
        ldiu      3,r0
        sti       r0,*+ar0(ir0)
	.line	76
;----------------------------------------------------------------------
; 867 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      fp,r0
        ldiu      *+fp(2),r1
        push      r1
        addi      3,r0
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
        bu        L416
;*      Branch Occurs to L416 
L411:        
	.line	79
;----------------------------------------------------------------------
; 870 | else if(m_DIAdd_Flag)                                                  
;----------------------------------------------------------------------
        ldi       @_m_DIAdd_Flag+0,r0
        beq       L416
;*      Branch Occurs to L416 
	.line	81
;----------------------------------------------------------------------
; 872 | m_DIAdd_Flag = 0;                                                      
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_DIAdd_Flag+0
	.line	83
;----------------------------------------------------------------------
; 874 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        sti       r0,*+fp(2)
	.line	84
;----------------------------------------------------------------------
; 875 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      r0,ir0
        addi      3,ar0
        addi      ir0,r1
        ldiu      2,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	85
;----------------------------------------------------------------------
; 876 | btTxBuf[nTxPos++] = LW_TRAIN_CONFIG; // Command Code                   
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r1
        ldiu      15,r0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	86
;----------------------------------------------------------------------
; 877 | btTxBuf[nTxPos++] = 0x10; // 0x00���� ����MPU-> LON 0x10               
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      1,r1
        addi      3,ar0
        ldiu      *+fp(2),ir0
        ldiu      16,r0
        addi      ir0,r1
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	87
;----------------------------------------------------------------------
; 878 | btTxBuf[nTxPos++] = 0x01; // ����                                      
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      ir0,r1
        ldiu      fp,ar0
        sti       r1,*+fp(2)
        addi      3,ar0
        ldiu      1,r0
        sti       r0,*+ar0(ir0)
	.line	88
;----------------------------------------------------------------------
; 879 | btTxBuf[nTxPos++] = BYTE_L(m_DIAdd_Val) == 1 ? 'A' : 'B'; //           
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_m_DIAdd_Val+0,r0
        cmpi      1,r0
        bned      L415
        ldine     66,r0
        ldine     fp,ar0
        ldine     1,r1
;*      Branch Occurs to L415 
        ldiu      65,r0
        ldiu      fp,ar0
        ldiu      1,r1
L415:        
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r1
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	89
;----------------------------------------------------------------------
; 880 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      fp,r0
        ldiu      1,r1
        addi      4,r0
        subri     *+fp(2),r1
        push      r1
        push      r0
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      *+fp(2),ir0
        addi      3,ar0
        addi      ir0,r1
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	90
;----------------------------------------------------------------------
; 881 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      *+fp(2),ir0
        ldiu      1,r1
        addi      ir0,r1
        ldiu      3,r0
        ldiu      fp,ar0
        addi      3,ar0
        sti       r1,*+fp(2)
        sti       r0,*+ar0(ir0)
	.line	91
;----------------------------------------------------------------------
; 882 | user_LonWorkTx(btTxBuf,nTxPos);                                        
; 886 | // NVSRAM�� ����� ������ RS232�� �����Ͽ� ������Ѵ�.                 
;----------------------------------------------------------------------
        ldiu      fp,r0
        ldiu      *+fp(2),r1
        addi      3,r0
        push      r1
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
L416:        
	.line	96
;----------------------------------------------------------------------
; 887 | if(m_bLnWkDbgTxFlag)                                                   
;----------------------------------------------------------------------
        ldi       @_m_bLnWkDbgTxFlag+0,r0
        beq       L418
;*      Branch Occurs to L418 
	.line	98
;----------------------------------------------------------------------
; 889 | m_bLnWkDbgTxFlag = FALSE;                                              
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_bLnWkDbgTxFlag+0
	.line	99
;----------------------------------------------------------------------
; 890 | m_nDbgTxPos = 0;                                                       
;----------------------------------------------------------------------
        sti       r0,@_m_nDbgTxPos+0
	.line	100
;----------------------------------------------------------------------
; 891 | m_nTxDbg1msTimer = 0;                                                  
;----------------------------------------------------------------------
        sti       r0,@_m_nTxDbg1msTimer+0
L418:        
	.line	103
;----------------------------------------------------------------------
; 894 | if(m_nDbgTxPos < m_nNvsramPos) //m_nDbgTxPos = 0xFFFFFFFF �� �׻� ū ��
;     | �� ������ �ִٰ� �����϶�� ���ɿ� ���� 0���� Ŭ���� �ȴ�.             
;----------------------------------------------------------------------
        ldiu      @_m_nDbgTxPos+0,r0
        cmpi      @_m_nNvsramPos+0,r0
        bhs       L428
;*      Branch Occurs to L428 
	.line	105
;----------------------------------------------------------------------
; 896 | if(m_nTxDbg1msTimer > 200)                                             
;----------------------------------------------------------------------
        ldiu      @_m_nTxDbg1msTimer+0,r0
        cmpi      200,r0
        bls       L433
;*      Branch Occurs to L433 
	.line	107
;----------------------------------------------------------------------
; 898 | m_nTxDbg1msTimer = 0;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nTxDbg1msTimer+0
	.line	108
;----------------------------------------------------------------------
; 899 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      132,ar0
        sti       r0,*ar0
	.line	109
;----------------------------------------------------------------------
; 900 | for(i=0;i<(MIN(128,(UINT)(m_nNvsramPos-m_nDbgTxPos)));i++) {sprintf(szB
;     | uf2,"%02X ",pNvsram[m_nDbgTxPos+i]); strcat(szBuf,szBuf2);}            
;----------------------------------------------------------------------
        sti       r0,*+fp(1)
        bu        L423
;*      Branch Occurs to L423 
	.line	109
L422:        
        addi      *+fp(131),ir0         ; Unsigned
        ldiu      @CL88,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      644,r1
        ldiu      fp,r0
        addi      fp,r1
        addi      132,r0
        push      r1
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
L423:        
        ldiu      @_m_nDbgTxPos+0,r0
        ldiu      128,r1
        subri     @_m_nNvsramPos+0,r0   ; Unsigned
        cmpi3     r0,r1
        bhs       L425
;*      Branch Occurs to L425 
        bud       L426
	nop
	nop
        ldiu      128,r0
;*      Branch Occurs to L426 
L425:        
        ldiu      @_m_nDbgTxPos+0,r0
        subri     @_m_nNvsramPos+0,r0   ; Unsigned
L426:        
        ldiu      *+fp(1),r1
        cmpi3     r0,r1
        blod      L422
        ldilo     @_m_nDbgTxPos+0,ir0
        ldilo     *+fp(1),ar0
        ldilo     644,r0
;*      Branch Occurs to L422 
	.line	110
;----------------------------------------------------------------------
; 901 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL25,r1
        ldiu      fp,r0
        push      r1
        addi      132,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	111
;----------------------------------------------------------------------
; 902 | user_DebugPrint(szBuf);                                                
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      132,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	112
;----------------------------------------------------------------------
; 903 | m_nDbgTxPos += 128;                                                    
;----------------------------------------------------------------------
        ldiu      128,r0
        addi      @_m_nDbgTxPos+0,r0    ; Unsigned
        sti       r0,@_m_nDbgTxPos+0
        bu        L433
;*      Branch Occurs to L433 
L428:        
	.line	114
;----------------------------------------------------------------------
; 905 | }else if(m_nDbgTxPos == 0xFFFFFFFF)                                    
;----------------------------------------------------------------------
        ldiu      @_m_nDbgTxPos+0,r0
        cmpi      @CL89,r0
        bne       L433
;*      Branch Occurs to L433 
	.line	116
;----------------------------------------------------------------------
; 907 | if(nTxPos)                                                             
;----------------------------------------------------------------------
        ldi       *+fp(2),r0
        beq       L433
;*      Branch Occurs to L433 
	.line	118
;----------------------------------------------------------------------
; 909 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      132,ar0
        ldiu      0,r0
        sti       r0,*ar0
	.line	119
;----------------------------------------------------------------------
; 910 | sprintf(szBuf2,"[TX:%02d] ",nTxPos); strcat(szBuf,szBuf2);             
;----------------------------------------------------------------------
        ldiu      @CL90,r2
        ldiu      *+fp(2),r1
        ldiu      644,r0
        push      r1
        addi      fp,r0
        push      r2
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      644,r1
        ldiu      fp,r0
        addi      fp,r1
        addi      132,r0
        push      r1
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	120
;----------------------------------------------------------------------
; 911 | for(i=0;i<nTxPos;i++) {sprintf(szBuf2,"%02X ",btTxBuf[i]); strcat(szBuf
;     | ,szBuf2);}                                                             
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        bge       L432
;*      Branch Occurs to L432 
L431:        
        ldiu      fp,ar0
        ldiu      *+fp(1),ir0
        ldiu      644,r0
        addi      3,ar0
        ldiu      @CL88,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      644,r1
        ldiu      fp,r0
        addi      fp,r1
        addi      132,r0
        push      r1
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        blt       L431
;*      Branch Occurs to L431 
L432:        
	.line	121
;----------------------------------------------------------------------
; 912 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL25,r1
        ldiu      fp,r0
        push      r1
        addi      132,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	122
;----------------------------------------------------------------------
; 913 | user_DebugPrint(szBuf);                                                
;----------------------------------------------------------------------
        ldiu      fp,r0
        addi      132,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
L433:        
	.line	125
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      709,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	916,000000000h,707



	.sect	".cinit"
	.field  	1,32
	.field  	_d_LonKindNum+0,32
	.field  	0,32		; _d_LonKindNum @ 0

	.sect	".text"

	.global	_d_LonKindNum
	.bss	_d_LonKindNum,1
	.sym	_d_LonKindNum,_d_LonKindNum,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_LonStData+0,32
	.field  	0,32		; _d_LonStData @ 0

	.sect	".text"

	.global	_d_LonStData
	.bss	_d_LonStData,1
	.sym	_d_LonStData,_d_LonStData,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_VerTxCnt+0,32
	.field  	0,32		; _d_VerTxCnt @ 0

	.sect	".text"

	.global	_d_VerTxCnt
	.bss	_d_VerTxCnt,1
	.sym	_d_VerTxCnt,_d_VerTxCnt,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_EndFlagCnt+0,32
	.field  	0,32		; _d_EndFlagCnt @ 0

	.sect	".text"

	.global	_d_EndFlagCnt
	.bss	_d_EndFlagCnt,1
	.sym	_d_EndFlagCnt,_d_EndFlagCnt,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_TimeTxCnt+0,32
	.field  	0,32		; _d_TimeTxCnt @ 0

	.sect	".text"

	.global	_d_TimeTxCnt
	.bss	_d_TimeTxCnt,1
	.sym	_d_TimeTxCnt,_d_TimeTxCnt,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_StTxCnt+0,32
	.field  	0,32		; _d_StTxCnt @ 0

	.sect	".text"

	.global	_d_StTxCnt
	.bss	_d_StTxCnt,1
	.sym	_d_StTxCnt,_d_StTxCnt,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_nDoorCntA+0,32
	.field  	0,32		; _d_nDoorCntA @ 0

	.sect	".text"

	.global	_d_nDoorCntA
	.bss	_d_nDoorCntA,1
	.sym	_d_nDoorCntA,_d_nDoorCntA,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_nDoorCntB+0,32
	.field  	0,32		; _d_nDoorCntB @ 0

	.sect	".text"

	.global	_d_nDoorCntB
	.bss	_d_nDoorCntB,1
	.sym	_d_nDoorCntB,_d_nDoorCntB,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_LonRxCnt+0,32
	.field  	0,32		; _d_LonRxCnt @ 0

	.sect	".text"

	.global	_d_LonRxCnt
	.bss	_d_LonRxCnt,1
	.sym	_d_LonRxCnt,_d_LonRxCnt,12,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_LonRxCnt2+0,32
	.field  	0,32		; _d_LonRxCnt2 @ 0

	.sect	".text"

	.global	_d_LonRxCnt2
	.bss	_d_LonRxCnt2,1
	.sym	_d_LonRxCnt2,_d_LonRxCnt2,12,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_nOldKind$4+0,32
	.field  	0,32		; _nOldKind$4 @ 0

	.sect	".text"

	.sect	".cinit"
	.field  	1,32
	.field  	_nRecRxPos$5+0,32
	.field  	0,32		; _nRecRxPos$5 @ 0

	.sect	".text"
	.sect	 ".text"

	.global	_user_LonWorkRead
	.sym	_user_LonWorkRead,_user_LonWorkRead,32,2,0
	.func	931
;******************************************************************************
;* FUNCTION NAME: _user_LonWorkRead                                           *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,ar0,ar1,fp,ar4,ir0,ir1,sp,st,rs,re,rc      *
;*   Regs Saved         : ar4                                                 *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 970 Auto + 1 SOE = 973 words      *
;******************************************************************************
_user_LonWorkRead:
	.bss	_nOldKind$4,1
	.sym	_nOldKind,_nOldKind$4,12,3,32
	.bss	_nRecRxPos$5,1
	.sym	_nRecRxPos,_nRecRxPos$5,4,3,32
	.bss	_btFtpOneRecRxBuf$6,1024
	.sym	_btFtpOneRecRxBuf,_btFtpOneRecRxBuf$6,60,3,32768,,1024
	.sym	_i,1,4,1,32
	.sym	_nTmp,2,4,1,32
	.sym	_pLnWkDp,3,24,1,32,.fake13
	.sym	_pNvsram,4,28,1,32
	.sym	_pLicVerDp,5,24,1,32,.fake46
	.sym	_nKind,6,12,1,32
	.sym	_nRxLen,7,12,1,32
	.sym	_btRxBuf,8,60,1,8192,,256
	.sym	_nTxPos,264,4,1,32
	.sym	_btTxBuf,265,60,1,4096,,128
	.sym	_szBuf,393,50,1,16384,,512
	.sym	_szBuf2,905,50,1,2048,,64
	.sym	_nCarNo,969,4,1,32
	.sym	_bCarNoUpdate,970,4,1,32
	.line	1
;----------------------------------------------------------------------
; 931 | void user_LonWorkRead()                                                
; 933 | int i;                                                                 
; 934 | int nTmp;                                                              
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      970,sp
        push      ar4
	.line	5
;----------------------------------------------------------------------
; 935 | PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;                                
;----------------------------------------------------------------------
        ldiu      @CL11,r0
        sti       r0,*+fp(3)
	.line	6
;----------------------------------------------------------------------
; 936 | UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;                                 
;----------------------------------------------------------------------
        ldiu      @CL87,r0
        sti       r0,*+fp(4)
	.line	8
;----------------------------------------------------------------------
; 938 | PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó�
;     | ��� ���� ���Ƿ� �������.                                              
; 940 | UCHAR nKind;                                                           
; 941 | static UCHAR nOldKind = 0;                                             
; 942 | UCHAR nRxLen;                                                          
; 943 | static int nRecRxPos = 0;                                              
; 944 | UCHAR btRxBuf[256];                                                    
; 945 | static UCHAR btFtpOneRecRxBuf[1024];                                   
;----------------------------------------------------------------------
        ldiu      @CL2,r0
        sti       r0,*+fp(5)
	.line	16
;----------------------------------------------------------------------
; 946 | int nTxPos = 0;                                                        
; 947 | UCHAR btTxBuf[128];                                                    
; 948 | char szBuf[512];                                                       
; 949 | char szBuf2[64];                                                       
; 951 | //'Y.J �߰� 2011-05-19                                                 
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	22
;----------------------------------------------------------------------
; 952 | int nCarNo = m_wCarNo;                                                 
;----------------------------------------------------------------------
        ldiu      969,ir0
        ldiu      @_m_wCarNo+0,r0
        sti       r0,*+fp(ir0)
	.line	23
;----------------------------------------------------------------------
; 953 | BOOL bCarNoUpdate = FALSE;                                             
;----------------------------------------------------------------------
        ldiu      970,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	25
;----------------------------------------------------------------------
; 955 | d_LonKindNum = nKind = WORD_L(pLnWkDp->btKind);                        
;----------------------------------------------------------------------
        ldiu      *+fp(3),ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        sti       r0,*+fp(6)
        sti       r0,@_d_LonKindNum+0
	.line	27
;----------------------------------------------------------------------
; 957 | d_LonRxCnt++;                                                          
; 959 | switch(nKind)                                                          
; 961 | // FTP1~6 ��������                                                     
; 962 | case 1: case 2: case 3: case 4: case 5: case 6:                        
;----------------------------------------------------------------------
        bud       L541
        ldiu      1,r0
        addi      @_d_LonRxCnt+0,r0     ; Unsigned
        sti       r0,@_d_LonRxCnt+0
;*      Branch Occurs to L541 
L436:        
	.line	33
;----------------------------------------------------------------------
; 963 | nRxLen = 0;                                                            
; 965 | // ����                                                                
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(7)
	.line	36
;----------------------------------------------------------------------
; 966 | if(nKind == 1)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(6),r0
        cmpi      1,r0
        bne       L448
;*      Branch Occurs to L448 
	.line	38
;----------------------------------------------------------------------
; 968 | nRecRxPos = 0;                                                         
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_nRecRxPos$5+0
	.line	39
;----------------------------------------------------------------------
; 969 | nRxLen = user_LonWorkRx(nKind,btRxBuf);                                
;----------------------------------------------------------------------
        ldiu      *+fp(6),r1
        ldiu      fp,r0
        addi      8,r0
        push      r0
        push      r1
        call      _user_LonWorkRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(7)
	.line	40
;----------------------------------------------------------------------
; 970 | if(nRxLen>6 && nRecRxPos<768)                                          
;----------------------------------------------------------------------
        cmpi      6,r0
        bls       L473
;*      Branch Occurs to L473 
        ldiu      @_nRecRxPos$5+0,r0
        cmpi      768,r0
        bge       L473
;*      Branch Occurs to L473 
	.line	42
;----------------------------------------------------------------------
; 972 | memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);             
;----------------------------------------------------------------------
        ldiu      @CL91,r0
        ldiu      7,r1
        ldiu      fp,r2
        addi      @_nRecRxPos$5+0,r0    ; Unsigned
        subri     *+fp(7),r1            ; Unsigned
        addi      13,r2
        push      r1
        push      r2
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	43
;----------------------------------------------------------------------
; 973 | nTmp = (nRxLen-7);                                                     
;----------------------------------------------------------------------
        ldiu      7,r0
        subri     *+fp(7),r0            ; Unsigned
        sti       r0,*+fp(2)
	.line	44
;----------------------------------------------------------------------
; 974 | nRecRxPos += nTmp;                                                     
;----------------------------------------------------------------------
        addi      @_nRecRxPos$5+0,r0
        sti       r0,@_nRecRxPos$5+0
	.line	46
;----------------------------------------------------------------------
; 976 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        ldiu      393,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	47
;----------------------------------------------------------------------
; 977 | sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szB
;     | uf,szBuf2);                                                            
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      @CL92,r1
        ldiu      905,r2
        ldiu      *ar0,r0
        push      r0
        ldiu      *+fp(7),r0
        push      r0
        ldiu      *+fp(6),r0
        push      r0
        push      r1
        addi      fp,r2
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      5,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	48
;----------------------------------------------------------------------
; 978 | if(nTmp < 128)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        cmpi      128,r0
        bge       L443
;*      Branch Occurs to L443 
	.line	50
;----------------------------------------------------------------------
; 980 | for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,
;     | szBuf2);}                                                              
; 982 | else                                                                   
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        bge       L447
;*      Branch Occurs to L447 
L441:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r1
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL93,r0
        ldiu      *+ar0(ir0),r2
        addi      fp,r1
        push      r2
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        blt       L441
;*      Branch Occurs to L441 
        bu        L447
;*      Branch Occurs to L447 
L443:        
	.line	54
;----------------------------------------------------------------------
; 984 | for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szB
;     | uf2);}                                                                 
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        bge       L445
;*      Branch Occurs to L445 
L444:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r2
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL93,r0
        ldiu      *+ar0(ir0),r1
        addi      fp,r2
        push      r1
        push      r0
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        blt       L444
;*      Branch Occurs to L444 
L445:        
	.line	55
;----------------------------------------------------------------------
; 985 | strcat(szBuf,"..");                                                    
;----------------------------------------------------------------------
        ldiu      @CL94,r1
        ldiu      393,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	56
;----------------------------------------------------------------------
; 986 | for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf
;     | ,szBuf2);}                                                             
;----------------------------------------------------------------------
        ldiu      120,r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        bge       L447
;*      Branch Occurs to L447 
L446:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r0
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL93,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        blt       L446
;*      Branch Occurs to L446 
L447:        
	.line	58
;----------------------------------------------------------------------
; 988 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL25,r0
        ldiu      393,r1
        push      r0
        addi      fp,r1
        push      r1
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	59
;----------------------------------------------------------------------
; 989 | user_DebugPrint(szBuf);                                                
; 992 | else                                                                   
; 993 | // �߰� ���ڵ� ����                                                    
;----------------------------------------------------------------------
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L473
;*      Branch Occurs to L473 
L448:        
	.line	64
;----------------------------------------------------------------------
; 994 | if(nKind >= 2 && nKind <= 5)                                           
;----------------------------------------------------------------------
        ldiu      *+fp(6),r0
        cmpi      2,r0
        blo       L461
;*      Branch Occurs to L461 
        cmpi      5,r0
        bhi       L461
;*      Branch Occurs to L461 
	.line	66
;----------------------------------------------------------------------
; 996 | nRxLen = user_LonWorkRx(nKind,btRxBuf);                                
;----------------------------------------------------------------------
        ldiu      fp,r0
        ldiu      *+fp(6),r1
        addi      8,r0
        push      r0
        push      r1
        call      _user_LonWorkRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(7)
	.line	67
;----------------------------------------------------------------------
; 997 | if(nRxLen>6 && nRecRxPos<768)                                          
;----------------------------------------------------------------------
        cmpi      6,r0
        bls       L473
;*      Branch Occurs to L473 
        ldiu      @_nRecRxPos$5+0,r0
        cmpi      768,r0
        bge       L473
;*      Branch Occurs to L473 
	.line	69
;----------------------------------------------------------------------
; 999 | memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);             
;----------------------------------------------------------------------
        ldiu      @CL91,r0
        ldiu      7,r1
        ldiu      fp,r2
        addi      @_nRecRxPos$5+0,r0    ; Unsigned
        subri     *+fp(7),r1            ; Unsigned
        addi      13,r2
        push      r1
        push      r2
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	70
;----------------------------------------------------------------------
; 1000 | nTmp = (nRxLen-7);                                                     
;----------------------------------------------------------------------
        ldiu      7,r0
        subri     *+fp(7),r0            ; Unsigned
        sti       r0,*+fp(2)
	.line	71
;----------------------------------------------------------------------
; 1001 | nRecRxPos += nTmp;                                                     
;----------------------------------------------------------------------
        addi      @_nRecRxPos$5+0,r0
        sti       r0,@_nRecRxPos$5+0
	.line	73
;----------------------------------------------------------------------
; 1003 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        ldiu      393,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	74
;----------------------------------------------------------------------
; 1004 | sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szB
;     | uf,szBuf2);                                                            
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      *ar0,r1
        push      r1
        ldiu      *+fp(7),r1
        push      r1
        ldiu      905,r2
        ldiu      *+fp(6),r1
        push      r1
        ldiu      @CL92,r0
        push      r0
        addi      fp,r2
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      5,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	75
;----------------------------------------------------------------------
; 1005 | if(nTmp < 128)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        cmpi      128,r0
        bge       L456
;*      Branch Occurs to L456 
	.line	77
;----------------------------------------------------------------------
; 1007 | for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,
;     | szBuf2);}                                                              
; 1009 | else                                                                   
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        bge       L460
;*      Branch Occurs to L460 
L454:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r0
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL93,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        blt       L454
;*      Branch Occurs to L454 
        bu        L460
;*      Branch Occurs to L460 
L456:        
	.line	81
;----------------------------------------------------------------------
; 1011 | for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szB
;     | uf2);}                                                                 
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        bge       L458
;*      Branch Occurs to L458 
L457:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r1
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL93,r0
        ldiu      *+ar0(ir0),r2
        addi      fp,r1
        push      r2
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        blt       L457
;*      Branch Occurs to L457 
L458:        
	.line	82
;----------------------------------------------------------------------
; 1012 | strcat(szBuf,"..");                                                    
;----------------------------------------------------------------------
        ldiu      @CL94,r1
        ldiu      393,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	83
;----------------------------------------------------------------------
; 1013 | for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf
;     | ,szBuf2);}                                                             
;----------------------------------------------------------------------
        ldiu      120,r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        bge       L460
;*      Branch Occurs to L460 
L459:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r0
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL93,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        blt       L459
;*      Branch Occurs to L459 
L460:        
	.line	85
;----------------------------------------------------------------------
; 1015 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL25,r0
        ldiu      393,r1
        push      r0
        addi      fp,r1
        push      r1
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	86
;----------------------------------------------------------------------
; 1016 | user_DebugPrint(szBuf);                                                
; 1019 | else                                                                   
; 1020 | // ��                                                                  
;----------------------------------------------------------------------
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
        bu        L473
;*      Branch Occurs to L473 
L461:        
	.line	91
;----------------------------------------------------------------------
; 1021 | if(nKind == 6)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(6),r0
        cmpi      6,r0
        bne       L473
;*      Branch Occurs to L473 
	.line	93
;----------------------------------------------------------------------
; 1023 | nRxLen = user_LonWorkRx(nKind,btRxBuf);                                
;----------------------------------------------------------------------
        ldiu      fp,r0
        ldiu      *+fp(6),r1
        addi      8,r0
        push      r0
        push      r1
        call      _user_LonWorkRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(7)
	.line	94
;----------------------------------------------------------------------
; 1024 | if(nRxLen>6 && nRecRxPos<768)                                          
;----------------------------------------------------------------------
        cmpi      6,r0
        bls       L473
;*      Branch Occurs to L473 
        ldiu      @_nRecRxPos$5+0,r0
        cmpi      768,r0
        bge       L473
;*      Branch Occurs to L473 
	.line	96
;----------------------------------------------------------------------
; 1026 | memcpy(&btFtpOneRecRxBuf[nRecRxPos],&btRxBuf[5],nRxLen-7);             
;----------------------------------------------------------------------
        ldiu      @CL91,r0
        ldiu      7,r1
        ldiu      fp,r2
        addi      @_nRecRxPos$5+0,r0    ; Unsigned
        subri     *+fp(7),r1            ; Unsigned
        addi      13,r2
        push      r1
        push      r2
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	97
;----------------------------------------------------------------------
; 1027 | nTmp = (nRxLen-7);                                                     
;----------------------------------------------------------------------
        ldiu      7,r0
        subri     *+fp(7),r0            ; Unsigned
        sti       r0,*+fp(2)
	.line	98
;----------------------------------------------------------------------
; 1028 | nRecRxPos += nTmp;                                                     
;----------------------------------------------------------------------
        addi      @_nRecRxPos$5+0,r0
        sti       r0,@_nRecRxPos$5+0
	.line	100
;----------------------------------------------------------------------
; 1030 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        ldiu      393,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	101
;----------------------------------------------------------------------
; 1031 | sprintf(szBuf2,"[%d,%3d,%c]",nKind,nRxLen,(char)btRxBuf[4]); strcat(szB
;     | uf,szBuf2);                                                            
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      *ar0,r1
        push      r1
        ldiu      *+fp(7),r1
        push      r1
        ldiu      905,r2
        ldiu      *+fp(6),r1
        push      r1
        ldiu      @CL92,r0
        push      r0
        addi      fp,r2
        push      r2
        call      _sprintf
                                        ; Call Occurs
        subi      5,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	102
;----------------------------------------------------------------------
; 1032 | if(nTmp < 128)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        cmpi      128,r0
        bge       L468
;*      Branch Occurs to L468 
	.line	104
;----------------------------------------------------------------------
; 1034 | for(i=0;i<nTmp;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,
;     | szBuf2);}                                                              
; 1036 | else                                                                   
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        bge       L472
;*      Branch Occurs to L472 
L466:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r1
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL93,r0
        ldiu      *+ar0(ir0),r2
        addi      fp,r1
        push      r2
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      *+fp(2),r0
        blt       L466
;*      Branch Occurs to L466 
        bu        L472
;*      Branch Occurs to L472 
L468:        
	.line	108
;----------------------------------------------------------------------
; 1038 | for(i=0;i<8;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf,szB
;     | uf2);}                                                                 
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        bge       L470
;*      Branch Occurs to L470 
L469:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r1
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL93,r0
        ldiu      *+ar0(ir0),r2
        addi      fp,r1
        push      r2
        push      r0
        push      r1
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      8,r0
        blt       L469
;*      Branch Occurs to L469 
L470:        
	.line	109
;----------------------------------------------------------------------
; 1039 | strcat(szBuf,"..");                                                    
;----------------------------------------------------------------------
        ldiu      @CL94,r1
        ldiu      393,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	110
;----------------------------------------------------------------------
; 1040 | for(i=120;i<128;i++) {sprintf(szBuf2,"%02X",btRxBuf[i+5]); strcat(szBuf
;     | ,szBuf2);}                                                             
;----------------------------------------------------------------------
        ldiu      120,r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        bge       L472
;*      Branch Occurs to L472 
L471:        
        ldiu      5,ir0
        ldiu      fp,ar0
        ldiu      905,r0
        addi      *+fp(1),ir0
        addi      8,ar0
        ldiu      @CL93,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      128,r0
        blt       L471
;*      Branch Occurs to L471 
L472:        
	.line	112
;----------------------------------------------------------------------
; 1042 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL25,r0
        ldiu      393,r1
        push      r0
        addi      fp,r1
        push      r1
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	113
;----------------------------------------------------------------------
; 1043 | user_DebugPrint(szBuf);                                                
; 1047 | // ���̰� 0~127���� �´ٸ� �����͸� �����Ѵ�.                          
;----------------------------------------------------------------------
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
L473:        
	.line	118
;----------------------------------------------------------------------
; 1048 | if((nRxLen>6 && nRxLen<134))                                           
;----------------------------------------------------------------------
        ldiu      *+fp(7),r0
        cmpi      6,r0
        bls       L476
;*      Branch Occurs to L476 
        cmpi      134,r0
        bhs       L476
;*      Branch Occurs to L476 
	.line	120
;----------------------------------------------------------------------
; 1050 | user_DebugPrint("***FTP File receive... ^^;;***\r\n");                 
;----------------------------------------------------------------------
        ldiu      @CL95,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	121
;----------------------------------------------------------------------
; 1051 | memcpy(&pNvsram[m_nNvsramPos],btFtpOneRecRxBuf,nRecRxPos);             
;----------------------------------------------------------------------
        ldiu      @_m_nNvsramPos+0,r0
        ldiu      @_nRecRxPos$5+0,r2
        ldiu      @CL91,r1
        addi      *+fp(4),r0            ; Unsigned
        push      r2
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	122
;----------------------------------------------------------------------
; 1052 | m_nNvsramPos += nRecRxPos;                                             
;----------------------------------------------------------------------
        ldiu      @_nRecRxPos$5+0,r0
        addi      @_m_nNvsramPos+0,r0   ; Unsigned
        sti       r0,@_m_nNvsramPos+0
	.line	123
;----------------------------------------------------------------------
; 1053 | m_bLnWkFtpEndFlag = TRUE;                                              
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_bLnWkFtpEndFlag+0
	.line	125
;----------------------------------------------------------------------
; 1055 | d_EndFlagCnt++;                                                        
; 1057 | else                                                                   
;----------------------------------------------------------------------
        addi      @_d_EndFlagCnt+0,r0
        sti       r0,@_d_EndFlagCnt+0
        bu        L478
;*      Branch Occurs to L478 
L476:        
	.line	128
;----------------------------------------------------------------------
; 1058 | if(nKind == 6)                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(6),r0
        cmpi      6,r0
        bne       L478
;*      Branch Occurs to L478 
	.line	130
;----------------------------------------------------------------------
; 1060 | user_DebugPrint("***FTP File receive End ^..^ ***\r\n");               
;----------------------------------------------------------------------
        ldiu      @CL96,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	131
;----------------------------------------------------------------------
; 1061 | memcpy(&pNvsram[m_nNvsramPos],btFtpOneRecRxBuf,nRecRxPos);             
;----------------------------------------------------------------------
        ldiu      @_m_nNvsramPos+0,r0
        ldiu      @_nRecRxPos$5+0,r2
        ldiu      @CL91,r1
        addi      *+fp(4),r0            ; Unsigned
        push      r2
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	132
;----------------------------------------------------------------------
; 1062 | m_nNvsramPos += nRecRxPos;                                             
;----------------------------------------------------------------------
        ldiu      @_nRecRxPos$5+0,r0
        addi      @_m_nNvsramPos+0,r0   ; Unsigned
        sti       r0,@_m_nNvsramPos+0
L478:        
	.line	135
;----------------------------------------------------------------------
; 1065 | nOldKind = nKind;                                                      
;----------------------------------------------------------------------
        ldiu      *+fp(6),r0
        sti       r0,@_nOldKind$4+0
	.line	137
;----------------------------------------------------------------------
; 1067 | break;                                                                 
; 1069 | // �Ϲ� ��������(����)                                                 
; 1070 | case 7:                                                                
;----------------------------------------------------------------------
        bu        L548
;*      Branch Occurs to L548 
	.line	141
;----------------------------------------------------------------------
; 1071 | nRxLen = user_LonWorkRx(7,btRxBuf);                                    
; 1073 | //memcpy(d_LonRxBuf,btRxBuf,nRxLen); //LonWorks���� ���� �����.       
;----------------------------------------------------------------------
L480:        
        addi      8,r0
        push      r0
        push      r1
        call      _user_LonWorkRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(7)
	.line	144
;----------------------------------------------------------------------
; 1074 | d_LonRxCnt2++;                                                         
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_LonRxCnt2+0,r0    ; Unsigned
        sti       r0,@_d_LonRxCnt2+0
	.line	146
;----------------------------------------------------------------------
; 1076 | if(m_nDbgTxPos == 0xFFFFFFFF)                                          
;----------------------------------------------------------------------
        ldiu      @_m_nDbgTxPos+0,r0
        cmpi      @CL89,r0
        bned      L484
	nop
        ldieq     393,ir0
        ldieq     0,r0
;*      Branch Occurs to L484 
	.line	148
;----------------------------------------------------------------------
; 1078 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        sti       r0,*+fp(ir0)
	.line	149
;----------------------------------------------------------------------
; 1079 | sprintf(szBuf2,"[RX:%02d] ",nRxLen); strcat(szBuf,szBuf2);             
;----------------------------------------------------------------------
        ldiu      *+fp(7),r2
        ldiu      @CL97,r1
        ldiu      905,r0
        push      r2
        addi      fp,r0
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	150
;----------------------------------------------------------------------
; 1080 | for(i=0;i<nRxLen;i++) {sprintf(szBuf2,"%02X ",btRxBuf[i]); strcat(szBuf
;     | ,szBuf2);}                                                             
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(7),r0
        bhs       L483
;*      Branch Occurs to L483 
L482:        
        ldiu      fp,ar0
        ldiu      *+fp(1),ir0
        ldiu      905,r0
        addi      8,ar0
        ldiu      @CL88,r1
        ldiu      *+ar0(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(7),r0
        blo       L482
;*      Branch Occurs to L482 
L483:        
	.line	151
;----------------------------------------------------------------------
; 1081 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL25,r1
        ldiu      393,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	152
;----------------------------------------------------------------------
; 1082 | user_DebugPrint(szBuf);                                                
;----------------------------------------------------------------------
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
L484:        
	.line	155
;----------------------------------------------------------------------
; 1085 | if(nRxLen)                                                             
;----------------------------------------------------------------------
        ldi       *+fp(7),r0
        beqd      L548
	nop
        ldine     264,ir0
        ldine     0,r0
;*      Branch Occurs to L548 
	.line	157
;----------------------------------------------------------------------
; 1087 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        sti       r0,*+fp(ir0)
	.line	159
;----------------------------------------------------------------------
; 1089 | d_LonStData = btRxBuf[1];                                              
; 1090 | switch(btRxBuf[1])                                                     
; 1092 | // WAYSIDE ON ACK ����                                                 
; 1093 | case LW_WAYSIDE_ON_ACK:                                                
;----------------------------------------------------------------------
        ldiu      fp,ar0
        bud       L533
        addi      9,ar0
        ldiu      *ar0,r0
        sti       r0,@_d_LonStData+0
;*      Branch Occurs to L533 
L486:        
	.line	164
;----------------------------------------------------------------------
; 1094 | m_nLnWkWaySideOnRxOk = 1;                                              
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_nLnWkWaySideOnRxOk+0
	.line	165
;----------------------------------------------------------------------
; 1095 | break;                                                                 
; 1096 | // FTP���� ��                                                          
; 1097 | case LW_FTP_TX_END:                                                    
;----------------------------------------------------------------------
        bu        L535
;*      Branch Occurs to L535 
L487:        
	.line	168
;----------------------------------------------------------------------
; 1098 | if(m_nLnWkWaySideOnRxOk)                                               
;----------------------------------------------------------------------
        ldi       @_m_nLnWkWaySideOnRxOk+0,r0
        beq       L535
;*      Branch Occurs to L535 
	.line	170
;----------------------------------------------------------------------
; 1100 | m_nLnWkWaySideOnRxOk--;                                                
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     @_m_nLnWkWaySideOnRxOk+0,r0 ; Unsigned
        sti       r0,@_m_nLnWkWaySideOnRxOk+0
	.line	171
;----------------------------------------------------------------------
; 1101 | m_bLnWkFtpEndFlag = TRUE;                                              
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_bLnWkFtpEndFlag+0
	.line	173
;----------------------------------------------------------------------
; 1103 | break;                                                                 
; 1104 | // Car Number �б�                                                     
; 1105 | case LW_CARNO:                                                         
; 1107 | //memcpy(d_LonRxBuf,btRxBuf,nRxLen); //LonWorks���� ���� �����.       
; 1109 | // Y.J ����(2011-05-19 �ӽú����� ������ȣ�� ���� ��, Single�� Married�
;     | � �����Ͽ� ������ȣ�� ����.)                                           
;----------------------------------------------------------------------
        bu        L535
;*      Branch Occurs to L535 
L489:        
	.line	181
;----------------------------------------------------------------------
; 1111 | nTmp = MAKE_WORD(BYTE_L(btRxBuf[4]),btRxBuf[5]);                       
; 1112 | //d_nCarNoList[d_n++] = nTmp;                                          
; 1114 | // Single Car...                                                       
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      fp,ar1
        ldiu      15,r0
        ldiu      255,r1
        addi      12,ar0
        addi      13,ar1
        and3      r0,*ar0,r0
        and3      r1,*ar1,r1
        ash       8,r0
        or3       r0,r1,r0
        and       65535,r0
        sti       r0,*+fp(2)
	.line	185
;----------------------------------------------------------------------
; 1115 | if((m_nCarNo[0] != nTmp && m_nCarNo[1] != nTmp))                       
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+0,r0
        cmpi      *+fp(2),r0
        beq       L495
;*      Branch Occurs to L495 
        ldiu      @_m_nCarNo+1,r0
        cmpi      *+fp(2),r0
        beq       L495
;*      Branch Occurs to L495 
	.line	187
;----------------------------------------------------------------------
; 1117 | if(m_nCarNo[0] == 0x0000)                                              
;----------------------------------------------------------------------
        ldi       @_m_nCarNo+0,r0
        bne       L493
;*      Branch Occurs to L493 
	.line	189
;----------------------------------------------------------------------
; 1119 | m_nCarNo[0] = nTmp;                                                    
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        sti       r0,@_m_nCarNo+0
	.line	190
;----------------------------------------------------------------------
; 1120 | nCarNo = ((m_nCarNo[0] / 100) << 8) | (((m_nCarNo[0] / 10)%10) << 4) |
;     | (m_nCarNo[0] % 10); //�޸���� ���� ������ ����Ѵ�                    
;----------------------------------------------------------------------
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      100,r1
        ash       4,r2
        ldiu      @_m_nCarNo+0,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r1
        ash       8,r1
        or3       r1,r2,r2
        ldiu      10,r1
        ldiu      @_m_nCarNo+0,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      969,ir0
        or3       r2,r0,r0
        sti       r0,*+fp(ir0)
	.line	191
;----------------------------------------------------------------------
; 1121 | bCarNoUpdate = ((m_nCarNo[0] / 100) == 7);                             
; 1123 | else                                                                   
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+0,r0
        ldiu      100,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      0,r1
        cmpi      7,r0
        ldieq     1,r1
        ldiu      970,ir0
        sti       r1,*+fp(ir0)
        bu        L495
;*      Branch Occurs to L495 
L493:        
	.line	194
;----------------------------------------------------------------------
; 1124 | if(m_nCarNo[1] == 0x0000) m_nCarNo[1] = nTmp;                          
;----------------------------------------------------------------------
        ldi       @_m_nCarNo+1,r0
        bne       L495
;*      Branch Occurs to L495 
        ldiu      *+fp(2),r0
        sti       r0,@_m_nCarNo+1
L495:        
	.line	197
;----------------------------------------------------------------------
; 1127 | if(m_nCarNo[0] == m_nCarNo[1])                                         
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+0,r0
        cmpi      @_m_nCarNo+1,r0
        bne       L497
;*      Branch Occurs to L497 
	.line	199
;----------------------------------------------------------------------
; 1129 | m_nCarNo[1] = 0x0000;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nCarNo+1
L497:        
	.line	202
;----------------------------------------------------------------------
; 1132 | if(m_nCarNo[0] == 0x0000 && m_nCarNo[1]) //�߻��� �� ���� ����         
;----------------------------------------------------------------------
        ldi       @_m_nCarNo+0,r0
        bne       L500
;*      Branch Occurs to L500 
        ldi       @_m_nCarNo+1,r0
        beq       L500
;*      Branch Occurs to L500 
	.line	204
;----------------------------------------------------------------------
; 1134 | nTmp = m_nCarNo[0];                                                    
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+0,r0
        sti       r0,*+fp(2)
	.line	205
;----------------------------------------------------------------------
; 1135 | m_nCarNo[0] = m_nCarNo[1];                                             
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+1,r0
        sti       r0,@_m_nCarNo+0
	.line	206
;----------------------------------------------------------------------
; 1136 | m_nCarNo[1] = nTmp;                                                    
; 1139 | // Married Car...                                                      
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        sti       r0,@_m_nCarNo+1
L500:        
	.line	210
;----------------------------------------------------------------------
; 1140 | if(m_nCarNo[0] && m_nCarNo[1])                                         
;----------------------------------------------------------------------
        ldi       @_m_nCarNo+0,r0
        beq       L505
;*      Branch Occurs to L505 
        ldi       @_m_nCarNo+1,r0
        beq       L505
;*      Branch Occurs to L505 
	.line	212
;----------------------------------------------------------------------
; 1142 | if(m_nCarNo[0] > m_nCarNo[1])                                          
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+0,r0
        cmpi      @_m_nCarNo+1,r0
        bls       L504
;*      Branch Occurs to L504 
	.line	214
;----------------------------------------------------------------------
; 1144 | nTmp = m_nCarNo[0];                                                    
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+0,r0
        sti       r0,*+fp(2)
	.line	215
;----------------------------------------------------------------------
; 1145 | m_nCarNo[0] = m_nCarNo[1];                                             
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+1,r0
        sti       r0,@_m_nCarNo+0
	.line	216
;----------------------------------------------------------------------
; 1146 | m_nCarNo[1] = nTmp;                                                    
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        sti       r0,@_m_nCarNo+1
L504:        
	.line	219
;----------------------------------------------------------------------
; 1149 | nCarNo = ((m_nCarNo[1] / 100) << 8) | (((m_nCarNo[1] / 10)%10) << 4) |
;     | (m_nCarNo[1] % 10); //�޸���� ���� ������ ����Ѵ�.                   
;----------------------------------------------------------------------
        ldiu      @_m_nCarNo+1,r0
        ldiu      10,r1
        call      DIV_U30
                                        ; Call Occurs
        ldiu      10,r1
        call      MOD_U30
                                        ; Call Occurs
        ldiu      r0,r2
        ldiu      100,r1
        ash       4,r2
        ldiu      @_m_nCarNo+1,r0
        call      DIV_U30
                                        ; Call Occurs
        ldiu      r0,r1
        ash       8,r1
        or3       r1,r2,r2
        ldiu      10,r1
        ldiu      @_m_nCarNo+1,r0
        call      MOD_U30
                                        ; Call Occurs
        ldiu      969,ir0
        or3       r2,r0,r0
        sti       r0,*+fp(ir0)
	.line	221
;----------------------------------------------------------------------
; 1151 | bCarNoUpdate = TRUE;                                                   
; 1154 | //if(d_n < 1024)                                                       
; 1155 | //      d_nCarNoList[d_n++] = m_wCarNo;                                
;----------------------------------------------------------------------
        ldiu      970,ir0
        ldiu      1,r0
        sti       r0,*+fp(ir0)
L505:        
	.line	226
;----------------------------------------------------------------------
; 1156 | if(bCarNoUpdate)                                                       
;----------------------------------------------------------------------
        ldiu      970,ir0
        ldi       *+fp(ir0),r0
        beq       L535
;*      Branch Occurs to L535 
	.line	228
;----------------------------------------------------------------------
; 1158 | m_wCarNo =  nCarNo;                                                    
;----------------------------------------------------------------------
        ldiu      969,ir0
        ldiu      *+fp(ir0),r0
        sti       r0,@_m_wCarNo+0
	.line	230
;----------------------------------------------------------------------
; 1160 | pLicVerDp->CarNum[0] = WORD_H(m_wCarNo);                               
;----------------------------------------------------------------------
        ldiu      *+fp(5),ar0
        ash       -8,r0
        and       255,r0
        sti       r0,*+ar0(241)
	.line	231
;----------------------------------------------------------------------
; 1161 | pLicVerDp->CarNum[1] = WORD_L(m_wCarNo);                               
;----------------------------------------------------------------------
        ldiu      255,r0
        ldiu      *+fp(5),ar0
        and       @_m_wCarNo+0,r0
        sti       r0,*+ar0(242)
	.line	234
;----------------------------------------------------------------------
; 1164 | break;                                                                 
; 1166 | // �ð���û, MPU�� DPRAM�� �����͸� ���� ���� ���ͷ�Ʈ�� ��������������
;     |  LIC_LON���� �������� ����                                             
; 1167 | case LW_TIME_REQ:                                                      
;----------------------------------------------------------------------
        bu        L535
;*      Branch Occurs to L535 
L507:        
	.line	238
;----------------------------------------------------------------------
; 1168 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	239
;----------------------------------------------------------------------
; 1169 | if(m_LIC_CNCS_TimSetFlag && m_nCncsRxCheck1msTimer)                    
;----------------------------------------------------------------------
        ldi       @_m_LIC_CNCS_TimSetFlag+0,r0
        beq       L535
;*      Branch Occurs to L535 
        ldi       @_m_nCncsRxCheck1msTimer+0,r0
        beq       L535
;*      Branch Occurs to L535 
	.line	241
;----------------------------------------------------------------------
; 1171 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        ldiu      264,ir1
        ldiu      265,ar0
        ldiu      2,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	242
;----------------------------------------------------------------------
; 1172 | btTxBuf[nTxPos++] = LW_TIME_TX; // Command Code                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir1),r0
        ldiu      9,r1
        addi      r0,r2
        addi3     r0,fp,ir1             ; Unsigned
        sti       r2,*+fp(ir0)
        sti       r1,*+ar0(ir1)
	.line	243
;----------------------------------------------------------------------
; 1173 | btTxBuf[nTxPos++] = 0x00; // 0x00���� ����                             
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        ldiu      0,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	244
;----------------------------------------------------------------------
; 1174 | btTxBuf[nTxPos++] = 0x06; // ����                                      
; 1176 | // Y.J ����                                                            
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        ldiu      6,r1
        sti       r1,*+ar0(ir0)
	.line	247
;----------------------------------------------------------------------
; 1177 | btTxBuf[nTxPos++] = m_tmUtcTime.year;
;     |                          // �� BCD                                     
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        ldiu      1,r1
        addi      r0,r1
        sti       r1,*+fp(ir1)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      @_m_tmUtcTime+5,r0
        sti       r0,*+ar0(ir0)
	.line	248
;----------------------------------------------------------------------
; 1178 | btTxBuf[nTxPos++] = m_tmUtcTime.month;
;     |                          // ��                                         
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir1),r0
        ldiu      1,r1
        addi      r0,r1
        sti       r1,*+fp(ir0)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      @_m_tmUtcTime+4,r0
        sti       r0,*+ar0(ir0)
	.line	249
;----------------------------------------------------------------------
; 1179 | btTxBuf[nTxPos++] = m_tmUtcTime.day;
;     |                          // ��                                         
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r0
        ldiu      *+fp(ir0),r1
        addi      r1,r0
        sti       r0,*+fp(ir1)
        addi3     r1,fp,ir0             ; Unsigned
        ldiu      @_m_tmUtcTime+3,r0
        sti       r0,*+ar0(ir0)
	.line	250
;----------------------------------------------------------------------
; 1180 | btTxBuf[nTxPos++] = m_tmUtcTime.hour;
;     |                          // ��                                         
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        ldiu      1,r1
        addi      r0,r1
        addi3     r0,fp,ir0             ; Unsigned
        sti       r1,*+fp(ir1)
        ldiu      @_m_tmUtcTime+2,r0
        sti       r0,*+ar0(ir0)
	.line	251
;----------------------------------------------------------------------
; 1181 | btTxBuf[nTxPos++] = m_tmUtcTime.minute;
;     |                          // ��                                         
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        ldiu      1,r1
        addi      r0,r1
        addi3     r0,fp,ir0             ; Unsigned
        sti       r1,*+fp(ir1)
        ldiu      @_m_tmUtcTime+1,r0
        sti       r0,*+ar0(ir0)
	.line	252
;----------------------------------------------------------------------
; 1182 | btTxBuf[nTxPos++] = m_tmUtcTime.second;
;     |                          // ��                                         
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r0
        ldiu      *+fp(ir1),r1
        addi      r1,r0
        sti       r0,*+fp(ir0)
        addi3     r1,fp,ir1             ; Unsigned
        ldiu      @_m_tmUtcTime+0,r0
        sti       r0,*+ar0(ir1)
	.line	254
;----------------------------------------------------------------------
; 1184 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      266,r0
        addi      fp,r0
        ldiu      1,r1
        subi3     r1,*+fp(ir0),r1
        push      r1
        push      r0
        call      _Make1ByteBcc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      2,sp
        ldiu      *+fp(ir0),r1
        addi3     r1,fp,ir0             ; Unsigned
        ldiu      264,ir1
        addi      1,r1
        ldiu      265,ar0
        sti       r1,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	255
;----------------------------------------------------------------------
; 1185 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir1),r2
        ldiu      3,r0
        ldiu      1,r1
        addi      r2,r1
        addi3     r2,fp,ir1             ; Unsigned
        sti       r1,*+fp(ir0)
        sti       r0,*+ar0(ir1)
	.line	256
;----------------------------------------------------------------------
; 1186 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),r0
        push      r0
        ldiu      265,r0
        addi      fp,r0
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	258
;----------------------------------------------------------------------
; 1188 | memset(d_TimeTxBuf,0x00,sizeof(d_TimeTxBuf));                          
;----------------------------------------------------------------------
        ldiu      10,r2
        ldiu      0,r0
        push      r2
        push      r0
        ldiu      @CL98,r1
        push      r1
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	260
;----------------------------------------------------------------------
; 1190 | d_TimeTxCnt++;                                                         
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_TimeTxCnt+0,r0
        sti       r0,@_d_TimeTxCnt+0
	.line	261
;----------------------------------------------------------------------
; 1191 | memcpy(d_TimeTxBuf,&btTxBuf[4],6);                                     
;----------------------------------------------------------------------
        ldiu      @CL98,ar1
        ldiu      269,ar0
        addi      fp,ar0
        ldiu      *ar0++(1),r0
        rpts      4                     ; Fast MEMCPY(#9)
        sti       r0,*ar1++(1)
||      ldi       *ar0++(1),r0
        sti       r0,*ar1++(1)
	.line	263
;----------------------------------------------------------------------
; 1193 | break;                                                                 
; 1195 | // ���µ����� ��û, MPU�� DPRAM�� �����͸� ���� ���� ���ͷ�Ʈ�� �������
;     | ������� LIC_LON���� �������� ����                                      
; 1196 | case LW_COMMST_REQ:                                                    
;----------------------------------------------------------------------
        bu        L535
;*      Branch Occurs to L535 
L510:        
	.line	268
;----------------------------------------------------------------------
; 1198 | d_StTxCnt++;                                                           
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_StTxCnt+0,r0
        sti       r0,@_d_StTxCnt+0
	.line	270
;----------------------------------------------------------------------
; 1200 | m_nCarCnt = btRxBuf[4];                                                
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldi       *ar0,r0
        sti       r0,@_m_nCarCnt+0
	.line	271
;----------------------------------------------------------------------
; 1201 | if(m_nCarCnt < 1 && m_nCarCnt > 2) m_nCarCnt = 1;                      
;----------------------------------------------------------------------
        bne       L513
;*      Branch Occurs to L513 
        cmpi      2,r0
        bls       L513
;*      Branch Occurs to L513 
        ldiu      1,r0
        sti       r0,@_m_nCarCnt+0
L513:        
	.line	272
;----------------------------------------------------------------------
; 1202 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	273
;----------------------------------------------------------------------
; 1203 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      1,r2
        ldiu      264,ir1
        ldiu      265,ar0
        ldiu      2,r1
        ldiu      *+fp(ir0),r0
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	274
;----------------------------------------------------------------------
; 1204 | btTxBuf[nTxPos++] = LW_COMMST_TX; // Command Code                      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        ldiu      11,r1
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	275
;----------------------------------------------------------------------
; 1205 | btTxBuf[nTxPos++] = 0x00; // 0x00���� ����                             
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      0,r1
        ldiu      *+fp(ir0),r0
        ldiu      1,r2
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	276
;----------------------------------------------------------------------
; 1206 | btTxBuf[nTxPos++] = 0x05; // ����                                      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r2
        ldiu      *+fp(ir0),r0
        addi      r0,r2
        addi3     r0,fp,ir0             ; Unsigned
        sti       r2,*+fp(ir1)
        ldiu      5,r1
        sti       r1,*+ar0(ir0)
	.line	277
;----------------------------------------------------------------------
; 1207 | btTxBuf[nTxPos++] = m_btCommSt[0]; // ���� ������                      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r1
        ldiu      *+fp(ir0),r0
        addi      r0,r1
        sti       r1,*+fp(ir1)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      @_m_btCommSt+0,r0
        sti       r0,*+ar0(ir0)
	.line	278
;----------------------------------------------------------------------
; 1208 | btTxBuf[nTxPos++] = m_btCommSt[1]; // ���� ������                      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        ldiu      1,r1
        addi      r0,r1
        sti       r1,*+fp(ir1)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      @_m_btCommSt+1,r0
        sti       r0,*+ar0(ir0)
	.line	279
;----------------------------------------------------------------------
; 1209 | btTxBuf[nTxPos++] = m_btCommSt[2]; // ���� ������                      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r1
        ldiu      *+fp(ir1),r0
        addi      r0,r1
        sti       r1,*+fp(ir0)
        addi3     r0,fp,ir0             ; Unsigned
        ldiu      @_m_btCommSt+2,r0
        sti       r0,*+ar0(ir0)
	.line	280
;----------------------------------------------------------------------
; 1210 | btTxBuf[nTxPos++] = m_btCommSt[3]; // ���� ������                      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r1
        ldiu      *+fp(ir0),r0
        addi      r0,r1
        addi3     r0,fp,ir0             ; Unsigned
        sti       r1,*+fp(ir1)
        ldiu      @_m_btCommSt+3,r0
        sti       r0,*+ar0(ir0)
	.line	281
;----------------------------------------------------------------------
; 1211 | btTxBuf[nTxPos++] = m_btCommSt[4]; // ���� ������                      
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      1,r1
        ldiu      *+fp(ir0),r0
        addi      r0,r1
        addi3     r0,fp,ir0             ; Unsigned
        sti       r1,*+fp(ir1)
        ldiu      @_m_btCommSt+4,r0
        sti       r0,*+ar0(ir0)
	.line	283
;----------------------------------------------------------------------
; 1213 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      266,r0
        ldiu      1,r1
        addi      fp,r0
        subi3     r1,*+fp(ir0),r1
        push      r1
        push      r0
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      264,ir1
        ldiu      *+fp(ir1),r2
        ldiu      1,r1
        ldiu      264,ir0
        addi      r2,r1
        sti       r1,*+fp(ir0)
        ldiu      265,ar0
        addi3     r2,fp,ir0             ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	284
;----------------------------------------------------------------------
; 1214 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        addi3     r0,fp,ir0             ; Unsigned
        addi      1,r0
        sti       r0,*+fp(ir1)
        ldiu      3,r1
        sti       r1,*+ar0(ir0)
	.line	285
;----------------------------------------------------------------------
; 1215 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        push      r0
        ldiu      265,r0
        addi      fp,r0
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	287
;----------------------------------------------------------------------
; 1217 | break;                                                                 
; 1219 | //������û                                                             
; 1220 | case LW_VERSION_REQ:                                                   
;----------------------------------------------------------------------
        bu        L535
;*      Branch Occurs to L535 
L514:        
	.line	291
;----------------------------------------------------------------------
; 1221 | d_VerTxCnt++;                                                          
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_VerTxCnt+0,r0
        sti       r0,@_d_VerTxCnt+0
	.line	292
;----------------------------------------------------------------------
; 1222 | nTxPos = 0;                                                            
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	293
;----------------------------------------------------------------------
; 1223 | memset(btTxBuf,0x00,sizeof(btTxBuf));                                  
;----------------------------------------------------------------------
        ldiu      265,r1
        ldiu      0,r2
        addi      fp,r1
        ldiu      128,r0
        push      r0
        push      r2
        push      r1
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	295
;----------------------------------------------------------------------
; 1225 | btTxBuf[nTxPos++] = STX; // STX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      264,ir1
        ldiu      *+fp(ir0),r2
        ldiu      1,r1
        addi      r2,r1
        sti       r1,*+fp(ir1)
        ldiu      265,ar0
        addi3     r2,fp,ir0             ; Unsigned
        ldiu      2,r0
        sti       r0,*+ar0(ir0)
	.line	296
;----------------------------------------------------------------------
; 1226 | btTxBuf[nTxPos++] = LW_VERSION_TX; // Command Code                     
; 1228 | // 2 : Firmware                                                        
; 1229 | // 0 : Not used�� ����ϰ� ������ ��¥�� ��������ʴ´�.               
; 1230 | // 6 : ��������(LIC -> CDT) ����                                       
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r2
        addi3     r2,fp,ir0             ; Unsigned
        ldiu      1,r0
        addi      r2,r0
        sti       r0,*+fp(ir1)
        ldiu      13,r1
        sti       r1,*+ar0(ir0)
	.line	302
;----------------------------------------------------------------------
; 1232 | nTmp = MAX(1,WORD_L(btRxBuf[4]));                                      
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        ldiu      1,r1
        cmpi3     r0,r1
        bls       L516
;*      Branch Occurs to L516 
        bud       L517
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L517 
L516:        
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
L517:        
        sti       r0,*+fp(2)
	.line	303
;----------------------------------------------------------------------
; 1233 | nTmp = MIN((VER_BDD_MAX_CNT)+1,WORD_L(btRxBuf[4]));                    
;----------------------------------------------------------------------
        ldiu      fp,ar0
        ldiu      25,r1
        addi      12,ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        cmpi3     r0,r1
        bhs       L519
;*      Branch Occurs to L519 
        bud       L520
	nop
	nop
        ldiu      25,r0
;*      Branch Occurs to L520 
L519:        
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
L520:        
        sti       r0,*+fp(2)
	.line	304
;----------------------------------------------------------------------
; 1234 | nTmp--;                                                                
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     *+fp(2),r0
        sti       r0,*+fp(2)
	.line	305
;----------------------------------------------------------------------
; 1235 | btTxBuf[nTxPos++] = (btRxBuf[4] == (VER_BDD_MAX_CNT+1)) ? 6 : 2; // Typ
;     | e (2011_03_03 ����)Ȯ�� ��û                                           
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      fp,ar0
        ldiu      264,ir0
        ldiu      *+fp(ir1),r1
        addi      12,ar0
        ldiu      1,r0
        addi      r1,r0
        sti       r0,*+fp(ir0)
        ldiu      *ar0,r0
        cmpi      25,r0
        bned      L522
        ldiu      265,ar1
        addi3     r1,fp,ir0             ; Unsigned
        ldine     2,r0
;*      Branch Occurs to L522 
        ldiu      6,r0
L522:        
        sti       r0,*+ar1(ir0)
	.line	307
;----------------------------------------------------------------------
; 1237 | btTxBuf[nTxPos++] = 0x1F; // ����                                      
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      264,ir0
        ldiu      264,ir1
        ldiu      265,ar0
        ldiu      *+fp(ir0),r2
        ldiu      31,r0
        addi      r2,r1
        addi3     r2,fp,ir0             ; Unsigned
        sti       r1,*+fp(ir1)
        sti       r0,*+ar0(ir0)
	.line	308
;----------------------------------------------------------------------
; 1238 | btTxBuf[nTxPos++] = btRxBuf[4]; // Index ��ȣ                          
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      fp,ar0
        ldiu      1,r1
        ldiu      265,ar1
        ldiu      *+fp(ir0),r0
        addi      12,ar0
        addi      r0,r1
        addi3     r0,fp,ir0             ; Unsigned
        sti       r1,*+fp(ir1)
        ldiu      *ar0,r0
        sti       r0,*+ar1(ir0)
	.line	310
;----------------------------------------------------------------------
; 1240 | btTxBuf[nTxPos++] = 0x04; // Index ��ȣ                                
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      4,r1
        ldiu      265,ar0
        ldiu      1,r0
        ldiu      *+fp(ir0),r2
        addi      r2,r0
        addi3     r2,fp,ir0             ; Unsigned
        sti       r0,*+fp(ir1)
        sti       r1,*+ar0(ir0)
	.line	312
;----------------------------------------------------------------------
; 1242 | memcpy(&btTxBuf[nTxPos],&LIC_VerList[nTmp][0],strlen((char*)&LIC_VerLis
;     | t[nTmp][0]));                                                          
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        mpyi      9,r0
        addi      @CL23,r0              ; Unsigned
        push      r0
        call      _strlen
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        addi3     fp,*+fp(ir0),r2       ; Unsigned
        addi      265,r2                ; Unsigned
        ldiu      *+fp(2),r1
        mpyi      9,r1
        addi      @CL23,r1              ; Unsigned
        push      r0
        push      r1
        push      r2
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	313
;----------------------------------------------------------------------
; 1243 | nTxPos = nTxPos+9;                                                     
;----------------------------------------------------------------------
        ldiu      9,r0
        ldiu      264,ir0
        ldiu      264,ir1
        addi3     r0,*+fp(ir0),r0
        sti       r0,*+fp(ir1)
	.line	315
;----------------------------------------------------------------------
; 1245 | btTxBuf[nTxPos+0] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]>>12)&0x
;     | 0F); // Production Version                                             
;----------------------------------------------------------------------
        ldiu      @CL4,ar0
        ldiu      255,ir0
        and       *+fp(2),ir0
        ldiu      -12,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      265,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	316
;----------------------------------------------------------------------
; 1246 | btTxBuf[nTxPos+1] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]>>8)&0x0
;     | F); // Production Version                                              
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL4,ar0
        and       *+fp(2),ir0
        ldiu      -8,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        ldiu      266,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	317
;----------------------------------------------------------------------
; 1247 | btTxBuf[nTxPos+2] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]>>4)&0x0
;     | F); // Production Version                                              
;----------------------------------------------------------------------
        ldiu      255,ir0
        and       *+fp(2),ir0
        ldiu      @CL4,ar0
        ldiu      -4,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      267,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	318
;----------------------------------------------------------------------
; 1248 | btTxBuf[nTxPos+3] = ConvHex2Asc((m_btExVersionTbl[WORD_L(nTmp)]&0x0F));
;     |  // Production Version                                                 
;----------------------------------------------------------------------
        ldiu      255,ir0
        and       *+fp(2),ir0
        ldiu      @CL4,ar0
        ldiu      15,r0
        and3      r0,*+ar0(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      268,ar0
        sti       r0,*+ar0(ir0)
	.line	320
;----------------------------------------------------------------------
; 1250 | nTxPos = nTxPos+9;                                                     
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      9,r0
        ldiu      264,ir1
        addi3     r0,*+fp(ir0),r0
        sti       r0,*+fp(ir1)
	.line	322
;----------------------------------------------------------------------
; 1252 | btTxBuf[nTxPos+0] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>20
;     | )&0xF);//0x20; // Year(õ�ڸ�,���ڸ�)                                  
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL5,ar0
        and       *+fp(2),ir0
        ldiu      -20,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        ldiu      265,ar0
        sti       r0,*+ar0(ir0)
	.line	323
;----------------------------------------------------------------------
; 1253 | btTxBuf[nTxPos+1] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>16
;     | )&0xF);//0x10;//btRxBuf[4]; // Year(���ڸ�,���ڸ�)                     
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL5,ar0
        and       *+fp(2),ir0
        ldiu      -16,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      266,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	324
;----------------------------------------------------------------------
; 1254 | btTxBuf[nTxPos+2] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>12
;     | )&0xF);//0x01;//btRxBuf[4]+1; // Month(���ڸ�,���ڸ�)                  
;----------------------------------------------------------------------
        ldiu      255,ir0
        and       *+fp(2),ir0
        ldiu      @CL5,ar0
        ldiu      -12,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      267,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	325
;----------------------------------------------------------------------
; 1255 | btTxBuf[nTxPos+3] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>8)
;     | &0xF);//0x01;//btRxBuf[4]+2; // Day(���ڸ�,���ڸ�)                     
;----------------------------------------------------------------------
        ldiu      255,ir0
        and       *+fp(2),ir0
        ldiu      @CL5,ar0
        ldiu      -8,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        ldiu      268,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	326
;----------------------------------------------------------------------
; 1256 | btTxBuf[nTxPos+4] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)]>>4)
;     | &0xF);//0x01;//btRxBuf[4]+1; // Month(���ڸ�,���ڸ�)                   
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL5,ar0
        and       *+fp(2),ir0
        ldiu      -4,r0
        lsh3      r0,*+ar0(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      264,ir0
        subi      1,sp
        ldiu      269,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	327
;----------------------------------------------------------------------
; 1257 | btTxBuf[nTxPos+5] = ConvHex2Asc((m_btExVersion_DAYTbl[WORD_L(nTmp)])&0x
;     | F);//0x01;//btRxBuf[4]+2; // Day(���ڸ�,���ڸ�)                        
;----------------------------------------------------------------------
        ldiu      255,ir0
        ldiu      @CL5,ar0
        and       *+fp(2),ir0
        ldiu      15,r0
        and3      r0,*+ar0(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      264,ir0
        ldiu      270,ar0
        addi3     fp,*+fp(ir0),ir0      ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	328
;----------------------------------------------------------------------
; 1258 | nTxPos = nTxPos+11;                                                    
;----------------------------------------------------------------------
        ldiu      264,ir1
        ldiu      11,r0
        ldiu      264,ir0
        addi3     r0,*+fp(ir1),r0
        sti       r0,*+fp(ir0)
	.line	330
;----------------------------------------------------------------------
; 1260 | btTxBuf[nTxPos++] = Make1ByteBcc(&btTxBuf[1],nTxPos-1); // Check Sum   
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      266,r1
        addi      fp,r1
        subi3     r0,*+fp(ir0),r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        ldiu      264,ir1
        ldiu      *+fp(ir1),r1
        ldiu      1,r2
        ldiu      264,ir0
        addi      r1,r2
        sti       r2,*+fp(ir0)
        ldiu      265,ar0
        addi3     r1,fp,ir0             ; Unsigned
        sti       r0,*+ar0(ir0)
	.line	331
;----------------------------------------------------------------------
; 1261 | btTxBuf[nTxPos++] = ETX; // ETX                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      *+fp(ir0),r0
        addi3     r0,fp,ir0             ; Unsigned
        addi      1,r0
        sti       r0,*+fp(ir1)
        ldiu      3,r1
        sti       r1,*+ar0(ir0)
	.line	333
;----------------------------------------------------------------------
; 1263 | if(WORD_L(btRxBuf[4]) != 0x01)                                         
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        cmpi      1,r0
        beq       L535
;*      Branch Occurs to L535 
	.line	335
;----------------------------------------------------------------------
; 1265 | user_LonWorkTx(btTxBuf,nTxPos);                                        
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldiu      265,r0
        ldiu      *+fp(ir0),r1
        addi      fp,r0
        push      r1
        push      r0
        call      _user_LonWorkTx
                                        ; Call Occurs
        subi      2,sp
	.line	337
;----------------------------------------------------------------------
; 1267 | break;                                                                 
; 1269 | //�������(Single or married A)                                        
; 1270 | case LW_DOOR_ST_REQ1:                                                  
;----------------------------------------------------------------------
        bu        L535
;*      Branch Occurs to L535 
L525:        
	.line	341
;----------------------------------------------------------------------
; 1271 | d_nDoorCntA++;                                                         
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_nDoorCntA+0,r0
        sti       r0,@_d_nDoorCntA+0
	.line	342
;----------------------------------------------------------------------
; 1272 | m_btCttSignalA = btRxBuf[4];                                           
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      12,ar0
        ldiu      *ar0,r0
        sti       r0,@_m_btCttSignalA+0
	.line	343
;----------------------------------------------------------------------
; 1273 | break;                                                                 
; 1274 | case LW_TRAIN_CONFIG:                                                  
;----------------------------------------------------------------------
        bu        L535
;*      Branch Occurs to L535 
L526:        
	.line	345
;----------------------------------------------------------------------
; 1275 | if(WORD_L(pLnWkDp->lgRxBuf.btMessCode) == 0x11)                        
;----------------------------------------------------------------------
        ldiu      *+fp(3),ir0
        ldiu      1218,ar0
        ldiu      255,r0
        and3      r0,*+ar0(ir0),r0
        cmpi      17,r0
        bne       L535
;*      Branch Occurs to L535 
	.line	347
;----------------------------------------------------------------------
; 1277 | user_DebugPrint("LW_TRAIN_CONFIG Recive OK \r\n");                     
;----------------------------------------------------------------------
        ldiu      @CL99,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	349
;----------------------------------------------------------------------
; 1279 | break;                                                                 
; 1280 | case LW_CI_POSITION :                                                  
;----------------------------------------------------------------------
        bu        L535
;*      Branch Occurs to L535 
L528:        
	.line	351
;----------------------------------------------------------------------
; 1281 | if(WORD_L(pLnWkDp->lgRxBuf.btMessCode) == 0x11)                        
;----------------------------------------------------------------------
        ldiu      *+fp(3),ir0
        ldiu      1218,ar0
        ldiu      255,r0
        and3      r0,*+ar0(ir0),r0
        cmpi      17,r0
        bne       L535
;*      Branch Occurs to L535 
	.line	353
;----------------------------------------------------------------------
; 1283 | user_DebugPrint("LW_CI_POSITION Recive OK \r\n");                      
;----------------------------------------------------------------------
        ldiu      @CL100,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	355
;----------------------------------------------------------------------
; 1285 | break;                                                                 
; 1286 | case LW_CI_FAULT :                                                     
;----------------------------------------------------------------------
        bu        L535
;*      Branch Occurs to L535 
L530:        
	.line	357
;----------------------------------------------------------------------
; 1287 | if(WORD_L(pLnWkDp->lgRxBuf.btMessCode) == 0x11)                        
;----------------------------------------------------------------------
        ldiu      *+fp(3),ir0
        ldiu      1218,ar0
        ldiu      255,r0
        and3      r0,*+ar0(ir0),r0
        cmpi      17,r0
        bne       L535
;*      Branch Occurs to L535 
	.line	359
;----------------------------------------------------------------------
; 1289 | user_DebugPrint("LW_CI_FAULT Recive OK \r\n");                         
; 1291 | //MyPrintf("LW_CI_FAULT Recive OK : %2d \r\n",d_nDoorCntA);            
;----------------------------------------------------------------------
        ldiu      @CL101,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	363
;----------------------------------------------------------------------
; 1293 | break;                                                                 
;----------------------------------------------------------------------
        bu        L535
;*      Branch Occurs to L535 
L533:        
	.line	160
        ldiu      fp,ar0
        addi      9,ar0
        ldiu      2,r0
        ldiu      *ar0,ir0
        subri     ir0,r0
        cmpi      15,r0
        bhi       L535
;*      Branch Occurs to L535 
        subi      2,ir0                 ; Unsigned
        ldiu      @CL102,ar0
        ldiu      *+ar0(ir0),r0
        bu        r0

	.sect	".text"
SW0:	.word	L486	; 2
	.word	L535	; 0
	.word	L535	; 0
	.word	L535	; 0
	.word	L487	; 6
	.word	L489	; 7
	.word	L507	; 8
	.word	L535	; 0
	.word	L510	; 10
	.word	L535	; 0
	.word	L514	; 12
	.word	L535	; 0
	.word	L525	; 14
	.word	L526	; 15
	.word	L528	; 16
	.word	L530	; 17
	.sect	".text"
;*      Branch Occurs to r0 
L535:        
	.line	367
;----------------------------------------------------------------------
; 1297 | if(nTxPos)                                                             
;----------------------------------------------------------------------
        ldiu      264,ir0
        ldi       *+fp(ir0),r0
        beq       L548
;*      Branch Occurs to L548 
	.line	369
;----------------------------------------------------------------------
; 1299 | if(m_nDbgTxPos == 0xFFFFFFFF)                                          
;----------------------------------------------------------------------
        ldiu      @_m_nDbgTxPos+0,r0
        cmpi      @CL89,r0
        bned      L548
	nop
        ldieq     393,ir0
        ldieq     0,r0
;*      Branch Occurs to L548 
	.line	371
;----------------------------------------------------------------------
; 1301 | szBuf[0] = 0;                                                          
;----------------------------------------------------------------------
        sti       r0,*+fp(ir0)
	.line	372
;----------------------------------------------------------------------
; 1302 | sprintf(szBuf2,"[TX:%02d] ",nTxPos); strcat(szBuf,szBuf2);             
;----------------------------------------------------------------------
        ldiu      @CL90,r1
        ldiu      264,ir0
        ldiu      905,r0
        ldiu      *+fp(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	373
;----------------------------------------------------------------------
; 1303 | for(i=0;i<nTxPos;i++) {sprintf(szBuf2,"%02X ",btTxBuf[i]); strcat(szBuf
;     | ,szBuf2);}                                                             
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        ldiu      264,ir0
        cmpi3     *+fp(ir0),r0
        ldiu      265,ar4
        bge       L539
;*      Branch Occurs to L539 
L538:        
        ldiu      *+fp(1),ir0
        ldiu      905,r0
        addi      fp,ir0
        ldiu      @CL88,r1
        ldiu      *+ar4(ir0),r2
        addi      fp,r0
        push      r2
        push      r1
        push      r0
        call      _sprintf
                                        ; Call Occurs
        subi      3,sp
        ldiu      905,r0
        addi      fp,r0
        push      r0
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        ldiu      264,ir0
        cmpi3     *+fp(ir0),r0
        blt       L538
;*      Branch Occurs to L538 
L539:        
	.line	374
;----------------------------------------------------------------------
; 1304 | strcat(szBuf,"\r\n");                                                  
;----------------------------------------------------------------------
        ldiu      @CL25,r1
        ldiu      393,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _strcat
                                        ; Call Occurs
        subi      2,sp
	.line	375
;----------------------------------------------------------------------
; 1305 | user_DebugPrint(szBuf);                                                
;----------------------------------------------------------------------
        ldiu      393,r0
        addi      fp,r0
        push      r0
        call      _user_DebugPrint
                                        ; Call Occurs
        subi      1,sp
	.line	379
;----------------------------------------------------------------------
; 1309 | break;                                                                 
;----------------------------------------------------------------------
        bu        L548
;*      Branch Occurs to L548 
L541:        
	.line	29
        ldiu      *+fp(6),r0
        cmpi      1,r0
        beq       L436
;*      Branch Occurs to L436 
        cmpi      2,r0
        beq       L436
;*      Branch Occurs to L436 
        cmpi      3,r0
        beq       L436
;*      Branch Occurs to L436 
        cmpi      4,r0
        beq       L436
;*      Branch Occurs to L436 
        cmpi      5,r0
        beq       L436
;*      Branch Occurs to L436 
        cmpi      6,r0
        beq       L436
;*      Branch Occurs to L436 
        cmpi      7,r0
        beqd      L480
	nop
        ldieq     fp,r0
        ldieq     7,r1
;*      Branch Occurs to L480 
L548:        
	.line	381
        ldiu      *-fp(1),bk
        pop       ar4
        ldiu      *fp,fp
        subi      972,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1311,000001000h,970


	.sect	 ".text"

	.global	_user_LonWorkRx
	.sym	_user_LonWorkRx,_user_LonWorkRx,44,2,0
	.func	1313
;******************************************************************************
;* FUNCTION NAME: _user_LonWorkRx                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,ar0,ar1,fp,ir0,ir1,sp,st                      *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 4 Auto + 0 SOE = 8 words          *
;******************************************************************************
_user_LonWorkRx:
	.sym	_nRxPos,-2,4,9,32
	.sym	_pRxBuf,-3,28,9,32
	.sym	_i,1,4,1,32
	.sym	_nRxLen,2,12,1,32
	.sym	_pBuf,3,28,1,32
	.sym	_pLnWkDp,4,24,1,32,.fake13
	.line	1
;----------------------------------------------------------------------
; 1313 | UCHAR user_LonWorkRx(int nRxPos, UCHAR *pRxBuf)                        
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      4,sp
	.line	2
;----------------------------------------------------------------------
; 1315 | int i;                                                                 
; 1316 | UCHAR nRxLen;                                                          
; 1317 | UCHAR *pBuf;                                                           
;----------------------------------------------------------------------
	.line	6
;----------------------------------------------------------------------
; 1318 | PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;                                
;----------------------------------------------------------------------
        ldiu      @CL11,r0
        sti       r0,*+fp(4)
	.line	8
;----------------------------------------------------------------------
; 1320 | if(nRxPos >= 1 && nRxPos <= 6)                                         
;----------------------------------------------------------------------
        ldi       *-fp(2),r0
        ble       L566
;*      Branch Occurs to L566 
        cmpi      6,r0
        bgt       L566
;*      Branch Occurs to L566 
	.line	10
;----------------------------------------------------------------------
; 1322 | nRxLen = MIN(sizeof(LNWKFTPIT)-1,WORD_L(pLnWkDp->lfBuf[nRxPos-1].btLen)
;     | +7);                                                                   
;----------------------------------------------------------------------
        ldiu      1,ar0
        subri     *-fp(2),ar0
        ldiu      255,r0
        mpyi      200,ar0
        addi      *+fp(4),ar0           ; Unsigned
        ldiu      199,r1
        and       *+ar0(19),r0
        addi      7,r0                  ; Unsigned
        cmpi3     r0,r1
        bhs       L554
;*      Branch Occurs to L554 
        bud       L555
	nop
	nop
        ldiu      199,r0
;*      Branch Occurs to L555 
L554:        
        ldiu      1,ar0
        subri     *-fp(2),ar0
        mpyi      200,ar0
        addi      *+fp(4),ar0           ; Unsigned
        ldiu      255,r0
        and       *+ar0(19),r0
        addi      7,r0                  ; Unsigned
L555:        
        sti       r0,*+fp(2)
	.line	11
;----------------------------------------------------------------------
; 1323 | if(nRxLen > 6)                                                         
;----------------------------------------------------------------------
        cmpi      6,r0
        bls       L564
;*      Branch Occurs to L564 
	.line	13
;----------------------------------------------------------------------
; 1325 | pBuf = &pLnWkDp->lfBuf[nRxPos-1].btStx;                                
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     *-fp(2),r0
        mpyi      200,r0
        addi      *+fp(4),r0            ; Unsigned
        addi      16,r0                 ; Unsigned
        sti       r0,*+fp(3)
	.line	14
;----------------------------------------------------------------------
; 1326 | for(i=0;i<nRxLen;i++) pRxBuf[i] = WORD_L(pBuf[i]);                     
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(2),r0
        ldiu      255,r1
        bhs       L558
;*      Branch Occurs to L558 
L557:        
        ldiu      *+fp(1),ar1
        ldiu      *+fp(3),ir0
        ldiu      *-fp(3),ir1
        ldiu      ar1,ar0
        and3      r1,*+ar1(ir0),r0
        sti       r0,*+ar0(ir1)
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(2),r0
        blo       L557
;*      Branch Occurs to L557 
L558:        
	.line	15
;----------------------------------------------------------------------
; 1327 | if(pRxBuf[0] == STX && pRxBuf[nRxLen-1] == ETX)                        
;----------------------------------------------------------------------
        ldiu      *-fp(3),ar0
        ldiu      *ar0,r0
        cmpi      2,r0
        bne       L562
;*      Branch Occurs to L562 
        ldiu      *+fp(2),ar0
        addi      *-fp(3),ar0           ; Unsigned
        ldiu      *-ar0(1),r0
        cmpi      3,r0
        bne       L562
;*      Branch Occurs to L562 
	.line	17
;----------------------------------------------------------------------
; 1329 | return nRxLen;                                                         
; 1331 | else                                                                   
;----------------------------------------------------------------------
        bud       L584
	nop
	nop
        ldiu      *+fp(2),r0
;*      Branch Occurs to L584 
L562:        
	.line	21
;----------------------------------------------------------------------
; 1333 | return 0;                                                              
; 1336 | else                                                                   
;----------------------------------------------------------------------
        bud       L584
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L584 
L564:        
	.line	26
;----------------------------------------------------------------------
; 1338 | return 0;                                                              
; 1341 | else                                                                   
;----------------------------------------------------------------------
        bud       L584
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L584 
L566:        
	.line	30
;----------------------------------------------------------------------
; 1342 | if(nRxPos == 7)                                                        
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        cmpi      7,r0
        bned      L582
        ldieq     255,r0
        ldieq     *+fp(4),ir0
        ldieq     1219,ar0
;*      Branch Occurs to L582 
	.line	32
;----------------------------------------------------------------------
; 1344 | nRxLen = MIN(sizeof(LNWKGERIT),WORD_L(pLnWkDp->lgRxBuf.btLen)+6);      
;----------------------------------------------------------------------
        ldiu      200,r1
        and3      r0,*+ar0(ir0),r0
        addi      6,r0                  ; Unsigned
        cmpi3     r0,r1
        bhsd      L569
        ldihs     *+fp(4),ir0
        ldihs     1219,ar0
        ldihs     255,r0
;*      Branch Occurs to L569 
        bud       L570
	nop
	nop
        ldiu      200,r0
;*      Branch Occurs to L570 
L569:        
        and3      r0,*+ar0(ir0),r0
        addi      6,r0                  ; Unsigned
L570:        
        sti       r0,*+fp(2)
	.line	33
;----------------------------------------------------------------------
; 1345 | if(nRxLen > 5)                                                         
;----------------------------------------------------------------------
        cmpi      5,r0
        bls       L580
;*      Branch Occurs to L580 
	.line	35
;----------------------------------------------------------------------
; 1347 | pBuf = &pLnWkDp->lfBuf[nRxPos-1].btStx;                                
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     *-fp(2),r0
        mpyi      200,r0
        addi      *+fp(4),r0            ; Unsigned
        addi      16,r0                 ; Unsigned
        sti       r0,*+fp(3)
	.line	36
;----------------------------------------------------------------------
; 1348 | for(i=0;i<nRxLen;i++) pRxBuf[i] = WORD_L(pBuf[i]);                     
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(2),r0
        ldiu      255,r1
        bhs       L573
;*      Branch Occurs to L573 
L572:        
        ldiu      *+fp(1),ar1
        ldiu      *+fp(3),ir0
        ldiu      *-fp(3),ir1
        ldiu      ar1,ar0
        and3      r1,*+ar1(ir0),r0
        sti       r0,*+ar0(ir1)
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        ldiu      *+fp(1),r0
        cmpi      *+fp(2),r0
        blo       L572
;*      Branch Occurs to L572 
L573:        
	.line	37
;----------------------------------------------------------------------
; 1349 | if(pRxBuf[0] == STX && pRxBuf[nRxLen-1] == ETX && !Make1ByteBcc(&pRxBuf
;     | [1],nRxLen-2))                                                         
;----------------------------------------------------------------------
        ldiu      *-fp(3),ar0
        ldiu      *ar0,r0
        cmpi      2,r0
        bne       L578
;*      Branch Occurs to L578 
        ldiu      *+fp(2),ar0
        addi      *-fp(3),ar0           ; Unsigned
        ldiu      *-ar0(1),r0
        cmpi      3,r0
        bned      L578
	nop
        ldieq     1,r1
        ldieq     2,r0
;*      Branch Occurs to L578 
        addi      *-fp(3),r1            ; Unsigned
        subri     *+fp(2),r0            ; Unsigned
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        cmpi      0,r0
        subi      2,sp
        bne       L578
;*      Branch Occurs to L578 
	.line	39
;----------------------------------------------------------------------
; 1351 | return nRxLen;                                                         
; 1353 | else                                                                   
;----------------------------------------------------------------------
        bud       L584
	nop
	nop
        ldiu      *+fp(2),r0
;*      Branch Occurs to L584 
L578:        
	.line	43
;----------------------------------------------------------------------
; 1355 | return 0;                                                              
; 1358 | else                                                                   
;----------------------------------------------------------------------
        bud       L584
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L584 
L580:        
	.line	48
;----------------------------------------------------------------------
; 1360 | return 0;                                                              
; 1363 | else                                                                   
;----------------------------------------------------------------------
        bud       L584
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L584 
L582:        
	.line	53
;----------------------------------------------------------------------
; 1365 | return 0;                                                              
;----------------------------------------------------------------------
        bud       L584
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L584 
	.line	56
;----------------------------------------------------------------------
; 1368 | return 0;                                                              
;----------------------------------------------------------------------
L584:        
	.line	57
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      6,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1369,000000000h,4



	.sect	".cinit"
	.field  	1,32
	.field  	_d_LonTxData+0,32
	.field  	0,32		; _d_LonTxData @ 0

	.sect	".text"

	.global	_d_LonTxData
	.bss	_d_LonTxData,1
	.sym	_d_LonTxData,_d_LonTxData,4,2,32
	.sect	 ".text"

	.global	_user_LonWorkTx
	.sym	_user_LonWorkTx,_user_LonWorkTx,32,2,0
	.func	1373
;******************************************************************************
;* FUNCTION NAME: _user_LonWorkTx                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,ar0,ar1,fp,ir0,ir1,sp,rs,re,rc                *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 579 Auto + 0 SOE = 583 words      *
;******************************************************************************
_user_LonWorkTx:
	.sym	_pTxBuf,-2,28,9,32
	.sym	_nLen,-3,12,9,32
	.sym	_i,1,4,1,32
	.sym	_szBuf,2,50,1,16384,,512
	.sym	_szBuf2,514,50,1,2048,,64
	.sym	_pBuf,578,28,1,32
	.sym	_pLnWkDp,579,24,1,32,.fake13
	.line	1
;----------------------------------------------------------------------
; 1373 | void user_LonWorkTx(UCHAR *pTxBuf,UCHAR nLen)                          
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      579,sp
	.line	2
;----------------------------------------------------------------------
; 1375 | int i;                                                                 
; 1376 | char szBuf[512];                                                       
; 1377 | char szBuf2[64];                                                       
; 1379 | UCHAR *pBuf;                                                           
;----------------------------------------------------------------------
	.line	8
;----------------------------------------------------------------------
; 1380 | PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;                                
;----------------------------------------------------------------------
        ldiu      579,ir0
        ldiu      @CL11,r0
        sti       r0,*+fp(ir0)
	.line	10
;----------------------------------------------------------------------
; 1382 | pBuf = &pLnWkDp->lgTxBuf.btStx;                                        
;----------------------------------------------------------------------
        ldiu      579,ir1
        ldiu      1416,r0
        ldiu      578,ir0
        addi3     r0,*+fp(ir1),r0       ; Unsigned
        sti       r0,*+fp(ir0)
	.line	12
;----------------------------------------------------------------------
; 1384 | memcpy(d_LonTxDataBuf,pBuf,30);                                        
;----------------------------------------------------------------------
        ldiu      @CL103,ar0
        ldiu      *+fp(ir0),ar1
        ldiu      *ar1++(1),r0
        rpts      28                    ; Fast MEMCPY(#12)
        sti       r0,*ar0++(1)
||      ldi       *ar1++(1),r0
        sti       r0,*ar0++(1)
	.line	14
;----------------------------------------------------------------------
; 1386 | d_LonTxData++;                                                         
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_LonTxData+0,r0
        sti       r0,@_d_LonTxData+0
	.line	16
;----------------------------------------------------------------------
; 1388 | memcpy(pBuf,pTxBuf,(int)nLen);                                         
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),r0
        ldiu      *-fp(3),r1
        push      r1
        ldiu      *-fp(2),r1
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	17
;----------------------------------------------------------------------
; 1389 | LNWK_TXINTREQ();                                                       
;----------------------------------------------------------------------
        ldiu      @CL104,ar1
        ldiu      @CL104,ar0
        ldiu      1,r0
        andn3     *ar1,r0,r0
        sti       r0,*ar0
	.line	19
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      581,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1391,000000000h,579



	.sect	".cinit"
	.field  	1,32
	.field  	_d_Len+0,32
	.field  	0,32		; _d_Len @ 0

	.sect	".text"

	.global	_d_Len
	.bss	_d_Len,1
	.sym	_d_Len,_d_Len,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_nRxPos$7+0,32
	.field  	0,32		; _nRxPos$7 @ 0

	.sect	".text"

	.sect	".cinit"
	.field  	1,32
	.field  	_nOldUart2RxOneByteGapDelayTime$8+0,32
	.field  	0,32		; _nOldUart2RxOneByteGapDelayTime$8 @ 0

	.sect	".text"

	.sect	".cinit"
	.field  	1,32
	.field  	_nTimeSendCnt$11+0,32
	.field  	0,32		; _nTimeSendCnt$11 @ 0

	.sect	".text"
	.sect	 ".text"

	.global	_user_WithCncsRs232Loop
	.sym	_user_WithCncsRs232Loop,_user_WithCncsRs232Loop,32,2,0
	.func	1398
;******************************************************************************
;* FUNCTION NAME: _user_WithCncsRs232Loop                                     *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,r3,r4,r5,ar0,ar1,fp,ir0,ir1,sp,st          *
;*   Regs Saved         : r4,r5                                               *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 284 Auto + 2 SOE = 288 words      *
;******************************************************************************
_user_WithCncsRs232Loop:
	.bss	_nRxPos$7,1
	.sym	_nRxPos,_nRxPos$7,4,3,32
	.bss	_nOldUart2RxOneByteGapDelayTime$8,1
	.sym	_nOldUart2RxOneByteGapDelayTime,_nOldUart2RxOneByteGapDelayTime$8,12,3,32
	.bss	_btRx2chBuf$9,512
	.sym	_btRx2chBuf,_btRx2chBuf$9,60,3,16384,,512
	.bss	_btTx2chBuf$10,512
	.sym	_btTx2chBuf,_btTx2chBuf$10,60,3,16384,,512
	.bss	_nTimeSendCnt$11,1
	.sym	_nTimeSendCnt,_nTimeSendCnt$11,4,3,32
	.sym	_i,1,4,1,32
	.sym	_nRxLen,2,4,1,32
	.sym	_btBuf,3,60,1,8192,,256
	.sym	_sTimeBuf,259,60,1,320,,10
	.sym	_sPotoLen,269,4,1,32
	.sym	_sBcc,270,12,1,32
	.sym	_LL,271,12,1,32
	.sym	_LH,272,12,1,32
	.sym	_HL,273,12,1,32
	.sym	_HH,274,12,1,32
	.sym	_nBlkSize,275,4,1,32
	.sym	_nTempBlkEnd,276,4,1,32
	.sym	_sTxDataSize,277,4,1,32
	.sym	_pNvsram,278,28,1,32
	.sym	_pLicVerDp,279,24,1,32,.fake46
	.sym	_pLic_Cncs,280,24,1,32,.fake44
	.sym	_pCncsLicSd,281,24,1,32,.fake48
	.sym	_pCnsc_Lic_T_F,282,24,1,32,.fake49
	.sym	_pCncs_Lic_T_F_C,283,24,1,32,.fake50
	.sym	_pInfo,284,24,1,32,.fake74
	.line	1
;----------------------------------------------------------------------
; 1398 | void user_WithCncsRs232Loop()                                          
; 1400 | int i;                                                                 
; 1401 | int nRxLen;                                                            
; 1402 | UCHAR btBuf[256]; //���� ������Ʈ���� �о� ���� ����                   
; 1403 | UCHAR sTimeBuf[10];//�ð� ���� ����.                                   
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      284,sp
        push      r4
        push      r5
	.line	7
;----------------------------------------------------------------------
; 1404 | int sPotoLen = 0; //���� ��Ŷ Index.                                   
;----------------------------------------------------------------------
        ldiu      269,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	8
;----------------------------------------------------------------------
; 1405 | UCHAR sBcc = 0;                                                        
; 1406 | static int nRxPos = 0; //���� ī����.                                  
; 1407 | static UCHAR nOldUart2RxOneByteGapDelayTime = 0; //10ms �̻� ������ �ʵ
;     | Ǹ� ���� ó�� �Ѵ�.                                                    
; 1408 | static UCHAR btRx2chBuf[512]; //���� ����                              
; 1409 | static UCHAR btTx2chBuf[512]; //���� ����.                             
; 1410 | static int nTimeSendCnt = 0;                                           
; 1411 | UCHAR LL,LH,HL,HH;                                                     
;----------------------------------------------------------------------
        ldiu      270,ir0
        sti       r0,*+fp(ir0)
	.line	16
;----------------------------------------------------------------------
; 1413 | int nBlkSize = 0;                                                      
;----------------------------------------------------------------------
        ldiu      275,ir0
        sti       r0,*+fp(ir0)
	.line	17
;----------------------------------------------------------------------
; 1414 | int nTempBlkEnd = 0;                                                   
;----------------------------------------------------------------------
        ldiu      276,ir0
        sti       r0,*+fp(ir0)
	.line	18
;----------------------------------------------------------------------
; 1415 | int sTxDataSize = 0; //���ž� ����Ÿ size�� ��� �Ͽ� 128�̸� �߰� ����
;     | �� ������ ������ �̴�.                                                 
;----------------------------------------------------------------------
        ldiu      277,ir0
        sti       r0,*+fp(ir0)
	.line	20
;----------------------------------------------------------------------
; 1417 | UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;                                 
;----------------------------------------------------------------------
        ldiu      278,ir0
        ldiu      @CL87,r0
        sti       r0,*+fp(ir0)
	.line	22
;----------------------------------------------------------------------
; 1419 | PLIC_DPRAM_Ver pLicVerDp = (LIC_DPRAM_Ver *)NVSRAM_VER; //���� ���� ó�
;     | ��� ���� ���Ƿ� �������.                                              
; 1420 | PLIC_CNCS_HD pLic_Cncs;                                                
; 1421 | PCNCS_LIC_SD pCncsLicSd;                                               
; 1423 | PCNCS_LIC_T_F pCnsc_Lic_T_F;                                           
;----------------------------------------------------------------------
        ldiu      279,ir0
        ldiu      @CL2,r0
        sti       r0,*+fp(ir0)
	.line	27
;----------------------------------------------------------------------
; 1424 | PCNCS_LIC_T_F_C pCncs_Lic_T_F_C = (CNCS_LIC_T_F_C *) btRx2chBuf;
;     |                          // ���� ��Ŷ ���� �Ϸ� Ȯ�� �������� �߰�(Y.J 
;     | 2011-05-10)                                                            
; 1426 | // Fault Block Information;                                            
;----------------------------------------------------------------------
        ldiu      283,ir0
        ldiu      @CL105,r0
        sti       r0,*+fp(ir0)
	.line	30
;----------------------------------------------------------------------
; 1427 | PFAULT_INFO pInfo = NULL;                                              
; 1429 | // ����                                                                
;----------------------------------------------------------------------
        ldiu      284,ir0
        ldiu      0,r0
        sti       r0,*+fp(ir0)
	.line	33
;----------------------------------------------------------------------
; 1430 | nRxLen = user_CncsRx(btBuf,128);                                       
;----------------------------------------------------------------------
        ldiu      128,r1
        ldiu      fp,r0
        push      r1
        addi      3,r0
        push      r0
        call      _user_CncsRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(2)
	.line	34
;----------------------------------------------------------------------
; 1431 | if(nRxLen)                                                             
;----------------------------------------------------------------------
        cmpi      0,r0
        beq       L594
;*      Branch Occurs to L594 
	.line	36
;----------------------------------------------------------------------
; 1433 | if(!m_nUart2RxOneByteGapDelayTime) nRxPos = 0;                         
;----------------------------------------------------------------------
        ldi       @_m_nUart2RxOneByteGapDelayTime+0,r0
        bne       L592
;*      Branch Occurs to L592 
        ldiu      0,r0
        sti       r0,@_nRxPos$7+0
L592:        
	.line	37
;----------------------------------------------------------------------
; 1434 | m_nUart2RxOneByteGapDelayTime = 10;                                    
;----------------------------------------------------------------------
        ldiu      10,r0
        sti       r0,@_m_nUart2RxOneByteGapDelayTime+0
	.line	39
;----------------------------------------------------------------------
; 1436 | if(nRxPos + nRxLen < 511)                                              
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        addi      @_nRxPos$7+0,r0
        cmpi      511,r0
        bged      L594
        ldilt     @CL105,r0
        ldilt     fp,r1
        ldilt     *+fp(2),r2
;*      Branch Occurs to L594 
	.line	41
;----------------------------------------------------------------------
; 1438 | memcpy(&btRx2chBuf[nRxPos],btBuf,nRxLen);                              
;----------------------------------------------------------------------
        addi      @_nRxPos$7+0,r0       ; Unsigned
        addi      3,r1
        push      r2
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	42
;----------------------------------------------------------------------
; 1439 | nRxPos += nRxLen;                                                      
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        addi      @_nRxPos$7+0,r0
        sti       r0,@_nRxPos$7+0
L594:        
	.line	46
;----------------------------------------------------------------------
; 1443 | if(nOldUart2RxOneByteGapDelayTime && !m_nUart2RxOneByteGapDelayTime)   
;----------------------------------------------------------------------
        ldi       @_nOldUart2RxOneByteGapDelayTime$8+0,r0
        beq       L631
;*      Branch Occurs to L631 
        ldi       @_m_nUart2RxOneByteGapDelayTime+0,r0
        bne       L631
;*      Branch Occurs to L631 
	.line	48
;----------------------------------------------------------------------
; 1445 | pCncsLicSd = (CNCS_LIC_SD *)btRx2chBuf;                                
;----------------------------------------------------------------------
        ldiu      281,ir0
        ldiu      @CL105,r0
        sti       r0,*+fp(ir0)
	.line	50
;----------------------------------------------------------------------
; 1447 | pCnsc_Lic_T_F = (CNCS_LIC_T_F *) btRx2chBuf;                           
;----------------------------------------------------------------------
        ldiu      282,ir0
        sti       r0,*+fp(ir0)
	.line	52
;----------------------------------------------------------------------
; 1449 | if(pCncsLicSd->phHdBuf.btSoh == SOH &&                                 
; 1450 |    pCncsLicSd->btEot == EOT &&                                         
; 1451 |    sizeof(CNCS_LIC_SD) == nRxPos &&                                    
; 1452 |    (TWOBYTE_ASC2HEX(pCncsLicSd->phHdBuf.chDestDev) == LIC_DEV_NO) &&   
; 1453 |    (TWOBYTE_ASC2HEX(pCncsLicSd->sCommand) == 0x09) &&  //CNCS�� �ð� ��
;     | ��                                                                     
; 1454 |    !((Make1ByteBcc(&pCncsLicSd->phHdBuf.chSrcDev[0],nRxPos-4)^(TWOBYTE_
;     | ASC2HEX(pCncsLicSd->chChkSum)))))                                      
;----------------------------------------------------------------------
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *ar0,r0
        cmpi      1,r0
        bne       L611
;*      Branch Occurs to L611 
        ldiu      *+fp(ir0),ir0
        ldiu      283,ar0
        ldiu      *+ar0(ir0),r0
        cmpi      4,r0
        bne       L611
;*      Branch Occurs to L611 
        ldiu      284,r0
        cmpi      @_nRxPos$7+0,r0
        bne       L611
;*      Branch Occurs to L611 
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(4),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      34,r0
        subi      1,sp
        bne       L611
;*      Branch Occurs to L611 
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(15),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(16),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      9,r0
        subi      1,sp
        bne       L611
;*      Branch Occurs to L611 
        ldiu      1,r1
        ldiu      281,ir0
        ldiu      4,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$7+0,r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        ldiu      281,ir0
        subi      2,sp
        ldiu      281,ar0
        ldiu      *+fp(ir0),ir0
        ldiu      *+ar0(ir0),r1
        ldiu      r0,r5
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      281,ir0
        ldiu      282,ar0
        ldiu      *+fp(ir0),ir0
        ldiu      *+ar0(ir0),r1
        ldiu      r0,r4
        ash       4,r4
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        xor3      r5,r0,r0
        subi      1,sp
        bne       L611
;*      Branch Occurs to L611 
	.line	59
;----------------------------------------------------------------------
; 1456 | d_Len++;                                                               
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_Len+0,r0
        sti       r0,@_d_Len+0
	.line	61
;----------------------------------------------------------------------
; 1458 | for(i=0;i<VER_BDD_MAX_CNT;i++)                                         
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      24,r0
        bge       L607
;*      Branch Occurs to L607 
L603:        
	.line	63
;----------------------------------------------------------------------
; 1460 | if(!MAKE_DWORD(0x00,m_tmUtcTime.year,m_tmUtcTime.month,m_tmUtcTime.day)
;     | )                                                                      
;----------------------------------------------------------------------
        ldiu      255,r1
        ldiu      255,r0
        ldiu      255,r2
        and       @_m_tmUtcTime+5,r1
        and       @_m_tmUtcTime+4,r0
        and       @_m_tmUtcTime+3,r2
        ash       16,r1
        ash       8,r0
        or3       r1,r0,r0
        or3       r0,r2,r0
        bne       L606
;*      Branch Occurs to L606 
	.line	65
;----------------------------------------------------------------------
; 1462 | pLicVerDp->VerCnt = FALSE;                                             
;----------------------------------------------------------------------
        ldiu      279,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      0,r0
        sti       r0,*ar0
	.line	66
;----------------------------------------------------------------------
; 1463 | memset(pLicVerDp->cvbBuf[i].chVer,'0',4);                              
;----------------------------------------------------------------------
        ldiu      4,r2
        ldiu      48,r1
        ldiu      *+fp(1),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),r0       ; Unsigned
        push      r2
        addi      1,r0                  ; Unsigned
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	67
;----------------------------------------------------------------------
; 1464 | memset(pLicVerDp->cvbBuf[i].chBuildDate,'0',6);                        
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        ldiu      279,ir0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),r0       ; Unsigned
        ldiu      6,r2
        push      r2
        addi      5,r0                  ; Unsigned
        ldiu      48,r1
        push      r1
        push      r0
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	68
;----------------------------------------------------------------------
; 1465 | break;                                                                 
; 1467 | else                                                                   
;----------------------------------------------------------------------
        bu        L607
;*      Branch Occurs to L607 
L606:        
	.line	72
;----------------------------------------------------------------------
; 1469 | pLicVerDp->VerCnt = TRUE;                                              
; 1471 | // ���� �Է�                                                           
;----------------------------------------------------------------------
        ldiu      279,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      1,r0
        sti       r0,*ar0
	.line	75
;----------------------------------------------------------------------
; 1472 | pLicVerDp->cvbBuf[i].chVer[0] = pCncsLicSd->cvbBuf[i].chVer[0];        
;----------------------------------------------------------------------
        ldiu      281,ir1
        ldiu      *+fp(1),r1
        ldiu      r1,r0
        mpyi      10,r0
        mpyi      10,r1
        addi3     r0,*+fp(ir1),ar1      ; Unsigned
        addi3     r1,*+fp(ir0),ar0      ; Unsigned
        ldiu      *+ar1(41),r0
        sti       r0,*+ar0(1)
	.line	76
;----------------------------------------------------------------------
; 1473 | pLicVerDp->cvbBuf[i].chVer[1] = pCncsLicSd->cvbBuf[i].chVer[1];        
;----------------------------------------------------------------------
        ldiu      279,ir1
        ldiu      281,ir0
        ldiu      *+fp(1),r0
        ldiu      r0,r1
        mpyi      10,r0
        mpyi      10,r1
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        addi3     r0,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+ar1(42),r0
        sti       r0,*+ar0(2)
	.line	77
;----------------------------------------------------------------------
; 1474 | pLicVerDp->cvbBuf[i].chVer[2] = pCncsLicSd->cvbBuf[i].chVer[2];        
;----------------------------------------------------------------------
        ldiu      *+fp(1),r1
        ldiu      r1,r0
        mpyi      10,r0
        mpyi      10,r1
        addi3     r0,*+fp(ir0),ar1      ; Unsigned
        addi3     r1,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+ar1(43),r0
        sti       r0,*+ar0(3)
	.line	78
;----------------------------------------------------------------------
; 1475 | pLicVerDp->cvbBuf[i].chVer[3] = pCncsLicSd->cvbBuf[i].chVer[3];        
; 1477 | // ������� ��¥ �Է�                                                  
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        ldiu      r0,r1
        mpyi      10,r1
        mpyi      10,r0
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        addi3     r0,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+ar1(44),r0
        sti       r0,*+ar0(4)
	.line	81
;----------------------------------------------------------------------
; 1478 | pLicVerDp->cvbBuf[i].chBuildDate[0] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [0];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r1
        ldiu      r1,r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar1      ; Unsigned
        mpyi      10,r1
        addi3     r1,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+ar1(45),r0
        sti       r0,*+ar0(5)
	.line	82
;----------------------------------------------------------------------
; 1479 | pLicVerDp->cvbBuf[i].chBuildDate[1] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [1];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        ldiu      r0,r1
        mpyi      10,r1
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        mpyi      10,r0
        addi3     r0,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+ar1(46),r0
        sti       r0,*+ar0(6)
	.line	83
;----------------------------------------------------------------------
; 1480 | pLicVerDp->cvbBuf[i].chBuildDate[2] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [2];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        ldiu      r0,r1
        mpyi      10,r1
        ldiu      281,ir1
        ldiu      279,ir0
        mpyi      10,r0
        addi3     r1,*+fp(ir1),ar0      ; Unsigned
        addi3     r0,*+fp(ir0),ar1      ; Unsigned
        ldiu      *+ar0(47),r0
        sti       r0,*+ar1(7)
	.line	84
;----------------------------------------------------------------------
; 1481 | pLicVerDp->cvbBuf[i].chBuildDate[3] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [3];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r1
        ldiu      r1,r0
        mpyi      10,r1
        mpyi      10,r0
        addi3     r0,*+fp(ir1),ar0      ; Unsigned
        addi3     r1,*+fp(ir0),ar1      ; Unsigned
        ldiu      *+ar0(48),r0
        sti       r0,*+ar1(8)
	.line	85
;----------------------------------------------------------------------
; 1482 | pLicVerDp->cvbBuf[i].chBuildDate[4] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [4];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r1
        mpyi      10,r1
        addi3     r1,*+fp(ir1),ar0      ; Unsigned
        ldiu      *+fp(1),r0
        mpyi      10,r0
        addi3     r0,*+fp(ir0),ar1      ; Unsigned
        ldiu      *+ar0(49),r0
        sti       r0,*+ar1(9)
	.line	86
;----------------------------------------------------------------------
; 1483 | pLicVerDp->cvbBuf[i].chBuildDate[5] = pCncsLicSd->cvbBuf[i].chBuildDate
;     | [5];                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),r1
        ldiu      r1,r0
        mpyi      10,r1
        mpyi      10,r0
        ldiu      281,ir0
        ldiu      279,ir1
        addi3     r0,*+fp(ir0),ar0      ; Unsigned
        addi3     r1,*+fp(ir1),ar1      ; Unsigned
        ldiu      *+ar0(50),r0
        sti       r0,*+ar1(10)
	.line	61
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      24,r0
        blt       L603
;*      Branch Occurs to L603 
L607:        
	.line	90
;----------------------------------------------------------------------
; 1487 | if(TWOBYTE_ASC2HEX(pCncsLicSd->sWaySide) == 0x01 && !m_LIC_CNCS_Tx_Flag
;     | ) // wayside on �˸�                                                   
;----------------------------------------------------------------------
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(29),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(30),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      1,r0
        subi      1,sp
        bne       L648
;*      Branch Occurs to L648 
        ldi       @_m_LIC_CNCS_Tx_Flag+0,r0
        bne       L648
;*      Branch Occurs to L648 
	.line	92
;----------------------------------------------------------------------
; 1489 | m_nCDT_FaultDataStFlag = 1;                                            
; 1491 | //2011_03_03 ����                                                      
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,@_m_nCDT_FaultDataStFlag+0
	.line	95
;----------------------------------------------------------------------
; 1492 | m_nFaultCnt = 0;                                                // ����
;     |  ������ 0���� �ʱ�ȭ.(Y.J �߰�);                                       
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nFaultCnt+0
	.line	96
;----------------------------------------------------------------------
; 1493 | memset((UCHAR *)NVSRAM_BASE,0x00,1024); // ���� ������ "0" ���� �ʽ�ȭ
;     | �Ѵ�. �ʱ� ��ġ 0���� 1024������ �ʱ�ȭ �Ѵ�.                          
;----------------------------------------------------------------------
        ldiu      1024,r2
        ldiu      @CL106,r1
        push      r2
        push      r0
        push      r1
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	97
;----------------------------------------------------------------------
; 1494 | ClearFltBlkInfo();                                              // ����
;     |  ������ Clear�ϴ� �κ�.                                                
; 1496 | //memset(aaa_FaultBlkList, 0xFF, 1024);                                
;----------------------------------------------------------------------
        call      _ClearFltBlkInfo
                                        ; Call Occurs
	.line	101
;----------------------------------------------------------------------
; 1498 | m_nNvsramPos = 0;       //��ü ��� ���� ��ġ�� ó������               
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nNvsramPos+0
	.line	102
;----------------------------------------------------------------------
; 1499 | nRecving_Posi = 0;      //���� ���� ������ ��ġ�� ó������             
;----------------------------------------------------------------------
        sti       r0,@_nRecving_Posi+0
	.line	103
;----------------------------------------------------------------------
; 1500 | m_nLnWkTxFlag = 0;      //���� �ڵ� ������ 0���� �ʱ�ȭ                
;----------------------------------------------------------------------
        sti       r0,@_m_nLnWkTxFlag+0
	.line	105
;----------------------------------------------------------------------
; 1502 | m_nLnWkTxFlag = TWOBYTE_ASC2HEX(pCncsLicSd->sDaType);                  
; 1504 | // ���� �ð� ��û WORD -> DWORD�� ����.(2011.05.08)                    
;----------------------------------------------------------------------
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(31),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(32),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        subi      1,sp
        sti       r0,@_m_nLnWkTxFlag+0
	.line	108
;----------------------------------------------------------------------
; 1505 | m_nDateTime2SecondCnt = MAKE_DWORD( MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->s
;     | FaultTime[0]),ConvAsc2Hex(pCncsLicSd->sFaultTime[1])),                 
; 1506 | 
;     |  MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->sFaultTime[2]),ConvAsc2Hex(pCncsLicS
;     | d->sFaultTime[3])),                                                    
; 1507 | 
;     |  MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->sFaultTime[4]),ConvAsc2Hex(pCncsLicS
;     | d->sFaultTime[5])),                                                    
; 1508 | 
;     |  MAKE_BYTE(ConvAsc2Hex(pCncsLicSd->sFaultTime[6]),ConvAsc2Hex(pCncsLicS
;     | d->sFaultTime[7])));                                                   
;----------------------------------------------------------------------
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(33),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(34),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        and       15,r0
        ldiu      *+fp(ir0),ar0
        or3       r4,r0,r5
        ldiu      *+ar0(35),r0
        and       255,r5
        push      r0
        ash       24,r5
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(36),r0
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        and       15,r0
        or3       r4,r0,r1
        subi      1,sp
        and       255,r1
        ldiu      *+fp(ir0),ar0
        ash       16,r1
        ldiu      *+ar0(37),r0
        or3       r5,r1,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r5
        ldiu      *+ar0(38),r0
        ash       4,r5
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        and       15,r0
        or3       r5,r0,r1
        ldiu      *+fp(ir0),ar0
        and       255,r1
        ldiu      *+ar0(39),r0
        ash       8,r1
        or3       r4,r1,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r5
        ldiu      *+ar0(40),r0
        ash       4,r5
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r5,r0,r0
        and       255,r0
        or3       r4,r0,r0
        sti       r0,@_m_nDateTime2SecondCnt+0
        subi      1,sp
        bu        L648
;*      Branch Occurs to L648 
L611:        
	.line	114
;----------------------------------------------------------------------
; 1511 | else if(pCncs_Lic_T_F_C->phHdBuf.btSoh == SOH &&
;     |                                                                        
;     |                                           		// ���� �ð� ��û WORD -> D
;     | WORD�� ����.(2011.05.11)                                               
; 1512 |         pCncs_Lic_T_F_C->btEot == EOT &&                               
; 1513 |         sizeof(CNCS_LIC_T_F_C) == nRxPos &&                            
; 1514 |    (TWOBYTE_ASC2HEX(pCncs_Lic_T_F_C->phHdBuf.chDestDev) == LIC_DEV_NO)
;     | &&                                                                     
; 1515 |    (TWOBYTE_ASC2HEX(pCncsLicSd->sCommand) == 0x07) &&  //���� ���� Ȯ��
;     |  ����(CNCS-> LIC)                                                      
; 1516 |    !((Make1ByteBcc(&pCncs_Lic_T_F_C->phHdBuf.chSrcDev[0],nRxPos-4)^(TWO
;     | BYTE_ASC2HEX(pCncs_Lic_T_F_C->chChkSum)))))                            
; 1518 |         // Y.J 2011-05-10 ��û�� ���� Index�� ����Ͽ�, �����ϵ��� ����
;     | .                                                                      
;----------------------------------------------------------------------
        ldiu      283,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *ar0,r0
        cmpi      1,r0
        bne       L648
;*      Branch Occurs to L648 
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(23),r0
        cmpi      4,r0
        bne       L648
;*      Branch Occurs to L648 
        ldiu      24,r0
        cmpi      @_nRxPos$7+0,r0
        bne       L648
;*      Branch Occurs to L648 
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      283,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(4),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      34,r0
        subi      1,sp
        bne       L648
;*      Branch Occurs to L648 
        ldiu      281,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(15),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      281,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(16),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      7,r0
        subi      1,sp
        bne       L648
;*      Branch Occurs to L648 
        ldiu      1,r1
        ldiu      283,ir0
        ldiu      4,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$7+0,r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        ldiu      283,ir0
        subi      2,sp
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(21),r1
        ldiu      r0,r5
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      283,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(22),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        xor3      r5,r0,r0
        subi      1,sp
        bne       L648
;*      Branch Occurs to L648 
	.line	122
;----------------------------------------------------------------------
; 1519 | sPotoLen = MAKE_WORD(MAKE_BYTE(ConvAsc2Hex(pCnsc_Lic_T_F->sTEXT[0]),Con
;     | vAsc2Hex(pCnsc_Lic_T_F->sTEXT[1])),                                    
; 1520 |                      MAKE_BYTE(ConvAsc2Hex(pCnsc_Lic_T_F->sTEXT[2]),Con
;     | vAsc2Hex(pCnsc_Lic_T_F->sTEXT[3])));                                   
;----------------------------------------------------------------------
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(17),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(18),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      282,ir0
        and       15,r0
        subi      1,sp
        or3       r4,r0,r5
        ldiu      *+fp(ir0),ar0
        and       255,r5
        ldiu      *+ar0(19),r0
        ash       8,r5
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(20),r0
        push      r0
        ash       4,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      269,ir0
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        or3       r5,r0,r0
        subi      1,sp
        and       65535,r0
        sti       r0,*+fp(ir0)
	.line	124
;----------------------------------------------------------------------
; 1521 | if(sPotoLen)                                                           
; 1523 |         //aaa_FaultCnt++;                                              
; 1524 |         //aaa_FaultInx = sPotoLen;                                     
; 1526 |         // �������� ���� ���� ������ ����.                             
;----------------------------------------------------------------------
        ldi       *+fp(ir0),r0
        beq       L630
;*      Branch Occurs to L630 
	.line	130
;----------------------------------------------------------------------
; 1527 | pInfo = GetFltBlkInfo(m_chCarKind);                                    
;----------------------------------------------------------------------
        ldiu      @_m_chCarKind+0,r0
        push      r0
        call      _GetFltBlkInfo
                                        ; Call Occurs
        subi      1,sp
        ldiu      284,ir0
        sti       r0,*+fp(ir0)
	.line	132
;----------------------------------------------------------------------
; 1529 | if(pInfo != NULL)                                                      
; 1531 |         // ������ ���� ��ġ�� �̵�.                                    
;----------------------------------------------------------------------
        ldi       *+fp(ir0),r0
        beq       L629
;*      Branch Occurs to L629 
	.line	135
;----------------------------------------------------------------------
; 1532 | nRecving_Posi = pInfo->nStPosi + ((sPotoLen-1) * 128);                 
; 1534 | // ������ ���� ũ�⸦ ���ϴ� �κ�.                                     
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      269,ir0
        ldiu      284,ir1
        subi3     r0,*+fp(ir0),r0
        ldiu      *+fp(ir1),ar0
        mpyi      128,r0
        addi      *+ar0(1),r0
        sti       r0,@_nRecving_Posi+0
	.line	138
;----------------------------------------------------------------------
; 1535 | if(sPotoLen < pInfo->nTCnt) //  (sPotoLen*128) <= nTempBlkEnd)         
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        cmpi3     *ar0,*+fp(ir0)
        bged      L622
	nop
        ldige     284,ir1
        ldige     269,ir0
;*      Branch Occurs to L622 
	.line	140
;----------------------------------------------------------------------
; 1537 | nBlkSize = 128;                                                        
;----------------------------------------------------------------------
        ldiu      275,ir0
        ldiu      128,r0
        sti       r0,*+fp(ir0)
        bu        L626
;*      Branch Occurs to L626 
	.line	142
;----------------------------------------------------------------------
; 1539 | else if(sPotoLen == pInfo->nTCnt)                                      
;----------------------------------------------------------------------
L622:        
        ldiu      *+fp(ir1),ar0
        cmpi3     *ar0,*+fp(ir0)
        bned      L625
	nop
        ldine     275,ir0
        ldine     0,r0
;*      Branch Occurs to L625 
	.line	144
;----------------------------------------------------------------------
; 1541 | nBlkSize = (pInfo->nEdPosi - pInfo->nStPosi) % 128; // - ((sPotoLen - 1
;     | ) * 128);                                                              
; 1543 | else                                                                   
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar1
        ldiu      284,ir0
        ldiu      2,ar0
        ldiu      *+fp(ir0),ir1
        subi3     *+ar1,*+ar0(ir1),r1
        ldiu      r1,r0
        ldiu      275,ir0
        ash       -6,r0
        lsh       @CL107,r0
        addi3     r0,r1,r0
        andn      127,r0
        subri     r1,r0
        sti       r0,*+fp(ir0)
        bu        L626
;*      Branch Occurs to L626 
	.line	148
;----------------------------------------------------------------------
; 1545 | nBlkSize = 0;                                                          
;----------------------------------------------------------------------
L625:        
        sti       r0,*+fp(ir0)
L626:        
	.line	151
;----------------------------------------------------------------------
; 1548 | if(nBlkSize < 0) nBlkSize = 0;                                         
; 1550 | // ������ ������ ��ġ�� ����.                                          
;----------------------------------------------------------------------
        ldiu      275,ir0
        ldi       *+fp(ir0),r0
        bge       L628
;*      Branch Occurs to L628 
        ldiu      0,r0
        sti       r0,*+fp(ir0)
L628:        
	.line	154
;----------------------------------------------------------------------
; 1551 | nTempBlkEnd = pInfo->nEdPosi;                                          
;----------------------------------------------------------------------
        ldiu      284,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      276,ir0
        ldiu      *+ar0(2),r0
        sti       r0,*+fp(ir0)
L629:        
	.line	157
;----------------------------------------------------------------------
; 1554 | sTxDataSize = nBlkSize + 2;                                            
; 1556 | // ���� �����͸� �����ϴ� �κ�.                                        
;----------------------------------------------------------------------
        ldiu      2,r0
        ldiu      275,ir1
        ldiu      277,ir0
        addi3     r0,*+fp(ir1),r0
        sti       r0,*+fp(ir0)
	.line	160
;----------------------------------------------------------------------
; 1557 | user_FaultDataTx(btTx2chBuf,sTxDataSize,TRUE,sPotoLen);                
;----------------------------------------------------------------------
        ldiu      269,ir1
        ldiu      1,r3
        ldiu      @CL108,r2

        ldiu      *+fp(ir1),r0
||      ldiu      *+fp(ir0),r1

        push      r0
        push      r3
        push      r1
        push      r2
        call      _user_FaultDataTx
                                        ; Call Occurs
        subi      4,sp
	.line	161
;----------------------------------------------------------------------
; 1558 | user_CncsTx(btTx2chBuf,(sTxDataSize*2)+18);                            
; 1560 | // ���� ��, ���� ��ġ�� ������ ��ġ�� ����.                            
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      2,r1
        mpyi3     r1,*+fp(ir0),r1
        addi      18,r1
        ldiu      @CL108,r0
        push      r1
        push      r0
        call      _user_CncsTx
                                        ; Call Occurs
        subi      2,sp
	.line	164
;----------------------------------------------------------------------
; 1561 | nRecving_Posi = nTempBlkEnd;                                           
; 1563 | else                                                                   
; 1564 | //�ٷ� ���� �ڵ尡 ���� �ɼ� �ִ�.                                     
;----------------------------------------------------------------------
        ldiu      276,ir0
        ldiu      *+fp(ir0),r0
        sti       r0,@_nRecving_Posi+0
        bu        L648
;*      Branch Occurs to L648 
L630:        
	.line	169
;----------------------------------------------------------------------
; 1566 | user_FtpEnd_CarNumFun();                                               
; 1570 | else // ����Ÿ ����                                                    
;----------------------------------------------------------------------
        call      _user_FtpEnd_CarNumFun
                                        ; Call Occurs
        bu        L648
;*      Branch Occurs to L648 
L631:        
	.line	175
;----------------------------------------------------------------------
; 1572 | if(m_nTxDbg1msTimer > 150)                                             
; 1574 |         //���� ���� ����.                                              
;----------------------------------------------------------------------
        ldiu      @_m_nTxDbg1msTimer+0,r0
        cmpi      150,r0
        bls       L648
;*      Branch Occurs to L648 
	.line	178
;----------------------------------------------------------------------
; 1575 | if(m_LIC_CNCS_Tx_Flag)                                                 
;----------------------------------------------------------------------
        ldi       @_m_LIC_CNCS_Tx_Flag+0,r0
        beq       L644
;*      Branch Occurs to L644 
	.line	180
;----------------------------------------------------------------------
; 1577 | m_nTxDbg1msTimer = 0;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nTxDbg1msTimer+0
	.line	182
;----------------------------------------------------------------------
; 1579 | m_LIC_CNCS_TX_DelyTime++;                                              
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_LIC_CNCS_TX_DelyTime+0,r0
        sti       r0,@_m_LIC_CNCS_TX_DelyTime+0
	.line	184
;----------------------------------------------------------------------
; 1581 | if(m_LIC_CNCS_TX_DelyTime > 50){m_bLnWkFtpEndFlag = TRUE;}             
;----------------------------------------------------------------------
        cmpi      50,r0
        ble       L635
;*      Branch Occurs to L635 
        ldiu      1,r0
        sti       r0,@_m_bLnWkFtpEndFlag+0
L635:        
	.line	186
;----------------------------------------------------------------------
; 1583 | if((m_nNvsramPos !=  (nRecving_Posi)) && (m_nNvsramPos >= (nRecving_Pos
;     | i+128)))                                                               
;----------------------------------------------------------------------
        ldiu      @_m_nNvsramPos+0,r0
        cmpi      @_nRecving_Posi+0,r0
        beqd      L640
	nop
        ldine     128,r0
        ldine     @_m_nNvsramPos+0,r1
;*      Branch Occurs to L640 
        addi      @_nRecving_Posi+0,r0  ; Unsigned
        cmpi3     r0,r1
        blo       L640
;*      Branch Occurs to L640 
	.line	188
;----------------------------------------------------------------------
; 1585 | m_nFaultCnt++;                                                         
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nFaultCnt+0,r0
        sti       r0,@_m_nFaultCnt+0
	.line	189
;----------------------------------------------------------------------
; 1586 | if(m_nFaultCnt == 1)                                                   
;----------------------------------------------------------------------
        cmpi      1,r0
        bne       L639
;*      Branch Occurs to L639 
	.line	190
;----------------------------------------------------------------------
; 1587 | SetFltBlkStPos(m_chCarKind, nRecving_Posi);
;     |                                          // ù��° ������ ���, ���� ��
;     | ���� ���� ��ġ�� ���.                                                 
;----------------------------------------------------------------------
        ldiu      @_nRecving_Posi+0,r0
        push      r0
        ldiu      @_m_chCarKind+0,r0
        push      r0
        call      _SetFltBlkStPos
                                        ; Call Occurs
        subi      2,sp
L639:        
	.line	192
;----------------------------------------------------------------------
; 1589 | sTxDataSize = 128 + 2;                                                 
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      130,r0
        sti       r0,*+fp(ir0)
	.line	194
;----------------------------------------------------------------------
; 1591 | user_FaultDataTx(btTx2chBuf,sTxDataSize,FALSE,0);                      
;----------------------------------------------------------------------
        ldiu      0,r1
        ldiu      @CL108,r2
        ldiu      *+fp(ir0),r3
        ldiu      0,r0
        push      r1
        push      r0
        push      r3
        push      r2
        call      _user_FaultDataTx
                                        ; Call Occurs
        subi      4,sp
	.line	196
;----------------------------------------------------------------------
; 1593 | nRecving_Posi += 128;                                                  
;----------------------------------------------------------------------
        ldiu      128,r0
        addi      @_nRecving_Posi+0,r0
        sti       r0,@_nRecving_Posi+0
	.line	198
;----------------------------------------------------------------------
; 1595 | user_CncsTx(btTx2chBuf,(sTxDataSize*2)+18);                            
; 1597 | else                                                                   
; 1598 | //�ٷ� ���� �ڵ尡 ���� �ɼ� �ִ�.                                     
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      2,r0
        mpyi3     r0,*+fp(ir0),r0
        addi      18,r0
        push      r0
        ldiu      @CL108,r1
        push      r1
        call      _user_CncsTx
                                        ; Call Occurs
        subi      2,sp
        bu        L648
;*      Branch Occurs to L648 
L640:        
	.line	202
;----------------------------------------------------------------------
; 1599 | if(m_bLnWkFtpEndFlag)                                                  
;----------------------------------------------------------------------
        ldi       @_m_bLnWkFtpEndFlag+0,r0
        beq       L648
;*      Branch Occurs to L648 
	.line	204
;----------------------------------------------------------------------
; 1601 | m_nFaultCnt++;                                                         
; 1602 | //aaa_CarAFautlCnt = m_nFaultCnt;                                      
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nFaultCnt+0,r0
        sti       r0,@_m_nFaultCnt+0
	.line	207
;----------------------------------------------------------------------
; 1604 | if(m_nFaultCnt == 1)                                                   
;----------------------------------------------------------------------
        cmpi      1,r0
        bne       L643
;*      Branch Occurs to L643 
	.line	208
;----------------------------------------------------------------------
; 1605 | SetFltBlkStPos(m_chCarKind, nRecving_Posi);
;     |                                          // ù��° ������ ���, ���� ��
;     | ���� ���� ��ġ�� ���.                                                 
; 1607 | // ���� ������ �����ϴ� �κ�.                                          
;----------------------------------------------------------------------
        ldiu      @_nRecving_Posi+0,r0
        push      r0
        ldiu      @_m_chCarKind+0,r0
        push      r0
        call      _SetFltBlkStPos
                                        ; Call Occurs
        subi      2,sp
L643:        
	.line	211
;----------------------------------------------------------------------
; 1608 | SetFltBlkEdInfo(m_chCarKind, m_nNvsramPos, m_nFaultCnt);               
;----------------------------------------------------------------------
        ldiu      @_m_nFaultCnt+0,r0
        ldiu      @_m_nNvsramPos+0,r1
        push      r0
        push      r1
        ldiu      @_m_chCarKind+0,r0
        push      r0
        call      _SetFltBlkEdInfo
                                        ; Call Occurs
        subi      3,sp
	.line	213
;----------------------------------------------------------------------
; 1610 | sTxDataSize = (m_nNvsramPos - nRecving_Posi) + 2;                      
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      @_nRecving_Posi+0,r0
        subri     @_m_nNvsramPos+0,r0   ; Unsigned
        addi      2,r0                  ; Unsigned
        sti       r0,*+fp(ir0)
	.line	214
;----------------------------------------------------------------------
; 1611 | user_FaultDataTx(btTx2chBuf,sTxDataSize,TRUE,0);                       
;----------------------------------------------------------------------
        ldiu      0,r1
        ldiu      @CL108,r2
        ldiu      *+fp(ir0),r3
        push      r1
        ldiu      1,r0
        push      r0
        push      r3
        push      r2
        call      _user_FaultDataTx
                                        ; Call Occurs
        subi      4,sp
	.line	215
;----------------------------------------------------------------------
; 1612 | nRecving_Posi += (sTxDataSize-2);                                      
; 1614 | // user_FtpEnd_CarNumFun();                                            
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      *+fp(ir0),r0
        addi      @_nRecving_Posi+0,r0
        subi      2,r0
        sti       r0,@_nRecving_Posi+0
	.line	219
;----------------------------------------------------------------------
; 1616 | user_CncsTx(btTx2chBuf,(sTxDataSize*2)+18);                            
;----------------------------------------------------------------------
        ldiu      2,r1
        mpyi3     r1,*+fp(ir0),r1
        addi      18,r1
        push      r1
        ldiu      @CL108,r0
        push      r0
        call      _user_CncsTx
                                        ; Call Occurs
        subi      2,sp
	.line	221
;----------------------------------------------------------------------
; 1618 | m_LIC_CNCS_Tx_Flag = FALSE;                                            
; 1621 | else                                                                   
; 1622 | //�ð� ���� ��û.                                                      
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_LIC_CNCS_Tx_Flag+0
        bu        L648
;*      Branch Occurs to L648 
L644:        
	.line	226
;----------------------------------------------------------------------
; 1623 | if(m_nTxDbg1msTimer > 1000)                                            
;----------------------------------------------------------------------
        ldiu      @_m_nTxDbg1msTimer+0,r0
        cmpi      1000,r0
        bls       L648
;*      Branch Occurs to L648 
	.line	228
;----------------------------------------------------------------------
; 1625 | m_nTxDbg1msTimer = 0;                                                  
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nTxDbg1msTimer+0
	.line	230
;----------------------------------------------------------------------
; 1627 | nTimeSendCnt++;                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_nTimeSendCnt$11+0,r0
        sti       r0,@_nTimeSendCnt$11+0
	.line	231
;----------------------------------------------------------------------
; 1628 | nTimeSendCnt = nTimeSendCnt%255;                                       
;----------------------------------------------------------------------
        ldiu      255,r1
        call      MOD_I30
                                        ; Call Occurs
        sti       r0,@_nTimeSendCnt$11+0
	.line	233
;----------------------------------------------------------------------
; 1630 | pCnsc_Lic_T_F = (CNCS_LIC_T_F *) btTx2chBuf;                           
;----------------------------------------------------------------------
        ldiu      282,ir0
        ldiu      @CL108,r0
        sti       r0,*+fp(ir0)
	.line	235
;----------------------------------------------------------------------
; 1632 | sTxDataSize = 4;                                                       
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      4,r0
        sti       r0,*+fp(ir0)
	.line	237
;----------------------------------------------------------------------
; 1634 | pCnsc_Lic_T_F->phHdBuf.btSoh =  0x01;                                  
;----------------------------------------------------------------------
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      1,r0
        sti       r0,*ar0
	.line	238
;----------------------------------------------------------------------
; 1635 | pCnsc_Lic_T_F->phHdBuf.chSrcDev[0] =  ConvHex2Asc(BYTE_H(0x11));       
;----------------------------------------------------------------------
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(1)
	.line	239
;----------------------------------------------------------------------
; 1636 | pCnsc_Lic_T_F->phHdBuf.chSrcDev[1] =  ConvHex2Asc(BYTE_L(0x11));       
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(2)
	.line	240
;----------------------------------------------------------------------
; 1637 | pCnsc_Lic_T_F->phHdBuf.chDestDev[0] =  ConvHex2Asc(BYTE_H(0x15));      
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(3)
	.line	241
;----------------------------------------------------------------------
; 1638 | pCnsc_Lic_T_F->phHdBuf.chDestDev[1] =  ConvHex2Asc(BYTE_L(0x15));      
;----------------------------------------------------------------------
        ldiu      5,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(4)
	.line	243
;----------------------------------------------------------------------
; 1640 | pCnsc_Lic_T_F->phHdBuf.chMsgCnt[0] = ConvHex2Asc(BYTE_H(WORD_H(nTimeSen
;     | dCnt)));                                                               
;----------------------------------------------------------------------
        ldiu      @_nTimeSendCnt$11+0,r0
        ash       -8,r0
        and       255,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(5)
	.line	244
;----------------------------------------------------------------------
; 1641 | pCnsc_Lic_T_F->phHdBuf.chMsgCnt[1] = ConvHex2Asc(BYTE_L(WORD_H(nTimeSen
;     | dCnt)));                                                               
;----------------------------------------------------------------------
        ldiu      @_nTimeSendCnt$11+0,r0
        ash       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(6)
	.line	245
;----------------------------------------------------------------------
; 1642 | pCnsc_Lic_T_F->phHdBuf.chMsgCnt[2] = ConvHex2Asc(BYTE_H(WORD_L(nTimeSen
;     | dCnt)));                                                               
;----------------------------------------------------------------------
        ldiu      255,r0
        and       @_nTimeSendCnt$11+0,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(7)
	.line	246
;----------------------------------------------------------------------
; 1643 | pCnsc_Lic_T_F->phHdBuf.chMsgCnt[3] = ConvHex2Asc(BYTE_L(WORD_L(nTimeSen
;     | dCnt)));                                                               
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_nTimeSendCnt$11+0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(8)
	.line	248
;----------------------------------------------------------------------
; 1645 | pCnsc_Lic_T_F->phHdBuf.chCmdCode[0] = ConvHex2Asc(BYTE_H(0x10));       
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(9)
	.line	249
;----------------------------------------------------------------------
; 1646 | pCnsc_Lic_T_F->phHdBuf.chCmdCode[1] = ConvHex2Asc(BYTE_L(0x10));       
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(10)
	.line	251
;----------------------------------------------------------------------
; 1648 | pCnsc_Lic_T_F->phHdBuf.chDataLen[0] = ConvHex2Asc(BYTE_H(WORD_H(sTxData
;     | Size))); // ����                                                       
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      -8,r0
        ash3      r0,*+fp(ir0),r0
        and       255,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(11)
	.line	252
;----------------------------------------------------------------------
; 1649 | pCnsc_Lic_T_F->phHdBuf.chDataLen[1] = ConvHex2Asc(BYTE_L(WORD_H(sTxData
;     | Size))); // ����                                                       
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      -8,r0
        ash3      r0,*+fp(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(12)
	.line	253
;----------------------------------------------------------------------
; 1650 | pCnsc_Lic_T_F->phHdBuf.chDataLen[2] = ConvHex2Asc(BYTE_H(WORD_L(sTxData
;     | Size))); // ����                                                       
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      255,r0
        and3      r0,*+fp(ir0),r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(13)
	.line	254
;----------------------------------------------------------------------
; 1651 | pCnsc_Lic_T_F->phHdBuf.chDataLen[3] = ConvHex2Asc(BYTE_L(WORD_L(sTxData
;     | Size))); // ����                                                       
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      15,r0
        and3      r0,*+fp(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(14)
	.line	256
;----------------------------------------------------------------------
; 1653 | pCnsc_Lic_T_F->sCommand[0] = ConvHex2Asc(BYTE_H(0x08));                
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(15)
	.line	257
;----------------------------------------------------------------------
; 1654 | pCnsc_Lic_T_F->sCommand[1] = ConvHex2Asc(BYTE_L(0x08));                
;----------------------------------------------------------------------
        ldiu      8,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(16)
	.line	259
;----------------------------------------------------------------------
; 1656 | pCnsc_Lic_T_F->sTEXT[0] = ConvHex2Asc(BYTE_H(WORD_H(m_wCarNo)));  //���
;     | � ��ȣ ����                                                            
;----------------------------------------------------------------------
        ldiu      @_m_wCarNo+0,r0
        ash       -8,r0
        and       255,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(17)
	.line	260
;----------------------------------------------------------------------
; 1657 | pCnsc_Lic_T_F->sTEXT[1] = ConvHex2Asc(BYTE_L(WORD_H(m_wCarNo)));  //���
;     | � ��ȣ ����                                                            
;----------------------------------------------------------------------
        ldiu      @_m_wCarNo+0,r0
        ash       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(18)
	.line	261
;----------------------------------------------------------------------
; 1658 | pCnsc_Lic_T_F->sTEXT[2] = ConvHex2Asc(BYTE_H(WORD_L(m_wCarNo)));  //���
;     | � ��ȣ ����                                                            
;----------------------------------------------------------------------
        ldiu      255,r0
        and       @_m_wCarNo+0,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(19)
	.line	262
;----------------------------------------------------------------------
; 1659 | pCnsc_Lic_T_F->sTEXT[3] = ConvHex2Asc(BYTE_L(WORD_L(m_wCarNo)));  //���
;     | � ��ȣ ����                                                            
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_m_wCarNo+0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(20)
	.line	264
;----------------------------------------------------------------------
; 1661 | pCnsc_Lic_T_F->chContactSignalBuf[0] = ConvHex2Asc(BYTE_H(m_btCttSignal
;     | A | m_btCttSignalB));                                                  
;----------------------------------------------------------------------
        ldiu      @_m_btCttSignalB+0,r0
        or        @_m_btCttSignalA+0,r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(21)
	.line	265
;----------------------------------------------------------------------
; 1662 | pCnsc_Lic_T_F->chContactSignalBuf[1] = ConvHex2Asc(BYTE_L(m_btCttSignal
;     | A | m_btCttSignalB));                                                  
;----------------------------------------------------------------------
        ldiu      @_m_btCttSignalB+0,r0
        or        @_m_btCttSignalA+0,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      282,ir0
        subi      1,sp
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(22)
	.line	267
;----------------------------------------------------------------------
; 1664 | sBcc = Make1ByteBcc(&pCnsc_Lic_T_F->phHdBuf.chSrcDev[0],(sTxDataSize*2)
;     | +14);                                                                  
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      2,r0
        ldiu      277,ir1
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        mpyi3     r0,*+fp(ir1),r0
        addi      14,r0
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        ldiu      270,ir0
        subi      2,sp
        sti       r0,*+fp(ir0)
	.line	269
;----------------------------------------------------------------------
; 1666 | pCnsc_Lic_T_F->chChkSum[0] = ConvHex2Asc(BYTE_H(sBcc));                
;----------------------------------------------------------------------
        ldiu      -4,r0
        lsh3      r0,*+fp(ir0),r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(23)
	.line	270
;----------------------------------------------------------------------
; 1667 | pCnsc_Lic_T_F->chChkSum[1] = ConvHex2Asc(BYTE_L(sBcc));                
;----------------------------------------------------------------------
        ldiu      270,ir0
        ldiu      15,r0
        and3      r0,*+fp(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      282,ir0
        ldiu      *+fp(ir0),ar0
        sti       r0,*+ar0(24)
	.line	272
;----------------------------------------------------------------------
; 1669 | pCnsc_Lic_T_F->btEot = 0x04;                                           
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      4,r0
        sti       r0,*+ar0(25)
	.line	274
;----------------------------------------------------------------------
; 1671 | user_CncsTx(&pCnsc_Lic_T_F->phHdBuf.btSoh,(sTxDataSize*2)+18);         
;----------------------------------------------------------------------
        ldiu      277,ir0
        ldiu      2,r0
        mpyi3     r0,*+fp(ir0),r0
        addi      18,r0
        ldiu      282,ir1
        push      r0
        ldiu      *+fp(ir1),r0
        push      r0
        call      _user_CncsTx
                                        ; Call Occurs
        subi      2,sp
L648:        
	.line	279
;----------------------------------------------------------------------
; 1676 | nOldUart2RxOneByteGapDelayTime = m_nUart2RxOneByteGapDelayTime;        
;----------------------------------------------------------------------
        ldiu      @_m_nUart2RxOneByteGapDelayTime+0,r0
        sti       r0,@_nOldUart2RxOneByteGapDelayTime$8+0
	.line	280
        pop       r5
        ldiu      *-fp(1),bk
        pop       r4
        ldiu      *fp,fp
        subi      286,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1677,000000030h,284


	.sect	 ".text"

	.global	_ClearFltBlkInfo
	.sym	_ClearFltBlkInfo,_ClearFltBlkInfo,32,2,0
	.func	1680
;******************************************************************************
;* FUNCTION NAME: _ClearFltBlkInfo                                            *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,fp,sp                                      *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 0 Auto + 0 SOE = 2 words          *
;******************************************************************************
_ClearFltBlkInfo:
	.line	1
;----------------------------------------------------------------------
; 1680 | void ClearFltBlkInfo()                                                 
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	3
;----------------------------------------------------------------------
; 1682 | memset(&m_tFaultInfo, 0x00, sizeof(m_tFaultInfo));
;     |  // ���� ���� ����.                                                    
;----------------------------------------------------------------------
        ldiu      6,r2
        ldiu      0,r0
        ldiu      @CL109,r1
        push      r2
        push      r0
        push      r1
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	4
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      2,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1683,000000000h,0


	.sect	 ".text"

	.global	_SetFltBlkStPos
	.sym	_SetFltBlkStPos,_SetFltBlkStPos,32,2,0
	.func	1686
;******************************************************************************
;* FUNCTION NAME: _SetFltBlkStPos                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,ar0,fp,sp,st                                     *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 1 Auto + 0 SOE = 5 words          *
;******************************************************************************
_SetFltBlkStPos:
	.sym	_chCarKind,-2,2,9,32
	.sym	_nStPosi,-3,4,9,32
	.sym	_pInfo,1,24,1,32,.fake74
	.line	1
;----------------------------------------------------------------------
; 1686 | void SetFltBlkStPos(char chCarKind, int nStPosi)                       
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      1,sp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 1688 | PFAULT_INFO pInfo = GetFltBlkInfo(chCarKind);                          
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        push      r0
        call      _GetFltBlkInfo
                                        ; Call Occurs
        subi      1,sp
        sti       r0,*+fp(1)
	.line	5
;----------------------------------------------------------------------
; 1690 | if(pInfo != NULL)                                                      
;----------------------------------------------------------------------
        cmpi      0,r0
        beq       L656
;*      Branch Occurs to L656 
	.line	6
;----------------------------------------------------------------------
; 1691 | pInfo->nStPosi = nStPosi;
;     |                  // ���� ���� ��ġ�� ����.                             
;----------------------------------------------------------------------
        ldiu      r0,ar0
        ldiu      *-fp(3),r0
        sti       r0,*+ar0(1)
L656:        
	.line	7
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      3,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1692,000000000h,1


	.sect	 ".text"

	.global	_SetFltBlkEdInfo
	.sym	_SetFltBlkEdInfo,_SetFltBlkEdInfo,32,2,0
	.func	1695
;******************************************************************************
;* FUNCTION NAME: _SetFltBlkEdInfo                                            *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,ar0,fp,sp,st                                     *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 3 Parm + 1 Auto + 0 SOE = 6 words          *
;******************************************************************************
_SetFltBlkEdInfo:
	.sym	_chCarKind,-2,2,9,32
	.sym	_nEndPosi,-3,4,9,32
	.sym	_nFltTCnt,-4,4,9,32
	.sym	_pInfo,1,24,1,32,.fake74
	.line	1
;----------------------------------------------------------------------
; 1695 | void SetFltBlkEdInfo(char chCarKind, int nEndPosi, int nFltTCnt)       
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      1,sp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 1697 | PFAULT_INFO pInfo = GetFltBlkInfo(chCarKind);                          
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        push      r0
        call      _GetFltBlkInfo
                                        ; Call Occurs
        subi      1,sp
        sti       r0,*+fp(1)
	.line	5
;----------------------------------------------------------------------
; 1699 | if(pInfo != NULL)                                                      
;----------------------------------------------------------------------
        cmpi      0,r0
        beq       L660
;*      Branch Occurs to L660 
	.line	7
;----------------------------------------------------------------------
; 1701 | pInfo->nTCnt = nFltTCnt;
;     |                          // ���� ��ü ������ ���.                     
;----------------------------------------------------------------------
        ldiu      r0,ar0
        ldiu      *-fp(4),r0
        sti       r0,*ar0
	.line	8
;----------------------------------------------------------------------
; 1702 | pInfo->nEdPosi = nEndPosi;
;     |                          // ���� ������ ��ġ�� ����.                   
;----------------------------------------------------------------------
        ldiu      *+fp(1),ar0
        ldiu      *-fp(3),r0
        sti       r0,*+ar0(2)
L660:        
	.line	10
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      3,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1704,000000000h,1


	.sect	 ".text"

	.global	_GetFltBlkInfo
	.sym	_GetFltBlkInfo,_GetFltBlkInfo,104,2,0,.fake74
	.func	1707
;******************************************************************************
;* FUNCTION NAME: _GetFltBlkInfo                                              *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,st                                               *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 1 Parm + 1 Auto + 0 SOE = 4 words          *
;******************************************************************************
_GetFltBlkInfo:
	.sym	_chCarKind,-2,2,9,32
	.sym	_nIdx,1,4,1,32
	.line	1
;----------------------------------------------------------------------
; 1707 | PFAULT_INFO GetFltBlkInfo(char chCarKind)                              
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      1,sp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 1709 | int nIdx = chCarKind - 'A';                                            
;----------------------------------------------------------------------
        ldiu      65,r0
        subri     *-fp(2),r0
        sti       r0,*+fp(1)
	.line	5
;----------------------------------------------------------------------
; 1711 | if(nIdx < eCDT_MAXIMUM)                                                
;----------------------------------------------------------------------
        cmpi      2,r0
        bge       L664
;*      Branch Occurs to L664 
	.line	6
;----------------------------------------------------------------------
; 1712 | return &m_tFaultInfo[nIdx];                                            
;----------------------------------------------------------------------
        bud       L665
	nop
        mpyi      3,r0
        addi      @CL109,r0             ; Unsigned
;*      Branch Occurs to L665 
L664:        
	.line	8
;----------------------------------------------------------------------
; 1714 | return NULL;                                                           
;----------------------------------------------------------------------
        ldiu      0,r0
L665:        
	.line	9
        ldiu      *-fp(1),r1
        ldiu      *fp,fp
        subi      3,sp
        bu        r1
;*      Branch Occurs to r1 
	.endfunc	1715,000000000h,1


	.sect	 ".text"

	.global	_GetFltBlkStPos
	.sym	_GetFltBlkStPos,_GetFltBlkStPos,36,2,0
	.func	1718
;******************************************************************************
;* FUNCTION NAME: _GetFltBlkStPos                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,ar0,fp,sp,st                                     *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 1 Parm + 2 Auto + 0 SOE = 5 words          *
;******************************************************************************
_GetFltBlkStPos:
	.sym	_chCarKind,-2,2,9,32
	.sym	_nStPos,1,4,1,32
	.sym	_pInfo,2,24,1,32,.fake74
	.line	1
;----------------------------------------------------------------------
; 1718 | int GetFltBlkStPos(char chCarKind)                                     
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      2,sp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 1720 | int nStPos = -1;                                                       
;----------------------------------------------------------------------
        ldiu      -1,r0
        sti       r0,*+fp(1)
	.line	4
;----------------------------------------------------------------------
; 1721 | PFAULT_INFO pInfo = GetFltBlkInfo(chCarKind);                          
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        push      r0
        call      _GetFltBlkInfo
                                        ; Call Occurs
        subi      1,sp
        sti       r0,*+fp(2)
	.line	6
;----------------------------------------------------------------------
; 1723 | if(pInfo != NULL)                                                      
;----------------------------------------------------------------------
        cmpi      0,r0
        beq       L669
;*      Branch Occurs to L669 
	.line	7
;----------------------------------------------------------------------
; 1724 | nStPos = pInfo->nStPosi;                                               
;----------------------------------------------------------------------
        ldiu      r0,ar0
        ldiu      *+ar0(1),r0
        sti       r0,*+fp(1)
L669:        
	.line	9
;----------------------------------------------------------------------
; 1726 | return nStPos;                                                         
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
	.line	10
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      4,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1727,000000000h,2



	.sect	".cinit"
	.field  	1,32
	.field  	_d_LicTxEndCnt+0,32
	.field  	0,32		; _d_LicTxEndCnt @ 0

	.sect	".text"

	.global	_d_LicTxEndCnt
	.bss	_d_LicTxEndCnt,1
	.sym	_d_LicTxEndCnt,_d_LicTxEndCnt,4,2,32
	.sect	 ".text"

	.global	_user_FaultDataTx
	.sym	_user_FaultDataTx,_user_FaultDataTx,32,2,0
	.func	1731
;******************************************************************************
;* FUNCTION NAME: _user_FaultDataTx                                           *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,ar0,fp,sp,st                               *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 4 Parm + 3 Auto + 0 SOE = 9 words          *
;******************************************************************************
_user_FaultDataTx:
	.sym	_pTxBuf,-2,28,9,32
	.sym	_nLen,-3,12,9,32
	.sym	_nEndFlag,-4,12,9,32
	.sym	_nFltIdx,-5,4,9,32
	.sym	_sTempData,1,12,1,32
	.sym	_pLic_Cncs,2,24,1,32,.fake44
	.sym	_pNvsram,3,28,1,32
	.line	1
;----------------------------------------------------------------------
; 1731 | void user_FaultDataTx(UCHAR *pTxBuf,UCHAR nLen,UCHAR nEndFlag,int nFltI
;     | dx)                                                                    
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      3,sp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 1733 | UCHAR sTempData = 0;                                                   
; 1734 | PLIC_CNCS_HD pLic_Cncs;                                                
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
	.line	5
;----------------------------------------------------------------------
; 1735 | UCHAR *pNvsram = (UCHAR *)NVSRAM_BASE;                                 
;----------------------------------------------------------------------
        ldiu      @CL87,r0
        sti       r0,*+fp(3)
	.line	7
;----------------------------------------------------------------------
; 1737 | pLic_Cncs =(LIC_CNCS_HD *) pTxBuf;                                     
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        sti       r0,*+fp(2)
	.line	9
;----------------------------------------------------------------------
; 1739 | pLic_Cncs->phHdBuf.btSoh = 0x01;                                       
;----------------------------------------------------------------------
        ldiu      r0,ar0
        ldiu      1,r0
        sti       r0,*ar0
	.line	10
;----------------------------------------------------------------------
; 1740 | pLic_Cncs->phHdBuf.chSrcDev[0] =  ConvHex2Asc(BYTE_H(0x11));           
;----------------------------------------------------------------------
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(1)
	.line	11
;----------------------------------------------------------------------
; 1741 | pLic_Cncs->phHdBuf.chSrcDev[1] =  ConvHex2Asc(BYTE_L(0x11));           
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(2)
	.line	12
;----------------------------------------------------------------------
; 1742 | pLic_Cncs->phHdBuf.chDestDev[0] =  ConvHex2Asc(BYTE_H(0x15));          
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(3)
	.line	13
;----------------------------------------------------------------------
; 1743 | pLic_Cncs->phHdBuf.chDestDev[1] =  ConvHex2Asc(BYTE_L(0x15));          
; 1745 | // ���� �ε����� �űԷ� ����(Y.J ����)                                 
;----------------------------------------------------------------------
        ldiu      5,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(4)
	.line	16
;----------------------------------------------------------------------
; 1746 | if(!nFltIdx) nFltIdx = m_nFaultCnt;                                    
;----------------------------------------------------------------------
        ldi       *-fp(5),r0
        bne       L674
;*      Branch Occurs to L674 
        ldiu      @_m_nFaultCnt+0,r0
        sti       r0,*-fp(5)
L674:        
	.line	18
;----------------------------------------------------------------------
; 1748 | pLic_Cncs->phHdBuf.chMsgCnt[0] = ConvHex2Asc(BYTE_H(WORD_H(nFltIdx))); 
;----------------------------------------------------------------------
        ldiu      *-fp(5),r0
        ash       -8,r0
        and       255,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(5)
	.line	19
;----------------------------------------------------------------------
; 1749 | pLic_Cncs->phHdBuf.chMsgCnt[1] = ConvHex2Asc(BYTE_L(WORD_H(nFltIdx))); 
;----------------------------------------------------------------------
        ldiu      *-fp(5),r0
        ash       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(6)
	.line	20
;----------------------------------------------------------------------
; 1750 | pLic_Cncs->phHdBuf.chMsgCnt[2] = ConvHex2Asc(BYTE_H(WORD_L(nFltIdx))); 
;----------------------------------------------------------------------
        ldiu      255,r0
        and       *-fp(5),r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(7)
	.line	21
;----------------------------------------------------------------------
; 1751 | pLic_Cncs->phHdBuf.chMsgCnt[3] = ConvHex2Asc(BYTE_L(WORD_L(nFltIdx))); 
;----------------------------------------------------------------------
        ldiu      15,r0
        and       *-fp(5),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(8)
	.line	23
;----------------------------------------------------------------------
; 1753 | pLic_Cncs->phHdBuf.chCmdCode[0] = ConvHex2Asc(BYTE_H(0x10));           
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(9)
	.line	24
;----------------------------------------------------------------------
; 1754 | pLic_Cncs->phHdBuf.chCmdCode[1] = ConvHex2Asc(BYTE_L(0x10));           
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(10)
	.line	26
;----------------------------------------------------------------------
; 1756 | pLic_Cncs->phHdBuf.chDataLen[0] = ConvHex2Asc(BYTE_H(WORD_H(nLen)));   
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        lsh       -8,r0
        and       255,r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(11)
	.line	27
;----------------------------------------------------------------------
; 1757 | pLic_Cncs->phHdBuf.chDataLen[1] = ConvHex2Asc(BYTE_L(WORD_H(nLen)));   
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        lsh       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(12)
	.line	28
;----------------------------------------------------------------------
; 1758 | pLic_Cncs->phHdBuf.chDataLen[2] = ConvHex2Asc(BYTE_H(WORD_L(nLen)));   
;----------------------------------------------------------------------
        ldiu      255,r0
        and       *-fp(3),r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(13)
	.line	29
;----------------------------------------------------------------------
; 1759 | pLic_Cncs->phHdBuf.chDataLen[3] = ConvHex2Asc(BYTE_L(WORD_L(nLen)));   
;----------------------------------------------------------------------
        ldiu      15,r0
        and       *-fp(3),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(14)
	.line	31
;----------------------------------------------------------------------
; 1761 | if(nEndFlag)                                                           
;----------------------------------------------------------------------
        ldi       *-fp(4),r0
        beq       L676
;*      Branch Occurs to L676 
	.line	33
;----------------------------------------------------------------------
; 1763 | pLic_Cncs->sCommand[0] = ConvHex2Asc(BYTE_H(0x06));//���� ���� ���� ��.
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(15)
	.line	34
;----------------------------------------------------------------------
; 1764 | pLic_Cncs->sCommand[1] = ConvHex2Asc(BYTE_L(0x06));//���� ���� ���� ��.
;----------------------------------------------------------------------
        ldiu      6,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(16)
	.line	36
;----------------------------------------------------------------------
; 1766 | d_LicTxEndCnt++;                                                       
; 1768 | else                                                                   
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_LicTxEndCnt+0,r0
        sti       r0,@_d_LicTxEndCnt+0
        bu        L677
;*      Branch Occurs to L677 
L676:        
	.line	40
;----------------------------------------------------------------------
; 1770 | pLic_Cncs->sCommand[0] = ConvHex2Asc(BYTE_H(0x04));//���� ���� ���� ��.
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(15)
	.line	41
;----------------------------------------------------------------------
; 1771 | pLic_Cncs->sCommand[1] = ConvHex2Asc(BYTE_L(0x04));//���� ���� ���� ��.
;----------------------------------------------------------------------
        ldiu      4,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(16)
L677:        
	.line	44
;----------------------------------------------------------------------
; 1774 | pLic_Cncs->sCarKind[0] = ConvHex2Asc(BYTE_H(m_chCarKind));             
;----------------------------------------------------------------------
        ldiu      @_m_chCarKind+0,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(17)
	.line	45
;----------------------------------------------------------------------
; 1775 | pLic_Cncs->sCarKind[1] = ConvHex2Asc(BYTE_L(m_chCarKind));             
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_m_chCarKind+0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      *+fp(2),ar0
        sti       r0,*+ar0(18)
	.line	47
;----------------------------------------------------------------------
; 1777 | FunConvHexAsc(&pNvsram[nRecving_Posi],(char *)pLic_Cncs->sTextDataAsc,(
;     | nLen-2));                                                              
;----------------------------------------------------------------------
        ldiu      19,r2
        ldiu      @_nRecving_Posi+0,r1
        addi      *+fp(3),r1            ; Unsigned
        ldiu      2,r0
        addi      *+fp(2),r2            ; Unsigned
        subri     *-fp(3),r0            ; Unsigned
        push      r0
        push      r2
        push      r1
        call      _FunConvHexAsc
                                        ; Call Occurs
        subi      3,sp
	.line	49
;----------------------------------------------------------------------
; 1779 | sTempData = Make1ByteBcc(&pLic_Cncs->phHdBuf.chSrcDev[0],(nLen*2)+14); 
;----------------------------------------------------------------------
        ldiu      1,r1
        addi      *+fp(2),r1            ; Unsigned
        ldiu      *-fp(3),r0
        mpyi      2,r0
        addi      14,r0                 ; Unsigned
        push      r0
        push      r1
        call      _Make1ByteBcc
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(1)
	.line	51
;----------------------------------------------------------------------
; 1781 | pLic_Cncs->sTextDataAsc[((nLen-2)*2)] = ConvHex2Asc(BYTE_H(sTempData));
;----------------------------------------------------------------------
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      2,ar0
        subri     *-fp(3),ar0           ; Unsigned
        mpyi      2,ar0
        addi      *+fp(2),ar0           ; Unsigned
        sti       r0,*+ar0(19)
	.line	52
;----------------------------------------------------------------------
; 1782 | pLic_Cncs->sTextDataAsc[((nLen-2)*2)+1] = ConvHex2Asc(BYTE_L(sTempData)
;     | );                                                                     
;----------------------------------------------------------------------
        ldiu      15,r0
        and       *+fp(1),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      2,ar0
        subri     *-fp(3),ar0           ; Unsigned
        mpyi      2,ar0
        addi      *+fp(2),ar0           ; Unsigned
        sti       r0,*+ar0(20)
	.line	54
;----------------------------------------------------------------------
; 1784 | pLic_Cncs->sTextDataAsc[((nLen-2)*2)+2] = 0x04;                        
;----------------------------------------------------------------------
        ldiu      2,ar0
        subri     *-fp(3),ar0           ; Unsigned
        mpyi      2,ar0
        addi      *+fp(2),ar0           ; Unsigned
        ldiu      4,r0
        sti       r0,*+ar0(21)
	.line	56
;----------------------------------------------------------------------
; 1786 | m_LIC_CNCS_TX_DelyTime = 0;                                            
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_LIC_CNCS_TX_DelyTime+0
	.line	57
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      5,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	1787,000000000h,3



	.sect	".cinit"
	.field  	1,32
	.field  	_d_BcarRxCnt+0,32
	.field  	0,32		; _d_BcarRxCnt @ 0

	.sect	".text"

	.global	_d_BcarRxCnt
	.bss	_d_BcarRxCnt,1
	.sym	_d_BcarRxCnt,_d_BcarRxCnt,4,2,32
	.sect	 ".text"

	.global	_user_FtpEnd_CarNumFun
	.sym	_user_FtpEnd_CarNumFun,_user_FtpEnd_CarNumFun,32,2,0
	.func	1793
;******************************************************************************
;* FUNCTION NAME: _user_FtpEnd_CarNumFun                                      *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,st                                               *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 0 Auto + 0 SOE = 2 words          *
;******************************************************************************
_user_FtpEnd_CarNumFun:
	.line	1
;----------------------------------------------------------------------
; 1793 | void user_FtpEnd_CarNumFun()                                           
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	3
;----------------------------------------------------------------------
; 1795 | m_bLnWkFtpEndFlag = FALSE;                                             
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_bLnWkFtpEndFlag+0
	.line	5
;----------------------------------------------------------------------
; 1797 | if(BYTE_L(m_wCarNo>>8) == 0x07)                                        
;----------------------------------------------------------------------
        ldiu      @_m_wCarNo+0,r0
        ash       -8,r0
        and       15,r0
        cmpi      7,r0
        bne       L682
;*      Branch Occurs to L682 
	.line	7
;----------------------------------------------------------------------
; 1799 | m_LIC_CNCS_Tx_Flag = FALSE; //���� ���� ������ ���� �̹Ƿ� ���� ��.    
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_LIC_CNCS_Tx_Flag+0
	.line	8
;----------------------------------------------------------------------
; 1800 | m_nNvsramPos = 0;                                                      
;----------------------------------------------------------------------
        sti       r0,@_m_nNvsramPos+0
	.line	9
;----------------------------------------------------------------------
; 1801 | nRecving_Posi = 0;                                                     
;----------------------------------------------------------------------
        sti       r0,@_nRecving_Posi+0
	.line	10
;----------------------------------------------------------------------
; 1802 | m_nLnWkWaySideOnRxOk = 0;                                              
;----------------------------------------------------------------------
        sti       r0,@_m_nLnWkWaySideOnRxOk+0
	.line	11
;----------------------------------------------------------------------
; 1803 | m_nFaultCnt = 0;                                                       
;----------------------------------------------------------------------
        sti       r0,@_m_nFaultCnt+0
	.line	12
;----------------------------------------------------------------------
; 1804 | m_chCarKind = 'A';                                                     
;----------------------------------------------------------------------
        ldiu      65,r0
        sti       r0,@_m_chCarKind+0
	.line	13
;----------------------------------------------------------------------
; 1805 | m_nLnWkTxFlag = 0;                                                     
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nLnWkTxFlag+0
        bu        L686
;*      Branch Occurs to L686 
L682:        
	.line	16
;----------------------------------------------------------------------
; 1808 | else if(BYTE_L(m_wCarNo>>8) == 0x08)                                   
;----------------------------------------------------------------------
        ldiu      @_m_wCarNo+0,r0
        ash       -8,r0
        and       15,r0
        cmpi      8,r0
        bne       L686
;*      Branch Occurs to L686 
	.line	18
;----------------------------------------------------------------------
; 1810 | if(WORD_L(m_chCarKind) == 'A')                                         
; 1812 |         //aaa_ACarDataPosi = m_nNvsramPos;                             
;----------------------------------------------------------------------
        ldiu      255,r0
        and       @_m_chCarKind+0,r0
        cmpi      65,r0
        bne       L685
;*      Branch Occurs to L685 
	.line	22
;----------------------------------------------------------------------
; 1814 | m_nLnWkWaySideOnRxOk = 0;                                              
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nLnWkWaySideOnRxOk+0
	.line	23
;----------------------------------------------------------------------
; 1815 | m_nFaultCnt = 0;                                                       
;----------------------------------------------------------------------
        sti       r0,@_m_nFaultCnt+0
	.line	24
;----------------------------------------------------------------------
; 1816 | m_chCarKind = 'B';                                                     
;----------------------------------------------------------------------
        ldiu      66,r0
        sti       r0,@_m_chCarKind+0
	.line	26
;----------------------------------------------------------------------
; 1818 | m_LIC_CNCS_Tx_Flag = FALSE; //���� ���� ������ ���� �̹Ƿ� ���� ��.    
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_LIC_CNCS_Tx_Flag+0
	.line	28
;----------------------------------------------------------------------
; 1820 | m_nCDT_FaultDataStFlag = 10;                                           
; 1822 | else                                                                   
;----------------------------------------------------------------------
        ldiu      10,r0
        sti       r0,@_m_nCDT_FaultDataStFlag+0
        bu        L686
;*      Branch Occurs to L686 
L685:        
	.line	32
;----------------------------------------------------------------------
; 1824 | d_BcarRxCnt++;                                                         
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_BcarRxCnt+0,r0
        sti       r0,@_d_BcarRxCnt+0
	.line	33
;----------------------------------------------------------------------
; 1825 | m_nNvsramPos = 0;                                                      
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nNvsramPos+0
	.line	34
;----------------------------------------------------------------------
; 1826 | nRecving_Posi = 0;                                                     
;----------------------------------------------------------------------
        sti       r0,@_nRecving_Posi+0
	.line	35
;----------------------------------------------------------------------
; 1827 | m_nLnWkWaySideOnRxOk = 0;                                              
;----------------------------------------------------------------------
        sti       r0,@_m_nLnWkWaySideOnRxOk+0
	.line	36
;----------------------------------------------------------------------
; 1828 | m_nFaultCnt = 0;                                                       
;----------------------------------------------------------------------
        sti       r0,@_m_nFaultCnt+0
	.line	37
;----------------------------------------------------------------------
; 1829 | m_chCarKind = 'A';                                                     
;----------------------------------------------------------------------
        ldiu      65,r0
        sti       r0,@_m_chCarKind+0
	.line	38
;----------------------------------------------------------------------
; 1830 | m_nLnWkTxFlag = 0;                                                     
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,@_m_nLnWkTxFlag+0
	.line	40
;----------------------------------------------------------------------
; 1832 | m_LIC_CNCS_Tx_Flag = FALSE; //���� ���� ������ ���� �̹Ƿ� ���� ��.    
;----------------------------------------------------------------------
        sti       r0,@_m_LIC_CNCS_Tx_Flag+0
L686:        
	.line	43
        ldiu      *-fp(1),r1
        ldiu      *fp,fp
        subi      2,sp
        bu        r1
;*      Branch Occurs to r1 
	.endfunc	1835,000000000h,0



	.sect	".cinit"
	.field  	1,32
	.field  	_d_Rx3ch+0,32
	.field  	0,32		; _d_Rx3ch @ 0

	.sect	".text"

	.global	_d_Rx3ch
	.bss	_d_Rx3ch,1
	.sym	_d_Rx3ch,_d_Rx3ch,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_RxUnitSt_1+0,32
	.field  	0,32		; _d_RxUnitSt_1 @ 0

	.sect	".text"

	.global	_d_RxUnitSt_1
	.bss	_d_RxUnitSt_1,1
	.sym	_d_RxUnitSt_1,_d_RxUnitSt_1,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_RxUnitSt_2+0,32
	.field  	0,32		; _d_RxUnitSt_2 @ 0

	.sect	".text"

	.global	_d_RxUnitSt_2
	.bss	_d_RxUnitSt_2,1
	.sym	_d_RxUnitSt_2,_d_RxUnitSt_2,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_CI_Fault+0,32
	.field  	0,32		; _d_CI_Fault @ 0

	.sect	".text"

	.global	_d_CI_Fault
	.bss	_d_CI_Fault,1
	.sym	_d_CI_Fault,_d_CI_Fault,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_CI_Index+0,32
	.field  	0,32		; _d_CI_Index @ 0

	.sect	".text"

	.global	_d_CI_Index
	.bss	_d_CI_Index,1
	.sym	_d_CI_Index,_d_CI_Index,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_d_CCP_PAC_Cnt+0,32
	.field  	0,32		; _d_CCP_PAC_Cnt @ 0

	.sect	".text"

	.global	_d_CCP_PAC_Cnt
	.bss	_d_CCP_PAC_Cnt,1
	.sym	_d_CCP_PAC_Cnt,_d_CCP_PAC_Cnt,4,2,32

	.sect	".cinit"
	.field  	1,32
	.field  	_nRxPos$12+0,32
	.field  	0,32		; _nRxPos$12 @ 0

	.sect	".text"

	.sect	".cinit"
	.field  	1,32
	.field  	_nOldUart3RxOneByteGapDelayTime$13+0,32
	.field  	0,32		; _nOldUart3RxOneByteGapDelayTime$13 @ 0

	.sect	".text"
	.sect	 ".text"

	.global	_user_WithPacRs485Loop
	.sym	_user_WithPacRs485Loop,_user_WithPacRs485Loop,32,2,0
	.func	1848
;******************************************************************************
;* FUNCTION NAME: _user_WithPacRs485Loop                                      *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r2,r4,ar0,ar1,fp,ir0,ir1,sp,st,rs,re,rc       *
;*   Regs Saved         : r4                                                  *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 391 Auto + 1 SOE = 394 words      *
;******************************************************************************
_user_WithPacRs485Loop:
	.bss	_nRxPos$12,1
	.sym	_nRxPos,_nRxPos$12,4,3,32
	.bss	_nOldUart3RxOneByteGapDelayTime$13,1
	.sym	_nOldUart3RxOneByteGapDelayTime,_nOldUart3RxOneByteGapDelayTime$13,12,3,32
	.bss	_btRx3chBuf$14,256
	.sym	_btRx3chBuf,_btRx3chBuf$14,60,3,8192,,256
	.sym	_i,1,4,1,32
	.sym	_nRxLen,2,4,1,32
	.sym	_nCciCnt,3,4,1,32
	.sym	_btTmp,4,12,1,32
	.sym	_btTmpBuf,5,60,1,3200,,100
	.sym	_btBuf,105,60,1,8192,,256
	.sym	_pLnWkDp,361,24,1,32,.fake13
	.sym	_pPaSdrBuf,362,24,1,32,.fake16
	.sym	_lsLicSdBuf,363,8,1,768,.fake38
	.sym	_pPa_PaBuf,387,24,1,32,.fake36
	.sym	_pCcp_Pac,388,24,1,32,.fake37
	.sym	_pPac_Pac_Sta,389,24,1,32,.fake17
	.sym	_pCommStatus,390,24,1,32,.fake52
	.sym	_pCommStatus_Lic,391,24,1,32,.fake60
	.line	1
;----------------------------------------------------------------------
; 1848 | void user_WithPacRs485Loop()                                           
; 1850 | int i;                                                                 
; 1851 | int nRxLen;                                                            
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      391,sp
        push      r4
	.line	5
;----------------------------------------------------------------------
; 1852 | int nCciCnt = 0;                                                       
; 1853 | UCHAR btTmp;                                                           
; 1854 | UCHAR btTmpBuf[100];                                                   
; 1855 | UCHAR btBuf[256];                                                      
; 1856 | static int nRxPos = 0;                                                 
; 1857 | static UCHAR nOldUart3RxOneByteGapDelayTime = 0;                       
; 1858 | static UCHAR btRx3chBuf[256];                                          
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(3)
	.line	12
;----------------------------------------------------------------------
; 1859 | PLNWKDP pLnWkDp = (LNWKDP *)DPRAM_BASE;                                
; 1861 | PPACSDR pPaSdrBuf;                                                     
; 1862 | LICSD lsLicSdBuf;                                                      
; 1863 | PPAC_PAC pPa_PaBuf;                                                    
; 1865 | PCCP_PAC pCcp_Pac;                                                     
; 1867 | PCRA_STATION pPac_Pac_Sta;                                             
; 1869 | PCOMMSTATUS_PA pCommStatus;                                            
; 1870 | PCOMMSTATUS_LIC pCommStatus_Lic;                                       
; 1872 | // ����                                                                
;----------------------------------------------------------------------
        ldiu      361,ir0
        ldiu      @CL11,r0
        sti       r0,*+fp(ir0)
	.line	26
;----------------------------------------------------------------------
; 1873 | nRxLen = user_PacRx(btBuf,128);                                        
;----------------------------------------------------------------------
        ldiu      128,r1
        ldiu      fp,r0
        push      r1
        addi      105,r0
        push      r0
        call      _user_PacRx
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(2)
	.line	27
;----------------------------------------------------------------------
; 1874 | if(nRxLen)                                                             
;----------------------------------------------------------------------
        cmpi      0,r0
        beq       L693
;*      Branch Occurs to L693 
	.line	29
;----------------------------------------------------------------------
; 1876 | if(!m_nUart3RxOneByteGapDelayTime) nRxPos = 0;                         
;----------------------------------------------------------------------
        ldi       @_m_nUart3RxOneByteGapDelayTime+0,r0
        bne       L691
;*      Branch Occurs to L691 
        ldiu      0,r0
        sti       r0,@_nRxPos$12+0
L691:        
	.line	30
;----------------------------------------------------------------------
; 1877 | m_nUart3RxOneByteGapDelayTime = 3;                                     
;----------------------------------------------------------------------
        ldiu      3,r0
        sti       r0,@_m_nUart3RxOneByteGapDelayTime+0
	.line	32
;----------------------------------------------------------------------
; 1879 | if(nRxPos + nRxLen < 250)                                              
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        addi      @_nRxPos$12+0,r0
        cmpi      250,r0
        bged      L693
        ldilt     @CL110,r0
        ldilt     fp,r1
        ldilt     *+fp(2),r2
;*      Branch Occurs to L693 
	.line	34
;----------------------------------------------------------------------
; 1881 | memcpy(&btRx3chBuf[nRxPos],btBuf,nRxLen);                              
;----------------------------------------------------------------------
        addi      @_nRxPos$12+0,r0      ; Unsigned
        addi      105,r1
        push      r2
        push      r1
        push      r0
        call      _memcpy
                                        ; Call Occurs
        subi      3,sp
	.line	35
;----------------------------------------------------------------------
; 1882 | nRxPos += nRxLen;                                                      
;----------------------------------------------------------------------
        ldiu      *+fp(2),r0
        addi      @_nRxPos$12+0,r0
        sti       r0,@_nRxPos$12+0
L693:        
	.line	39
;----------------------------------------------------------------------
; 1886 | if(nOldUart3RxOneByteGapDelayTime && !m_nUart3RxOneByteGapDelayTime)   
;----------------------------------------------------------------------
        ldi       @_nOldUart3RxOneByteGapDelayTime$13+0,r0
        beq       L742
;*      Branch Occurs to L742 
        ldi       @_m_nUart3RxOneByteGapDelayTime+0,r0
        bne       L742
;*      Branch Occurs to L742 
	.line	42
;----------------------------------------------------------------------
; 1889 | if(nRxPos >= 10)                                                       
;----------------------------------------------------------------------
        ldiu      @_nRxPos$12+0,r0
        cmpi      10,r0
        blt       L742
;*      Branch Occurs to L742 
	.line	44
;----------------------------------------------------------------------
; 1891 | pPaSdrBuf = (PACSDR *)btRx3chBuf;                                      
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      @CL110,r0
        sti       r0,*+fp(ir0)
	.line	46
;----------------------------------------------------------------------
; 1893 | pPa_PaBuf = (PAC_PAC *)btRx3chBuf;                                     
;----------------------------------------------------------------------
        ldiu      387,ir0
        sti       r0,*+fp(ir0)
	.line	49
;----------------------------------------------------------------------
; 1896 | pCcp_Pac = (CCP_PAC *)btRx3chBuf;                                      
; 1898 | //PAC -> LIC �κ� ���������� �и� �Ѵ�.                                
; 1899 | if(                                                                    
;----------------------------------------------------------------------
        ldiu      388,ir0
        sti       r0,*+fp(ir0)
	.line	53
;----------------------------------------------------------------------
; 1900 | WORD_L(pPaSdrBuf->phHdBuf.btSoh) == SOH &&                             
; 1901 | WORD_L(pPaSdrBuf->btEot) == EOT &&                                     
; 1902 | sizeof(PACSDR) == nRxPos &&                                            
; 1903 | (TWOBYTE_ASC2HEX(pPaSdrBuf->phHdBuf.chDestDev) == LIC_DEV_NO)&&        
; 1905 | ConvAsc2Hex(pPaSdrBuf->nCRC[0]) == BYTE_H(WORD_H(crc16_ccitt(&pPaSdrBuf
;     | ->phHdBuf.chSrcDev[0],nRxPos-6)))&&                                    
; 1906 | ConvAsc2Hex(pPaSdrBuf->nCRC[1]) == BYTE_L(WORD_H(crc16_ccitt(&pPaSdrBuf
;     | ->phHdBuf.chSrcDev[0],nRxPos-6)))&&                                    
; 1907 | ConvAsc2Hex(pPaSdrBuf->nCRC[2]) == BYTE_H(WORD_L(crc16_ccitt(&pPaSdrBuf
;     | ->phHdBuf.chSrcDev[0],nRxPos-6)))&&                                    
; 1908 | ConvAsc2Hex(pPaSdrBuf->nCRC[3]) == BYTE_L(WORD_L(crc16_ccitt(&pPaSdrBuf
;     | ->phHdBuf.chSrcDev[0],nRxPos-6))))                                     
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        cmpi      1,r0
        bne       L712
;*      Branch Occurs to L712 
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and       *+ar0(17),r0
        cmpi      4,r0
        bne       L712
;*      Branch Occurs to L712 
        ldiu      18,r0
        cmpi      @_nRxPos$12+0,r0
        bne       L712
;*      Branch Occurs to L712 
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      362,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(4),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      34,r0
        subi      1,sp
        bne       L712
;*      Branch Occurs to L712 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      362,ir0
        ldiu      r0,r4
        subi      2,sp
        lsh       -8,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(13),r0
        lsh       -4,r4
        and       15,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L712
;*      Branch Occurs to L712 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        subi      2,sp
        ldiu      362,ir0
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(14),r0
        lsh       -8,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L712
;*      Branch Occurs to L712 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      362,ir0
        subi      2,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(15),r0
        lsh       -4,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L712
;*      Branch Occurs to L712 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      362,ir0
        subi      2,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(16),r0
        and       15,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L712
;*      Branch Occurs to L712 
	.line	63
;----------------------------------------------------------------------
; 1910 | d_Rx3ch++;                                                             
; 1912 | switch(TWOBYTE_ASC2HEX(pPaSdrBuf->phHdBuf.chCmdCode))                  
; 1914 | case REQ_CMD: //PAC -> LIC                                             
;----------------------------------------------------------------------
        bud       L709
        ldiu      1,r0
        addi      @_d_Rx3ch+0,r0
        sti       r0,@_d_Rx3ch+0
;*      Branch Occurs to L709 
	.line	69
;----------------------------------------------------------------------
; 1916 | lsLicSdBuf.phHdBuf.btSoh = SOH;                                        
;----------------------------------------------------------------------
L706:        
        sti       r0,*+fp(ir0)
	.line	70
;----------------------------------------------------------------------
; 1917 | lsLicSdBuf.phHdBuf.chSrcDev[0] = ConvHex2Asc(BYTE_H(LIC_DEV_NO));      
;----------------------------------------------------------------------
        ldiu      2,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      364,ir0
        sti       r0,*+fp(ir0)
	.line	71
;----------------------------------------------------------------------
; 1918 | lsLicSdBuf.phHdBuf.chSrcDev[1] = ConvHex2Asc(BYTE_L(LIC_DEV_NO));      
;----------------------------------------------------------------------
        ldiu      2,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      365,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	72
;----------------------------------------------------------------------
; 1919 | lsLicSdBuf.phHdBuf.chDestDev[0] = pPaSdrBuf->phHdBuf.chSrcDev[0];      
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      366,ir0
        ldiu      *+ar0(1),r0
        sti       r0,*+fp(ir0)
	.line	73
;----------------------------------------------------------------------
; 1920 | lsLicSdBuf.phHdBuf.chDestDev[1] = pPaSdrBuf->phHdBuf.chSrcDev[1];      
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      367,ir0
        ldiu      *+ar0(2),r0
        sti       r0,*+fp(ir0)
	.line	74
;----------------------------------------------------------------------
; 1921 | lsLicSdBuf.phHdBuf.chMsgCnt[0] = pPaSdrBuf->phHdBuf.chMsgCnt[0];       
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      368,ir0
        ldiu      *+ar0(5),r0
        sti       r0,*+fp(ir0)
	.line	75
;----------------------------------------------------------------------
; 1922 | lsLicSdBuf.phHdBuf.chMsgCnt[1] = pPaSdrBuf->phHdBuf.chMsgCnt[1];       
;----------------------------------------------------------------------
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      369,ir0
        ldiu      *+ar0(6),r0
        sti       r0,*+fp(ir0)
	.line	76
;----------------------------------------------------------------------
; 1923 | lsLicSdBuf.phHdBuf.chCmdCode[0] = ConvHex2Asc(BYTE_H(RPY_CMD));        
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      370,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	77
;----------------------------------------------------------------------
; 1924 | lsLicSdBuf.phHdBuf.chCmdCode[1] = ConvHex2Asc(BYTE_L(RPY_CMD));        
;----------------------------------------------------------------------
        ldiu      1,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      371,ir0
        sti       r0,*+fp(ir0)
	.line	78
;----------------------------------------------------------------------
; 1925 | lsLicSdBuf.phHdBuf.chDataLen[0] = ConvHex2Asc(BYTE_H(((sizeof(LICSD)-16
;     | )/2)));                                                                
;----------------------------------------------------------------------
        ldiu      0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      372,ir0
        sti       r0,*+fp(ir0)
	.line	79
;----------------------------------------------------------------------
; 1926 | lsLicSdBuf.phHdBuf.chDataLen[1] = ConvHex2Asc(BYTE_L(((sizeof(LICSD)-16
;     | )/2)));                                                                
;----------------------------------------------------------------------
        ldiu      4,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      373,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	81
;----------------------------------------------------------------------
; 1928 | lsLicSdBuf.DATA1.BIT.All_Doors_Closed = 0;                             
;----------------------------------------------------------------------
        ldiu      375,ir0
        ldiu      *+fp(ir0),r0
        ldiu      375,ir1
        andn      1,r0
        sti       r0,*+fp(ir1)
	.line	82
;----------------------------------------------------------------------
; 1929 | lsLicSdBuf.DATA1.BIT.EP_Mode = 0;                                      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),r0
        andn      2,r0
        sti       r0,*+fp(ir1)
	.line	83
;----------------------------------------------------------------------
; 1930 | lsLicSdBuf.DATA1.BIT.Traction = 0;                                     
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),r0
        andn      4,r0
        sti       r0,*+fp(ir1)
	.line	84
;----------------------------------------------------------------------
; 1931 | lsLicSdBuf.DATA1.BIT.Atcive_Cab = 0;                                   
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),r0
        andn      8,r0
        sti       r0,*+fp(ir1)
	.line	86
;----------------------------------------------------------------------
; 1933 | lsLicSdBuf.DATA2.BIT.CI_Fault =d_CI_Fault;                             
;----------------------------------------------------------------------
        ldiu      1,r0
        ldiu      374,ir0
        and       @_d_CI_Fault+0,r0
        ldiu      *+fp(ir0),r1
        andn      4,r1
        ldiu      374,ir1
        ash       2,r0
        or3       r1,r0,r0
        sti       r0,*+fp(ir1)
	.line	87
;----------------------------------------------------------------------
; 1934 | lsLicSdBuf.DATA2.BIT.DST = 0;                                          
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),r0
        andn      8,r0
        sti       r0,*+fp(ir1)
	.line	89
;----------------------------------------------------------------------
; 1936 | lsLicSdBuf.DATA1.BYTE = ConvHex2Asc(BYTE_L(lsLicSdBuf.DATA1.BYTE));    
;----------------------------------------------------------------------
        ldiu      375,ir0
        ldiu      15,r0
        and3      r0,*+fp(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      375,ir0
        sti       r0,*+fp(ir0)
	.line	91
;----------------------------------------------------------------------
; 1938 | lsLicSdBuf.DATA2.BYTE = ConvHex2Asc(BYTE_L(lsLicSdBuf.DATA2.BYTE));    
;----------------------------------------------------------------------
        ldiu      374,ir0
        ldiu      15,r0
        and3      r0,*+fp(ir0),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      374,ir0
        sti       r0,*+fp(ir0)
	.line	94
;----------------------------------------------------------------------
; 1941 | lsLicSdBuf.CI_Index_Num[0] =ConvHex2Asc(BYTE_H(d_CI_Index));           
;----------------------------------------------------------------------
        ldiu      @_d_CI_Index+0,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      376,ir0
        sti       r0,*+fp(ir0)
	.line	95
;----------------------------------------------------------------------
; 1942 | lsLicSdBuf.CI_Index_Num[1] =ConvHex2Asc(BYTE_L(d_CI_Index));           
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_d_CI_Index+0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      377,ir0
        sti       r0,*+fp(ir0)
	.line	98
;----------------------------------------------------------------------
; 1945 | lsLicSdBuf.chCarn[0][0] = ConvHex2Asc(BYTE_H(WORD_H(m_wCarNo))); // Car
;     |  Number(-.���ڸ�)                                                      
;----------------------------------------------------------------------
        ldiu      @_m_wCarNo+0,r0
        ash       -8,r0
        and       255,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      378,ir0
        sti       r0,*+fp(ir0)
	.line	99
;----------------------------------------------------------------------
; 1946 | lsLicSdBuf.chCarn[0][1] = ConvHex2Asc(BYTE_L(WORD_H(m_wCarNo)));       
;----------------------------------------------------------------------
        ldiu      @_m_wCarNo+0,r0
        ash       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      379,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	100
;----------------------------------------------------------------------
; 1947 | lsLicSdBuf.chCarn[1][0] = ConvHex2Asc(BYTE_H(m_wCarNo)); // Car Number(
;     | ���ڸ�,���ڸ�)                                                         
;----------------------------------------------------------------------
        ldiu      @_m_wCarNo+0,r0
        ash       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      380,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	101
;----------------------------------------------------------------------
; 1948 | lsLicSdBuf.chCarn[1][1] = ConvHex2Asc(BYTE_L(m_wCarNo));               
;----------------------------------------------------------------------
        ldiu      15,r0
        and       @_m_wCarNo+0,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      381,ir0
        sti       r0,*+fp(ir0)
	.line	103
;----------------------------------------------------------------------
; 1950 | btTmp = crc16_ccitt(&lsLicSdBuf.phHdBuf.chSrcDev[0],sizeof(LICSD)-6);  
;----------------------------------------------------------------------
        ldiu      18,r1
        ldiu      364,r0
        push      r1
        addi      fp,r0
        push      r0
        call      _crc16_ccitt
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(4)
	.line	104
;----------------------------------------------------------------------
; 1951 | lsLicSdBuf.nCRC[0] = ConvHex2Asc(BYTE_H(WORD_H(btTmp)));               
;----------------------------------------------------------------------
        lsh       -8,r0
        and       255,r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      382,ir0
        sti       r0,*+fp(ir0)
	.line	105
;----------------------------------------------------------------------
; 1952 | lsLicSdBuf.nCRC[1] = ConvHex2Asc(BYTE_L(WORD_H(btTmp)));               
;----------------------------------------------------------------------
        ldiu      *+fp(4),r0
        lsh       -8,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        subi      1,sp
        ldiu      383,ir0
        sti       r0,*+fp(ir0)
	.line	106
;----------------------------------------------------------------------
; 1953 | lsLicSdBuf.nCRC[2] = ConvHex2Asc(BYTE_H(WORD_L(btTmp)));               
;----------------------------------------------------------------------
        ldiu      255,r0
        and       *+fp(4),r0
        lsh       -4,r0
        and       15,r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      384,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	107
;----------------------------------------------------------------------
; 1954 | lsLicSdBuf.nCRC[3] = ConvHex2Asc(BYTE_L(WORD_L(btTmp)));               
;----------------------------------------------------------------------
        ldiu      15,r0
        and       *+fp(4),r0
        push      r0
        call      _ConvHex2Asc
                                        ; Call Occurs
        ldiu      385,ir0
        subi      1,sp
        sti       r0,*+fp(ir0)
	.line	108
;----------------------------------------------------------------------
; 1955 | lsLicSdBuf.btEot = EOT;                                                
;----------------------------------------------------------------------
        ldiu      386,ir0
        ldiu      4,r0
        sti       r0,*+fp(ir0)
	.line	110
;----------------------------------------------------------------------
; 1957 | memcpy(d_RxUnitStBuf,(UCHAR *)&lsLicSdBuf,sizeof(LICSD));              
;----------------------------------------------------------------------
        ldiu      363,ar1
        addi      fp,ar1
        ldiu      @CL111,ar0
        ldiu      *ar1++(1),r0
        rpts      22                    ; Fast MEMCPY(#15)
        sti       r0,*ar0++(1)
||      ldi       *ar1++(1),r0
        sti       r0,*ar0++(1)
	.line	112
;----------------------------------------------------------------------
; 1959 | user_PacTx((UCHAR *)&lsLicSdBuf,sizeof(LICSD));                        
;----------------------------------------------------------------------
        ldiu      24,r0
        push      r0
        ldiu      363,r0
        addi      fp,r0
        push      r0
        call      _user_PacTx
                                        ; Call Occurs
        subi      2,sp
	.line	113
;----------------------------------------------------------------------
; 1960 | break;                                                                 
; 1961 | default:                                                               
;----------------------------------------------------------------------
        bu        L742
;*      Branch Occurs to L742 
	.line	115
;----------------------------------------------------------------------
; 1962 | break;                                                                 
; 1966 | else                                                                   
;----------------------------------------------------------------------
L709:        
	.line	65
        ldiu      362,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(7),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      362,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(8),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      16,r0
        beqd      L706
        subi      1,sp
        ldieq     363,ir0
        ldieq     1,r0
;*      Branch Occurs to L706 
        bu        L742
;*      Branch Occurs to L742 
L712:        
	.line	120
;----------------------------------------------------------------------
; 1967 | if(WORD_L(pPa_PaBuf->phHdBuf.btSoh) == SOH &&  // PAC <-> PAC ���� ����
;     |  ������ �����Ѵ�.                                                      
; 1968 |             WORD_L(pPa_PaBuf->btEot) == EOT &&                         
; 1969 |             sizeof(PAC_PAC) == nRxPos &&                               
; 1970 |                 (TWOBYTE_ASC2HEX(pPa_PaBuf->phHdBuf.chSrcDev) == PAC_DE
;     | V_NO) &&                                                               
; 1971 |             (TWOBYTE_ASC2HEX(pPa_PaBuf->phHdBuf.chDestDev) == PAC_BAKDE
;     | V_NO)&&                                                                
; 1973 |             ConvAsc2Hex(pPa_PaBuf->nCRC[0]) == BYTE_H(WORD_H(crc16_ccit
;     | t(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&                        
; 1974 |                 ConvAsc2Hex(pPa_PaBuf->nCRC[1]) == BYTE_L(WORD_H(crc16_
;     | ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&                    
; 1975 |                 ConvAsc2Hex(pPa_PaBuf->nCRC[2]) == BYTE_H(WORD_L(crc16_
;     | ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))&&                    
; 1976 |                 ConvAsc2Hex(pPa_PaBuf->nCRC[3]) == BYTE_L(WORD_L(crc16_
;     | ccitt(&pPaSdrBuf->phHdBuf.chSrcDev[0],nRxPos-6)))                      
; 1977 |             )                                                          
;----------------------------------------------------------------------
        ldiu      387,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        cmpi      1,r0
        bne       L731
;*      Branch Occurs to L731 
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and       *+ar0(253),r0
        cmpi      4,r0
        bne       L731
;*      Branch Occurs to L731 
        ldiu      254,r0
        cmpi      @_nRxPos$12+0,r0
        bne       L731
;*      Branch Occurs to L731 
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      387,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(2),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      33,r0
        subi      1,sp
        bne       L731
;*      Branch Occurs to L731 
        ldiu      387,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      387,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(4),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      37,r0
        subi      1,sp
        bne       L731
;*      Branch Occurs to L731 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      387,ir0
        ldiu      r0,r4
        subi      2,sp
        lsh       -8,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(249),r0
        lsh       -4,r4
        and       15,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L731
;*      Branch Occurs to L731 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        subi      2,sp
        ldiu      387,ir0
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(250),r0
        lsh       -8,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L731
;*      Branch Occurs to L731 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      387,ir0
        subi      2,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(251),r0
        lsh       -4,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L731
;*      Branch Occurs to L731 
        ldiu      1,r1
        ldiu      362,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      387,ir0
        subi      2,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(252),r0
        and       15,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L731
;*      Branch Occurs to L731 
	.line	132
;----------------------------------------------------------------------
; 1979 | d_RxUnitSt_1++;                                                        
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_RxUnitSt_1+0,r0
        sti       r0,@_d_RxUnitSt_1+0
	.line	134
;----------------------------------------------------------------------
; 1981 | memset(m_btCommSt,0x00,sizeof(m_btCommSt));                            
;----------------------------------------------------------------------
        ldiu      7,r2
        ldiu      @CL3,r1
        push      r2
        ldiu      0,r0
        push      r0
        push      r1
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	136
;----------------------------------------------------------------------
; 1983 | pCommStatus_Lic = (COMMSTATUS_LIC *)m_btCommSt;                        
;----------------------------------------------------------------------
        ldiu      391,ir0
        ldiu      @CL3,r0
        sti       r0,*+fp(ir0)
	.line	138
;----------------------------------------------------------------------
; 1985 | for(i=0;i<4;i++)                                                       
;----------------------------------------------------------------------
        ldiu      0,r0
        sti       r0,*+fp(1)
        cmpi      4,r0
        bge       L742
;*      Branch Occurs to L742 
L722:        
	.line	140
;----------------------------------------------------------------------
; 1987 | FunConvAscHex((char *)&pPa_PaBuf->phCRA_Sta[i][0][0] ,btTmpBuf,22);    
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
        ldiu      387,ir0
        ldiu      22,r2
        ldiu      fp,r1
        mpyi      22,r0
        addi3     r0,*+fp(ir0),r0       ; Unsigned
        addi      161,r0                ; Unsigned
        push      r2
        addi      5,r1
        push      r1
        push      r0
        call      _FunConvAscHex
                                        ; Call Occurs
        subi      3,sp
	.line	142
;----------------------------------------------------------------------
; 1989 | pPac_Pac_Sta = (CRA_STATION *) btTmpBuf;                               
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      fp,r0
        addi      5,r0
        sti       r0,*+fp(ir0)
	.line	144
;----------------------------------------------------------------------
; 1991 | if(m_chCarKind == 'A')                                                 
;----------------------------------------------------------------------
        ldiu      @_m_chCarKind+0,r0
        cmpi      65,r0
        bne       L726
;*      Branch Occurs to L726 
	.line	146
;----------------------------------------------------------------------
; 1993 | if(DWORD_L(m_wCarNo) == MAKE_WORD(pPac_Pac_Sta->CarNum_H,pPac_Pac_Sta->
;     | CarNum_L))                                                             
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      389,ir1
        ldiu      255,r0
        ldiu      *+ar0(9),r2
        ldiu      @_m_wCarNo+0,r1
        ldiu      *+fp(ir1),ar0
        ash       8,r2
        and       *+ar0(10),r0
        and       65535,r1
        or3       r2,r0,r0
        and       65535,r0
        cmpi3     r0,r1
        bne       L729
;*      Branch Occurs to L729 
	.line	148
;----------------------------------------------------------------------
; 1995 | pCommStatus_Lic->BYTE_1.BIT.nCcp = pPac_Pac_Sta->CRA_2.BIT.sACCP1;     
;----------------------------------------------------------------------
        ldiu      391,ir1
        ldiu      128,r0
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        and       *+ar1(1),r0
        ldiu      *ar0,r1
        lsh       -7,r0
        andn      128,r1
        and       1,r0
        ash       7,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	149
;----------------------------------------------------------------------
; 1996 | pCommStatus_Lic->BYTE_1.BIT.nCncs = pPac_Pac_Sta->CRA_3.BIT.sACNCS;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      16,r0
        ldiu      *+fp(ir1),ar0
        and       *+ar1(2),r0
        ldiu      *ar0,r1
        lsh       -4,r0
        andn      1,r1
        and       1,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	150
;----------------------------------------------------------------------
; 1997 | pCommStatus_Lic->BYTE_1.BIT.nGps = pPac_Pac_Sta->CRA_2.BIT.sAGPS;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      32,r0
        ldiu      *+fp(ir1),ar0
        and       *+ar1(1),r0
        ldiu      *ar0,r1
        lsh       -5,r0
        andn      32,r1
        and       1,r0
        ash       5,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	151
;----------------------------------------------------------------------
; 1998 | pCommStatus_Lic->BYTE_1.BIT.nLic = pPac_Pac_Sta->CRA_3.BIT.sALIC;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      *ar0,r1
        ldiu      64,r0
        ldiu      *+fp(ir0),ar1
        andn      4,r1
        and       *+ar1(2),r0
        lsh       -6,r0
        and       1,r0
        ash       2,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	152
;----------------------------------------------------------------------
; 1999 | pCommStatus_Lic->BYTE_1.BIT.nPac = pPac_Pac_Sta->CRA_3.BIT.sAPAC;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      128,r0
        and       *+ar0(2),r0
        lsh       -7,r0
        ldiu      *+fp(ir0),ar0
        and       1,r0
        ldiu      *ar0,r1
        andn      8,r1
        ash       3,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	153
;----------------------------------------------------------------------
; 2000 | pCommStatus_Lic->BYTE_1.BIT.nVoip = pPac_Pac_Sta->CRA_2.BIT.sAVOIP;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      64,r0
        ldiu      391,ir0
        and       *+ar0(1),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *ar0,r1
        andn      64,r1
        lsh       -6,r0
        and       1,r0
        ash       6,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	154
;----------------------------------------------------------------------
; 2001 | pCommStatus_Lic->BYTE_1.BIT.nVtx = pPac_Pac_Sta->CRA_3.BIT.sAVTX;      
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      32,r0
        ldiu      *+fp(ir1),ar0
        and       *+ar1(2),r0
        ldiu      *ar0,r1
        andn      2,r1
        lsh       -5,r0
        and       1,r0
        ash       1,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	155
;----------------------------------------------------------------------
; 2002 | pCommStatus_Lic->BYTE_1.BIT.nWlr = pPac_Pac_Sta->CRA_2.BIT.sAWLR;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      16,r0
        and       *+ar0(1),r0
        ldiu      391,ir0
        lsh       -4,r0
        ldiu      *+fp(ir0),ar0
        and       1,r0
        ash       4,r0
        ldiu      *ar0,r1
        andn      16,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	158
;----------------------------------------------------------------------
; 2005 | pCommStatus_Lic->BYTE_2.BIT.nFdi = pPac_Pac_Sta->CRA_4.BIT.sAFDI;      
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      64,r0
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        and       *+ar1(3),r0
        lsh       -6,r0
        and       1,r0
        ldiu      *+ar0(1),r1
        ash       6,r0
        andn      64,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	159
;----------------------------------------------------------------------
; 2006 | pCommStatus_Lic->BYTE_2.BIT.nPii1 = pPac_Pac_Sta->CRA_4.BIT.sAPII1;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      32,r0
        and       *+ar0(3),r0
        lsh       -5,r0
        ldiu      391,ir0
        and       1,r0
        ldiu      *+fp(ir0),ar0
        ash       5,r0
        ldiu      *+ar0(1),r1
        andn      32,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	160
;----------------------------------------------------------------------
; 2007 | pCommStatus_Lic->BYTE_2.BIT.nPii2 = pPac_Pac_Sta->CRA_4.BIT.sAPII2;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      16,r0
        and       *+ar0(3),r0
        ldiu      391,ir0
        lsh       -4,r0
        ldiu      *+fp(ir0),ar0
        and       1,r0
        ldiu      *+ar0(1),r1
        andn      16,r1
        ash       4,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	161
;----------------------------------------------------------------------
; 2008 | pCommStatus_Lic->BYTE_2.BIT.nSdi1 = pPac_Pac_Sta->CRA_5.BIT.sASDI1;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      128,r0
        and       *+ar0(4),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r1
        lsh       -7,r0
        and       1,r0
        ash       3,r0
        andn      8,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	162
;----------------------------------------------------------------------
; 2009 | pCommStatus_Lic->BYTE_2.BIT.nSdi2 = pPac_Pac_Sta->CRA_5.BIT.sASDI2;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      64,r0
        and       *+ar0(4),r0
        ldiu      391,ir0
        lsh       -6,r0
        and       1,r0
        ldiu      *+fp(ir0),ar0
        ash       2,r0
        ldiu      *+ar0(1),r1
        andn      4,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	163
;----------------------------------------------------------------------
; 2010 | pCommStatus_Lic->BYTE_2.BIT.nSdi3 = pPac_Pac_Sta->CRA_5.BIT.sASDI3;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      32,r0
        and       *+ar1(4),r0
        ldiu      *+fp(ir1),ar0
        lsh       -5,r0
        and       1,r0
        ldiu      *+ar0(1),r1
        ash       1,r0
        andn      2,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	164
;----------------------------------------------------------------------
; 2011 | pCommStatus_Lic->BYTE_2.BIT.nSdi4 = pPac_Pac_Sta->CRA_5.BIT.sASDI4;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      16,r0
        ldiu      *+ar0(1),r1
        ldiu      *+fp(ir0),ar1
        andn      1,r1
        and       *+ar1(4),r0
        lsh       -4,r0
        and       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	166
;----------------------------------------------------------------------
; 2013 | pCommStatus_Lic->BYTE_3.BIT.nPid1_1 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_1;
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      128,r0
        ldiu      391,ir0
        and       *+ar0(5),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(2),r1
        lsh       -7,r0
        and       1,r0
        andn      16,r1
        ash       4,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	167
;----------------------------------------------------------------------
; 2014 | pCommStatus_Lic->BYTE_3.BIT.nPid1_2 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_2;
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      64,r0
        ldiu      391,ir0
        and       *+ar0(5),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(2),r1
        lsh       -6,r0
        andn      8,r1
        and       1,r0
        ash       3,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	168
;----------------------------------------------------------------------
; 2015 | pCommStatus_Lic->BYTE_3.BIT.nPid1_3 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_3;
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      32,r0
        ldiu      391,ir0
        and       *+ar0(5),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(2),r1
        lsh       -5,r0
        and       1,r0
        andn      4,r1
        ash       2,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	169
;----------------------------------------------------------------------
; 2016 | pCommStatus_Lic->BYTE_3.BIT.nPid1_4 = pPac_Pac_Sta->CRA_6.BIT.sAPID1_4;
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      16,r0
        and       *+ar1(5),r0
        lsh       -4,r0
        ldiu      *+fp(ir1),ar0
        and       1,r0
        ldiu      *+ar0(2),r1
        andn      2,r1
        ash       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	170
;----------------------------------------------------------------------
; 2017 | pCommStatus_Lic->BYTE_3.BIT.nPid2_1 = pPac_Pac_Sta->CRA_7.BIT.sAPID2_1;
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        ldiu      128,r0
        ldiu      *+ar0(2),r1
        and       *+ar1(6),r0
        lsh       -7,r0
        andn      1,r1
        and       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	172
;----------------------------------------------------------------------
; 2019 | pCommStatus_Lic->BYTE_4.BIT.nDph = pPac_Pac_Sta->CRA_9.BIT.sADPH;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      128,r0
        and       *+ar1(8),r0
        lsh       -7,r0
        ldiu      *+fp(ir1),ar0
        and       1,r0
        ldiu      *+ar0(3),r1
        andn      128,r1
        ash       7,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	173
;----------------------------------------------------------------------
; 2020 | pCommStatus_Lic->BYTE_4.BIT.nDpo = pPac_Pac_Sta->CRA_9.BIT.sADPO;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      16,r0
        and       *+ar0(8),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r1
        andn      16,r1
        lsh       -4,r0
        and       1,r0
        ash       4,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	174
;----------------------------------------------------------------------
; 2021 | pCommStatus_Lic->BYTE_4.BIT.nPei1 = pPac_Pac_Sta->CRA_7.BIT.sAPEI1;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        ldiu      16,r0
        ldiu      *+ar0(3),r1
        andn      1,r1
        and       *+ar1(6),r0
        lsh       -4,r0
        and       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	175
;----------------------------------------------------------------------
; 2022 | pCommStatus_Lic->BYTE_4.BIT.nPei2 = pPac_Pac_Sta->CRA_7.BIT.sAPEI2;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      32,r0
        ldiu      391,ir0
        and       *+ar0(6),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r1
        lsh       -5,r0
        andn      2,r1
        and       1,r0
        ash       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	177
;----------------------------------------------------------------------
; 2024 | break;                                                                 
;----------------------------------------------------------------------
        bu        L742
;*      Branch Occurs to L742 
L726:        
	.line	180
;----------------------------------------------------------------------
; 2027 | else if(m_chCarKind == 'B') //�������ݿ��� MA ���� ��ȣ�� �����Ƿ� MB��
;     |  ������ �ν� �ؾ� �Ѵ�.                                                
;----------------------------------------------------------------------
        ldiu      @_m_chCarKind+0,r0
        cmpi      66,r0
        bne       L729
;*      Branch Occurs to L729 
	.line	182
;----------------------------------------------------------------------
; 2029 | if(DWORD_L(m_wCarNo) == (MAKE_WORD(pPac_Pac_Sta->CarNum_H,pPac_Pac_Sta-
;     | >CarNum_L)+1))                                                         
;----------------------------------------------------------------------
        ldiu      389,ir1
        ldiu      389,ir0
        ldiu      255,r0
        ldiu      *+fp(ir1),ar0
        ldiu      @_m_wCarNo+0,r1
        ldiu      *+ar0(9),r2
        ldiu      *+fp(ir0),ar0
        ash       8,r2
        and       *+ar0(10),r0
        and       65535,r1
        or3       r2,r0,r0
        and       65535,r0
        addi      1,r0                  ; Unsigned
        cmpi3     r0,r1
        bne       L729
;*      Branch Occurs to L729 
	.line	184
;----------------------------------------------------------------------
; 2031 | pCommStatus_Lic->BYTE_1.BIT.nCcp = pPac_Pac_Sta->CRA_2.BIT.sBCCP1;     
;----------------------------------------------------------------------
        ldiu      391,ir1
        ldiu      8,r0
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        and       *+ar1(1),r0
        ldiu      *ar0,r1
        lsh       -3,r0
        andn      128,r1
        and       1,r0
        ash       7,r0
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	185
;----------------------------------------------------------------------
; 2032 | pCommStatus_Lic->BYTE_1.BIT.nCncs = pPac_Pac_Sta->CRA_3.BIT.sBCNCS;    
;----------------------------------------------------------------------
        ldiu      1,r1
        ldiu      *+fp(ir1),ar0
        ldiu      *+fp(ir0),ar1
        ldiu      *ar0,r0
        and       *+ar1(2),r1
        andn      1,r0
        or3       r0,r1,r0
        sti       r0,*ar0
	.line	186
;----------------------------------------------------------------------
; 2033 | pCommStatus_Lic->BYTE_1.BIT.nGps = pPac_Pac_Sta->CRA_2.BIT.sBGPS;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      2,r0
        and       *+ar1(1),r0
        lsh       -1,r0
        and       1,r0
        ldiu      *+fp(ir1),ar0
        ash       5,r0
        ldiu      *ar0,r1
        andn      32,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	187
;----------------------------------------------------------------------
; 2034 | pCommStatus_Lic->BYTE_1.BIT.nLic = pPac_Pac_Sta->CRA_3.BIT.sBLIC;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      4,r0
        and       *+ar0(2),r0
        lsh       -2,r0
        ldiu      *+fp(ir1),ar1
        and       1,r0
        ldiu      *ar1,r1
        ash       2,r0
        andn      4,r1
        or3       r1,r0,r0
        sti       r0,*ar1
	.line	188
;----------------------------------------------------------------------
; 2035 | pCommStatus_Lic->BYTE_1.BIT.nPac = pPac_Pac_Sta->CRA_3.BIT.sBPAC;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      8,r0
        and       *+ar0(2),r0
        ldiu      391,ir0
        lsh       -3,r0
        ldiu      *+fp(ir0),ar0
        and       1,r0
        ldiu      *ar0,r1
        ash       3,r0
        andn      8,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	189
;----------------------------------------------------------------------
; 2036 | pCommStatus_Lic->BYTE_1.BIT.nVoip = pPac_Pac_Sta->CRA_2.BIT.sBVOIP;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      4,r0
        and       *+ar0(1),r0
        lsh       -2,r0
        and       1,r0
        ldiu      *+fp(ir0),ar0
        ash       6,r0
        ldiu      *ar0,r1
        andn      64,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	190
;----------------------------------------------------------------------
; 2037 | pCommStatus_Lic->BYTE_1.BIT.nVtx = pPac_Pac_Sta->CRA_3.BIT.sBVTX;      
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      2,r0
        and       *+ar1(2),r0
        lsh       -1,r0
        and       1,r0
        ldiu      *+fp(ir1),ar0
        ash       1,r0
        ldiu      *ar0,r1
        andn      2,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	191
;----------------------------------------------------------------------
; 2038 | pCommStatus_Lic->BYTE_1.BIT.nWlr = pPac_Pac_Sta->CRA_2.BIT.sBWLR;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      1,r0
        and       *+ar1(1),r0
        ldiu      *+fp(ir1),ar0
        ash       4,r0
        ldiu      *ar0,r1
        andn      16,r1
        or3       r1,r0,r0
        sti       r0,*ar0
	.line	194
;----------------------------------------------------------------------
; 2041 | pCommStatus_Lic->BYTE_2.BIT.nFdi = pPac_Pac_Sta->CRA_4.BIT.sBFDI;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      4,r0
        and       *+ar0(3),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r1
        andn      64,r1
        lsh       -2,r0
        and       1,r0
        ash       6,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	195
;----------------------------------------------------------------------
; 2042 | pCommStatus_Lic->BYTE_2.BIT.nPii1 = pPac_Pac_Sta->CRA_4.BIT.sBPII1;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      2,r0
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        and       *+ar0(3),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r1
        lsh       -1,r0
        andn      32,r1
        and       1,r0
        ash       5,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	196
;----------------------------------------------------------------------
; 2043 | pCommStatus_Lic->BYTE_2.BIT.nPii2 = pPac_Pac_Sta->CRA_4.BIT.sBPII2;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      1,r0
        and       *+ar1(3),r0
        ldiu      *+fp(ir1),ar0
        ash       4,r0
        ldiu      *+ar0(1),r1
        andn      16,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	197
;----------------------------------------------------------------------
; 2044 | pCommStatus_Lic->BYTE_2.BIT.nSdi1 = pPac_Pac_Sta->CRA_5.BIT.sBSDI1;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      8,r0
        and       *+ar0(4),r0
        ldiu      391,ir0
        lsh       -3,r0
        ldiu      *+fp(ir0),ar0
        and       1,r0
        ldiu      *+ar0(1),r1
        ash       3,r0
        andn      8,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	198
;----------------------------------------------------------------------
; 2045 | pCommStatus_Lic->BYTE_2.BIT.nSdi2 = pPac_Pac_Sta->CRA_5.BIT.sBSDI2;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      4,r0
        ldiu      391,ir0
        and       *+ar0(4),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r1
        lsh       -2,r0
        and       1,r0
        andn      4,r1
        ash       2,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	199
;----------------------------------------------------------------------
; 2046 | pCommStatus_Lic->BYTE_2.BIT.nSdi3 = pPac_Pac_Sta->CRA_5.BIT.sBSDI3;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar1
        ldiu      2,r0
        and       *+ar1(4),r0
        ldiu      *+fp(ir1),ar0
        lsh       -1,r0
        ldiu      *+ar0(1),r1
        and       1,r0
        andn      2,r1
        ash       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	200
;----------------------------------------------------------------------
; 2047 | pCommStatus_Lic->BYTE_2.BIT.nSdi4 = pPac_Pac_Sta->CRA_5.BIT.sBSDI4;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      *+fp(ir0),ar1
        ldiu      *+ar0(1),r1
        andn      1,r1
        ldiu      1,r0
        and       *+ar1(4),r0
        or3       r1,r0,r0
        sti       r0,*+ar0(1)
	.line	202
;----------------------------------------------------------------------
; 2049 | pCommStatus_Lic->BYTE_3.BIT.nPid1_1 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_1;
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      *+ar0(2),r1
        ldiu      8,r0
        ldiu      *+fp(ir0),ar1
        andn      16,r1
        and       *+ar1(5),r0
        lsh       -3,r0
        and       1,r0
        ash       4,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	203
;----------------------------------------------------------------------
; 2050 | pCommStatus_Lic->BYTE_3.BIT.nPid1_2 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_2;
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar1
        ldiu      *+fp(ir1),ar0
        ldiu      4,r0
        and       *+ar1(5),r0
        lsh       -2,r0
        and       1,r0
        ash       3,r0
        ldiu      *+ar0(2),r1
        andn      8,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	204
;----------------------------------------------------------------------
; 2051 | pCommStatus_Lic->BYTE_3.BIT.nPid1_3 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_3;
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      *+ar0(2),r1
        andn      4,r1
        ldiu      *+fp(ir0),ar1
        ldiu      2,r0
        and       *+ar1(5),r0
        lsh       -1,r0
        and       1,r0
        ash       2,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	205
;----------------------------------------------------------------------
; 2052 | pCommStatus_Lic->BYTE_3.BIT.nPid1_4 = pPac_Pac_Sta->CRA_6.BIT.sBPID1_4;
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar0
        ldiu      *+ar0(2),r1
        ldiu      1,r0
        ldiu      *+fp(ir0),ar1
        andn      2,r1
        and       *+ar1(5),r0
        ash       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	206
;----------------------------------------------------------------------
; 2053 | pCommStatus_Lic->BYTE_3.BIT.nPid2_1 = pPac_Pac_Sta->CRA_7.BIT.sBPID2_1;
;----------------------------------------------------------------------
        ldiu      391,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      389,ir1
        ldiu      *+ar0(2),r1
        ldiu      *+fp(ir1),ar1
        ldiu      8,r0
        and       *+ar1(6),r0
        lsh       -3,r0
        and       1,r0
        andn      1,r1
        or3       r1,r0,r0
        sti       r0,*+ar0(2)
	.line	208
;----------------------------------------------------------------------
; 2055 | pCommStatus_Lic->BYTE_4.BIT.nDph = pPac_Pac_Sta->CRA_9.BIT.sBDPH;      
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      8,r0
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        and       *+ar0(8),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r1
        andn      128,r1
        lsh       -3,r0
        and       1,r0
        ash       7,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	209
;----------------------------------------------------------------------
; 2056 | pCommStatus_Lic->BYTE_4.BIT.nDpo = pPac_Pac_Sta->CRA_9.BIT.sBDPO;      
;----------------------------------------------------------------------
        ldiu      *+fp(ir1),ar1
        ldiu      1,r1
        ldiu      *+fp(ir0),ar0
        and       *+ar1(8),r1
        ldiu      *+ar0(3),r0
        ash       4,r1
        andn      16,r0
        or3       r0,r1,r0
        sti       r0,*+ar0(3)
	.line	210
;----------------------------------------------------------------------
; 2057 | pCommStatus_Lic->BYTE_4.BIT.nPei1 = pPac_Pac_Sta->CRA_7.BIT.sBPEI1;    
;----------------------------------------------------------------------
        ldiu      *+fp(ir0),ar0
        ldiu      1,r0
        ldiu      *+ar0(3),r1
        ldiu      *+fp(ir1),ar1
        andn      1,r1
        and       *+ar1(6),r0
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	211
;----------------------------------------------------------------------
; 2058 | pCommStatus_Lic->BYTE_4.BIT.nPei2 = pPac_Pac_Sta->CRA_7.BIT.sBPEI2;    
;----------------------------------------------------------------------
        ldiu      389,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      391,ir0
        ldiu      2,r0
        and       *+ar0(6),r0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r1
        lsh       -1,r0
        andn      2,r1
        and       1,r0
        ash       1,r0
        or3       r1,r0,r0
        sti       r0,*+ar0(3)
	.line	212
;----------------------------------------------------------------------
; 2059 | break;                                                                 
; 2066 | else                                                                   
;----------------------------------------------------------------------
        bu        L742
;*      Branch Occurs to L742 
L729:        
	.line	138
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
        cmpi      4,r0
        blt       L722
;*      Branch Occurs to L722 
        bu        L742
;*      Branch Occurs to L742 
L731:        
	.line	220
;----------------------------------------------------------------------
; 2067 | if(WORD_L(pCcp_Pac->phHdBuf.btSoh) == SOH &&  // CCP -> PAC ���� ���� �
;     | ����� �����Ѵ�.                                                        
; 2068 |         WORD_L(pCcp_Pac->btEot) == EOT &&                              
; 2069 |         sizeof(CCP_PAC) == nRxPos &&                                   
; 2070 |         (TWOBYTE_ASC2HEX(pCcp_Pac->phHdBuf.chSrcDev) == CCP_DEV_NO) && 
; 2071 |         (TWOBYTE_ASC2HEX(pCcp_Pac->phHdBuf.chDestDev) == PAC_DEV_NO)&& 
; 2073 |         ConvAsc2Hex(pCcp_Pac->nCRC[0]) == BYTE_H(WORD_H(crc16_ccitt(&pC
;     | cp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))&&                              
; 2074 |         ConvAsc2Hex(pCcp_Pac->nCRC[1]) == BYTE_L(WORD_H(crc16_ccitt(&pC
;     | cp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))&&                              
; 2075 |         ConvAsc2Hex(pCcp_Pac->nCRC[2]) == BYTE_H(WORD_L(crc16_ccitt(&pC
;     | cp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))&&                              
; 2076 |         ConvAsc2Hex(pCcp_Pac->nCRC[3]) == BYTE_L(WORD_L(crc16_ccitt(&pC
;     | cp_Pac->phHdBuf.chSrcDev[0],nRxPos-6)))                                
; 2077 |         )                                                              
;----------------------------------------------------------------------
        ldiu      388,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and3      r0,*ar0,r0
        cmpi      1,r0
        bne       L742
;*      Branch Occurs to L742 
        ldiu      *+fp(ir0),ar0
        ldiu      255,r0
        and       *+ar0(155),r0
        cmpi      4,r0
        bne       L742
;*      Branch Occurs to L742 
        ldiu      156,r0
        cmpi      @_nRxPos$12+0,r0
        bne       L742
;*      Branch Occurs to L742 
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(1),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      388,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(2),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      17,r0
        subi      1,sp
        bne       L742
;*      Branch Occurs to L742 
        ldiu      388,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(3),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      388,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(4),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        cmpi      33,r0
        subi      1,sp
        bne       L742
;*      Branch Occurs to L742 
        ldiu      1,r1
        ldiu      388,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      388,ir0
        ldiu      r0,r4
        subi      2,sp
        lsh       -8,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(151),r0
        lsh       -4,r4
        and       15,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L742
;*      Branch Occurs to L742 
        ldiu      1,r1
        ldiu      388,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        subi      2,sp
        ldiu      388,ir0
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(152),r0
        lsh       -8,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L742
;*      Branch Occurs to L742 
        ldiu      1,r1
        ldiu      388,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      388,ir0
        subi      2,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        and       255,r4
        ldiu      *+ar0(153),r0
        lsh       -4,r4
        push      r0
        and       15,r4
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L742
;*      Branch Occurs to L742 
        ldiu      1,r1
        ldiu      388,ir0
        ldiu      6,r0
        addi3     r1,*+fp(ir0),r1       ; Unsigned
        subri     @_nRxPos$12+0,r0
        push      r0
        push      r1
        call      _crc16_ccitt
                                        ; Call Occurs
        ldiu      388,ir0
        subi      2,sp
        ldiu      *+fp(ir0),ar0
        ldiu      r0,r4
        ldiu      *+ar0(154),r1
        and       15,r4
        push      r1
        call      _ConvAsc2Hex
                                        ; Call Occurs
        cmpi3     r4,r0
        subi      1,sp
        bne       L742
;*      Branch Occurs to L742 
	.line	232
;----------------------------------------------------------------------
; 2079 | d_CCP_PAC_Cnt++;                                                       
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_d_CCP_PAC_Cnt+0,r0
        sti       r0,@_d_CCP_PAC_Cnt+0
	.line	234
;----------------------------------------------------------------------
; 2081 | d_CI_Index = MAKE_BYTE(ConvAsc2Hex(pCcp_Pac->sCI_Index[0][0]),ConvAsc2H
;     | ex(pCcp_Pac->sCI_Index[0][1]) );                                       
;----------------------------------------------------------------------
        ldiu      388,ir0
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(123),r0
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        ldiu      388,ir0
        subi      1,sp
        ldiu      r0,r4
        ldiu      *+fp(ir0),ar0
        ldiu      *+ar0(124),r0
        ash       4,r4
        push      r0
        call      _ConvAsc2Hex
                                        ; Call Occurs
        and       15,r0
        or3       r4,r0,r0
        and       255,r0
        subi      1,sp
        sti       r0,@_d_CI_Index+0
	.line	236
;----------------------------------------------------------------------
; 2083 | FunConvAscHex((char *)&pCcp_Pac->sCCP_Date[0][0],btTmpBuf,12);         
;----------------------------------------------------------------------
        ldiu      388,ir0
        ldiu      139,r0
        ldiu      12,r1
        addi3     r0,*+fp(ir0),r2       ; Unsigned
        push      r1
        ldiu      fp,r0
        addi      5,r0
        push      r0
        push      r2
        call      _FunConvAscHex
                                        ; Call Occurs
        subi      3,sp
	.line	238
;----------------------------------------------------------------------
; 2085 | memcpy(&m_tmCurTime.second,btTmpBuf,6);                                
;----------------------------------------------------------------------
        ldiu      fp,ar0
        addi      5,ar0
        ldiu      @CL16,ar1
        ldiu      *ar0++(1),r0
        rpts      4                     ; Fast MEMCPY(#18)
        sti       r0,*ar1++(1)
||      ldi       *ar0++(1),r0
        sti       r0,*ar1++(1)
	.line	247
;----------------------------------------------------------------------
; 2094 | memset(&m_tmUtcTime, 0x00, sizeof(DATE_TIME_TYPE));                    
;----------------------------------------------------------------------
        ldiu      7,r2
        push      r2
        ldiu      0,r0
        push      r0
        ldiu      @CL15,r1
        push      r1
        call      _memset
                                        ; Call Occurs
        subi      3,sp
	.line	249
;----------------------------------------------------------------------
; 2096 | if(m_LIC_CNCS_TimSetFlag = GetLocalTimeToUTC(&m_tmCurTime, -5, &m_tmUtc
;     | Time))                                                                 
;----------------------------------------------------------------------
        ldiu      -5,r2
        ldiu      @CL15,r1
        push      r1
        push      r2
        ldiu      @CL16,r0
        push      r0
        call      _GetLocalTimeToUTC
                                        ; Call Occurs
        cmpi      0,r0
        beqd      L742
	nop
        subi      3,sp
        sti       r0,@_m_LIC_CNCS_TimSetFlag+0
;*      Branch Occurs to L742 
	.line	251
;----------------------------------------------------------------------
; 2098 | m_tmUtcTime.year        = ConvDec2Hex(m_tmUtcTime.year  );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+5,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+5
        subi      1,sp
	.line	252
;----------------------------------------------------------------------
; 2099 | m_tmUtcTime.month       = ConvDec2Hex(m_tmUtcTime.month );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+4,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+4
        subi      1,sp
	.line	253
;----------------------------------------------------------------------
; 2100 | m_tmUtcTime.day         = ConvDec2Hex(m_tmUtcTime.day   );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+3,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+3
        subi      1,sp
	.line	254
;----------------------------------------------------------------------
; 2101 | m_tmUtcTime.hour        = ConvDec2Hex(m_tmUtcTime.hour  );             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+2,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+2
        subi      1,sp
	.line	255
;----------------------------------------------------------------------
; 2102 | m_tmUtcTime.minute      = ConvDec2Hex(m_tmUtcTime.minute);             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+1,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+1
        subi      1,sp
	.line	256
;----------------------------------------------------------------------
; 2103 | m_tmUtcTime.second      = ConvDec2Hex(m_tmUtcTime.second);             
;----------------------------------------------------------------------
        ldiu      @_m_tmUtcTime+0,r0
        push      r0
        call      _ConvDec2Hex
                                        ; Call Occurs
        sti       r0,@_m_tmUtcTime+0
        subi      1,sp
	.line	258
;----------------------------------------------------------------------
; 2105 | m_nCncsRxCheck1msTimer = 2000;                                         
;----------------------------------------------------------------------
        ldiu      2000,r0
        sti       r0,@_m_nCncsRxCheck1msTimer+0
L742:        
	.line	268
;----------------------------------------------------------------------
; 2115 | nOldUart3RxOneByteGapDelayTime = m_nUart3RxOneByteGapDelayTime;        
;----------------------------------------------------------------------
        ldiu      @_m_nUart3RxOneByteGapDelayTime+0,r0
        sti       r0,@_nOldUart3RxOneByteGapDelayTime$13+0
	.line	269
        ldiu      *-fp(1),bk
        pop       r4
        ldiu      *fp,fp
        subi      393,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	2116,000000010h,391


	.sect	 ".text"

	.global	_GetLocalTimeToUTC
	.sym	_GetLocalTimeToUTC,_GetLocalTimeToUTC,36,2,0
	.func	2121
;******************************************************************************
;* FUNCTION NAME: _GetLocalTimeToUTC                                          *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,r4,ar0,ar1,fp,sp,st                           *
;*   Regs Saved         : r4                                                  *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 3 Parm + 5 Auto + 1 SOE = 11 words         *
;******************************************************************************
_GetLocalTimeToUTC:
	.sym	_pLocal,-2,24,9,32,.fake5
	.sym	_nHour,-3,4,9,32
	.sym	_pUTC,-4,24,9,32,.fake5
	.sym	_nHourT,1,4,1,32
	.sym	_nDayT,2,4,1,32
	.sym	_nLastDays,3,4,1,32
	.sym	_nMonthT,4,4,1,32
	.sym	_nYearT,5,4,1,32
	.line	1
;----------------------------------------------------------------------
; 2121 | BOOL GetLocalTimeToUTC( DATE_TIME_PTR pLocal, int nHour, DATE_TIME_PTR
;     | pUTC )                                                                 
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
        addi      5,sp
        push      r4
	.line	2
;----------------------------------------------------------------------
; 2123 | // �ð��� ����ϴ� �κ�.                                               
;----------------------------------------------------------------------
	.line	4
;----------------------------------------------------------------------
; 2124 | int nHourT = pLocal->hour - nHour;                                     
;----------------------------------------------------------------------
        ldiu      *-fp(2),ar0
        ldiu      *-fp(3),r0
        subri     *+ar0(2),r0           ; Unsigned
        sti       r0,*+fp(1)
	.line	5
;----------------------------------------------------------------------
; 2125 | int nDayT = pLocal->day;                                               
;----------------------------------------------------------------------
        ldiu      *+ar0(3),r0
        sti       r0,*+fp(2)
	.line	6
;----------------------------------------------------------------------
; 2126 | int nLastDays = GetDaysOfMonth( pLocal->month, pLocal->year );
;     |                                                                        
;     |                                                                        
;----------------------------------------------------------------------
        ldiu      ar0,ar1
        ldiu      *+ar0(4),r1
        ldiu      *+ar1(5),r0
        push      r0
        push      r1
        call      _GetDaysOfMonth
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(3)
	.line	7
;----------------------------------------------------------------------
; 2127 | int nMonthT = pLocal->month;                                           
;----------------------------------------------------------------------
        ldiu      *-fp(2),ar0
        ldiu      *+ar0(4),r0
        sti       r0,*+fp(4)
	.line	8
;----------------------------------------------------------------------
; 2128 | int nYearT = 2000 + pLocal->year;                                      
; 2130 | // �ð� ������ ���ϴ� �κ�.                                            
;----------------------------------------------------------------------
        ldiu      2000,r0
        addi      *+ar0(5),r0           ; Unsigned
        sti       r0,*+fp(5)
	.line	11
;----------------------------------------------------------------------
; 2131 | if(nHourT < 0 ) {                                                      
;----------------------------------------------------------------------
        ldi       *+fp(1),r0
        bge       L747
;*      Branch Occurs to L747 
	.line	12
;----------------------------------------------------------------------
; 2132 | nHourT += 24;                                                          
;----------------------------------------------------------------------
        ldiu      24,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
	.line	13
;----------------------------------------------------------------------
; 2133 | nDayT += -1;                                                           
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     *+fp(2),r0
        sti       r0,*+fp(2)
        bu        L749
;*      Branch Occurs to L749 
L747:        
	.line	15
;----------------------------------------------------------------------
; 2135 | else if( 24 <= nHourT ) {                                              
;----------------------------------------------------------------------
        ldiu      24,r0
        cmpi      *+fp(1),r0
        bgt       L749
;*      Branch Occurs to L749 
	.line	16
;----------------------------------------------------------------------
; 2136 | nHourT -= 24;                                                          
;----------------------------------------------------------------------
        subri     *+fp(1),r0
        sti       r0,*+fp(1)
	.line	17
;----------------------------------------------------------------------
; 2137 | nDayT += 1;                                                            
; 2140 | // ���ڸ� ���ϴ� �κ�.                                                 
; 2141 | // �ð��� ����Ͽ� ���ڸ� �����ؾ��ϴ� ���.                           
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      *+fp(2),r0
        sti       r0,*+fp(2)
L749:        
	.line	22
;----------------------------------------------------------------------
; 2142 | if(nDayT < 1)
;     |                                                                        
;     |                                                                        
;     |                                                                        
;----------------------------------------------------------------------
        ldi       *+fp(2),r0
        bgt       L752
;*      Branch Occurs to L752 
	.line	24
;----------------------------------------------------------------------
; 2144 | nDayT = GetDaysOfMonth( nMonthT, nYearT );                             
;----------------------------------------------------------------------
        ldiu      *+fp(5),r0
        push      r0
        ldiu      *+fp(4),r0
        push      r0
        call      _GetDaysOfMonth
                                        ; Call Occurs
        subi      2,sp
        sti       r0,*+fp(2)
	.line	26
;----------------------------------------------------------------------
; 2146 | if(--nMonthT < 1)                                                      
;----------------------------------------------------------------------
        ldiu      1,r0
        subri     *+fp(4),r0
        bgtd      L755
        sti       r0,*+fp(4)
	nop
        ldile     1,r0
;*      Branch Occurs to L755 
	.line	28
;----------------------------------------------------------------------
; 2148 | nYearT--;                                                              
;----------------------------------------------------------------------
        subri     *+fp(5),r0
        sti       r0,*+fp(5)
	.line	29
;----------------------------------------------------------------------
; 2149 | nMonthT = 12;                                                          
;----------------------------------------------------------------------
        ldiu      12,r0
        sti       r0,*+fp(4)
        bu        L755
;*      Branch Occurs to L755 
L752:        
	.line	32
;----------------------------------------------------------------------
; 2152 | else if(nLastDays < nDayT)                                             
;----------------------------------------------------------------------
        ldiu      *+fp(3),r0
        cmpi      *+fp(2),r0
        bge       L755
;*      Branch Occurs to L755 
	.line	34
;----------------------------------------------------------------------
; 2154 | nDayT = 1;                                                             
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,*+fp(2)
	.line	36
;----------------------------------------------------------------------
; 2156 | if(12 < ++nMonthT)                                                     
;----------------------------------------------------------------------
        ldiu      12,r1
        addi      *+fp(4),r0
        cmpi3     r0,r1
        bged      L755
        sti       r0,*+fp(4)
	nop
        ldilt     1,r0
;*      Branch Occurs to L755 
	.line	38
;----------------------------------------------------------------------
; 2158 | nYearT++;                                                              
;----------------------------------------------------------------------
        addi      *+fp(5),r0
        sti       r0,*+fp(5)
	.line	39
;----------------------------------------------------------------------
; 2159 | nMonthT = 1;                                                           
; 2163 | // �谣�� �ú��� ������ UTC �ð����� �̵���Ű�� �κ�.                  
;----------------------------------------------------------------------
        ldiu      1,r0
        sti       r0,*+fp(4)
L755:        
	.line	44
;----------------------------------------------------------------------
; 2164 | pUTC->second = pLocal->second;                                         
;----------------------------------------------------------------------
        ldiu      *-fp(2),ar0
        ldiu      *-fp(4),ar1
        ldiu      *ar0,r0
        sti       r0,*ar1
	.line	45
;----------------------------------------------------------------------
; 2165 | pUTC->minute = pLocal->minute;                                         
;----------------------------------------------------------------------
        ldiu      *-fp(2),ar1
        ldiu      *-fp(4),ar0
        ldiu      *+ar1(1),r0
        sti       r0,*+ar0(1)
	.line	46
;----------------------------------------------------------------------
; 2166 | pUTC->hour = nHourT;                                                   
;----------------------------------------------------------------------
        ldiu      *-fp(4),ar0
        ldiu      *+fp(1),r0
        sti       r0,*+ar0(2)
	.line	47
;----------------------------------------------------------------------
; 2167 | pUTC->day = nDayT;                                                     
;----------------------------------------------------------------------
        ldiu      *-fp(4),ar0
        ldiu      *+fp(2),r0
        sti       r0,*+ar0(3)
	.line	48
;----------------------------------------------------------------------
; 2168 | pUTC->month = nMonthT;                                                 
;----------------------------------------------------------------------
        ldiu      *-fp(4),ar0
        ldiu      *+fp(4),r0
        sti       r0,*+ar0(4)
	.line	49
;----------------------------------------------------------------------
; 2169 | pUTC->year = nYearT - 2000;                                            
; 2171 | return      (( 10 <= pUTC->year ) &&
;     |                                                                        
;     |                                   // 10�� �̻�                         
; 2172 |                         (( 1 <= pUTC->month ) && ( pUTC->month <= 12 ))
;     |  &&                                                                    
;     |                   // ��                                                
; 2173 |                         (( 1 <= pUTC->day )   && ( pUTC->day <= GetDays
;     | OfMonth(nMonthT, nYearT) )) &&                           // ��         
; 2174 |                         (( 0 <= pUTC->hour )  && ( pUTC->hour < 24 ))
;     |  &&                                                                    
;     |                   // ��                                                
; 2175 |                         (( 0 <= pUTC->minute) && ( pUTC->minute < 60 ))
;     |  &&                                                                    
;     |                   // ��                                                
;----------------------------------------------------------------------
        ldiu      2000,r0
        ldiu      *-fp(4),ar0
        subri     *+fp(5),r0            ; Unsigned
        sti       r0,*+ar0(5)
	.line	56
;----------------------------------------------------------------------
; 2176 | (( 0 <= pUTC->second) && ( pUTC->second < 60 )));
;     |                                                                  // �� 
;----------------------------------------------------------------------
        ldiu      *-fp(4),ar0
        ldiu      10,r0
        cmpi      *+ar0(5),r0
        ldiu      0,r4
        bhi       L766
;*      Branch Occurs to L766 
        ldiu      1,r0
        cmpi      *+ar0(4),r0
        bhi       L766
;*      Branch Occurs to L766 
        ldiu      *+ar0(4),r0
        cmpi      12,r0
        bhi       L766
;*      Branch Occurs to L766 
        ldiu      1,r0
        cmpi      *+ar0(3),r0
        bhi       L766
;*      Branch Occurs to L766 
        ldiu      *+fp(5),r0
        push      r0
        ldiu      *+fp(4),r0
        push      r0
        call      _GetDaysOfMonth
                                        ; Call Occurs
        subi      2,sp
        ldiu      *-fp(4),ar0
        ldiu      *+ar0(3),r1
        cmpi3     r0,r1
        bhi       L766
;*      Branch Occurs to L766 
        ldiu      0,r0
        cmpi      *+ar0(2),r0
        bhi       L766
;*      Branch Occurs to L766 
        ldiu      *+ar0(2),r0
        cmpi      24,r0
        bhs       L766
;*      Branch Occurs to L766 
        ldiu      0,r0
        cmpi3     *+ar0,r0
        bhi       L766
;*      Branch Occurs to L766 
        ldiu      *+ar0(1),r0
        cmpi      60,r0
        bhs       L766
;*      Branch Occurs to L766 
        ldiu      0,r0
        cmpi3     *ar0,r0
        bhi       L766
;*      Branch Occurs to L766 
        ldiu      *ar0,r0
        cmpi      60,r0
        ldilo     1,r4
L766:        
	.line	57
        ldiu      r4,r0
        ldiu      *-fp(1),bk
        pop       r4
        ldiu      *fp,fp
        subi      7,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	2177,000000010h,5


	.sect	 ".text"

	.global	_IsLeapYear
	.sym	_IsLeapYear,_IsLeapYear,36,2,0
	.func	2182
;******************************************************************************
;* FUNCTION NAME: _IsLeapYear                                                 *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,st                                            *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 1 Parm + 0 Auto + 0 SOE = 3 words          *
;******************************************************************************
_IsLeapYear:
	.sym	_nYear,-2,4,9,32
	.line	1
;----------------------------------------------------------------------
; 2182 | int IsLeapYear( int nYear )
;     |                  // ���� ������ ���ϴ� �κ�.                           
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	3
;----------------------------------------------------------------------
; 2184 | if( nYear % 400 == 0 )                                                 
;----------------------------------------------------------------------
        ldiu      400,r1
        ldiu      *-fp(2),r0
        call      MOD_I30
                                        ; Call Occurs
        cmpi      0,r0
        bne       L771
;*      Branch Occurs to L771 
	.line	4
;----------------------------------------------------------------------
; 2185 | return 1;                                                              
;----------------------------------------------------------------------
        bud       L776
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L776 
L771:        
	.line	6
;----------------------------------------------------------------------
; 2187 | if( nYear % 100 == 0 )                                                 
;----------------------------------------------------------------------
        ldiu      *-fp(2),r0
        ldiu      100,r1
        call      MOD_I30
                                        ; Call Occurs
        cmpi      0,r0
        bne       L773
;*      Branch Occurs to L773 
	.line	7
;----------------------------------------------------------------------
; 2188 | return 0;                                                              
;----------------------------------------------------------------------
        bud       L776
	nop
	nop
        ldiu      0,r0
;*      Branch Occurs to L776 
L773:        
	.line	9
;----------------------------------------------------------------------
; 2190 | if( nYear % 4 == 0 )                                                   
;----------------------------------------------------------------------
        ldiu      *-fp(2),r1
        ldiu      r1,r0
        ash       -1,r0
        lsh       @CL112,r0
        addi3     r0,r1,r0
        andn      3,r0
        subri     r1,r0
        bne       L775
;*      Branch Occurs to L775 
	.line	10
;----------------------------------------------------------------------
; 2191 | return 1;                                                              
;----------------------------------------------------------------------
        bud       L776
	nop
	nop
        ldiu      1,r0
;*      Branch Occurs to L776 
L775:        
	.line	12
;----------------------------------------------------------------------
; 2193 | return 0;                                                              
;----------------------------------------------------------------------
        ldiu      0,r0
L776:        
	.line	13
        ldiu      *-fp(1),ar1
        ldiu      *fp,fp
        subi      2,sp
        bu        ar1
;*      Branch Occurs to ar1 
	.endfunc	2194,000000000h,0


	.sect	 ".text"

	.global	_GetDaysOfMonth
	.sym	_GetDaysOfMonth,_GetDaysOfMonth,36,2,0
	.func	2196
;******************************************************************************
;* FUNCTION NAME: _GetDaysOfMonth                                             *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,ar0,fp,ir0,sp,st                                 *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 2 Parm + 1 Auto + 0 SOE = 5 words          *
;******************************************************************************
_GetDaysOfMonth:
	.sym	_nMonth,-2,4,9,32
	.sym	_nYear,-3,4,9,32
	.sym	_nDays,1,4,1,32
	.line	1
;----------------------------------------------------------------------
; 2196 | int GetDaysOfMonth( int nMonth, int nYear )
;     |  // ���� ������ ���ڸ� ���ϴ� �κ�.                                    
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	2
	.line	4
;----------------------------------------------------------------------
; 2199 | int nDays = 0;                                                         
; 2201 | switch( nMonth )                                                       
; 2203 | case 1 :
;     |                                  // 31�� ������ ����                   
; 2204 | case 3 :                                                               
; 2205 | case 5 :                                                               
; 2206 | case 7 :                                                               
; 2207 | case 8 :                                                               
; 2208 | case 10 :                                                              
; 2209 | case 12 :                                                              
;----------------------------------------------------------------------
        bud       L784
        addi      1,sp
        ldiu      0,r0
        sti       r0,*+fp(1)
;*      Branch Occurs to L784 
L779:        
	.line	15
;----------------------------------------------------------------------
; 2210 | nDays = 31;                                                            
;----------------------------------------------------------------------
        ldiu      31,r0
        sti       r0,*+fp(1)
	.line	16
;----------------------------------------------------------------------
; 2211 | break;                                                                 
; 2212 | case 2 :                                                               
;----------------------------------------------------------------------
        bu        L786
;*      Branch Occurs to L786 
L780:        
	.line	18
;----------------------------------------------------------------------
; 2213 | nDays = 28;                                                            
;----------------------------------------------------------------------
        ldiu      28,r0
        sti       r0,*+fp(1)
	.line	19
;----------------------------------------------------------------------
; 2214 | if( IsLeapYear( nYear ) )
;     |          // ������ ����Ͽ�, ������ ���, +1                           
;----------------------------------------------------------------------
        ldiu      *-fp(3),r0
        push      r0
        call      _IsLeapYear
                                        ; Call Occurs
        cmpi      0,r0
        subi      1,sp
        beq       L786
;*      Branch Occurs to L786 
	.line	20
;----------------------------------------------------------------------
; 2215 | nDays += 1;                                                            
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      *+fp(1),r0
        sti       r0,*+fp(1)
	.line	21
;----------------------------------------------------------------------
; 2216 | break;                                                                 
; 2217 | case 4 :
;     |                                  // 30�� ������ ����                   
; 2218 | case 6 :                                                               
; 2219 | case 9 :                                                               
; 2220 | case 11 :                                                              
;----------------------------------------------------------------------
        bu        L786
;*      Branch Occurs to L786 
L782:        
	.line	26
;----------------------------------------------------------------------
; 2221 | nDays = 30;                                                            
;----------------------------------------------------------------------
        ldiu      30,r0
        sti       r0,*+fp(1)
	.line	27
;----------------------------------------------------------------------
; 2222 | break;                                                                 
;----------------------------------------------------------------------
        bu        L786
;*      Branch Occurs to L786 
L784:        
	.line	6
        ldiu      1,r0
        ldiu      *-fp(2),ir0
        subri     ir0,r0
        cmpi      11,r0
        bhi       L786
;*      Branch Occurs to L786 
        subi      1,ir0
        ldiu      @CL113,ar0
        ldiu      *+ar0(ir0),r0
        bu        r0

	.sect	".text"
SW1:	.word	L779	; 1
	.word	L780	; 2
	.word	L779	; 3
	.word	L782	; 4
	.word	L779	; 5
	.word	L782	; 6
	.word	L779	; 7
	.word	L779	; 8
	.word	L782	; 9
	.word	L779	; 10
	.word	L782	; 11
	.word	L779	; 12
	.sect	".text"
;*      Branch Occurs to r0 
L786:        
	.line	30
;----------------------------------------------------------------------
; 2225 | return nDays;                                                          
;----------------------------------------------------------------------
        ldiu      *+fp(1),r0
	.line	31
        ldiu      *-fp(1),bk
        ldiu      *fp,fp
        subi      3,sp
        bu        bk
;*      Branch Occurs to bk 
	.endfunc	2226,000000000h,1


	.sect	 ".text"

	.global	_user_1msLoop
	.sym	_user_1msLoop,_user_1msLoop,32,2,0
	.func	2232
;******************************************************************************
;* FUNCTION NAME: _user_1msLoop                                               *
;*                                                                            *
;*   Architecture       : TMS320C30                                           *
;*   Calling Convention : Stack Parameter Convention                          *
;*   Function Uses Regs : r0,r1,st                                            *
;*   Regs Saved         :                                                     *
;*   Stack Frame        : Full (w/ debug)                                     *
;*   Total Frame Size   : 2 Call + 0 Parm + 0 Auto + 0 SOE = 2 words          *
;******************************************************************************
_user_1msLoop:
	.line	1
;----------------------------------------------------------------------
; 2232 | void user_1msLoop()                                                    
;----------------------------------------------------------------------
        push      fp
        ldiu      sp,fp
	.line	3
;----------------------------------------------------------------------
; 2234 | m_nTxDbg1msTimer++;                                                    
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nTxDbg1msTimer+0,r0 ; Unsigned
        sti       r0,@_m_nTxDbg1msTimer+0
	.line	4
;----------------------------------------------------------------------
; 2235 | m_nUserDebug1msTimer++;                                                
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nUserDebug1msTimer+0,r0 ; Unsigned
        sti       r0,@_m_nUserDebug1msTimer+0
	.line	5
;----------------------------------------------------------------------
; 2236 | m_nSingleOrMarriedCarUpdate1msTimer++;                                 
;----------------------------------------------------------------------
        ldiu      1,r0
        addi      @_m_nSingleOrMarriedCarUpdate1msTimer+0,r0 ; Unsigned
        sti       r0,@_m_nSingleOrMarriedCarUpdate1msTimer+0
	.line	7
;----------------------------------------------------------------------
; 2238 | if(!(m_nUserDebug1msTimer%100)) //A�� ���� �ϰ� 1�� �ִٰ� B�� ���� �ϱ
;     | � ���Ͽ� �ð��� ������ �Ѵ�.                                           
;----------------------------------------------------------------------
        ldiu      100,r1
        ldiu      @_m_nUserDebug1msTimer+0,r0
        call      MOD_U30
                                        ; Call Occurs
        cmpi      0,r0
        bne       L792
;*      Branch Occurs to L792 
	.line	9
;----------------------------------------------------------------------
; 2240 | if(m_nCDT_FaultDataStFlag) m_nCDT_FaultDataStFlag--;                   
;----------------------------------------------------------------------
        ldi       @_m_nCDT_FaultDataStFlag+0,r0
        beq       L792
;*      Branch Occurs to L792 
        ldiu      1,r0
        subri     @_m_nCDT_FaultDataStFlag+0,r0
        sti       r0,@_m_nCDT_FaultDataStFlag+0
L792:        
	.line	12
;----------------------------------------------------------------------
; 2243 | if(m_nUart1RxOneByteGapDelayTime) m_nUart1RxOneByteGapDelayTime--;     
;----------------------------------------------------------------------
        ldi       @_m_nUart1RxOneByteGapDelayTime+0,r0
        beq       L794
;*      Branch Occurs to L794 
        ldiu      1,r0
        subri     @_m_nUart1RxOneByteGapDelayTime+0,r0 ; Unsigned
        sti       r0,@_m_nUart1RxOneByteGapDelayTime+0
L794:        
	.line	13
;----------------------------------------------------------------------
; 2244 | if(m_nUart2RxOneByteGapDelayTime) m_nUart2RxOneByteGapDelayTime--;     
;----------------------------------------------------------------------
        ldi       @_m_nUart2RxOneByteGapDelayTime+0,r0
        beq       L796
;*      Branch Occurs to L796 
        ldiu      1,r0
        subri     @_m_nUart2RxOneByteGapDelayTime+0,r0 ; Unsigned
        sti       r0,@_m_nUart2RxOneByteGapDelayTime+0
L796:        
	.line	14
;----------------------------------------------------------------------
; 2245 | if(m_nUart3RxOneByteGapDelayTime) m_nUart3RxOneByteGapDelayTime--;     
;----------------------------------------------------------------------
        ldi       @_m_nUart3RxOneByteGapDelayTime+0,r0
        beq       L798
;*      Branch Occurs to L798 
        ldiu      1,r0
        subri     @_m_nUart3RxOneByteGapDelayTime+0,r0 ; Unsigned
        sti       r0,@_m_nUart3RxOneByteGapDelayTime+0
L798:        
	.line	16
;----------------------------------------------------------------------
; 2247 | if(m_nGiaRxCheck1msTimer) m_nGiaRxCheck1msTimer--;                     
;----------------------------------------------------------------------
        ldi       @_m_nGiaRxCheck1msTimer+0,r0
        beq       L800
;*      Branch Occurs to L800 
        ldiu      1,r0
        subri     @_m_nGiaRxCheck1msTimer+0,r0 ; Unsigned
        sti       r0,@_m_nGiaRxCheck1msTimer+0
L800:        
	.line	18
;----------------------------------------------------------------------
; 2249 | if(m_nCncsRxCheck1msTimer) m_nCncsRxCheck1msTimer--;                   
;----------------------------------------------------------------------
        ldi       @_m_nCncsRxCheck1msTimer+0,r0
        beq       L802
;*      Branch Occurs to L802 
        ldiu      1,r0
        subri     @_m_nCncsRxCheck1msTimer+0,r0 ; Unsigned
        sti       r0,@_m_nCncsRxCheck1msTimer+0
L802:        
	.line	19
        ldiu      *-fp(1),ar1
        ldiu      *fp,fp
        subi      2,sp
        bu        ar1
;*      Branch Occurs to ar1 
	.endfunc	2250,000000000h,0



	.global	_d_TimeTxBuf
	.bss	_d_TimeTxBuf,10
	.sym	_d_TimeTxBuf,_d_TimeTxBuf,52,2,320,,10

	.global	_m_tFaultInfo
	.bss	_m_tFaultInfo,6
	.sym	_m_tFaultInfo,_m_tFaultInfo,56,2,192,.fake74,2

	.global	_d_LonRxData
	.bss	_d_LonRxData,100
	.sym	_d_LonRxData,_d_LonRxData,60,2,3200,,100

	.global	_m_btExVersionTbl
	.bss	_m_btExVersionTbl,28
	.sym	_m_btExVersionTbl,_m_btExVersionTbl,61,2,896,,28

	.global	_m_tmUtcTime
	.bss	_m_tmUtcTime,7
	.sym	_m_tmUtcTime,_m_tmUtcTime,8,2,224,.fake5

	.global	_m_btCommSt
	.bss	_m_btCommSt,7
	.sym	_m_btCommSt,_m_btCommSt,60,2,224,,7

	.global	_d_RxUnitStBuf
	.bss	_d_RxUnitStBuf,100
	.sym	_d_RxUnitStBuf,_d_RxUnitStBuf,60,2,3200,,100

	.global	_m_btExVersion_DAYTbl
	.bss	_m_btExVersion_DAYTbl,28
	.sym	_m_btExVersion_DAYTbl,_m_btExVersion_DAYTbl,61,2,896,,28

	.global	_d_LonTxDataBuf
	.bss	_d_LonTxDataBuf,30
	.sym	_d_LonTxDataBuf,_d_LonTxDataBuf,52,2,960,,30

	.global	_m_bExVersionEnableTbl
	.bss	_m_bExVersionEnableTbl,28
	.sym	_m_bExVersionEnableTbl,_m_bExVersionEnableTbl,52,2,896,,28

	.global	_mRackDi
	.bss	_mRackDi,1
	.sym	_mRackDi,_mRackDi,8,2,32,.fake71

	.global	_m_tmCurTime
	.bss	_m_tmCurTime,7
	.sym	_m_tmCurTime,_m_tmCurTime,8,2,224,.fake5
;******************************************************************************
;* STRINGS                                                                    *
;******************************************************************************
	.sect	".const"
SL1:	.byte	"Lonwork Monitor Program, Version:%d.%d%d%d",13,10,0
SL2:	.byte	"->",13,10,0
SL3:	.byte	"T",0
SL4:	.byte	"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%"
	.byte	"02X[minute],%02X[second] ",13,10,0
SL5:	.byte	"Not Date&time format ",13,10,0
SL6:	.byte	"t",0
SL7:	.byte	"V",0
SL8:	.byte	"LIC-MPU Version:%d.%d%d%d,Build Date:20%06d, LIC-LON Versio"
	.byte	"n:%d.%d%d%d,Build Date:%08X",13,10,0
SL9:	.byte	"---",0
SL10:	.byte	13,10,0
SL11:	.byte	"Recent",0
SL12:	.byte	"Recent fault read start send ",13,10,0
SL13:	.byte	"Historical",0
SL14:	.byte	"Historical read start send, Historical start time : %08XH, "
	.byte	"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%"
	.byte	"02X[minute],%02X[second] ",13,10,0
SL15:	.byte	"Rxinfo",0
SL16:	.byte	"Total byte : %d, Packet count : %d, window count : %d, rema"
	.byte	"ind packet : %d, m_nLnWkWaySideOnRxOk : %d, m_bLnWkFtpEndFl"
	.byte	"ag : %d, Historical start time : %08XH ",13,10,0
SL17:	.byte	"LnWayClr",0
SL18:	.byte	"'m_nLnWkWaySideOnRxOk' Clear OK ",13,10,0
SL19:	.byte	"LnFtpClr",0
SL20:	.byte	"'m_bLnWkFtpEndFlag' Clear OK ",13,10,0
SL21:	.byte	"HisStTm",0
SL22:	.byte	"Date&Time : 20%02X[year],%02X[month],%02X[day],%02X[hour],%"
	.byte	"02X[minute],%02X[second], Setting OK ",13,10,0
SL23:	.byte	"No format ",13,10,0
SL24:	.byte	"ViewCarNo",0
SL25:	.byte	"Car number 0 : %d, Car number 1 : %d ",13,10,0
SL26:	.byte	"CarNoClr",0
SL27:	.byte	"Car number clear OK ",13,10,0
SL28:	.byte	"WaySideON",0
SL29:	.byte	"m_nCDT_FaultDataStFlag  = %d ",13,10,0
SL30:	.byte	"COMMST",0
SL31:	.byte	"COMMST  %02X-%02X-%02X-%02X ",13,10,0
SL32:	.byte	"COMMST Syntax error",13,10,0
SL33:	.byte	"TrainConf",0
SL34:	.byte	"TrainConf Val = %02X ",13,10,0
SL35:	.byte	"TrainConf Syntax error",13,10,0
SL36:	.byte	"CiPosi",0
SL37:	.byte	"CiPosi Val = %02X ",13,10,0
SL38:	.byte	"CiPosi Syntax error",13,10,0
SL39:	.byte	"CiFault",0
SL40:	.byte	"CiFault Val = %02X ",13,10,0
SL41:	.byte	"CiFault Syntax error",13,10,0
SL42:	.byte	"DIAdd",0
SL43:	.byte	"DIAdd Val = %02X ",13,10,0
SL44:	.byte	"DIAdd Syntax error",13,10,0
SL45:	.byte	"VerSet",0
SL46:	.byte	":",0
SL47:	.byte	"VerSet Syntax error",13,10,0
SL48:	.byte	"?",0
SL49:	.byte	"[ENTER]      : Move next line after out '->' ",13,10,0
SL50:	.byte	"'?'          : Help ",13,10,0
SL51:	.byte	"'T'          : Date&time setting , 'TYYMMDDHHMNSS', 'EX)T10"
	.byte	"0312154200' ",13,10,0
SL52:	.byte	"'t'          : Date&time read ",13,10,0
SL53:	.byte	"'V'          : Version ",13,10,0
SL54:	.byte	"'Recent'     : Recently faults start ",13,10,0
SL55:	.byte	"'Historical' : Historical data start ",13,10,0
SL56:	.byte	"'Rxinfo'     : Recieve info ",13,10,0
SL57:	.byte	"'LnWayClr'   : 'm_nLnWkWaySideOnRxOk' variable clear ",13,10
	.byte	0
SL58:	.byte	"'LnFtpClr'   : 'm_bLnWkFtpEndFlag' variable clear ",13,10,0
SL59:	.byte	"'HisStTm'    : Historical data start time set(2000/1/1 0:0:"
	.byte	"0 ~ total second), HisStTmxxxxxxxx, 'EX)HisStTm0000000F' ",13
	.byte	10,0
SL60:	.byte	"'ViewCarNo'  : View car number ",13,10,0
SL61:	.byte	"'CarNoClr'   : Car number clear ",13,10,0
SL62:	.byte	"'TrainConf'  : Train Configuration. TrainConfx(x : 1~2) ",13
	.byte	10,0
SL63:	.byte	"'CiPosi'     : C_I Index Position. CiPosixx 'EX)CiPosi00' ",13
	.byte	10,0
SL64:	.byte	"'CiFault'    : Other C/I Fault. CiFaultxx :  'EX)CiFault01'"
	.byte	" ",13,10,0
SL65:	.byte	"'DIAdd'      : DI_Address_A/B  DIAdd1x(x : 1~2) 'EX)DIAdd1'"
	.byte	" ",13,10,0
SL66:	.byte	"'WaySideON'  : WaySide_ON ",13,10,0
SL67:	.byte	"'COMMST'     : Comm Status. COMMST=XXXXXXXX  'EX) COMMST=FF"
	.byte	"7F1F53' ",13,10,0
SL68:	.byte	"'VerSet'     : Unit Ver Set. VerSet=XX(incdex):XXXX(Ver):XX"
	.byte	"XXXX(BuildDate) ",13,10,0
SL69:	.byte	"Syntax error",13,10,0
SL70:	.byte	"%02X ",0
SL71:	.byte	"[TX:%02d] ",0
SL72:	.byte	"[%d,%3d,%c]",0
SL73:	.byte	"%02X",0
SL74:	.byte	"..",0
SL75:	.byte	"***FTP File receive... ^^;;***",13,10,0
SL76:	.byte	"***FTP File receive End ^..^ ***",13,10,0
SL77:	.byte	"[RX:%02d] ",0
SL78:	.byte	"LW_TRAIN_CONFIG Recive OK ",13,10,0
SL79:	.byte	"LW_CI_POSITION Recive OK ",13,10,0
SL80:	.byte	"LW_CI_FAULT Recive OK ",13,10,0
;******************************************************************************
;* CONSTANT TABLE                                                             *
;******************************************************************************
	.sect	".const"
	.bss	CL1,1
	.bss	CL2,1
	.bss	CL3,1
	.bss	CL4,1
	.bss	CL5,1
	.bss	CL6,1
	.bss	CL7,1
	.bss	CL8,1
	.bss	CL9,1
	.bss	CL10,1
	.bss	CL11,1
	.bss	CL12,1
	.bss	CL13,1
	.bss	CL14,1
	.bss	CL15,1
	.bss	CL16,1
	.bss	CL17,1
	.bss	CL18,1
	.bss	CL19,1
	.bss	CL20,1
	.bss	CL21,1
	.bss	CL22,1
	.bss	CL23,1
	.bss	CL24,1
	.bss	CL25,1
	.bss	CL26,1
	.bss	CL27,1
	.bss	CL28,1
	.bss	CL29,1
	.bss	CL30,1
	.bss	CL31,1
	.bss	CL32,1
	.bss	CL33,1
	.bss	CL34,1
	.bss	CL35,1
	.bss	CL36,1
	.bss	CL37,1
	.bss	CL38,1
	.bss	CL39,1
	.bss	CL40,1
	.bss	CL41,1
	.bss	CL42,1
	.bss	CL43,1
	.bss	CL44,1
	.bss	CL45,1
	.bss	CL46,1
	.bss	CL47,1
	.bss	CL48,1
	.bss	CL49,1
	.bss	CL50,1
	.bss	CL51,1
	.bss	CL52,1
	.bss	CL53,1
	.bss	CL54,1
	.bss	CL55,1
	.bss	CL56,1
	.bss	CL57,1
	.bss	CL58,1
	.bss	CL59,1
	.bss	CL60,1
	.bss	CL61,1
	.bss	CL62,1
	.bss	CL63,1
	.bss	CL64,1
	.bss	CL65,1
	.bss	CL66,1
	.bss	CL67,1
	.bss	CL68,1
	.bss	CL69,1
	.bss	CL70,1
	.bss	CL71,1
	.bss	CL72,1
	.bss	CL73,1
	.bss	CL74,1
	.bss	CL75,1
	.bss	CL76,1
	.bss	CL77,1
	.bss	CL78,1
	.bss	CL79,1
	.bss	CL80,1
	.bss	CL81,1
	.bss	CL82,1
	.bss	CL83,1
	.bss	CL84,1
	.bss	CL85,1
	.bss	CL86,1
	.bss	CL87,1
	.bss	CL88,1
	.bss	CL89,1
	.bss	CL90,1
	.bss	CL91,1
	.bss	CL92,1
	.bss	CL93,1
	.bss	CL94,1
	.bss	CL95,1
	.bss	CL96,1
	.bss	CL97,1
	.bss	CL98,1
	.bss	CL99,1
	.bss	CL100,1
	.bss	CL101,1
	.bss	CL102,1
	.bss	CL103,1
	.bss	CL104,1
	.bss	CL105,1
	.bss	CL106,1
	.bss	CL107,1
	.bss	CL108,1
	.bss	CL109,1
	.bss	CL110,1
	.bss	CL111,1
	.bss	CL112,1
	.bss	CL113,1

	.sect	".cinit"
	.field  	113,32
	.field  	CL1+0,32
	.field  	11534336,32
	.field  	16776716,32
	.field  	_m_btCommSt,32
	.field  	_m_btExVersionTbl,32
	.field  	_m_btExVersion_DAYTbl,32
	.field  	65535,32
	.field  	100000,32
	.field  	536870912,32
	.field  	SL1,32
	.field  	16777215,32
	.field  	11534336,32
	.field  	_btRxBuf$3,32
	.field  	SL2,32
	.field  	SL3,32
	.field  	_m_tmUtcTime,32
	.field  	_m_tmCurTime,32
	.field  	100000,32
	.field  	SL4,32
	.field  	SL5,32
	.field  	SL6,32
	.field  	SL7,32
	.field  	SL8,32
	.field  	_LIC_VerList,32
	.field  	SL9,32
	.field  	SL10,32
	.field  	SL11,32
	.field  	SL12,32
	.field  	SL13,32
	.field  	SL14,32
	.field  	SL15,32
	.field  	SL16,32
	.field  	SL17,32
	.field  	SL18,32
	.field  	SL19,32
	.field  	SL20,32
	.field  	SL21,32
	.field  	SL22,32
	.field  	SL23,32
	.field  	SL24,32
	.field  	SL25,32
	.field  	SL26,32
	.field  	SL27,32
	.field  	SL28,32
	.field  	SL29,32
	.field  	SL30,32
	.field  	_btRxBuf$3+7,32
	.field  	SL31,32
	.field  	SL32,32
	.field  	SL33,32
	.field  	SL34,32
	.field  	SL35,32
	.field  	SL36,32
	.field  	SL37,32
	.field  	SL38,32
	.field  	SL39,32
	.field  	SL40,32
	.field  	SL41,32
	.field  	SL42,32
	.field  	SL43,32
	.field  	SL44,32
	.field  	SL45,32
	.field  	SL46,32
	.field  	SL47,32
	.field  	SL48,32
	.field  	SL49,32
	.field  	SL50,32
	.field  	SL51,32
	.field  	SL52,32
	.field  	SL53,32
	.field  	SL54,32
	.field  	SL55,32
	.field  	SL56,32
	.field  	SL57,32
	.field  	SL58,32
	.field  	SL59,32
	.field  	SL60,32
	.field  	SL61,32
	.field  	SL62,32
	.field  	SL63,32
	.field  	SL64,32
	.field  	SL65,32
	.field  	SL66,32
	.field  	SL67,32
	.field  	SL68,32
	.field  	SL69,32
	.field  	_m_bExVersionEnableTbl,32
	.field  	12582912,32
	.field  	SL70,32
	.field  	-1,32
	.field  	SL71,32
	.field  	_btFtpOneRecRxBuf$6,32
	.field  	SL72,32
	.field  	SL73,32
	.field  	SL74,32
	.field  	SL75,32
	.field  	SL76,32
	.field  	SL77,32
	.field  	_d_TimeTxBuf,32
	.field  	SL78,32
	.field  	SL79,32
	.field  	SL80,32
	.field  	SW0,32
	.field  	_d_LonTxDataBuf,32
	.field  	10485760,32
	.field  	_btRx2chBuf$9,32
	.field  	12582912,32
	.field  	-25,32
	.field  	_btTx2chBuf$10,32
	.field  	_m_tFaultInfo,32
	.field  	_btRx3chBuf$14,32
	.field  	_d_RxUnitStBuf,32
	.field  	-30,32
	.field  	SW1,32

	.sect	".text"
;******************************************************************************
;* UNDEFINED EXTERNAL REFERENCES                                              *
;******************************************************************************

	.global	_memset

	.global	_strcat

	.global	_strcmp

	.global	_strlen

	.global	_strncpy

	.global	_IsNumAsc

	.global	_ConvHex2Asc

	.global	_ConvAsc2Hex

	.global	_GetFirmwareVersion

	.global	_Make1ByteBcc

	.global	_gm_SysTimeToRtc

	.global	_FunConvAscHex

	.global	_FunConvHexAsc

	.global	_crc16_ccitt

	.global	_xr16l784_GetRxBuffer1Ch

	.global	_xr16l784_GetRxBuffer2Ch

	.global	_xr16l784_GetRxBuffer3Ch

	.global	_xr16l784_Send

	.global	_xr16l784_RtsDelayStartSend
	.global	MOD_I30
	.global	DIV_I30
	.global	_sprintf
	.global	_memcpy
	.global	_ConvDec2Hex
	.global	DIV_U30
	.global	MOD_U30
