#pragma once

#define		PAGE_ID_HOME		0
#define		PAGE_ID_TRAIN		1
#define		PAGE_ID_CREW		2
#define		PAGE_ID_ROUTE		3
#define		PAGE_ID_CONFIG		4
#define		PAGE_ID_CHECK		5
#define		PAGE_ID_HELP		6
#define		PAGE_ID_PEI			7
#define		PAGE_ID_CM			8
#define		PAGE_ID_CI			9
#define		PAGE_ID_PASSWORD_CHECK	10
#define		PAGE_ID_PASSWORD_NEW	11
#define		PAGE_ID_PASSWORD_VOL	12
#define		PAGE_ID_PASSWORD_CI	13

// CMgrPage ���� ����Դϴ�.

class CPageManager : public CObject
{
private:
	CMap <UINT, UINT&, CDialog*, CDialog*> m_mapPage;

	UINT	m_nCurrentPage;

public:
	UINT	GetCurrentPage();
	void	AddPage(int nPageIndex, CDialog *pPage);
	bool	ShowPage(int nPageIndex);

	CPageManager();
	virtual ~CPageManager();

};


